import React from 'react';
import { LocationView } from './LocationView';
import { X, MapPin } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({ isOpen, onClose }) => {
  const { t, lang } = useApp();
  const isRtl = lang === 'ar';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-5xl w-full max-h-[92vh] overflow-y-auto p-4 sm:p-6 space-y-4 my-auto animate-in zoom-in-95 duration-200"
        dir={isRtl ? 'rtl' : 'ltr'}
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 text-base sm:text-lg">
                {t.location.title}
              </h2>
              <p className="text-xs text-slate-500">
                {lang === 'ar' ? 'أبواب مراكش، المنطقة 10، السكن المتوسط | إقامة المرجان - مراكش' : 'Abouab Marrakech, Zone 10, Logement Moyen Standing | Résidence Al Morjane - Marrakech'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors cursor-pointer"
            title={t.common.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <LocationView isModal onCloseModal={onClose} />
      </div>
    </div>
  );
};
