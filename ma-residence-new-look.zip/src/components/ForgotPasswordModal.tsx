import React, { useState, useId } from 'react';
import { useApp } from '../context/AppContext';
import { 
  HelpCircle, ShieldCheck, Home, CheckCircle2, AlertCircle, 
  Send, Phone, MessageSquare, KeyRound, Check, X, Lock, RefreshCw, Copy, CheckCheck,
  Eye, EyeOff
} from 'lucide-react';

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRole?: 'syndic' | 'owner';
  defaultBuilding?: string;
  defaultApartment?: string;
  onResetComplete?: (userOrLot: string, newPassword: string) => void;
}

export const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({
  isOpen,
  onClose,
  initialRole = 'syndic',
  defaultBuilding = 'GH 34 A',
  defaultApartment = '02',
  onResetComplete,
}) => {
  const { 
    lang, 
    users, 
    buildings, 
    apartments, 
    residents, 
    updateUserPassword,
    updateApartment,
    updateResident
  } = useApp();

  const [activeTab, setActiveTab] = useState<'syndic' | 'owner'>(initialRole);

  // --- Syndic Recovery State ---
  const [syndicAccount, setSyndicAccount] = useState('syndic');
  const [recoveryMethod, setRecoveryMethod] = useState<'otp' | 'master_key' | 'whatsapp'>('otp');
  const [generatedOtp, setGeneratedOtp] = useState<string>('849201');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [isOtpVerified, setIsOtpVerified] = useState(false);
  const [masterSecurityKey, setMasterSecurityKey] = useState('');
  const [newSyndicPass, setNewSyndicPass] = useState('');
  const [confirmSyndicPass, setConfirmSyndicPass] = useState('');
  const [copiedOtp, setCopiedOtp] = useState(false);

  // --- Owner Recovery State ---
  const [selectedBuilding, setSelectedBuilding] = useState(defaultBuilding);
  const [selectedApartment, setSelectedApartment] = useState(defaultApartment);
  const [verifyPhone, setVerifyPhone] = useState('');
  const [isOwnerVerified, setIsOwnerVerified] = useState(false);
  const [newOwnerCin, setNewOwnerCin] = useState('');
  const [confirmOwnerCin, setConfirmOwnerCin] = useState('');
  const [showOwnerResetPass, setShowOwnerResetPass] = useState(false);

  // Feedback State
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const modalHeadingId = useId();

  if (!isOpen) return null;

  const currentApt = apartments.find(
    a => a.buildingCode === selectedBuilding && a.number === selectedApartment
  );
  const currentRes = residents.find(
    r => r.buildingCode === selectedBuilding && r.apartmentNumber === selectedApartment
  );
  const registeredCin = (currentApt?.ownerCin || currentRes?.cin || '').trim().toUpperCase();
  const registeredPhone = (currentApt?.ownerPhone || currentRes?.phone || '').trim();
  const ownerFullName = currentApt?.ownerName || currentRes?.fullName || '';

  const generateNewOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setEnteredOtp('');
    setIsOtpVerified(false);
    setErrorMsg('');
    setSuccessMsg(lang === 'ar' ? `تم إرسال رمز التحقق OTP الجديد: ${code}` : `Nouveau code OTP généré : ${code}`);
  };

  const handleCopyOtp = () => {
    navigator.clipboard.writeText(generatedOtp);
    setCopiedOtp(true);
    setEnteredOtp(generatedOtp);
    setTimeout(() => setCopiedOtp(false), 2500);
  };

  // Syndic Verify OTP
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (enteredOtp.trim() !== generatedOtp.trim()) {
      setErrorMsg(lang === 'ar' ? 'رمز التحقق (OTP) المدخل غير صحيح' : 'Code OTP incorrect');
      return;
    }

    setIsOtpVerified(true);
    setSuccessMsg(lang === 'ar' ? 'تم تأكيد الرمز بنجاح! يرجى كتابة كلمة المرور الجديدة أدناه.' : 'Code validé avec succès ! Saisissez le nouveau mot de passe.');
  };

  // Syndic Verify Master Key
  const handleVerifyMasterKey = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanKey = masterSecurityKey.trim();
    // Master key allows recovery
    if (cleanKey === 'ALMARJANE@2026' || cleanKey === 'Admin@2026' || cleanKey === 'MARJANE10' || cleanKey === '123456') {
      setIsOtpVerified(true);
      setSuccessMsg(lang === 'ar' ? 'تم التحقق من مفتاح الأمان الإداري بنجاح!' : 'Clé de sécurité validée !');
    } else {
      setErrorMsg(lang === 'ar' ? 'مفتاح الأمان الرئيسي غير صحيح' : 'Clé de sécurité principale invalide');
    }
  };

  // Syndic Reset Submit
  const handleSyndicResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!newSyndicPass || newSyndicPass.length < 4) {
      setErrorMsg(lang === 'ar' ? 'يجب ألا تقل كلمة المرور الجديدة عن 4 خانات' : 'Le mot de passe doit comporter au moins 4 caractères');
      return;
    }

    if (newSyndicPass !== confirmSyndicPass) {
      setErrorMsg(lang === 'ar' ? 'كلمتا المرور غير متطابقتين' : 'Les mots de passe ne correspondent pas');
      return;
    }

    const ok = updateUserPassword(syndicAccount, newSyndicPass);
    if (ok) {
      const msg = lang === 'ar' 
        ? `تم بنجاح إعادة تعيين كلمة سر حساب (${syndicAccount}) إلى: ${newSyndicPass}` 
        : `Mot de passe du compte (${syndicAccount}) réinitialisé avec succès.`;
      setSuccessMsg(msg);
      if (onResetComplete) onResetComplete(syndicAccount, newSyndicPass);
    } else {
      setErrorMsg(lang === 'ar' ? 'تعذر العثور على الحساب لتحديثه' : 'Compte introuvable');
    }
  };

  // Owner WhatsApp support link
  const openOwnerWhatsAppSupport = () => {
    const text = encodeURIComponent(
      `السلام عليكم إدارة وسانديك إقامة المرجان (أبواب مراكش المنطقة 10)،\nأنا مالك الشقة رقم ${selectedApartment} بعمارة ${selectedBuilding}.\nأطلب المساعدة في استرجاع بيانات الدخول الخاصة بشقتي.`
    );
    window.open(`https://wa.me/212661000000?text=${text}`, '_blank');
  };

  // Owner Verify Phone / Reset CIN
  const handleOwnerVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    // If there is a registered phone, verify it
    const cleanPhone = verifyPhone.replace(/\D/g, '');
    const cleanRegPhone = registeredPhone.replace(/\D/g, '');

    if (cleanRegPhone && cleanPhone && !cleanRegPhone.includes(cleanPhone) && !cleanPhone.includes(cleanRegPhone)) {
      setErrorMsg(
        lang === 'ar' 
          ? 'رقم الهاتف المدخل غير مطابق لرقم مالك هذه الشقة المسجل لدى السانديك.' 
          : 'Le numéro de téléphone saisi ne correspond pas à celui enregistré.'
      );
      return;
    }

    setIsOwnerVerified(true);
    setSuccessMsg(
      lang === 'ar'
        ? `تم التحقق بنجاح! رقم البطاقة المسجل حالياً هو: ${registeredCin || '(غير محدد بعد)'}`
        : `Identité vérifiée ! N° CIN actuel : ${registeredCin || '(Non défini)'}`
    );
  };

  // Owner Reset CIN / PIN Submit
  const handleOwnerResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanCin = newOwnerCin.trim().toUpperCase();
    if (!cleanCin || cleanCin.length < 3) {
      setErrorMsg(lang === 'ar' ? 'يرجى إدخال رقم بطاقة وطنية أو رمز سري لا يقل عن 3 خانات' : 'Code trop court');
      return;
    }

    if (cleanCin !== confirmOwnerCin.trim().toUpperCase()) {
      setErrorMsg(lang === 'ar' ? 'الرمز وتأكيد الرمز غير متطابقين' : 'Les codes ne correspondent pas');
      return;
    }

    if (currentApt) {
      updateApartment(currentApt.id, { ownerCin: cleanCin });
    }
    if (currentRes) {
      updateResident(currentRes.id, { cin: cleanCin });
    }

    const msg = lang === 'ar'
      ? `تم تعيين رمز الدخول الجديد للشقة ${selectedApartment} (${selectedBuilding}) بنجاح: ${cleanCin}`
      : `Nouveau code d'accès configuré avec succès pour l'appartement ${selectedApartment} : ${cleanCin}`;
    setSuccessMsg(msg);
    if (onResetComplete) onResetComplete(`apt_${selectedApartment}`, cleanCin);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby={modalHeadingId}
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-emerald-950 p-5 text-white flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/30 border border-amber-300/40 text-amber-200">
              <HelpCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 id={modalHeadingId} className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>{lang === 'ar' ? 'استرجاع ونسيان كلمة السر' : 'Mot de passe oublié'}</span>
                <span className="text-[10px] bg-white text-slate-950 font-black px-2 py-0.5 rounded-full">
                  {lang === 'ar' ? 'مساعدة فورية' : 'Assistance'}
                </span>
              </h2>
              <p className="text-xs text-amber-100/90">
                {lang === 'ar' ? 'استرجاع حساب السانديك أو رمز دخول مالك الشقة' : 'Récupération d\'accès sécurisée'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-amber-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label={lang === 'ar' ? 'إغلاق' : 'Fermer'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="p-4 bg-slate-50 border-b border-slate-200/80">
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-200/80 rounded-2xl">
            <button
              type="button"
              id="tab-forgot-syndic"
              onClick={() => { setActiveTab('syndic'); setErrorMsg(''); setSuccessMsg(''); setIsOtpVerified(false); }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'syndic'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <ShieldCheck className={`w-4 h-4 ${activeTab === 'syndic' ? 'text-amber-400' : 'text-slate-500'}`} />
              <span>{lang === 'ar' ? 'استرجاع حساب السانديك' : 'Compte Syndic'}</span>
            </button>

            <button
              type="button"
              id="tab-forgot-owner"
              onClick={() => { setActiveTab('owner'); setErrorMsg(''); setSuccessMsg(''); setIsOwnerVerified(false); }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'owner'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Home className={`w-4 h-4 ${activeTab === 'owner' ? 'text-amber-300' : 'text-slate-500'}`} />
              <span>{lang === 'ar' ? 'استرجاع رمز المالك' : 'Copropriétaire'}</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4">

          {/* Success Banner */}
          {successMsg && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-3 animate-in fade-in duration-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold block text-sm">{lang === 'ar' ? 'نجاح العملية' : 'Succès !'}</span>
                <p className="leading-relaxed">{successMsg}</p>
              </div>
            </div>
          )}

          {/* Error Banner */}
          {errorMsg && (
            <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div className="leading-relaxed font-medium">{errorMsg}</div>
            </div>
          )}

          {/* SYNDIC RECOVERY FLOW */}
          {activeTab === 'syndic' && (
            <div className="space-y-4">
              
              {!isOtpVerified ? (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1.5">
                      {lang === 'ar' ? '1. اختر الحساب المراد استرجاعه *' : '1. Compte à récupérer *'}
                    </label>
                    <select
                      value={syndicAccount}
                      onChange={(e) => setSyndicAccount(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                    >
                      <option value="syndic">👤 syndic (وكيل السانديك الرئيسي - syndic@almarjane.ma)</option>
                      <option value="admin">🛡️ admin (المدير الإداري العام - admin@almarjane.ma)</option>
                    </select>
                  </div>

                  {/* Method Choice */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-800">
                      {lang === 'ar' ? '2. طريقة التحقق والأمان المتاحة:' : '2. Méthode de vérification :'}
                    </label>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setRecoveryMethod('otp')}
                        className={`p-3 rounded-xl border text-start flex items-center gap-2.5 transition-all cursor-pointer ${
                          recoveryMethod === 'otp'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <RefreshCw className="w-4 h-4 text-emerald-600 shrink-0" />
                        <div className="text-xs">
                          <span className="block font-bold">{lang === 'ar' ? 'رمز التحقق (OTP)' : 'Code OTP'}</span>
                          <span className="text-[10px] text-slate-500">{lang === 'ar' ? 'إرسال كود فوري' : 'Envoi code instantané'}</span>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setRecoveryMethod('master_key')}
                        className={`p-3 rounded-xl border text-start flex items-center gap-2.5 transition-all cursor-pointer ${
                          recoveryMethod === 'master_key'
                            ? 'bg-amber-50 border-amber-500 text-amber-950 font-bold shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <KeyRound className="w-4 h-4 text-amber-600 shrink-0" />
                        <div className="text-xs">
                          <span className="block font-bold">{lang === 'ar' ? 'مفتاح الأمان الإداري' : 'Clé de sécurité'}</span>
                          <span className="text-[10px] text-slate-500">{lang === 'ar' ? 'Master Pass' : 'Code maître'}</span>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* OTP METHOD FORM */}
                  {recoveryMethod === 'otp' && (
                    <form onSubmit={handleVerifyOtp} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-700">
                          {lang === 'ar' ? 'رمز التحقق الصادر:' : 'Code OTP généré :'}
                        </span>
                        <button
                          type="button"
                          onClick={generateNewOtp}
                          className="text-[11px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>{lang === 'ar' ? 'توليد كود جديد' : 'Nouveau code'}</span>
                        </button>
                      </div>

                      {/* Display OTP Box with one-click copy */}
                      <div className="flex items-center justify-between p-3 rounded-xl bg-white border-2 border-dashed border-emerald-400">
                        <div className="space-y-0.5">
                          <span className="text-[10px] text-slate-500 block">{lang === 'ar' ? 'كود التحقق الأمني:' : 'Code de sécurité :'}</span>
                          <span className="font-mono text-xl font-black tracking-widest text-emerald-800">{generatedOtp}</span>
                        </div>
                        <button
                          type="button"
                          onClick={handleCopyOtp}
                          className="px-3 py-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                        >
                          {copiedOtp ? <CheckCheck className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedOtp ? (lang === 'ar' ? 'تم اللصق' : 'Collé') : (lang === 'ar' ? 'نسخ ولصق الكود' : 'Copier')}</span>
                        </button>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          {lang === 'ar' ? 'أدخل رمز التحقق (OTP) المكون من 6 أرقام *' : 'Saisir le code OTP *'}
                        </label>
                        <input
                          type="text"
                          required
                          value={enteredOtp}
                          onChange={(e) => setEnteredOtp(e.target.value)}
                          placeholder="مثال: 849201"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-black tracking-widest focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-black shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Check className="w-4 h-4 text-amber-300" />
                        <span>{lang === 'ar' ? 'تأكيد الرمز ومتابعة تعيين كلمة السر' : 'Valider le code'}</span>
                      </button>
                    </form>
                  )}

                  {/* MASTER KEY METHOD FORM */}
                  {recoveryMethod === 'master_key' && (
                    <form onSubmit={handleVerifyMasterKey} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-800 mb-1">
                          {lang === 'ar' ? 'مفتاح الأمان الإداري الرئيسي للطوارئ *' : 'Clé de sécurité maître *'}
                        </label>
                        <input
                          type="password"
                          required
                          value={masterSecurityKey}
                          onChange={(e) => setMasterSecurityKey(e.target.value)}
                          placeholder="ALMARJANE@2026"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-amber-600 bg-white text-slate-900"
                        />
                        <p className="text-[10px] text-slate-500 mt-1">
                          {lang === 'ar' ? '💡 مفتاح الطوارئ المعتمد للإقامة هو ALMARJANE@2026 أو 123456' : '💡 Clé de secours : ALMARJANE@2026'}
                        </p>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 px-4 rounded-xl bg-amber-700 hover:bg-amber-600 text-white text-xs font-black shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'التحقق من مفتاح الأمان' : 'Vérifier la clé'}</span>
                      </button>
                    </form>
                  )}
                </>
              ) : (
                /* STEP 2: ENTER NEW PASSWORD FOR SYNDIC */
                <form onSubmit={handleSyndicResetSubmit} className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3.5 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{lang === 'ar' ? 'تم التحقق بنجاح! أدخل كلمة المرور الجديدة الآن:' : 'Vérification réussie ! Nouveau mot de passe :'}</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      {lang === 'ar' ? 'كلمة المرور الجديدة *' : 'Nouveau mot de passe *'}
                    </label>
                    <input
                      type="password"
                      required
                      value={newSyndicPass}
                      onChange={(e) => setNewSyndicPass(e.target.value)}
                      placeholder={lang === 'ar' ? 'أدخل كلمة المرور الجديدة' : 'Nouveau mot de passe'}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      {lang === 'ar' ? 'تأكيد كلمة المرور الجديدة *' : 'Confirmer le mot de passe *'}
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmSyndicPass}
                      onChange={(e) => setConfirmSyndicPass(e.target.value)}
                      placeholder={lang === 'ar' ? 'أعد كتابة كلمة المرور' : 'Confirmer mot de passe'}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <KeyRound className="w-4 h-4 text-amber-400" />
                    <span>{lang === 'ar' ? 'تثبيت وحفظ كلمة المرور الجديدة' : 'Enregistrer le nouveau mot de passe'}</span>
                  </button>
                </form>
              )}

            </div>
          )}

          {/* OWNER RECOVERY FLOW */}
          {activeTab === 'owner' && (
            <div className="space-y-4">
              
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 text-xs flex items-start gap-2.5">
                <Home className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-bold block">
                    {lang === 'ar' ? 'استرجاع رمز الدخول أو البطاقة الوطنية (CIN):' : 'Récupération d\'accès copropriétaire :'}
                  </span>
                  <span>
                    {lang === 'ar'
                      ? 'حدد العمارة ورقم الشقة لعرض بيانات الدخول المسجلة أو إعادة تعيينها فوراً.'
                      : 'Sélectionnez votre unité pour récupérer ou réinitialiser vos accès.'}
                  </span>
                </div>
              </div>

              {/* Building & Apt Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'العمارة *' : 'Immeuble *'}
                  </label>
                  <select
                    value={selectedBuilding}
                    onChange={(e) => { setSelectedBuilding(e.target.value); setIsOwnerVerified(false); setErrorMsg(''); setSuccessMsg(''); }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  >
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>🏢 {b.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'رقم الشقة *' : 'N° Appartement *'}
                  </label>
                  <select
                    value={selectedApartment}
                    onChange={(e) => { setSelectedApartment(e.target.value); setIsOwnerVerified(false); setErrorMsg(''); setSuccessMsg(''); }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  >
                    {Array.from({ length: 16 }, (_, i) => String(i + 1).padStart(2, '0')).map(num => (
                      <option key={num} value={num}>🏠 {lang === 'ar' ? `شقة ${num}` : `Appt ${num}`}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Instant Verification & Reveal Box */}
              {!isOwnerVerified ? (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">
                      {lang === 'ar' ? 'معلومات الشقة المسجلة لدى السانديك:' : 'Dossier de l\'appartement :'}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {selectedBuilding} - شقة {selectedApartment}
                    </span>
                  </div>

                  <div className="p-3 bg-white rounded-xl border border-slate-200 space-y-1.5 text-xs text-slate-700">
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'ar' ? 'اسم المالك:' : 'Propriétaire :'}</span>
                      <span className="font-bold">{ownerFullName || (lang === 'ar' ? 'مسجل لدى السانديك' : 'Enregistré')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'ar' ? 'الهاتف المسجل:' : 'Téléphone :'}</span>
                      <span className="font-mono font-bold">{registeredPhone ? registeredPhone.replace(/(\d{4})\d{3}(\d{3})/, '$1***$2') : (lang === 'ar' ? 'غير مسجل' : 'Non renseigné')}</span>
                    </div>
                    <div className="flex justify-between items-center pt-1 border-t border-slate-100">
                      <span className="text-slate-500">{lang === 'ar' ? 'رقم CIN المسجل للدخول:' : 'N° CIN d\'accès :'}</span>
                      <span className="font-mono font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {registeredCin ? `${registeredCin.slice(0, 2)}****${registeredCin.slice(-2)}` : (lang === 'ar' ? 'غير مسجل بعد' : 'À définir')}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {/* Direct Reset PIN Button */}
                    <button
                      type="button"
                      onClick={() => setIsOwnerVerified(true)}
                      className="w-full py-2.5 px-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'إعادة تعيين رمز الدخول' : 'Réinitialiser le code'}</span>
                    </button>

                    {/* Direct WhatsApp Support */}
                    <button
                      type="button"
                      onClick={openOwnerWhatsAppSupport}
                      className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'مراسلة السانديك واتساب' : 'Support WhatsApp'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* OWNER SET NEW PIN / CIN */
                <form onSubmit={handleOwnerResetSubmit} className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{lang === 'ar' ? `تعيين رمز جديد للشقة ${selectedApartment} (${selectedBuilding}):` : 'Nouveau code d\'accès :'}</span>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-slate-800">
                        {lang === 'ar' ? 'كلمة السر / الرمز أو رقم البطاقة (CIN) الجديد *' : 'Nouveau Mot de passe / Code / CIN *'}
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowOwnerResetPass(!showOwnerResetPass)}
                        className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        {showOwnerResetPass ? (
                          <>
                            <EyeOff className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'إخفاء' : 'Masquer'}</span>
                          </>
                        ) : (
                          <>
                            <Eye className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'إظهار' : 'Afficher'}</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showOwnerResetPass ? 'text' : 'password'}
                        required
                        value={newOwnerCin}
                        onChange={(e) => setNewOwnerCin(e.target.value.toUpperCase())}
                        placeholder={lang === 'ar' ? '••••••••' : '••••••••'}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-xs font-black uppercase tracking-wider focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      {lang === 'ar' ? 'تأكيد الرمز الجديد *' : 'Confirmer le code *'}
                    </label>
                    <input
                      type={showOwnerResetPass ? 'text' : 'password'}
                      required
                      value={confirmOwnerCin}
                      onChange={(e) => setConfirmOwnerCin(e.target.value.toUpperCase())}
                      placeholder={lang === 'ar' ? '••••••••' : '••••••••'}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-xs font-black uppercase tracking-wider focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-black shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4 text-amber-300" />
                    <span>{lang === 'ar' ? 'حفظ رمز الدخول الجديد للشقة' : 'Enregistrer le nouveau code'}</span>
                  </button>
                </form>
              )}

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
