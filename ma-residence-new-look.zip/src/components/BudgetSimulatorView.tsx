import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { exportElementToPdf } from '../utils/monthlyPdfReportUtils';
import { 
  Calculator, TrendingUp, TrendingDown, DollarSign, PiggyBank, 
  Percent, AlertTriangle, CheckCircle2, Copy, Check, Printer, 
  FileDown, Share2, Sparkles, RefreshCw, Plus, Trash2, 
  ArrowUpRight, Shield, Building2, HelpCircle, Layers, 
  PieChart as PieChartIcon, Eye, Settings2, Info, ArrowRight,
  Sliders, FileText, CheckCircle, BarChart3, ChevronDown, ChevronUp
} from 'lucide-react';
import { 
  ResponsiveContainer, PieChart, Pie, Cell, Tooltip, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend 
} from 'recharts';
import { ProjectedExpenseItem, BudgetSimulationPlan, ExpenseCategory } from '../types';

const INITIAL_EXPENSE_TEMPLATES: Omit<ProjectedExpenseItem, 'id'>[] = [
  {
    category: 'security_company',
    nameAr: 'الحراسة والأمن والمراقبة',
    nameFr: 'Gardiennage & Sécurité',
    monthlyAmount: 14000,
    annualAmount: 168000,
    enabled: true,
    notes: 'أجور الحراس، كاميرات المراقبة وتأمين مداخل ومخارج الإقامة'
  },
  {
    category: 'cleaning_company',
    nameAr: 'النظافة ومواد التعقيم والغسيل',
    nameFr: 'Nettoyage & Hygiène des communs',
    monthlyAmount: 9000,
    annualAmount: 108000,
    enabled: true,
    notes: 'أجور عمال النظافة ومواد التطهير والأكياس'
  },
  {
    category: 'electricity',
    nameAr: 'فاتورة الكهرباء المشتركة (الإنارة والسلالم)',
    nameFr: 'Électricité des parties communes',
    monthlyAmount: 6500,
    annualAmount: 78000,
    enabled: true,
    notes: 'إنارة السلالم، المداخل، الساحات ومضخات المياه'
  },
  {
    category: 'water',
    nameAr: 'فاتورة الماء للمرافق المشتركة والري',
    nameFr: 'Eau & Arrosage des espaces verts',
    monthlyAmount: 1800,
    annualAmount: 21600,
    enabled: true,
    notes: 'سقي الحدائق وغسيل العمارات والساحات'
  },
  {
    category: 'emergency_repairs',
    nameAr: 'صيانة المصاعد والمراقبة التقنية',
    nameFr: 'Maintenance ascenseurs & Bureau de contrôle',
    monthlyAmount: 4200,
    annualAmount: 50400,
    enabled: true,
    notes: 'عقد الصيانة الوقائية مع الشركة وتغيير قطع الغيار'
  },
  {
    category: 'supplies',
    nameAr: 'صيانة محطة ضخ المياه والمحركات (Surpresseurs)',
    nameFr: 'Maintenance des pompes & Surpresseurs',
    monthlyAmount: 1500,
    annualAmount: 18000,
    enabled: true,
    notes: 'تأمين وصول الماء الصالح للشرب لكافة الطوابق العلوية'
  },
  {
    category: 'gardening' as any,
    nameAr: 'العناية بالحدائق والمساحات الخضراء',
    nameFr: 'Jardinage & Espaces verts',
    monthlyAmount: 2200,
    annualAmount: 26400,
    enabled: true,
    notes: 'أسمدة، تشذيب الأشجار، صيانة شبكة الري بالرش والتنقيط'
  },
  {
    category: 'electrical_supplies',
    nameAr: 'المواد الكهربائية، المصابيح وأجهزة الاستشعار',
    nameFr: 'Fournitures électriques & Éclairage LED',
    monthlyAmount: 1200,
    annualAmount: 14400,
    enabled: true,
    notes: 'استبدال المصابيح المحترقة ومفاتيح الإنارة التلقائية'
  },
  {
    category: 'hardware_droguerie',
    nameAr: 'العقاقير، الصباغة والإصلاحات البسيطة',
    nameFr: 'Droguerie, Quincaillerie & Réparations',
    monthlyAmount: 1800,
    annualAmount: 21600,
    enabled: true,
    notes: 'أقفال الأبواب، طلاء الجدران المشتركة، السباكة الخفيفة'
  },
  {
    category: 'office_stationery',
    nameAr: 'المصاريف الإدارية، المكتبيات والتسيير',
    nameFr: 'Frais de gestion, Papeterie & Frais bancaires',
    monthlyAmount: 1000,
    annualAmount: 12000,
    enabled: true,
    notes: 'طباعة التواصيل، الإشعارات، البريد والمصاريف البنكية'
  },
  {
    category: 'insurance' as any,
    nameAr: 'التأمين المتعدد المخاطر على العمارة (RC Copropriété)',
    nameFr: 'Assurance multirisque immeuble',
    monthlyAmount: 1200,
    annualAmount: 14400,
    enabled: true,
    notes: 'تغطية المسؤولية المدنية للأضرار وحرائق المرافق المشتركة'
  },
  {
    category: 'emergency_repairs',
    nameAr: 'مخصص الطوارئ والأعطاب الفجائية',
    nameFr: 'Imprévus & Dépannages d\'urgence',
    monthlyAmount: 2000,
    annualAmount: 24000,
    enabled: true,
    notes: 'تسربات المياه المفاجئة، أعطاب الأبواب الآلية'
  }
];

const COLORS = [
  '#0a8591', '#059669', '#0a8591', '#d97706', '#7c3aed', 
  '#0891b2', '#e11d48', '#4b5563', '#10b981', '#f59e0b', 
  '#6366f1', '#14b8a6', '#84cc16'
];

export const BudgetSimulatorView: React.FC = () => {
  const { 
    t, lang, apartments, expenses, buildings,
    showToast, setActiveSection 
  } = useApp();

  const isRtl = lang === 'ar';
  const currentYear = new Date().getFullYear();
  const defaultTargetYear = currentYear + 1;

  // Contributing Apartments count (excluding dedicated office if applicable)
  const defaultAptCount = useMemo(() => {
    const active = apartments.filter(a => !a.isSyndicOffice);
    return active.length > 0 ? active.length : (apartments.length > 0 ? apartments.length : 319);
  }, [apartments]);

  // Current average monthly fee from active apartments
  const defaultCurrentFee = useMemo(() => {
    const fees = apartments.map(a => Number(a.monthlyFee) || 150).filter(f => f > 0);
    if (fees.length === 0) return 150;
    const avg = Math.round(fees.reduce((a, b) => a + b, 0) / fees.length);
    return avg || 150;
  }, [apartments]);

  // State with LocalStorage initial restoration
  const [targetYear, setTargetYear] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.targetYear === 'number') return c.targetYear;
      }
    } catch (e) { console.error(e); }
    return defaultTargetYear;
  });

  const [apartmentsCount, setApartmentsCount] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.apartmentsCount === 'number') return c.apartmentsCount;
      }
    } catch (e) { console.error(e); }
    return defaultAptCount;
  });

  const [currentFeePerApt, setCurrentFeePerApt] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.currentFeePerApt === 'number') return c.currentFeePerApt;
      }
    } catch (e) { console.error(e); }
    return defaultCurrentFee;
  });

  const [reserveFundPercent, setReserveFundPercent] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.reserveFundPercent === 'number') return c.reserveFundPercent;
      }
    } catch (e) { console.error(e); }
    return 10; // 10% under Law 18-00
  });

  const [expectedCollectionRate, setExpectedCollectionRate] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.expectedCollectionRate === 'number') return c.expectedCollectionRate;
      }
    } catch (e) { console.error(e); }
    return 92; // 92% recovery
  });

  const [distributionMethod, setDistributionMethod] = useState<'equal' | 'by_area'>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (c.distributionMethod) return c.distributionMethod;
      }
    } catch (e) { console.error(e); }
    return 'equal';
  });

  const [activeScenario, setActiveScenario] = useState<'custom' | 'austerity' | 'balanced' | 'enhanced'>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (c.activeScenario) return c.activeScenario;
      }
    } catch (e) { console.error(e); }
    return 'balanced';
  });
  
  // Expenses Items list (LocalStorage backed)
  const [items, setItems] = useState<ProjectedExpenseItem[]>(() => {
    const saved = localStorage.getItem('budget_simulator_items');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return INITIAL_EXPENSE_TEMPLATES.map((tpl, idx) => ({
      ...tpl,
      id: 'proj-' + (idx + 1)
    }));
  });

  // New Item modal / form inline
  const [newItemNameAr, setNewItemNameAr] = useState('');
  const [newItemNameFr, setNewItemNameFr] = useState('');
  const [newItemMonthly, setNewItemMonthly] = useState<number>(1000);
  const [newItemNotes, setNewItemNotes] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // UI state
  const [copiedSuccess, setCopiedSuccess] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [inflationPercent, setInflationPercent] = useState<number>(() => {
    try {
      const raw = localStorage.getItem('budget_simulator_config');
      if (raw) {
        const c = JSON.parse(raw);
        if (typeof c.inflationPercent === 'number') return c.inflationPercent;
      }
    } catch (e) { console.error(e); }
    return 5;
  });

  // Auto-Save Status tracking
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving'>('saved');
  const [lastAutoSaveTime, setLastAutoSaveTime] = useState<string>('');

  // Auto-save items to local storage
  useEffect(() => {
    localStorage.setItem('budget_simulator_items', JSON.stringify(items));
  }, [items]);

  // Debounced Auto-save simulator configurations to local storage
  useEffect(() => {
    setAutoSaveStatus('saving');
    const timer = setTimeout(() => {
      try {
        const config = {
          targetYear,
          apartmentsCount,
          currentFeePerApt,
          reserveFundPercent,
          expectedCollectionRate,
          distributionMethod,
          activeScenario,
          inflationPercent,
          savedAt: new Date().toLocaleTimeString(isRtl ? 'ar-MA' : 'fr-FR', {
            hour: '2-digit', minute: '2-digit', second: '2-digit'
          })
        };
        localStorage.setItem('budget_simulator_config', JSON.stringify(config));
        setAutoSaveStatus('saved');
        setLastAutoSaveTime(config.savedAt);
      } catch (e) {
        console.error('Failed to auto-save budget simulator configuration:', e);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [
    targetYear, apartmentsCount, currentFeePerApt, reserveFundPercent,
    expectedCollectionRate, distributionMethod, activeScenario, inflationPercent, isRtl
  ]);

  // Toggle item enabled
  const handleToggleItem = (id: string) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, enabled: !item.enabled } : item));
    setActiveScenario('custom');
  };

  // Update item monthly amount
  const handleUpdateItemMonthly = (id: string, newMonthly: number) => {
    const val = Math.max(0, Number(newMonthly) || 0);
    setItems(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          monthlyAmount: val,
          annualAmount: val * 12
        };
      }
      return item;
    }));
    setActiveScenario('custom');
  };

  // Delete item
  const handleDeleteItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
    setActiveScenario('custom');
  };

  // Add custom item
  const handleAddCustomItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemNameAr.trim()) {
      showToast(lang === 'ar' ? 'يرجى إدخال اسم المصروف' : 'Veuillez saisir le nom de la dépense', { type: 'error' });
      return;
    }
    const val = Math.max(0, Number(newItemMonthly) || 0);
    const newItem: ProjectedExpenseItem = {
      id: 'custom-' + Date.now(),
      category: 'other',
      nameAr: newItemNameAr.trim(),
      nameFr: newItemNameFr.trim() || newItemNameAr.trim(),
      monthlyAmount: val,
      annualAmount: val * 12,
      enabled: true,
      isCustom: true,
      notes: newItemNotes.trim() || undefined
    };
    setItems(prev => [...prev, newItem]);
    setNewItemNameAr('');
    setNewItemNameFr('');
    setNewItemMonthly(1000);
    setNewItemNotes('');
    setShowAddForm(false);
    setActiveScenario('custom');
    showToast(lang === 'ar' ? 'تمت إضافة البند التقديري بنجاح' : 'Ligne prévisionnelle ajoutée avec succès', { type: 'success' });
  };

  // Apply Inflation Percentage to all active items
  const handleApplyInflation = (pct: number) => {
    const factor = 1 + (pct / 100);
    setItems(prev => prev.map(item => {
      const newMonthly = Math.round(item.monthlyAmount * factor);
      return {
        ...item,
        monthlyAmount: newMonthly,
        annualAmount: newMonthly * 12
      };
    }));
    setActiveScenario('custom');
    showToast(lang === 'ar' ? `تم تطبيق نسبة تعديل ${pct > 0 ? '+' : ''}${pct}% بنجاح` : `Ajustement de ${pct}% appliqué`, { type: 'success' });
  };

  // Reset to default templates
  const handleResetDefaults = () => {
    setItems(INITIAL_EXPENSE_TEMPLATES.map((tpl, idx) => ({
      ...tpl,
      id: 'proj-' + (idx + 1)
    })));
    setReserveFundPercent(10);
    setExpectedCollectionRate(92);
    setApartmentsCount(defaultAptCount);
    setCurrentFeePerApt(defaultCurrentFee);
    setActiveScenario('balanced');
    showToast(lang === 'ar' ? 'تمت استعادة القالب المرجعي الموصى به' : 'Modèle de référence restauré', { type: 'info' });
  };

  // Import baseline from actual expenses in the application
  const handleImportFromActualExpenses = () => {
    if (expenses.length === 0) {
      showToast(lang === 'ar' ? 'لا توجد مصاريف مسجلة حالياً للاستيراد منها' : 'Aucune dépense enregistrée à importer', { type: 'error' });
      return;
    }

    // Group actual expenses by category
    const categoryTotals: Record<string, number> = {};
    expenses.forEach(e => {
      const cat = e.category || 'other';
      categoryTotals[cat] = (categoryTotals[cat] || 0) + Number(e.amount || 0);
    });

    // Approximate annual projection based on existing expenses (if e.g. 6-12 months are recorded)
    const updated = items.map(item => {
      const actualCatSum = categoryTotals[item.category];
      if (actualCatSum && actualCatSum > 0) {
        // assume actual expense represents ~6 to 12 months, or take average
        const annualEstimate = Math.round(actualCatSum > 50000 ? actualCatSum : actualCatSum * 1.5);
        const monthlyEstimate = Math.round(annualEstimate / 12);
        return {
          ...item,
          monthlyAmount: monthlyEstimate,
          annualAmount: annualEstimate,
          notes: `${item.notes || ''} (مستند للمصاريف الفعلية: ${actualCatSum.toLocaleString()} درهم)`
        };
      }
      return item;
    });

    setItems(updated);
    setActiveScenario('custom');
    showToast(lang === 'ar' ? 'تم تحديث التقديرات استناداً للمصاريف الفعلية المسجلة!' : 'Estimations synchronisées avec les dépenses réelles !', { type: 'success' });
  };

  // Apply Predefined Scenarios
  const handleSelectScenario = (sc: 'austerity' | 'balanced' | 'enhanced') => {
    setActiveScenario(sc);
    if (sc === 'austerity') {
      // Minimum operations, 0% reserve fund
      setReserveFundPercent(0);
      setExpectedCollectionRate(95);
      setItems(prev => prev.map(item => {
        // reduce non-essentials
        if (item.category === ('gardening' as any) || item.nameAr.includes('طوارئ') || item.nameAr.includes('عقاقير')) {
          const reduced = Math.round(item.monthlyAmount * 0.65);
          return { ...item, monthlyAmount: reduced, annualAmount: reduced * 12 };
        }
        return item;
      }));
    } else if (sc === 'balanced') {
      // Recommended: 10% reserve fund, normal baseline
      handleResetDefaults();
      setActiveScenario('balanced');
    } else if (sc === 'enhanced') {
      // Enhanced: 15% reserve fund, extra maintenance, high quality
      setReserveFundPercent(15);
      setExpectedCollectionRate(90);
      setItems(prev => prev.map(item => {
        const boosted = Math.round(item.monthlyAmount * 1.12);
        return { ...item, monthlyAmount: boosted, annualAmount: boosted * 12 };
      }));
    }
  };

  // COMPUTATIONS:
  const calculations = useMemo(() => {
    // 1. Total Routine Operational Expenses
    const activeItems = items.filter(i => i.enabled);
    const routineMonthly = activeItems.reduce((sum, item) => sum + (Number(item.monthlyAmount) || 0), 0);
    const routineAnnual = routineMonthly * 12;

    // 2. Reserve Fund (Fonds de réserve Loi 18-00)
    const reserveFundAnnual = Math.round(routineAnnual * (reserveFundPercent / 100));
    const reserveFundMonthly = Math.round(reserveFundAnnual / 12);

    // 3. Total Annual & Monthly Budget Needed
    const totalAnnualBudget = routineAnnual + reserveFundAnnual;
    const totalMonthlyBudget = routineMonthly + reserveFundMonthly;

    // 4. Monthly Fee Per Apartment (100% collection rate)
    const count = apartmentsCount > 0 ? apartmentsCount : 1;
    const rawFee100 = totalMonthlyBudget / count;
    const recommendedFee100 = Math.ceil(rawFee100); // Rounded up to nearest DH for clean cashflow

    // 5. Monthly Fee Per Apartment adjusted for Uncollected/Default rate (Taux de recouvrement)
    const recoveryRate = Math.max(0.5, Math.min(1, (expectedCollectionRate || 92) / 100));
    const safeFeeWithDefaultMargin = Math.ceil(totalMonthlyBudget / (count * recoveryRate));

    // 6. Comparison with Current Fee (e.g. 150 DH)
    const currentTotalMonthlyCollection = currentFeePerApt * count;
    const currentTotalAnnualCollection = currentTotalMonthlyCollection * 12;

    // Deficit or Surplus if current fee is maintained:
    const monthlyGapIfCurrentMaintained = currentTotalMonthlyCollection - totalMonthlyBudget;
    const annualGapIfCurrentMaintained = currentTotalAnnualCollection - totalAnnualBudget;
    const isDeficitIfMaintained = annualGapIfCurrentMaintained < 0;

    // Difference per apartment
    const feeDiffMonthly = recommendedFee100 - currentFeePerApt;
    const feeDiffPercent = currentFeePerApt > 0 
      ? Math.round((feeDiffMonthly / currentFeePerApt) * 100 * 10) / 10 
      : 0;

    // Safe fee diff
    const safeFeeDiffMonthly = safeFeeWithDefaultMargin - currentFeePerApt;

    // Chart Data by Category
    const chartData = activeItems.map(item => ({
      name: isRtl ? item.nameAr : item.nameFr,
      shortName: (isRtl ? item.nameAr : item.nameFr).slice(0, 14) + '...',
      monthly: item.monthlyAmount,
      annual: item.annualAmount,
      percentage: totalMonthlyBudget > 0 ? Math.round((item.monthlyAmount / totalMonthlyBudget) * 100) : 0
    }));

    if (reserveFundMonthly > 0) {
      chartData.push({
        name: isRtl ? 'صندوق الاحتياط والأشغال (قانون 18-00)' : 'Fonds de réserve & travaux',
        shortName: isRtl ? 'صندوق الاحتياط' : 'Fonds réserve',
        monthly: reserveFundMonthly,
        annual: reserveFundAnnual,
        percentage: totalMonthlyBudget > 0 ? Math.round((reserveFundMonthly / totalMonthlyBudget) * 100) : 0
      });
    }

    return {
      routineMonthly,
      routineAnnual,
      reserveFundMonthly,
      reserveFundAnnual,
      totalAnnualBudget,
      totalMonthlyBudget,
      recommendedFee100,
      safeFeeWithDefaultMargin,
      currentTotalMonthlyCollection,
      currentTotalAnnualCollection,
      monthlyGapIfCurrentMaintained,
      annualGapIfCurrentMaintained,
      isDeficitIfMaintained,
      feeDiffMonthly,
      feeDiffPercent,
      safeFeeDiffMonthly,
      activeItemsCount: activeItems.length,
      chartData
    };
  }, [items, reserveFundPercent, expectedCollectionRate, apartmentsCount, currentFeePerApt, isRtl]);

  // Export to PDF
  const handleExportPdf = async () => {
    setIsExportingPdf(true);
    try {
      const success = await exportElementToPdf(
        'budget-simulation-export-container', 
        `Projet_Budget_Previsionnel_${targetYear}_Syndic`
      );
      if (success) {
        showToast(lang === 'ar' ? 'تم تصدير مشروع الميزانية التقديرية إلى PDF بنجاح!' : 'Projet de budget prévisionnel exporté en PDF !', { type: 'success' });
      } else {
        showToast(lang === 'ar' ? 'حدث خطأ أثناء إنشاء ملف PDF' : 'Erreur lors de la génération du PDF', { type: 'error' });
      }
    } catch (err) {
      console.error(err);
      showToast(lang === 'ar' ? 'فشل التصدير' : 'Échec de l\'exportation', { type: 'error' });
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Copy General Assembly Resolution Text
  const generateGaResolutionText = () => {
    return `مقرر الجمع العام السنوي للملاك المشتركين - إقامة المرجان
مشروع الميزانية التقديرية وتحديد واجبات السنديك لسنة ${targetYear}
==================================================

1. الميزانية الإجمالية المصادق عليها:
- النفقات التشغيلية الدورية السنوية: ${calculations.routineAnnual.toLocaleString()} درهم (${calculations.routineMonthly.toLocaleString()} درهم/شهر).
- مخصص صندوق الاحتياط للأشغال الكبرى (القانون 18-00 بنسبة ${reserveFundPercent}%): ${calculations.reserveFundAnnual.toLocaleString()} درهم سنوياً.
=> إجمالي الميزانية السنوية التقديرية: ${calculations.totalAnnualBudget.toLocaleString()} درهم مغربي.

2. عدد الشقق والوحدات المعنية بالتحملات: ${apartmentsCount} شقة.

3. تحديد الواجب الشهري لكل شقة لسنة ${targetYear}:
- الواجب الحالي: ${currentFeePerApt} درهم / شهرياً.
- الواجب المقترح المتوازن: ${calculations.recommendedFee100} درهم / شهرياً (فارق: ${calculations.feeDiffMonthly > 0 ? '+' : ''}${calculations.feeDiffMonthly} درهم).
- الواجب الآمن (مع احتساب هامش تحصيل ${expectedCollectionRate}%): ${calculations.safeFeeWithDefaultMargin} درهم / شهرياً.

4. أسباب الملاءمة:
- تغطية الزيادات في فواتير الكهرباء وصيانة المصاعد ومحطة الضخ.
- الامتثال للمادة القانونية بإحداث صندوق الاحتياط لضمان صيانة المباني وتفادي النداءات الاستثنائية.

حرر بإجماع / أغلبية الجمع العام بتاريخ: ${new Date().toLocaleDateString('ar-MA')}`;
  };

  const handleCopyGaText = () => {
    const text = generateGaResolutionText();
    navigator.clipboard.writeText(text);
    setCopiedSuccess(true);
    showToast(lang === 'ar' ? 'تم نسخ نص مشروع القرار لعرضه في الجمع العام!' : 'Texte de résolution copié !', { type: 'success' });
    setTimeout(() => setCopiedSuccess(false), 3000);
  };

  const handleShareWhatsApp = () => {
    const text = generateGaResolutionText();
    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Top Header Card */}
      <div className="bg-gradient-to-r from-[#0f172a] via-[#0a8591] to-[#0d5262] rounded-2xl p-5 sm:p-7 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 end-0 w-80 h-80 bg-white/5 rounded-full blur-3xl -me-20 -mt-20 pointer-events-none aurora-blob aurora-a" />
        <Calculator className="absolute top-5 end-10 w-20 h-20 text-white/10 anim-float pointer-events-none hidden sm:block" />
        <Sparkles className="absolute bottom-5 end-1/3 w-8 h-8 text-amber-300/30 anim-float-2 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-emerald-300 text-xs font-bold mb-3 backdrop-blur-xs border border-white/15">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'أداة التخطيط المالي والجمع العام للملاك' : 'Outil de Planification & Assemblée Générale'}</span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight flex items-center gap-3">
              <Calculator className="icon-wiggle anim-bob w-7 h-7 sm:w-8 sm:h-8 text-amber-300 shrink-0" />
              <span>{lang === 'ar' ? 'محاكاة الميزانية التقديرية للسنة القادمة' : 'Simulateur de Budget Prévisionnel'}</span>
              <span className="text-lg sm:text-xl font-mono text-emerald-300 bg-black/30 px-3 py-0.5 rounded-xl border border-white/15">
                {targetYear}
              </span>
            </h1>

            <p className="text-emerald-100/90 text-sm mt-2 max-w-2xl leading-relaxed">
              {lang === 'ar' 
                ? 'أداة رقمية متطورة تُمكّن السنديك من صياغة توقعات المصاريف لسنة قادمة وحساب أثرها المالي المباشر على الواجبات الشهرية المطلوبة من الملاك وفق مقتضيات قانون الملكية المشتركة (18-00).'
                : 'Permet au syndic de modéliser les prévisions de dépenses pour l\'exercice à venir et de calculer l\'impact direct sur les cotisations mensuelles dues par les copropriétaires.'}
            </p>
          </div>

          {/* Quick Actions in Header */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="px-4 py-2.5 rounded-xl bg-white text-[#0a8591] font-bold text-xs sm:text-sm hover:bg-rose-50 transition-all flex items-center gap-2 shadow-md active:scale-95 disabled:opacity-50"
              title={lang === 'ar' ? 'تصدير وثيقة الجمع العام بصيغة PDF' : 'Exporter le rapport d\'AG en PDF'}
            >
              <FileDown className="w-4 h-4 text-[#0a8591]" />
              <span>{isExportingPdf ? (lang === 'ar' ? 'جاري التصدير...' : 'Exportation...') : (lang === 'ar' ? 'تصدير وثيقة PDF' : 'Rapport PDF')}</span>
            </button>

            <button
              onClick={handleCopyGaText}
              className="px-4 py-2.5 rounded-xl bg-black/30 hover:bg-black/40 text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2 border border-white/20 active:scale-95"
              title={lang === 'ar' ? 'نسخ نص مشروع القرار لعرضه في الجمع العام' : 'Copier la résolution d\'AG'}
            >
              {copiedSuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-300" />}
              <span>{copiedSuccess ? (lang === 'ar' ? 'تم النسخ!' : 'Copié !') : (lang === 'ar' ? 'نسخ نص القرار' : 'Copier texte')}</span>
            </button>

            <button
              onClick={handleShareWhatsApp}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm transition-all flex items-center gap-2 shadow-md active:scale-95"
              title={lang === 'ar' ? 'مشاركة الملخص عبر واتساب' : 'Partager via WhatsApp'}
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">{lang === 'ar' ? 'واتساب' : 'WhatsApp'}</span>
            </button>
          </div>
        </div>

        {/* Target Year Selector Bar */}
        <div className="mt-5 pt-4 border-t border-white/15 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-amber-200 font-semibold">{lang === 'ar' ? 'السنة المستهدفة بالمحاكاة:' : 'Année cible :'}</span>
            <div className="flex items-center gap-1 bg-black/25 p-1 rounded-lg border border-white/10">
              {[currentYear, currentYear + 1, currentYear + 2].map(yr => (
                <button
                  key={yr}
                  onClick={() => setTargetYear(yr)}
                  className={`px-2.5 py-1 rounded-md font-mono font-bold transition-all ${
                    targetYear === yr ? 'bg-amber-400 text-slate-900 shadow-sm' : 'text-white/80 hover:text-white'
                  }`}
                >
                  {yr}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleImportFromActualExpenses}
              className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-emerald-200 hover:text-white font-semibold transition-colors flex items-center gap-1.5 border border-white/10"
              title={lang === 'ar' ? 'تحديث التقديرات من واقع مصاريف الإقامة الحالية' : 'Synchroniser avec dépenses réelles'}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'استيراد من المصاريف الفعلية الحالية' : 'Importer dépenses réelles'}</span>
            </button>

            <button
              onClick={handleResetDefaults}
              className="px-2.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-amber-200 hover:text-white font-semibold transition-colors flex items-center gap-1.5 border border-white/10"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'إعادة ضبط' : 'Réinitialiser'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* AUTO-SAVE STATUS & LOCALSTORAGE PERSISTENCE INDICATOR */}
      <div className="bg-emerald-50/90 border border-emerald-300 rounded-xl p-3 px-4 flex flex-wrap items-center justify-between gap-3 text-xs shadow-2xs">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${autoSaveStatus === 'saving' ? 'bg-amber-400' : 'bg-emerald-400'} opacity-75`} />
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${autoSaveStatus === 'saving' ? 'bg-amber-500' : 'bg-emerald-600'}`} />
          </span>
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-bold text-slate-800 flex items-center gap-1.5">
              {autoSaveStatus === 'saving' ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" />
                  <span>{lang === 'ar' ? 'جارٍ حفظ إعدادات وبنود الميزانية في المتصفح...' : 'Enregistrement en cours (LocalStorage)...'}</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'ar' ? 'الحفظ التلقائي نشط (LocalStorage): التعديلات محفوظة ولا تضيع عند تحديث الصفحة ✓' : 'Sauvegarde auto active (LocalStorage) ✓'}</span>
                </>
              )}
            </span>
            {lastAutoSaveTime && (
              <span className="text-[11px] font-mono text-emerald-800 bg-emerald-100/90 px-2 py-0.5 rounded font-bold border border-emerald-200">
                {lang === 'ar' ? `آخر حفظ: ${lastAutoSaveTime}` : `Sauvegardé: ${lastAutoSaveTime}`}
              </span>
            )}
          </div>
        </div>

        <div className="text-[11px] text-slate-500 font-medium">
          {lang === 'ar' ? 'جميع مبالغ الخانات والنسب والبنود المخصصة مخزنة محلياً في الـ LocalStorage' : 'Toutes les cases et valeurs sont mémorisées localement'}
        </div>
      </div>

      {/* 4 Primary Impact KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Annual Budget */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">
                {lang === 'ar' ? 'الميزانية السنوية التقديرية' : 'Budget Annuel Prévisionnel'}
              </span>
              <div className="p-2 rounded-xl bg-purple-50 text-purple-700">
                <BarChart3 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
              {calculations.totalAnnualBudget.toLocaleString()} <span className="text-sm font-sans font-bold text-slate-500">DH</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
            <span>{lang === 'ar' ? 'المعدل الشهري للإقامة:' : 'Budget mensuel :'}</span>
            <span className="font-bold font-mono text-slate-900">
              {calculations.totalMonthlyBudget.toLocaleString()} DH/شهر
            </span>
          </div>
        </div>

        {/* Card 2: Recommended Monthly Fee per Apt (100% Recouvrement) */}
        <div className="bg-white rounded-2xl p-5 border-2 border-emerald-500/30 shadow-xs flex flex-col justify-between hover:border-emerald-500 transition-all bg-gradient-to-b from-emerald-50/20 to-white">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                {lang === 'ar' ? 'الواجب الشهري المقترح للشقة' : 'Cotisation Mensuelle Conseillée'}
              </span>
              <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 font-bold">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-emerald-700 font-mono tracking-tight">
                {calculations.recommendedFee100}
              </span>
              <span className="text-sm font-sans font-bold text-slate-500">DH / شهر</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-emerald-100/60 flex items-center justify-between text-[11px]">
            <span className="text-slate-600">{lang === 'ar' ? 'فارق عن الواجب الحالي:' : 'Écart vs actuel :'}</span>
            <span className={`font-bold font-mono px-2 py-0.5 rounded-full ${
              calculations.feeDiffMonthly > 0 
                ? 'bg-amber-100 text-amber-800' 
                : calculations.feeDiffMonthly === 0 
                  ? 'bg-slate-100 text-slate-700' 
                  : 'bg-emerald-100 text-emerald-800'
            }`}>
              {calculations.feeDiffMonthly > 0 ? `+${calculations.feeDiffMonthly}` : calculations.feeDiffMonthly} DH ({calculations.feeDiffPercent > 0 ? `+${calculations.feeDiffPercent}` : calculations.feeDiffPercent}%)
            </span>
          </div>
        </div>

        {/* Card 3: Safe Fee With Default Margin (Taux de Recouvrement e.g. 92%) */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all">
          <div>
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">
                {lang === 'ar' ? `الواجب الآمن (تحصيل ${expectedCollectionRate}%)` : `Cotisation Sécurisée (${expectedCollectionRate}%)`}
              </span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-700">
                <Shield className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-slate-900 font-mono tracking-tight">
                {calculations.safeFeeWithDefaultMargin}
              </span>
              <span className="text-sm font-sans font-bold text-slate-500">DH / شهر</span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
            <span>{lang === 'ar' ? 'يحمي الصندوق من تعثر الأداء' : 'Compense les impayés'}</span>
            <span className="font-bold text-amber-700">
              +{calculations.safeFeeDiffMonthly} DH
            </span>
          </div>
        </div>

        {/* Card 4: Impact If Current Fee Kept (Deficit Warning) */}
        <div className={`rounded-2xl p-5 border shadow-xs flex flex-col justify-between transition-all ${
          calculations.isDeficitIfMaintained 
            ? 'bg-rose-50/50 border-rose-200 text-rose-950' 
            : 'bg-emerald-50/50 border-emerald-200 text-emerald-950'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider">
                {lang === 'ar' ? 'أثر الإبقاء على الواجب الحالي' : 'Si cotisation actuelle maintenue'}
              </span>
              <div className={`p-2 rounded-xl ${calculations.isDeficitIfMaintained ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                {calculations.isDeficitIfMaintained ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
              </div>
            </div>
            
            <div className="flex items-baseline gap-1.5">
              <span className={`text-2xl sm:text-3xl font-black font-mono tracking-tight ${
                calculations.isDeficitIfMaintained ? 'text-rose-700' : 'text-emerald-700'
              }`}>
                {Math.abs(calculations.annualGapIfCurrentMaintained).toLocaleString()}
              </span>
              <span className="text-xs font-bold">DH / سنة</span>
            </div>

            <div className="text-[11px] font-bold mt-1">
              {calculations.isDeficitIfMaintained ? (
                <span className="text-rose-700 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  {lang === 'ar' ? 'عجز سنوي مؤكد في ميزانية التسيير!' : 'Déficit annuel projeté !'}
                </span>
              ) : (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  {lang === 'ar' ? 'فائض مالي مريح ومتوازن' : 'Excédent budgétaire confortable'}
                </span>
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-rose-200/60 flex items-center justify-between text-[11px]">
            <span>{lang === 'ar' ? 'الواجب الحالي المعتمد:' : 'Cotisation actuelle :'}</span>
            <span className="font-bold font-mono">{currentFeePerApt} DH/شهر</span>
          </div>
        </div>

      </div>

      {/* Simulation Scenarios Presets Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-slate-100 text-slate-700">
            <Sliders className="w-5 h-5 text-[#0a8591]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'ar' ? 'سيناريوهات المحاكاة الجاهزة للمصادقة' : 'Scénarios Budgétaires Prédéfinis'}
            </h3>
            <p className="text-xs text-slate-500">
              {lang === 'ar' ? 'اختر سيناريو لعرض دراسته ومقارنته فوراً قبل تعديل البنود التفصيلية' : 'Basculez entre différents scénarios pour comparer l\'impact'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleSelectScenario('austerity')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all border ${
              activeScenario === 'austerity'
                ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
          >
            {lang === 'ar' ? '1. سيناريو متقشف (حد أدنى)' : '1. Austérité (Minimum)'}
          </button>

          <button
            onClick={() => handleSelectScenario('balanced')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all border ${
              activeScenario === 'balanced'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
          >
            {lang === 'ar' ? '2. سيناريو متوازن (موصى به)' : '2. Équilibré (Recommandé)'}
          </button>

          <button
            onClick={() => handleSelectScenario('enhanced')}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all border ${
              activeScenario === 'enhanced'
                ? 'bg-[#0a8591] text-white border-[#0a8591] shadow-xs'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
          >
            {lang === 'ar' ? '3. سيناريو معزز (مع صندوق الأشغال)' : '3. Renforcé (Investissements)'}
          </button>
        </div>
      </div>

      {/* Main Grid: Parameters & Interactive Item List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (1/3): Simulation Parameters & Adjustments */}
        <div className="space-y-6">
          
          {/* General Simulation Settings */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-5">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-3 border-b border-slate-100">
              <Settings2 className="w-4 h-4 text-[#0a8591]" />
              <span>{lang === 'ar' ? 'إعدادات المحاكاة وقاعدة الشقق' : 'Paramètres de la Copropriété'}</span>
            </h3>

            {/* Total Apartments Count */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>{lang === 'ar' ? 'عدد الشقق المشاركة في الأداء:' : 'Nombre de lots participants :'}</span>
                <span className="font-bold text-slate-900 font-mono">{apartmentsCount} شقة</span>
              </div>
              <input
                type="number"
                min="1"
                max="2000"
                value={apartmentsCount}
                onChange={(e) => setApartmentsCount(Math.max(1, Number(e.target.value) || 1))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'ar' ? 'محتسب من شقق الإقامة المستغلة الفعلية' : 'Issu de la base de données des appartements'}
              </p>
            </div>

            {/* Current Monthly Fee */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>{lang === 'ar' ? 'الواجب الشهري المعتمد حالياً:' : 'Cotisation actuelle (par lot) :'}</span>
                <span className="font-bold text-slate-900 font-mono">{currentFeePerApt} DH</span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="50"
                  max="5000"
                  step="10"
                  value={currentFeePerApt}
                  onChange={(e) => setCurrentFeePerApt(Math.max(1, Number(e.target.value) || 0))}
                  className="w-full px-3 py-2 pe-12 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
                />
                <span className="absolute end-3 top-2.5 text-xs text-slate-400 font-bold">DH</span>
              </div>
            </div>

            {/* Reserve Fund (Fonds de Réserve - Loi 18-00) */}
            <div className="pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span className="flex items-center gap-1.5 text-purple-900 font-bold">
                  <PiggyBank className="w-4 h-4 text-purple-600" />
                  <span>{lang === 'ar' ? 'صندوق الاحتياط للأشغال (قانون 18-00):' : 'Fonds de réserve (Loi 18-00) :'}</span>
                </span>
                <span className="font-bold text-purple-700 font-mono text-sm bg-purple-50 px-2 py-0.5 rounded-md">
                  {reserveFundPercent}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="25"
                step="1"
                value={reserveFundPercent}
                onChange={(e) => setReserveFundPercent(Number(e.target.value))}
                className="w-full accent-purple-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>0% (دون احتياط)</span>
                <span className="text-purple-700 font-semibold">10% (الموصى به قانوناً)</span>
                <span>25% (أشغال كبرى)</span>
              </div>
              <div className="mt-2 text-[11px] text-slate-600 bg-purple-50/70 p-2.5 rounded-xl border border-purple-100">
                {lang === 'ar' 
                  ? `مخصص سنوي بقيمة ${calculations.reserveFundAnnual.toLocaleString()} DH (${calculations.reserveFundMonthly.toLocaleString()} DH/شهر) يخصص لإصلاحات المصاعد والواجهات والحالات الطارئة دون الحاجة لجمع مساهمات استثنائية مفاجئة.`
                  : `Provision de ${calculations.reserveFundAnnual.toLocaleString()} DH/an pour travaux structurels.`}
              </div>
            </div>

            {/* Collection Rate Slider (Taux de Recouvrement) */}
            <div className="pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span className="flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5 text-amber-600" />
                  <span>{lang === 'ar' ? 'معدل التحصيل المتوقع (الاستخلاص):' : 'Taux de recouvrement estimé :'}</span>
                </span>
                <span className="font-bold text-amber-800 font-mono text-sm bg-amber-50 px-2 py-0.5 rounded-md">
                  {expectedCollectionRate}%
                </span>
              </div>
              <input
                type="range"
                min="70"
                max="100"
                step="1"
                value={expectedCollectionRate}
                onChange={(e) => setExpectedCollectionRate(Number(e.target.value))}
                className="w-full accent-amber-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>70% (تأخر شديد)</span>
                <span>90% (واقعي)</span>
                <span>100% (مثالي كامل)</span>
              </div>
            </div>

            {/* Quick Inflation Batch Adjustment */}
            <div className="pt-3 border-t border-slate-100">
              <span className="text-xs font-semibold text-slate-700 block mb-2">
                {lang === 'ar' ? 'تعديل نسبي شامل لكافة المصاريف (التضخم):' : 'Ajustement inflation sur toutes les lignes :'}
              </span>
              <div className="grid grid-cols-4 gap-1.5">
                {[-5, 5, 10, 15].map(pct => (
                  <button
                    key={pct}
                    onClick={() => handleApplyInflation(pct)}
                    className="px-2 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold font-mono transition-colors"
                  >
                    {pct > 0 ? `+${pct}%` : `${pct}%`}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Mini Chart: Category Breakdown */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <span className="flex items-center gap-2">
                <PieChartIcon className="w-4 h-4 text-emerald-600" />
                <span>{lang === 'ar' ? 'توزيع بنود الميزانية' : 'Répartition des Postes'}</span>
              </span>
              <span className="text-xs font-mono text-slate-400">{calculations.activeItemsCount} بنود</span>
            </h3>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={calculations.chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="monthly"
                  >
                    {calculations.chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(val: number) => [`${val.toLocaleString()} DH/شهر`, 'المبلغ']}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Top 4 expenses list */}
            <div className="space-y-1.5 mt-2">
              {calculations.chartData
                .sort((a, b) => b.monthly - a.monthly)
                .slice(0, 4)
                .map((d, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 truncate max-w-[180px]">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="text-slate-600 truncate">{d.name}</span>
                    </div>
                    <span className="font-mono font-bold text-slate-800 shrink-0">
                      {d.percentage}%
                    </span>
                  </div>
                ))}
            </div>
          </div>

        </div>

        {/* Right Column (2/3): Projected Expenses Lines Editor */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-[#0a8591]" />
                  <span>{lang === 'ar' ? 'جدول توقعات المصاريف لسنة ' + targetYear : 'Tableau Prévisionnel des Dépenses ' + targetYear}</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === 'ar' ? 'أدخل التوقعات الشهرية أو السنوية لكل بند لتحديث الواجبات تلقائياً' : 'Ajustez les montants pour chaque poste de charge'}
                </p>
              </div>

              <button
                onClick={() => setShowAddForm(prev => !prev)}
                className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === 'ar' ? 'إضافة بند مصروف جديد' : 'Ajouter un poste'}</span>
              </button>
            </div>

            {/* Inline Add Custom Item Form */}
            {showAddForm && (
              <form onSubmit={handleAddCustomItem} className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3 animate-in fade-in duration-200">
                <div className="font-bold text-xs text-slate-800">
                  {lang === 'ar' ? 'إضافة بند مصروف تقديري إضافي:' : 'Nouveau poste prévisionnel :'}
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      {lang === 'ar' ? 'اسم البند (بالعربية) *' : 'Intitulé (Arabe) *'}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: طلاء واجهة العمارات، تجديد كاميرات..."
                      value={newItemNameAr}
                      onChange={e => setNewItemNameAr(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                      {lang === 'ar' ? 'المبلغ التقديري الشهري (درهم) *' : 'Montant mensuel estimé (DH) *'}
                    </label>
                    <input
                      type="number"
                      min="0"
                      step="50"
                      required
                      value={newItemMonthly}
                      onChange={e => setNewItemMonthly(Number(e.target.value))}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                    {lang === 'ar' ? 'ملاحظات وتبرير النفقات للجمع العام (اختياري)' : 'Justification pour l\'AG (facultatif)'}
                  </label>
                  <input
                    type="text"
                    placeholder="ملاحظات توضيحية لتقديمها للملاك..."
                    value={newItemNotes}
                    onChange={e => setNewItemNotes(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-3 py-1.5 rounded-lg bg-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-300"
                  >
                    {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                  >
                    {lang === 'ar' ? 'حفظ وإدراج' : 'Enregistrer'}
                  </button>
                </div>
              </form>
            )}

            {/* List of Expense Items */}
            <div className="mt-4 divide-y divide-slate-100">
              {items.map((item, idx) => (
                <div 
                  key={item.id} 
                  className={`py-3 sm:py-3.5 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    !item.enabled ? 'opacity-40 bg-slate-50/50' : 'hover:bg-slate-50/80'
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <input
                      type="checkbox"
                      checked={item.enabled}
                      onChange={() => handleToggleItem(item.id)}
                      className="mt-1 w-4 h-4 rounded text-[#0a8591] focus:ring-[#0a8591] cursor-pointer"
                      title={lang === 'ar' ? 'تفعيل / تعطيل هذا البند في الحساب' : 'Activer / Désactiver'}
                    />
                    
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs sm:text-sm text-slate-800 truncate">
                          {isRtl ? item.nameAr : item.nameFr}
                        </span>
                        {item.isCustom && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                            {lang === 'ar' ? 'مخصص' : 'Personnalisé'}
                          </span>
                        )}
                      </div>
                      {item.notes && (
                        <p className="text-[11px] text-slate-500 truncate max-w-md mt-0.5">
                          {item.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Monthly & Annual inputs */}
                  <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                    <div className="text-end">
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-[11px] text-slate-400 font-semibold">{lang === 'ar' ? 'شهرياً:' : 'Mois :'}</span>
                        <input
                          type="number"
                          disabled={!item.enabled}
                          min="0"
                          step="100"
                          value={item.monthlyAmount}
                          onChange={(e) => handleUpdateItemMonthly(item.id, Number(e.target.value))}
                          className="w-24 px-2 py-1 text-end text-xs font-bold font-mono bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0a8591]"
                        />
                        <span className="text-[10px] font-mono text-slate-500">DH</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {(item.monthlyAmount * 12).toLocaleString()} DH/سنة
                      </div>
                    </div>

                    {item.isCustom && (
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 transition-colors"
                        title={lang === 'ar' ? 'حذف البند' : 'Supprimer'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Total Operational Summary Row */}
            <div className="mt-4 pt-4 border-t-2 border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/80 p-3.5 rounded-xl">
              <div>
                <span className="text-xs font-bold text-slate-700 block">
                  {lang === 'ar' ? 'مجموع نفقات التسيير الدورية المباشرة:' : 'Total charges courantes :'}
                </span>
                <span className="text-[11px] text-slate-500">
                  {lang === 'ar' ? 'قبل إضافة مخصص صندوق الاحتياط' : 'Hors fonds de réserve'}
                </span>
              </div>

              <div className="text-end">
                <div className="text-base font-extrabold text-slate-900 font-mono">
                  {calculations.routineMonthly.toLocaleString()} <span className="text-xs font-sans text-slate-500">DH/شهر</span>
                </div>
                <div className="text-xs font-mono text-slate-500">
                  {calculations.routineAnnual.toLocaleString()} DH/سنة
                </div>
              </div>
            </div>

          </div>

          {/* Building By Building Impact Preview */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <span className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#0a8591]" />
                <span>{lang === 'ar' ? 'توزيع المداخيل حسب العمارات (GH)' : 'Répartition des Recettes par Immeuble'}</span>
              </span>
              <span className="text-xs font-semibold text-slate-500 font-mono">
                {buildings.length} عمارات مسجلة
              </span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {buildings.slice(0, 8).map(b => {
                const bApts = apartments.filter(a => a.buildingCode === b.code);
                const aptCount = bApts.length;
                const monthlyRevenueSimulated = aptCount * calculations.recommendedFee100;
                const monthlyRevenueCurrent = aptCount * currentFeePerApt;
                const revenueDiff = monthlyRevenueSimulated - monthlyRevenueCurrent;

                return (
                  <div key={b.code} className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-center hover:bg-slate-100/70 transition-colors">
                    <div className="text-xs font-bold text-slate-800">{b.code}</div>
                    <div className="text-[11px] text-slate-500">{aptCount} شقة</div>
                    <div className="text-sm font-mono font-extrabold text-emerald-700 mt-1">
                      {monthlyRevenueSimulated.toLocaleString()} <span className="text-[10px]">DH</span>
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {revenueDiff > 0 ? `+${revenueDiff} DH` : 'مطابق'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

      {/* Hidden/Printable Official GA Document Container for High-Res PDF Export */}
      <div className="hidden">
        <div id="budget-simulation-export-container" className="p-8 bg-white text-slate-900 font-sans max-w-4xl mx-auto" dir={isRtl ? 'rtl' : 'ltr'}>
          
          {/* Header */}
          <div className="border-b-2 border-[#0a8591] pb-4 mb-6 flex justify-between items-start">
            <div>
              <h1 className="text-xl font-black text-[#0a8591]">إقامة المرجان - السكنية والتجارية</h1>
              <p className="text-xs text-slate-600 mt-1">اتحاد الملاك المشتركين (السانديك) - خاضع لمقتضيات القانون 18-00</p>
              <h2 className="text-base font-extrabold text-slate-800 mt-3">
                مشروع الميزانية التقديرية وتحديد واجبات السنديك لسنة {targetYear}
              </h2>
            </div>
            <div className="text-end text-xs font-mono text-slate-500">
              <div>تاريخ التقرير: {new Date().toLocaleDateString('fr-FR')}</div>
              <div>المرجع: PREV-BUDGET-{targetYear}</div>
            </div>
          </div>

          {/* GA Summary Cards */}
          <div className="grid grid-cols-3 gap-4 mb-6 text-center">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="text-[11px] text-slate-500 font-bold">الميزانية السنوية الإجمالية</div>
              <div className="text-lg font-black font-mono text-slate-900">{calculations.totalAnnualBudget.toLocaleString()} DH</div>
            </div>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
              <div className="text-[11px] text-emerald-800 font-bold">الواجب الشهري المقترح للشقة</div>
              <div className="text-lg font-black font-mono text-emerald-700">{calculations.recommendedFee100} DH / شهر</div>
              <div className="text-[10px] text-slate-500 font-mono">(الحالي: {currentFeePerApt} DH)</div>
            </div>
            <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="text-[11px] text-purple-800 font-bold">مخصص صندوق الاحتياط ({reserveFundPercent}%)</div>
              <div className="text-lg font-black font-mono text-purple-700">{calculations.reserveFundAnnual.toLocaleString()} DH / سنة</div>
            </div>
          </div>

          {/* Table */}
          <table className="w-full text-xs border-collapse border border-slate-200 mb-6">
            <thead>
              <tr className="bg-[#0a8591] text-white">
                <th className="p-2 border border-slate-300 text-start">بند المصروف التقديري</th>
                <th className="p-2 border border-slate-300 text-center">المبلغ الشهري التقديري</th>
                <th className="p-2 border border-slate-300 text-center">المبلغ السنوي التقديري</th>
                <th className="p-2 border border-slate-300 text-start">الملاحظات والتبرير</th>
              </tr>
            </thead>
            <tbody>
              {items.filter(i => i.enabled).map((item, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-2 border border-slate-200 font-bold">{item.nameAr}</td>
                  <td className="p-2 border border-slate-200 text-center font-mono">{item.monthlyAmount.toLocaleString()} DH</td>
                  <td className="p-2 border border-slate-200 text-center font-mono font-bold">{(item.monthlyAmount * 12).toLocaleString()} DH</td>
                  <td className="p-2 border border-slate-200 text-slate-600 text-[11px]">{item.notes || '-'}</td>
                </tr>
              ))}
              {calculations.reserveFundAnnual > 0 && (
                <tr className="bg-purple-50 font-bold text-purple-900">
                  <td className="p-2 border border-slate-200">صندوق الاحتياط للأشغال الكبرى (قانون 18-00 بنسبة {reserveFundPercent}%)</td>
                  <td className="p-2 border border-slate-200 text-center font-mono">{calculations.reserveFundMonthly.toLocaleString()} DH</td>
                  <td className="p-2 border border-slate-200 text-center font-mono font-bold">{calculations.reserveFundAnnual.toLocaleString()} DH</td>
                  <td className="p-2 border border-slate-200 text-[11px]">مخصص وقائي قانوني للصيانة الكبرى وتفادي النداءات الاستثنائية</td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-black text-slate-900">
                <td className="p-2 border border-slate-300">المجموع الإجمالي العام</td>
                <td className="p-2 border border-slate-300 text-center font-mono">{calculations.totalMonthlyBudget.toLocaleString()} DH/شهر</td>
                <td className="p-2 border border-slate-300 text-center font-mono text-emerald-800 font-bold">{calculations.totalAnnualBudget.toLocaleString()} DH/سنة</td>
                <td className="p-2 border border-slate-300 text-[11px] text-slate-600">المعدل الشهري: {calculations.recommendedFee100} DH على {apartmentsCount} شقة</td>
              </tr>
            </tfoot>
          </table>

          {/* Footer signatures */}
          <div className="mt-8 pt-4 border-t border-slate-300 flex justify-between text-xs text-slate-600">
            <div>
              <div>رئيس مكتب السانديك: .......................................</div>
              <div className="text-[10px] mt-1 text-slate-400">التوقيع والخاتم</div>
            </div>
            <div>
              <div>لجنة المراقبة والتدقيق: .......................................</div>
              <div className="text-[10px] mt-1 text-slate-400">ممثلو الملاك المشتركين</div>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
