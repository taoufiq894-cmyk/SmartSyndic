import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ResidenceLocationInfo } from '../types';
import { 
  getResidenceLocation, 
  saveResidenceLocation, 
  DEFAULT_RESIDENCE_LOCATION,
  shareLocationViaWhatsApp,
  generateLocationShareMessage,
  parseCoordinatesFromInput,
  clearStoredResidenceLocation,
  hasValidCoordinates
} from '../utils/locationUtils';
import { 
  MapPin, Send, Share2, Copy, Check, ExternalLink, QrCode, 
  Navigation, Car, Compass, Phone, Mail, Building2, Shield, 
  Sparkles, Printer, Download, Edit3, RotateCcw, Save, X, 
  Info, MessageSquare, Map as MapIcon, Layers, CheckCheck, 
  Smartphone, Eye, Trash2, SlidersHorizontal, AlertTriangle, 
  Search, Link, ArrowRightLeft, RefreshCw, Bot, Lock
} from 'lucide-react';

interface LocationViewProps {
  onCloseModal?: () => void;
  isModal?: boolean;
}

export const LocationView: React.FC<LocationViewProps> = ({ onCloseModal, isModal = false }) => {
  const { t, lang, currentUser, showToast, buildings, apartments, setActiveSection } = useApp();
  const isRtl = lang === 'ar';
  const isAdminOrSyndic = currentUser?.role === 'admin' || currentUser?.role === 'syndic';

  // Location state
  const [locationInfo, setLocationInfo] = useState<ResidenceLocationInfo>(() => getResidenceLocation());
  
  // Coordinate Editor Form State (always available and controllable)
  const [showCoordsPanel, setShowCoordsPanel] = useState(true);
  const [inputLat, setInputLat] = useState<string>(() => String(locationInfo.latitude || ''));
  const [inputLng, setInputLng] = useState<string>(() => String(locationInfo.longitude || ''));
  const [inputCity, setInputCity] = useState<string>(() => locationInfo.city || '');
  const [inputName, setInputName] = useState<string>(() => locationInfo.name || '');
  const [inputAddress, setInputAddress] = useState<string>(() => locationInfo.fullAddressAr || '');
  const [pasteText, setPasteText] = useState('');

  // Full Edit modal state
  const [isFullEditModalOpen, setIsFullEditModalOpen] = useState(false);
  const [fullEditForm, setFullEditForm] = useState<ResidenceLocationInfo>(locationInfo);

  // Quick Share modal & form
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [selectedBuilding, setSelectedBuilding] = useState<string>(currentUser?.building || '');
  const [selectedApartment, setSelectedApartment] = useState<string>(currentUser?.apartment || '');

  // Copy feedback states
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCoords, setCopiedCoords] = useState(false);
  const [copiedGuide, setCopiedGuide] = useState(false);

  // Map view controls
  const [mapZoom, setMapZoom] = useState(16);
  const [mapType, setMapType] = useState<'roadmap' | 'satellite'>('roadmap');

  // Check validity of current coordinates
  const isValidCoords = useMemo(() => hasValidCoordinates(locationInfo), [locationInfo]);

  useEffect(() => {
    const loc = getResidenceLocation();
    setLocationInfo(loc);
    setInputLat(loc.latitude ? String(loc.latitude) : '');
    setInputLng(loc.longitude ? String(loc.longitude) : '');
    setInputCity(loc.city || '');
    setInputName(loc.name || '');
    setInputAddress(loc.fullAddressAr || '');
    setFullEditForm(loc);
  }, []);

  const googleMapsUrl = isValidCoords 
    ? `https://maps.google.com/?q=${locationInfo.latitude},${locationInfo.longitude}` 
    : 'https://maps.google.com';
  const wazeUrl = isValidCoords 
    ? `https://waze.com/ul?ll=${locationInfo.latitude},${locationInfo.longitude}&navigate=yes` 
    : 'https://waze.com';
  const appleMapsUrl = isValidCoords 
    ? `https://maps.apple.com/?q=${locationInfo.latitude},${locationInfo.longitude}` 
    : 'https://maps.apple.com';
  
  // Embed map URL
  const embedMapUrl = isValidCoords
    ? `https://maps.google.com/maps?q=${locationInfo.latitude},${locationInfo.longitude}&t=${mapType === 'satellite' ? 'k' : ''}&z=${mapZoom}&ie=UTF8&iwloc=&output=embed`
    : '';

  // Quick QR Code Image URL
  const qrCodeUrl = isValidCoords
    ? `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(googleMapsUrl)}&color=064e3b&bgcolor=f0fdf4&margin=1`
    : '';

  // Handle Quick Paste & Extraction of Coordinates
  const handleExtractFromPaste = () => {
    if (!pasteText.trim()) {
      showToast(lang === 'ar' ? 'يرجى لصق رابط خرائط جوجل أو نص الإحداثيات أولاً' : 'Veuillez coller un lien ou texte d\'abord');
      return;
    }

    const parsed = parseCoordinatesFromInput(pasteText);
    if (parsed) {
      setInputLat(String(parsed.latitude));
      setInputLng(String(parsed.longitude));
      showToast(t.location?.coordsExtractedSuccess || (lang === 'ar' ? 'تم استخراج الإحداثيات بنجاح!' : 'Coordonnées extraites avec succès !'));
    } else {
      showToast(t.location?.coordsExtractedFailed || (lang === 'ar' ? 'تعذر استخراج الإحداثيات. يرجى التأكد من صحة الرابط أو الأرقام.' : 'Impossible d\'extraire les coordonnées.'), { type: 'warning' });
    }
  };

  // Handle Saving the Coordinates directly from the Box
  const handleSaveCoordinates = () => {
    const latNum = parseFloat(inputLat.trim());
    const lngNum = parseFloat(inputLng.trim());

    if (isNaN(latNum) || isNaN(lngNum) || latNum < -90 || latNum > 90 || lngNum < -180 || lngNum > 180) {
      showToast(t.location?.invalidCoordsError || (lang === 'ar' ? 'يرجى إدخال قيم صحيحة لخط العرض (-90 إلى 90) وخط الطول (-180 إلى 180).' : 'Valeurs de latitude (-90 à 90) et longitude (-180 à 180) invalides.'), { type: 'error' });
      return;
    }

    const updated: ResidenceLocationInfo = {
      ...locationInfo,
      latitude: Number(latNum.toFixed(6)),
      longitude: Number(lngNum.toFixed(6)),
      city: inputCity.trim() || locationInfo.city,
      name: inputName.trim() || locationInfo.name,
      fullAddressAr: inputAddress.trim() || locationInfo.fullAddressAr,
      googleMapsUrl: `https://maps.google.com/?q=${latNum},${lngNum}`,
      googleMapsShortUrl: `https://maps.google.com/?q=${latNum},${lngNum}`,
      wazeUrl: `https://waze.com/ul?ll=${latNum},${lngNum}&navigate=yes`,
      appleMapsUrl: `https://maps.apple.com/?q=${latNum},${lngNum}`,
    };

    saveResidenceLocation(updated);
    setLocationInfo(updated);
    setFullEditForm(updated);
    showToast(t.location?.coordsSavedSuccess || (lang === 'ar' ? 'تم حفظ الإحداثيات بنجاح!' : 'Coordonnées enregistrées avec succès !'));
  };

  // Handle Canceling Coordinate Edits (Reverts to currently saved state)
  const handleCancelCoordinates = () => {
    setInputLat(locationInfo.latitude ? String(locationInfo.latitude) : '');
    setInputLng(locationInfo.longitude ? String(locationInfo.longitude) : '');
    setInputCity(locationInfo.city || '');
    setInputName(locationInfo.name || '');
    setInputAddress(locationInfo.fullAddressAr || '');
    setPasteText('');
    showToast(t.location?.coordsCanceled || (lang === 'ar' ? 'تم إلغاء التعديل واسترجاع القيم المحفوظة.' : 'Modifications annulées.'));
  };

  // Handle Clearing/Deleting Coordinates (مسح وتفريغ الإحداثيات)
  const handleClearCoordinates = () => {
    const confirmMsg = t.location?.confirmClearCoords || (lang === 'ar' ? 'هل أنت متأكد من رغبتك في مسح وتفريغ إحداثيات الموقع الحالية؟' : 'Effacer définitivement les coordonnées GPS ?');
    if (confirm(confirmMsg)) {
      const cleared = clearStoredResidenceLocation();
      setLocationInfo(cleared);
      setInputLat('');
      setInputLng('');
      setPasteText('');
      setFullEditForm(cleared);
      showToast(t.location?.coordsClearedSuccess || (lang === 'ar' ? 'تم مسح وتفريغ الإحداثيات بنجاح.' : 'Coordonnées effacées avec succès.'), { type: 'info' });
    }
  };

  // Reset to original default coordinates
  const handleResetDefaults = () => {
    const confirmMsg = lang === 'ar' 
      ? 'هل تريد استرجاع الإحداثيات والبيانات الافتراضية الأصلية لإقامة المرجان؟' 
      : 'Réinitialiser aux coordonnées par défaut de la Résidence ?';
    if (confirm(confirmMsg)) {
      saveResidenceLocation(DEFAULT_RESIDENCE_LOCATION);
      setLocationInfo(DEFAULT_RESIDENCE_LOCATION);
      setInputLat(String(DEFAULT_RESIDENCE_LOCATION.latitude));
      setInputLng(String(DEFAULT_RESIDENCE_LOCATION.longitude));
      setInputCity(DEFAULT_RESIDENCE_LOCATION.city);
      setInputName(DEFAULT_RESIDENCE_LOCATION.name);
      setInputAddress(DEFAULT_RESIDENCE_LOCATION.fullAddressAr);
      setPasteText('');
      setFullEditForm(DEFAULT_RESIDENCE_LOCATION);
      setIsFullEditModalOpen(false);
      showToast(lang === 'ar' ? 'تم استرجاع البيانات الافتراضية بنجاح' : 'Coordonnées par défaut restaurées');
    }
  };

  // Copy handlers
  const handleCopyLink = () => {
    if (!isValidCoords) {
      showToast(lang === 'ar' ? 'يرجى حفظ إحداثيات صالحة أولاً' : 'Veuillez définir des coordonnées valides', { type: 'warning' });
      return;
    }
    navigator.clipboard.writeText(googleMapsUrl);
    setCopiedLink(true);
    showToast(t.location?.linkCopied || 'تم نسخ رابط الموقع بنجاح');
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCopyCoords = () => {
    if (!isValidCoords) {
      showToast(lang === 'ar' ? 'لا توجد إحداثيات محددة لنسخها' : 'Aucune coordonnée définie', { type: 'warning' });
      return;
    }
    const coordsStr = `${locationInfo.latitude}, ${locationInfo.longitude}`;
    navigator.clipboard.writeText(coordsStr);
    setCopiedCoords(true);
    showToast(t.location?.coordsCopied || 'تم نسخ إحداثيات GPS');
    setTimeout(() => setCopiedCoords(false), 2500);
  };

  const handleCopyFullGuide = () => {
    const guide = generateLocationShareMessage(locationInfo, lang, {
      building: selectedBuilding,
      apartment: selectedApartment,
      recipientName: recipientName
    });
    navigator.clipboard.writeText(guide);
    setCopiedGuide(true);
    showToast(t.location?.guideCopied || 'تم نسخ رسالة التوجيه للزوار');
    setTimeout(() => setCopiedGuide(false), 2500);
  };

  const handleNativeShare = async () => {
    const message = generateLocationShareMessage(locationInfo, lang, {
      building: selectedBuilding,
      apartment: selectedApartment,
      recipientName: recipientName
    });

    if (navigator.share) {
      try {
        await navigator.share({
          title: lang === 'ar' ? `موقع ${locationInfo.name}` : `Localisation ${locationInfo.nameFr}`,
          text: message,
          url: isValidCoords ? googleMapsUrl : undefined,
        });
        showToast(lang === 'ar' ? 'تمت المشاركة بنجاح' : 'Partage réussi');
      } catch (err) {
        // User cancelled
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsAppSend = (customPhone?: string) => {
    shareLocationViaWhatsApp(locationInfo, customPhone || recipientPhone, lang, {
      building: selectedBuilding,
      apartment: selectedApartment,
      recipientName: recipientName
    });
  };

  const handleSaveFullEditModal = () => {
    saveResidenceLocation(fullEditForm);
    setLocationInfo(fullEditForm);
    setInputLat(fullEditForm.latitude ? String(fullEditForm.latitude) : '');
    setInputLng(fullEditForm.longitude ? String(fullEditForm.longitude) : '');
    setInputCity(fullEditForm.city || '');
    setInputName(fullEditForm.name || '');
    setInputAddress(fullEditForm.fullAddressAr || '');
    setIsFullEditModalOpen(false);
    showToast(lang === 'ar' ? 'تم حفظ كافة بيانات الموقع بنجاح' : 'Toutes les données ont été enregistrées');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className={`space-y-6 ${isModal ? 'p-2' : ''}`} dir={isRtl ? 'rtl' : 'ltr'}>
      
      {/* Top Header Banner with Glow Effect & Primary Action Button */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0f172a] via-[#0f172a] to-[#0a8591] text-white shadow-xl p-6 sm:p-8 border border-[#0d5262]">
        <div className="absolute -top-16 -end-16 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -start-16 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none aurora-blob aurora-b" />
        <MapPin className="absolute top-6 end-10 w-20 h-20 text-white/10 anim-float pointer-events-none hidden sm:block" />
        <MapPin className="absolute bottom-5 end-1/3 w-8 h-8 text-amber-300/30 anim-bob pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-amber-200 text-xs font-semibold backdrop-blur-xs">
              <MapPin className="w-3.5 h-3.5 text-rose-300 animate-bounce" />
              <span>{locationInfo.name} • {locationInfo.city}</span>
              {isValidCoords ? (
                <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-mono font-bold text-white">
                  {locationInfo.latitude}, {locationInfo.longitude}
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/80 text-[10px] font-bold text-slate-950">
                  {lang === 'ar' ? 'الإحداثيات غير محددة' : 'Coordonnées non définies'}
                </span>
              )}
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white flex items-center gap-2.5">
              <span>{t.location?.title || (lang === 'ar' ? 'موقع إقامة المرجان (Localisation)' : 'Localisation de la Résidence')}</span>
            </h1>
            
            <p className="text-emerald-100/90 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {t.location?.subtitle || (lang === 'ar' ? 'الموقع الجغرافي الدقيق، إحداثيات GPS، بوابات الدخول ومكتب السانديك' : 'Position GPS exacte, accès et bureau syndic')}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              id="btn-send-exact-location-primary"
              onClick={() => setIsShareModalOpen(true)}
              className="px-5 py-3 rounded-xl bg-white hover:bg-rose-50 active:bg-rose-100 text-[#0a8591] font-extrabold text-sm sm:text-base shadow-lg shadow-black/20 hover:shadow-xl hover:scale-102 transition-all flex items-center gap-2.5 cursor-pointer border border-white/40"
              title={t.location?.sendExactLocationDesc}
            >
              <Send className="w-5 h-5 text-[#0a8591] animate-pulse" />
              <span>{t.location?.sendExactLocationBtn || (lang === 'ar' ? 'إرسال الموقع بالضبط 📍' : 'Envoyer la localisation 📍')}</span>
            </button>

            <button
              id="btn-toggle-coords-management"
              onClick={() => setShowCoordsPanel(prev => !prev)}
              className={`px-3.5 py-3 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                showCoordsPanel 
                  ? 'bg-white/20 text-white border-white/40 shadow-sm' 
                  : 'bg-black/20 hover:bg-black/30 text-rose-100 border-white/20'
              }`}
              title={t.location?.manageCoordsCardTitle}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>{lang === 'ar' ? 'خانة ضبط الإحداثيات' : 'Réglage GPS'}</span>
            </button>

            {isAdminOrSyndic && (
              <button
                id="btn-open-full-edit-modal"
                onClick={() => setIsFullEditModalOpen(true)}
                className="px-3.5 py-3 rounded-xl bg-black/20 hover:bg-black/30 text-white text-xs font-semibold border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer"
                title={t.location?.editLocation}
              >
                <Edit3 className="w-4 h-4" />
                <span className="hidden sm:inline">{lang === 'ar' ? 'تعديل كامل البيانات' : 'Modifier tout'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Warning Banner if No Valid Coordinates are Set */}
      {!isValidCoords && (
        <div className="bg-amber-500/10 border-2 border-amber-500/40 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-amber-950">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-800 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5 text-amber-700 animate-bounce" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm sm:text-base text-amber-900">
                {t.location?.noCoordsSetWarning || (lang === 'ar' ? 'تنبيه: لم يتم تعيين إحداثيات GPS صالحة حالياً أو تم مسحها' : 'Attention : Aucune coordonnée GPS définie')}
              </h4>
              <p className="text-xs text-amber-800 mt-0.5">
                {lang === 'ar' 
                  ? 'يرجى إدخال خط العرض وخط الطول في الخانة أدناه أو لصق رابط Google Maps ثم الضغط على «حفظ الإحداثيات الجديدة» لتفعيل الخريطة ومشاركتها.' 
                  : 'Saisissez la latitude/longitude ou collez un lien Google Maps ci-dessous puis cliquez sur "Enregistrer".'}
              </p>
            </div>
          </div>

          <button
            onClick={handleResetDefaults}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.location?.resetDefaults || 'استرجاع الإحداثيات الافتراضية'}</span>
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DEDICATED COORDINATES MANAGEMENT CARD (تغيير وحفظ وإلغاء ومسح الإحداثيات) */}
      {/* ========================================================================= */}
      {showCoordsPanel && (
        <div className="bg-white rounded-2xl border-2 border-[#92e8dd] shadow-md p-5 sm:p-6 space-y-5 animate-in fade-in slide-in-from-top-3 duration-200">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#e9fbf8] text-[#0a8591] flex items-center justify-center font-bold">
                <MapPin className="w-5 h-5 text-[#0a8591]" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                  <span>{t.location?.manageCoordsCardTitle || (lang === 'ar' ? 'خانة تغيير وضبط الإحداثيات الجغرافية (GPS & Google Maps)' : 'Gestion & Modification des Coordonnées GPS')}</span>
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-[#e9fbf8] text-[#0a8591]">
                    {isValidCoords ? (lang === 'ar' ? 'إحداثيات مفعلة ✓' : 'Actif ✓') : (lang === 'ar' ? 'غير محددة ✕' : 'Non défini')}
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  {t.location?.manageCoordsCardDesc || (lang === 'ar' ? 'يمكنك إدخال إحداثيات خط العرض وخط الطول يدوياً، أو لصق رابط خرائط جوجل مباشرة، مع إمكانية الحفظ، الإلغاء، أو مسح الإحداثيات نهائياً.' : 'Saisissez ou collez les coordonnées GPS avec options d\'enregistrement, annulation ou suppression.')}
                </p>
              </div>
            </div>

            {/* Quick reset to default shortcut */}
            <button
              type="button"
              onClick={handleResetDefaults}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              title={t.location?.resetDefaults}
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>{lang === 'ar' ? 'الإحداثيات الافتراضية' : 'Valeurs par défaut'}</span>
            </button>
          </div>

          {/* Quick Paste & Auto-Extraction Input Box */}
          <div className="bg-slate-50/90 p-3.5 sm:p-4 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Link className="w-3.5 h-3.5 text-[#0a8591]" />
              <span>{t.location?.pasteInputPlaceholder || (lang === 'ar' ? 'لصق رابط خرائط جوجل أو إحداثيات GPS (لصق سريع):' : 'Coller le lien Google Maps ou texte GPS :')}</span>
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder={lang === 'ar' ? 'مثال: https://maps.google.com/?q=33.92147,-6.91742 أو 31.6340, -8.0123...' : 'Ex: https://maps.google.com/?q=33.92147,-6.91742 ou 31.6340, -8.0123...'}
                className="flex-1 px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white font-mono"
              />
              <button
                type="button"
                onClick={handleExtractFromPaste}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 active:bg-black text-white text-xs font-bold shadow-xs transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.location?.autoExtractBtn || (lang === 'ar' ? 'استخراج تلقائي' : 'Extraire')}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              {lang === 'ar' 
                ? '💡 يدعم الروابط من Google Maps و Waze والإحداثيات العشرية (Decimal) ودرجات الزوايا (DMS) لأي مدينة أو إقامة بالمغرب وخارجه.' 
                : '💡 Compatible avec les liens Google Maps, Waze, coordonnées décimales et DMS.'}
            </p>
          </div>

          {/* Coordinates & Location Inputs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            {/* Latitude */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-800 flex items-center justify-between">
                <span>{t.location?.latitudeLabel || 'خط العرض (Latitude)'}</span>
                <span className="text-[10px] text-[#0a8591] font-mono">-90 إلى +90</span>
              </label>
              <input
                type="number"
                step="any"
                value={inputLat}
                onChange={(e) => setInputLat(e.target.value)}
                placeholder="مثال: 31.643700"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white font-mono text-sm font-bold text-slate-900 shadow-inner"
              />
            </div>

            {/* Longitude */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-800 flex items-center justify-between">
                <span>{t.location?.longitudeLabel || 'خط الطول (Longitude)'}</span>
                <span className="text-[10px] text-[#0a8591] font-mono">-180 إلى +180</span>
              </label>
              <input
                type="number"
                step="any"
                value={inputLng}
                onChange={(e) => setInputLng(e.target.value)}
                placeholder="مثال: -8.075400"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white font-mono text-sm font-bold text-slate-900 shadow-inner"
              />
            </div>

            {/* City / Region */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-800">
                <span>{t.location?.city || (lang === 'ar' ? 'المدينة / الإقليم' : 'Ville / Région')}</span>
              </label>
              <input
                type="text"
                value={inputCity}
                onChange={(e) => setInputCity(e.target.value)}
                placeholder="مثال: مراكش / الدار البيضاء / تمارة"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white text-xs font-semibold text-slate-800"
              />
            </div>

            {/* Residence Name */}
            <div className="space-y-1.5">
              <label className="block font-bold text-slate-800">
                <span>{lang === 'ar' ? 'اسم الإقامة' : 'Nom Résidence'}</span>
              </label>
              <input
                type="text"
                value={inputName}
                onChange={(e) => setInputName(e.target.value)}
                placeholder="إقامة المرجان"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white text-xs font-semibold text-slate-800"
              />
            </div>
          </div>

          {/* Full Address Input */}
          <div className="space-y-1.5 text-xs">
            <label className="block font-bold text-slate-800">
              <span>{lang === 'ar' ? 'العنوان الدقيق للإقامة المعتمد في رسائل التوجيه والخريطة' : 'Adresse complète de la résidence'}</span>
            </label>
            <input
              type="text"
              value={inputAddress}
              onChange={(e) => setInputAddress(e.target.value)}
              placeholder="مثال: أبواب مراكش، المنطقة 10، السكن المتوسط، إقامة المرجان"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591] bg-white text-xs font-medium text-slate-800"
            />
          </div>

          {/* ACTION BUTTONS: SAVE, CANCEL, CLEAR / DELETE */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
            {/* Clear / Delete Button (مسح الإحداثيات) */}
            <button
              type="button"
              id="btn-clear-coordinates"
              onClick={handleClearCoordinates}
              className="px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 active:bg-rose-200 text-rose-700 text-xs font-extrabold border border-rose-200 transition-all flex items-center gap-1.5 cursor-pointer"
              title={t.location?.clearCoordsBtn || 'مسح وتفريغ الإحداثيات'}
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>{t.location?.clearCoordsBtn || (lang === 'ar' ? 'مسح وتفريغ الإحداثيات 🗑️' : 'Effacer les coordonnées 🗑️')}</span>
            </button>

            {/* Save & Cancel Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                id="btn-cancel-coordinates-edit"
                onClick={handleCancelCoordinates}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 text-xs font-bold border border-slate-300 transition-all flex items-center gap-1.5 cursor-pointer"
                title={t.location?.cancelEditBtn || 'إلغاء التعديل'}
              >
                <X className="w-4 h-4 text-slate-500" />
                <span>{t.location?.cancelEditBtn || (lang === 'ar' ? 'إلغاء التعديل ✕' : 'Annuler ✕')}</span>
              </button>

              <button
                type="button"
                id="btn-save-coordinates-main"
                onClick={handleSaveCoordinates}
                className="px-5 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] active:bg-[#0f172a] text-white text-xs sm:text-sm font-extrabold shadow-md transition-all flex items-center gap-2 cursor-pointer"
                title={t.location?.saveCoordsBtn || 'حفظ الإحداثيات'}
              >
                <Save className="w-4 h-4 text-white" />
                <span>{t.location?.saveCoordsBtn || (lang === 'ar' ? 'حفظ الإحداثيات الجديدة 💾' : 'Enregistrer les coordonnées 💾')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid: Interactive Map & Details / Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left/Main Column: Interactive Google Map & Details (8 Cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Interactive Map Box */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
            {/* Map Top Bar */}
            <div className="p-3.5 sm:p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-slate-800 font-bold text-xs sm:text-sm">
                <MapIcon className="w-4 h-4 text-emerald-600" />
                <span>{lang === 'ar' ? `الخريطة التفاعلية: ${locationInfo.name}` : `Carte interactive : ${locationInfo.nameFr}`}</span>
                {isValidCoords ? (
                  <span className="text-[11px] font-mono font-medium text-emerald-800 px-2 py-0.5 rounded bg-emerald-100 border border-emerald-200">
                    {locationInfo.latitude}, {locationInfo.longitude}
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-amber-800 px-2 py-0.5 rounded bg-amber-100 border border-amber-200">
                    {lang === 'ar' ? 'الإحداثيات ممسوحة' : 'Coordonnées vides'}
                  </span>
                )}
              </div>

              {/* Map Type Switcher & Controls */}
              {isValidCoords && (
                <div className="flex items-center gap-2">
                  <div className="inline-flex rounded-lg border border-slate-300 p-0.5 bg-white text-xs font-semibold text-slate-700">
                    <button
                      onClick={() => setMapType('roadmap')}
                      className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${mapType === 'roadmap' ? 'bg-emerald-600 text-white shadow-xs' : 'hover:bg-slate-100'}`}
                    >
                      {lang === 'ar' ? 'خريطة' : 'Plan'}
                    </button>
                    <button
                      onClick={() => setMapType('satellite')}
                      className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${mapType === 'satellite' ? 'bg-emerald-600 text-white shadow-xs' : 'hover:bg-slate-100'}`}
                    >
                      {lang === 'ar' ? 'قمر صناعي' : 'Satellite'}
                    </button>
                  </div>

                  <div className="hidden sm:flex items-center gap-1">
                    <button
                      onClick={() => setMapZoom(prev => Math.min(prev + 1, 20))}
                      className="w-7 h-7 rounded-md border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center cursor-pointer"
                      title="تكبير"
                    >
                      +
                    </button>
                    <button
                      onClick={() => setMapZoom(prev => Math.max(prev - 1, 10))}
                      className="w-7 h-7 rounded-md border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-center cursor-pointer"
                      title="تصغير"
                    >
                      -
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Embedded Live Map Iframe or Placeholder if Cleared */}
            <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-100 flex items-center justify-center">
              {isValidCoords ? (
                <>
                  <iframe
                    title="Residence Location Map"
                    src={embedMapUrl}
                    className="w-full h-full border-0"
                    loading="lazy"
                    allowFullScreen
                    referrerPolicy="no-referrer-when-downgrade"
                  />

                  {/* Floating Pin Quick Overlay */}
                  <div className="absolute bottom-3 start-3 bg-white/95 backdrop-blur-xs border border-slate-200 rounded-xl p-2.5 shadow-lg flex items-center gap-2.5 max-w-[90%] pointer-events-none">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4 text-emerald-700" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-xs text-slate-900 truncate">
                        {locationInfo.name}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        {locationInfo.city} • {locationInfo.latitude}, {locationInfo.longitude}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center p-6 max-w-md space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto shadow-inner">
                    <MapPin className="w-7 h-7 text-amber-700" />
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm sm:text-base">
                    {lang === 'ar' ? 'لا توجد خريطة لعرضها حالياً' : 'Aucune carte à afficher'}
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {lang === 'ar' 
                      ? 'تم مسح الإحداثيات الجغرافية. يرجى إدخال خط العرض وخط الطول في خانة الضبط بالأعلى والضغط على حفظ لعرض الخريطة الحية.' 
                      : 'Les coordonnées GPS ont été effacées. Veuillez définir les coordonnées dans le panneau ci-dessus.'}
                  </p>
                  <button
                    onClick={() => setShowCoordsPanel(true)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'فتح خانة إدخال الإحداثيات' : 'Ouvrir le panneau GPS'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Map Action Quick Bar */}
            <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                {isValidCoords ? (
                  <>
                    <a
                      href={googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>{t.location?.openInGoogleMaps || 'Google Maps'}</span>
                      <ExternalLink className="w-3 h-3 ms-0.5 opacity-80" />
                    </a>

                    <a
                      href={wazeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                    >
                      <Car className="w-3.5 h-3.5" />
                      <span>{t.location?.openInWaze || 'Waze'}</span>
                      <ExternalLink className="w-3 h-3 ms-0.5 opacity-80" />
                    </a>

                    <a
                      href={appleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hidden sm:inline-flex px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-all shadow-xs items-center gap-1.5 cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>{t.location?.openInAppleMaps || 'Apple Maps'}</span>
                    </a>
                  </>
                ) : (
                  <span className="text-xs text-slate-500 italic">
                    {lang === 'ar' ? 'روابط الملاحة معطلة لعدم وجود إحداثيات' : 'Liens désactivés (coordonnées absentes)'}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyLink}
                  disabled={!isValidCoords}
                  className={`px-3 py-2 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                    !isValidCoords 
                      ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                      : copiedLink 
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 cursor-pointer' 
                        : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-700 cursor-pointer'
                  }`}
                  title={t.location?.copyLink}
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                  <span>{copiedLink ? (lang === 'ar' ? 'تم النسخ!' : 'Copié !') : (t.location?.copyLink || 'نسخ الرابط')}</span>
                </button>

                <button
                  onClick={handleCopyCoords}
                  disabled={!isValidCoords}
                  className={`hidden sm:inline-flex px-3 py-2 rounded-xl border text-xs font-bold transition-all items-center gap-1.5 ${
                    !isValidCoords 
                      ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                      : copiedCoords 
                        ? 'bg-emerald-100 border-emerald-300 text-emerald-800 cursor-pointer' 
                        : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-700 cursor-pointer'
                  }`}
                  title={t.location?.copyCoordinates}
                >
                  {copiedCoords ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <MapPin className="w-3.5 h-3.5 text-slate-500" />}
                  <span>{copiedCoords ? (lang === 'ar' ? 'تم النسخ!' : 'Copié !') : (t.location?.copyCoordinates || 'نسخ الإحداثيات')}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Location Details & Access Points */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sm:p-6 space-y-5">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Building2 className="w-5 h-5 text-emerald-600" />
              <span>{t.location?.addressSection || 'العنوان الرسمي والمعالم'}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Full Address Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'ar' ? 'العنوان البريدي الكامل' : 'Adresse postale'}</span>
                </div>
                <div className="text-sm font-bold text-slate-900 leading-relaxed">
                  {lang === 'ar' ? locationInfo.fullAddressAr : locationInfo.fullAddressFr}
                </div>
                <div className="text-xs text-slate-500 font-medium pt-1">
                  {lang === 'ar' ? 'المدينة:' : 'Ville:'} <span className="text-slate-800 font-semibold">{locationInfo.city}</span> | {locationInfo.country}
                </div>
              </div>

              {/* Syndic Office Card */}
              <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{t.location?.syndicOffice || 'مكتب السانديك'}</span>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <Bot className="w-3 h-3 text-emerald-700" />
                    {lang === 'ar' ? 'خانة الذكاء الاصطناعي (AI)' : 'Espace IA'}
                  </span>
                </div>
                <div className="text-sm font-bold text-emerald-950">
                  {lang === 'ar' ? locationInfo.syndicOfficeLocationAr : locationInfo.syndicOfficeLocationFr}
                </div>
                <div className="text-xs text-emerald-800 font-medium">
                  {lang === 'ar' ? 'المجموعات السكنية:' : 'Groupes:'} 20 عمارة (GH34 A - GH43 A & GH34 B - GH43 B)
                </div>
                {isAdminOrSyndic ? (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (onCloseModal) onCloseModal();
                        setActiveSection('syndic-office');
                      }}
                      className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                    >
                      <Bot className="w-4 h-4 text-cyan-200" />
                      <span>{lang === 'ar' ? 'الدخول لمكتب السانديك والمساعد الذكي 🤖' : 'Accéder au Bureau & Assistant IA'}</span>
                    </button>
                  </div>
                ) : (
                  <div className="pt-1">
                    <div className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 text-slate-600 text-xs font-semibold border border-slate-200">
                      <Lock className="w-3.5 h-3.5 text-slate-500" />
                      <span>{lang === 'ar' ? 'مكتب السانديك ونظام IA مخصص للإدارة فقط' : 'Bureau Syndic & IA réservé exclusivement à l\'administration'}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Main Entrance & Security Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{t.location?.mainEntrance || 'البوابة الرئيسية'}</span>
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {lang === 'ar' ? locationInfo.mainEntranceAr : locationInfo.mainEntranceFr}
                </div>
              </div>

              {/* Landmarks & Accessibility Card */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-amber-600" />
                  <span>{t.location?.landmarks || 'أبرز المعالم المجاورة'}</span>
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {lang === 'ar' ? locationInfo.landmarksAr : locationInfo.landmarksFr}
                </div>
              </div>
            </div>

            {/* Notes & Instructions for Delivery / Visitors */}
            <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-950 text-xs sm:text-sm leading-relaxed flex items-start gap-3">
              <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-amber-900 mb-0.5">
                  {t.location?.notesForVisitors || 'إرشادات للزوار وعمال التوصيل'}
                </div>
                <p className="text-amber-800">
                  {lang === 'ar' ? locationInfo.notesAr : locationInfo.notesFr}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Quick Share, QR Code & Emergency Contacts (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Quick Share Widget Box */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                <Send className="w-4 h-4 text-emerald-600" />
                <span>{t.location?.quickSendToVisitor || 'إرسال سريع للزائر أو عامل التوصيل'}</span>
              </h3>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t.location?.recipientOptional || 'اسم المستلم / الزائر (اختياري)'}
                </label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: السائق / عامل التوصيل / الضيف' : 'Ex: Livreur, Chauffeur, Visiteur'}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-slate-50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'رقم هاتف الواتساب (اختياري)' : 'Numéro WhatsApp (optionnel)'}
                </label>
                <input
                  type="tel"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  placeholder="06XXXXXXXX"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-slate-50"
                />
              </div>

              {/* Destination Building / Apartment Pickers */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'العمارة' : 'Bâtiment'}
                  </label>
                  <select
                    value={selectedBuilding}
                    onChange={(e) => setSelectedBuilding(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 bg-white"
                  >
                    <option value="">{lang === 'ar' ? '-- بدون تحديد --' : '-- Non spécifié --'}</option>
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'الشقة' : 'Appartement'}
                  </label>
                  <input
                    type="text"
                    value={selectedApartment}
                    onChange={(e) => setSelectedApartment(e.target.value)}
                    placeholder={lang === 'ar' ? 'شقة 12' : 'Apt 12'}
                    className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 bg-white"
                  />
                </div>
              </div>

              {/* Action Trigger Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={() => handleWhatsAppSend()}
                  className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs sm:text-sm shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{t.location?.shareViaWhatsApp || 'مشاركة عبر واتساب'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-200"
                >
                  <Share2 className="w-3.5 h-3.5 text-slate-600" />
                  <span>{t.location?.shareNative || 'مشاركة عبر الهاتف'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyFullGuide}
                  className="w-full py-2 px-3 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-300"
                >
                  {copiedGuide ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                  <span>{copiedGuide ? (lang === 'ar' ? 'تم نسخ النص كاملاً!' : 'Guide complet copié !') : (t.location?.copyFullGuide || 'نسخ الرسالة كاملة')}</span>
                </button>
              </div>
            </div>
          </div>

          {/* QR Code Navigation Box */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 text-center space-y-3">
            <div className="flex items-center justify-center gap-2 font-bold text-slate-900 text-sm">
              <QrCode className="w-4 h-4 text-emerald-600" />
              <span>{t.location?.qrCodeTitle || 'رمز QR للملاحة المباشرة'}</span>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              {t.location?.qrCodeDesc || 'امسح الرمز بكاميرا الهاتف للوصول المباشر إلى مدخل الإقامة عبر خرائط جوجل'}
            </p>

            {isValidCoords ? (
              <>
                <div className="flex justify-center p-3 bg-emerald-50/50 rounded-2xl border border-emerald-100 inline-block mx-auto">
                  <img
                    src={qrCodeUrl}
                    alt="QR Code Navigation"
                    className="w-44 h-44 object-contain rounded-xl shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex items-center justify-center gap-2 pt-1">
                  <a
                    href={qrCodeUrl}
                    download="Residence-Location-QR.png"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.location?.downloadQr || 'تحميل QR'}</span>
                  </a>

                  <button
                    type="button"
                    onClick={handlePrint}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-500" />
                    <span>{lang === 'ar' ? 'طباعة' : 'Imprimer'}</span>
                  </button>
                </div>
              </>
            ) : (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500">
                {lang === 'ar' ? 'رمز QR سيتوفر بعد حفظ إحداثيات صالحة' : 'QR Code disponible après enregistrement des coordonnées'}
              </div>
            )}
          </div>

          {/* Quick Contact & Emergency Card */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl shadow-sm p-5 space-y-3">
            <div className="font-bold text-sm text-emerald-300 flex items-center gap-2 border-b border-slate-700 pb-2.5">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>{t.location?.contactInfo || 'أرقام التواصل والاستقبال'}</span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">{lang === 'ar' ? 'هاتف السانديك:' : 'Tél Syndic:'}</span>
                <a href={`tel:${locationInfo.contactPhone}`} className="font-bold text-white hover:text-emerald-300 transition-colors">
                  {locationInfo.contactPhone}
                </a>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">{lang === 'ar' ? 'أمن وحراسة الإقامة:' : 'Sécurité 24/7:'}</span>
                <a href={`tel:${locationInfo.securityPhone}`} className="font-bold text-emerald-300 hover:underline">
                  {locationInfo.securityPhone}
                </a>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-400">{lang === 'ar' ? 'البريد الإلكتروني:' : 'Email:'}</span>
                <a href={`mailto:${locationInfo.email}`} className="font-bold text-white hover:text-emerald-300 truncate max-w-[170px]">
                  {locationInfo.email}
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Share Modal Dialog (When clicking primary "إرسال الموقع بالضبط" button) */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div 
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-5 sm:p-6 space-y-5 animate-in zoom-in-95 duration-200"
            dir={isRtl ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <Send className="w-5 h-5 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {t.location?.sendExactLocationBtn || (lang === 'ar' ? 'إرسال الموقع بالضبط' : 'Envoyer la localisation')}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'ar' ? `مشاركة الموقع الجغرافي لـ ${locationInfo.name}` : `Partager l'adresse de ${locationInfo.nameFr}`}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsShareModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Preview Box */}
            <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs text-slate-800 space-y-1.5">
              <div className="font-bold text-emerald-950 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                <span>{locationInfo.name} ({locationInfo.city})</span>
              </div>
              <div className="text-slate-600 text-[11px] leading-relaxed">
                {lang === 'ar' ? locationInfo.fullAddressAr : locationInfo.fullAddressFr}
              </div>
              {isValidCoords ? (
                <div className="text-emerald-800 font-mono text-[10px] pt-1">
                  GPS: {locationInfo.latitude}, {locationInfo.longitude}
                </div>
              ) : (
                <div className="text-amber-800 text-[10px] font-bold pt-1">
                  {lang === 'ar' ? 'تنبيه: الإحداثيات غير محددة (سيتم إرسال العنوان النصي فقط)' : 'Attention : Coordonnées non définies'}
                </div>
              )}
            </div>

            {/* Quick Actions List */}
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => {
                  handleWhatsAppSend();
                  setIsShareModalOpen(false);
                }}
                className="w-full p-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-5 h-5" />
                  <span>{lang === 'ar' ? 'إرسال عبر واتساب (WhatsApp)' : 'Envoyer par WhatsApp'}</span>
                </div>
                <ExternalLink className="w-4 h-4 opacity-80" />
              </button>

              <button
                type="button"
                onClick={() => {
                  handleNativeShare();
                  setIsShareModalOpen(false);
                }}
                className="w-full p-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm shadow-sm transition-all flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Share2 className="w-5 h-5" />
                  <span>{lang === 'ar' ? 'مشاركة عبر تطبيقات الهاتف' : 'Partager sur mobile (Share)'}</span>
                </div>
                <Smartphone className="w-4 h-4 opacity-80" />
              </button>

              {isValidCoords && (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <a
                    href={googleMapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer text-center"
                  >
                    <Navigation className="w-3.5 h-3.5 text-blue-600" />
                    <span>Google Maps</span>
                  </a>

                  <a
                    href={wazeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer text-center"
                  >
                    <Car className="w-3.5 h-3.5 text-cyan-600" />
                    <span>Waze App</span>
                  </a>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleCopyLink}
                  disabled={!isValidCoords}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                    !isValidCoords ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-transparent cursor-pointer'
                  }`}
                >
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>{t.location?.copyLink || 'نسخ الرابط'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyFullGuide}
                  className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>{t.location?.copyFullGuide || 'نسخ الدليل'}</span>
                </button>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs cursor-pointer"
              >
                {t.common?.close || 'إغلاق'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Full Details Edit Modal */}
      {isFullEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div 
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-5 sm:p-6 space-y-5 my-8 animate-in zoom-in-95 duration-200"
            dir={isRtl ? 'rtl' : 'ltr'}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">
                  {lang === 'ar' ? 'تعديل بيانات الموقع والإقامة الشاملة' : 'Modifier toutes les données de localisation'}
                </h3>
              </div>
              <button
                onClick={() => setIsFullEditModalOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">اسم الإقامة (عربي)</label>
                <input
                  type="text"
                  value={fullEditForm.name}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nom de Résidence (FR)</label>
                <input
                  type="text"
                  value={fullEditForm.nameFr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, nameFr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Latitude (خط العرض)</label>
                <input
                  type="number"
                  step="any"
                  value={fullEditForm.latitude}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, latitude: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Longitude (خط الطول)</label>
                <input
                  type="number"
                  step="any"
                  value={fullEditForm.longitude}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, longitude: parseFloat(e.target.value) || 0 }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">المدينة / الإقليم</label>
                <input
                  type="text"
                  value={fullEditForm.city}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, city: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">الدولة</label>
                <input
                  type="text"
                  value={fullEditForm.country}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, country: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">العنوان الكامل (عربي)</label>
                <input
                  type="text"
                  value={fullEditForm.fullAddressAr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, fullAddressAr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">Adresse Complète (FR)</label>
                <input
                  type="text"
                  value={fullEditForm.fullAddressFr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, fullAddressFr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">موقع مكتب السانديك</label>
                <input
                  type="text"
                  value={fullEditForm.syndicOfficeLocationAr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, syndicOfficeLocationAr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">البوابة الرئيسية والحراسة</label>
                <input
                  type="text"
                  value={fullEditForm.mainEntranceAr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, mainEntranceAr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">هاتف السانديك</label>
                <input
                  type="text"
                  value={fullEditForm.contactPhone}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, contactPhone: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">هاتف الحراسة والأمن</label>
                <input
                  type="text"
                  value={fullEditForm.securityPhone}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, securityPhone: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1">ملاحظات وإرشادات للزوار (عربي)</label>
                <textarea
                  rows={2}
                  value={fullEditForm.notesAr}
                  onChange={(e) => setFullEditForm(prev => ({ ...prev, notesAr: e.target.value }))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-slate-50"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleResetDefaults}
                className="px-3 py-2 rounded-lg text-rose-600 hover:bg-rose-50 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.location?.resetDefaults || 'استرجاع الافتراضي'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsFullEditModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  {t.common?.cancel || 'إلغاء'}
                </button>
                <button
                  type="button"
                  onClick={handleSaveFullEditModal}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{t.common?.save || 'حفظ'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
