import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Expense, ExpenseCategory, PaymentMethod } from '../types';
import { 
  Receipt, Plus, Search, Trash2, Edit2, Check, X, Zap, Droplet, Sparkles, Shield, 
  Wrench, Package, Lock, Archive, Printer, FileSpreadsheet, Users, Briefcase, 
  Hammer, Droplets, FileText, Scale, Gavel, Calendar, AlertTriangle, Clock, Calculator
} from 'lucide-react';
import { exportExpensesToExcel } from '../utils/exportUtils';
import { ExpensesExportModal } from './ExpensesExportModal';
import { 
  getAvailableMonthsList, 
  filterPaymentsByMonth, 
  filterExpensesByMonth, 
  ARABIC_MONTH_NAMES, 
  FRENCH_MONTH_NAMES 
} from '../utils/monthlyFinanceUtils';
import { checkDuplicateExpense } from '../utils/duplicateCheckUtils';
import { DuplicateWarningModal } from './DuplicateWarningModal';
import { ReceiptText as HeaderIcon } from 'lucide-react';

export const ExpensesView: React.FC = () => {
  const { 
    t, lang, currentUser, expenses, payments, buildings, 
    addExpense, updateExpense, deleteExpense, setActiveSection, archivedExpenses 
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('ALL');
  const [filterMonth, setFilterMonth] = useState<string>('2026-05');
  const [filterType, setFilterType] = useState<'ALL' | 'INVOICES' | 'SALARIES'>('ALL');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Form State (Quick Expense)
  const [quickCategory, setQuickCategory] = useState<ExpenseCategory>('electricity');
  const [quickTitle, setQuickTitle] = useState('');
  const [quickAmount, setQuickAmount] = useState<number | ''>('');

  // Form State (New Expense)
  const [category, setCategory] = useState<ExpenseCategory>('electricity');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState(500);
  const [buildingCode, setBuildingCode] = useState('ALL');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [supplier, setSupplier] = useState('');
  const [invoiceRef, setInvoiceRef] = useState('');
  const [paidBy, setPaidBy] = useState('مكتب السانديك');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');

  // Edit Expense / Invoice State
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editCategory, setEditCategory] = useState<ExpenseCategory>('electricity');
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editBuildingCode, setEditBuildingCode] = useState('ALL');
  const [editDate, setEditDate] = useState('');
  const [editSupplier, setEditSupplier] = useState('');
  const [editInvoiceRef, setEditInvoiceRef] = useState('');
  const [editPaidBy, setEditPaidBy] = useState('مكتب السانديك');
  const [editPaymentMethod, setEditPaymentMethod] = useState<PaymentMethod>('bank_transfer');

  // Duplicate Expense Warning Modal State
  const [duplicateExpenseModal, setDuplicateExpenseModal] = useState<{
    isOpen: boolean;
    existingExpense?: Expense;
    candidateExpense?: {
      title: string;
      category?: string;
      amount: number;
      date: string;
      supplier?: string;
      invoiceRef?: string;
    };
    customMessage?: string;
    onConfirm: () => void;
  } | null>(null);

  // Live duplicate check for main expense form
  const duplicateExpenseCheck = useMemo(() => {
    if (!isFormOpen || (!title.trim() && !invoiceRef.trim())) {
      return { isDuplicate: false, messageAr: '', messageFr: '' };
    }
    return checkDuplicateExpense(expenses, {
      title,
      category,
      amount: Number(amount) || 0,
      date,
      supplier,
      invoiceRef
    });
  }, [isFormOpen, expenses, title, category, amount, date, supplier, invoiceRef]);

  // Live duplicate check for quick add expense modal
  const quickDuplicateExpenseCheck = useMemo(() => {
    if (!isQuickAddOpen || !quickTitle.trim()) {
      return { isDuplicate: false, messageAr: '', messageFr: '' };
    }
    return checkDuplicateExpense(expenses, {
      title: quickTitle,
      category: quickCategory,
      amount: Number(quickAmount) || 0,
      date: new Date().toISOString().slice(0, 10),
      supplier: 'شركة خدمات',
    });
  }, [isQuickAddOpen, expenses, quickTitle, quickCategory, quickAmount]);

  // Delete Expense / Invoice Confirmation Modal
  const [deletingExpense, setDeletingExpense] = useState<Expense | null>(null);

  const handleOpenNew = () => {
    if (isOwner) return;
    setTitle('');
    setCategory('electricity');
    setAmount(500);
    setBuildingCode('ALL');
    setDate(new Date().toISOString().slice(0, 10));
    setSupplier('');
    setInvoiceRef('');
    setPaidBy('مكتب السانديك');
    setPaymentMethod('bank_transfer');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (exp: Expense) => {
    if (isOwner) return;
    setEditingExpense(exp);
    setEditTitle(exp.title);
    setEditCategory(exp.category);
    setEditAmount(exp.amount);
    setEditBuildingCode(exp.buildingCode || 'ALL');
    setEditDate(exp.date || new Date().toISOString().slice(0, 10));
    setEditSupplier(exp.supplier || '');
    setEditInvoiceRef(exp.invoiceRef || '');
    setEditPaidBy(exp.paidBy || 'مكتب السانديك');
    setEditPaymentMethod(exp.paymentMethod || 'bank_transfer');
  };

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!quickTitle.trim() || !quickAmount) return;

    const expData = {
      category: quickCategory,
      title: quickTitle.trim(),
      amount: Number(quickAmount),
      buildingCode: 'ALL',
      date: new Date().toISOString().slice(0, 10),
      supplier: 'شركة خدمات',
      invoiceRef: '',
      paidBy: 'مكتب السانديك',
      paymentMethod: 'cash' as PaymentMethod,
    };

    // Check for duplicate expense
    const dupCheck = checkDuplicateExpense(expenses, expData);
    if (dupCheck.isDuplicate) {
      setDuplicateExpenseModal({
        isOpen: true,
        existingExpense: dupCheck.existingExpense,
        candidateExpense: {
          title: expData.title,
          category: expData.category,
          amount: expData.amount,
          date: expData.date,
          supplier: expData.supplier
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          addExpense(expData);
          setQuickTitle('');
          setQuickAmount('');
          setIsQuickAddOpen(false);
        }
      });
      return;
    }

    addExpense(expData);
    if (expData.date) {
      setFilterMonth(expData.date.slice(0, 7));
    }
    setQuickTitle('');
    setQuickAmount('');
    setIsQuickAddOpen(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!title.trim() || !amount) return;

    const expData = {
      category,
      title: title.trim(),
      amount: Number(amount),
      buildingCode,
      date,
      supplier: supplier || 'شركة خدمات',
      invoiceRef: invoiceRef.trim(),
      paidBy,
      paymentMethod,
    };

    // Check for duplicate expense
    const dupCheck = checkDuplicateExpense(expenses, expData);
    if (dupCheck.isDuplicate) {
      setDuplicateExpenseModal({
        isOpen: true,
        existingExpense: dupCheck.existingExpense,
        candidateExpense: {
          title: expData.title,
          category: expData.category,
          amount: expData.amount,
          date: expData.date,
          supplier: expData.supplier,
          invoiceRef: expData.invoiceRef
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          addExpense(expData);
          if (expData.date) {
            setFilterMonth(expData.date.slice(0, 7));
          }
          setIsFormOpen(false);
        }
      });
      return;
    }

    addExpense(expData);
    if (expData.date) {
      setFilterMonth(expData.date.slice(0, 7));
    }
    setIsFormOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpense || isOwner) return;
    if (!editTitle.trim() || !editAmount) return;

    const dupCheck = checkDuplicateExpense(expenses, {
      title: editTitle.trim(),
      category: editCategory,
      amount: Number(editAmount),
      date: editDate,
      supplier: editSupplier.trim() || 'شركة خدمات',
      invoiceRef: editInvoiceRef.trim(),
      excludeId: editingExpense.id
    });

    if (dupCheck.isDuplicate) {
      setDuplicateExpenseModal({
        isOpen: true,
        existingExpense: dupCheck.existingExpense,
        candidateExpense: {
          title: editTitle.trim(),
          category: editCategory,
          amount: Number(editAmount),
          date: editDate,
          supplier: editSupplier.trim() || 'شركة خدمات',
          invoiceRef: editInvoiceRef.trim(),
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          updateExpense(editingExpense.id, {
            title: editTitle.trim(),
            category: editCategory,
            amount: Number(editAmount),
            buildingCode: editBuildingCode,
            date: editDate,
            supplier: editSupplier.trim() || 'شركة خدمات',
            invoiceRef: editInvoiceRef.trim(),
            paidBy: editPaidBy.trim(),
            paymentMethod: editPaymentMethod,
          });
          setEditingExpense(null);
        }
      });
      return;
    }

    updateExpense(editingExpense.id, {
      title: editTitle.trim(),
      category: editCategory,
      amount: Number(editAmount),
      buildingCode: editBuildingCode,
      date: editDate,
      supplier: editSupplier.trim() || 'شركة خدمات',
      invoiceRef: editInvoiceRef.trim(),
      paidBy: editPaidBy.trim(),
      paymentMethod: editPaymentMethod,
    });

    setEditingExpense(null);
  };

  const handleConfirmDelete = () => {
    if (!deletingExpense || isOwner) return;
    deleteExpense(deletingExpense.id);
    setDeletingExpense(null);
  };

  const getCategoryLabel = (cat: ExpenseCategory) => {
    switch (cat) {
      case 'worker_salaries': return t.expenses.catWorkerSalaries;
      case 'syndic_fees': return t.expenses.catSyndicAgent;
      case 'cleaning_supplies': return t.expenses.catCleaningSupplies;
      case 'electrical_supplies': return t.expenses.catElectricalSupplies;
      case 'hardware_droguerie': return t.expenses.catHardwareDroguerie;
      case 'building_materials': return t.expenses.catBuildingMaterials;
      case 'irrigation_tools': return t.expenses.catIrrigationTools;
      case 'office_stationery': return t.expenses.catOfficeStationery;
      case 'lawyer_fees': return t.expenses.catLawyerFees;
      case 'bailiff_fees': return t.expenses.catBailiffFees;
      case 'electricity': return t.expenses.catElectricity;
      case 'water': return t.expenses.catWater;
      case 'cleaning_company': return t.expenses.catCleaning;
      case 'security_company': return t.expenses.catSecurity;
      case 'emergency_repairs': return t.expenses.catEmergency;
      case 'supplies': return t.expenses.catSupplies;
      default: return t.expenses.catOther;
    }
  };

  const getMethodLabel = (m: PaymentMethod) => {
    switch (m) {
      case 'cash': return t.payments.methodCash;
      case 'check': return t.payments.methodCheck;
      case 'bank_transfer': return t.payments.methodTransfer;
      case 'online': return t.payments.methodOnline;
      default: return m;
    }
  };

  const getCategoryIcon = (cat: ExpenseCategory) => {
    switch (cat) {
      case 'worker_salaries': return <Users className="w-4 h-4 text-sky-600" />;
      case 'syndic_fees': return <Briefcase className="w-4 h-4 text-amber-600" />;
      case 'cleaning_supplies': return <Sparkles className="w-4 h-4 text-emerald-600" />;
      case 'electrical_supplies': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'hardware_droguerie': return <Wrench className="w-4 h-4 text-orange-600" />;
      case 'building_materials': return <Hammer className="w-4 h-4 text-stone-600" />;
      case 'irrigation_tools': return <Droplets className="w-4 h-4 text-teal-600" />;
      case 'office_stationery': return <FileText className="w-4 h-4 text-blue-600" />;
      case 'lawyer_fees': return <Scale className="w-4 h-4 text-purple-600" />;
      case 'bailiff_fees': return <Gavel className="w-4 h-4 text-rose-600" />;
      case 'electricity': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'water': return <Droplet className="w-4 h-4 text-blue-500" />;
      case 'cleaning_company': return <Sparkles className="w-4 h-4 text-emerald-500" />;
      case 'security_company': return <Shield className="w-4 h-4 text-indigo-500" />;
      case 'emergency_repairs': return <Wrench className="w-4 h-4 text-red-500" />;
      default: return <Package className="w-4 h-4 text-slate-500" />;
    }
  };

  const availableMonths = useMemo(() => getAvailableMonthsList(payments, expenses), [payments, expenses]);

  const filteredExpenses = expenses.filter(e => {
    const matchesSearch = 
      e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.invoiceRef && e.invoiceRef.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesCategory = filterCategory === 'ALL' || e.category === filterCategory;
    const matchesMonth = filterMonth === 'ALL' || (e.date && e.date.startsWith(filterMonth));

    const isSalary = e.category === 'worker_salaries' || e.category === 'syndic_fees';
    const matchesType = 
      filterType === 'ALL' ? true :
      filterType === 'SALARIES' ? isSalary :
      !isSalary;

    return matchesSearch && matchesCategory && matchesMonth && matchesType;
  });

  const totalFilteredExpenses = filteredExpenses.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  // Month-specific calculations (مداخيل ومصاريف الشهر المحدد)
  const monthPayments = useMemo(() => filterPaymentsByMonth(payments, filterMonth), [payments, filterMonth]);
  const monthExpenses = useMemo(() => filterExpensesByMonth(expenses, filterMonth), [expenses, filterMonth]);
  const monthIncomeTotal = useMemo(() => monthPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0), [monthPayments]);
  const monthExpenseTotal = useMemo(() => monthExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0), [monthExpenses]);
  const monthNetBalance = monthIncomeTotal - monthExpenseTotal;

  const monthLabel = useMemo(() => {
    if (filterMonth === 'ALL') return lang === 'ar' ? 'جميع الشهور (الإجمالي الشامل)' : 'Tous les mois (Cumul)';
    const [y, m] = filterMonth.split('-');
    return lang === 'ar' ? `${ARABIC_MONTH_NAMES[m] || m} ${y}` : `${FRENCH_MONTH_NAMES[m] || m} ${y}`;
  }, [filterMonth, lang]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative overflow-hidden bg-white p-5 rounded-2xl border border-slate-200 border-t-4 border-t-rose-500 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-rose-400 to-rose-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.expenses.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">{t.expenses.subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Export PDF Button */}
          <button
            type="button"
            id="btn-open-expenses-pdf-modal"
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all border border-slate-200 cursor-pointer shadow-2xs"
            title={t.expenses.exportTooltip}
          >
            <Printer className="w-4 h-4 text-slate-800" />
            <span>{t.expenses.exportPdf}</span>
          </button>

          {/* Export Excel (CSV) Button */}
          <button
            type="button"
            id="btn-direct-expenses-excel"
            onClick={() => exportExpensesToExcel(filteredExpenses, buildings, lang, getCategoryLabel, getMethodLabel, filterCategory)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all border border-amber-200 cursor-pointer shadow-2xs"
            title={t.expenses.exportTooltip}
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-700" />
            <span>{t.expenses.exportExcel}</span>
          </button>

          {/* Budget Simulator Button */}
          <button
            type="button"
            id="btn-expenses-budget-simulator"
            onClick={() => setActiveSection('budget-simulator')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-900 text-xs font-bold transition-all border border-indigo-200 cursor-pointer shadow-2xs"
            title={lang === 'ar' ? 'محاكاة الميزانية التقديرية للسنة القادمة وأثرها على واجبات السنديك' : 'Simulateur du budget prévisionnel'}
          >
            <Calculator className="w-4 h-4 text-indigo-700" />
            <span>{lang === 'ar' ? 'محاكاة الميزانية القادمة 🧮' : 'Simulateur Budget'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('archive')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all border border-slate-200 cursor-pointer"
          >
            <Archive className="w-4 h-4 text-slate-600" />
            <span>{t.nav.archive}</span>
            {archivedExpenses.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-800 text-[10px]">
                {archivedExpenses.length}
              </span>
            )}
          </button>

          {!isOwner ? (
            <button
              onClick={handleOpenNew}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.expenses.addBtn}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>{lang === 'ar' ? 'تقرير الشفافية المالية (اطلاع فقط)' : 'Transparence des dépenses'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Form Modal / Box (Syndic only) */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-[#0a8591] shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-[#0a8591] flex items-center gap-2">
              <Receipt className="w-5 h-5 text-[#0a8591]" />
              <span>{t.expenses.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.titleLabel} *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="فاتورة كهرباء المرافق المشتركة، صيانة المضخات، مواد نظافة..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.category} *</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white font-medium"
                >
                  <optgroup label={t.expenses.title || "أبواب المصاريف الرسمية"}>
                    <option value="worker_salaries">1. {t.expenses.catWorkerSalaries}</option>
                    <option value="syndic_fees">2. {t.expenses.catSyndicAgent}</option>
                    <option value="cleaning_supplies">3. {t.expenses.catCleaningSupplies}</option>
                    <option value="electrical_supplies">4. {t.expenses.catElectricalSupplies}</option>
                    <option value="hardware_droguerie">5. {t.expenses.catHardwareDroguerie}</option>
                    <option value="building_materials">6. {t.expenses.catBuildingMaterials}</option>
                    <option value="irrigation_tools">7. {t.expenses.catIrrigationTools}</option>
                    <option value="office_stationery">8. {t.expenses.catOfficeStationery}</option>
                    <option value="lawyer_fees">9. {t.expenses.catLawyerFees}</option>
                    <option value="bailiff_fees">10. {t.expenses.catBailiffFees}</option>
                  </optgroup>
                  <optgroup label="مصاريف وخدمات أخرى">
                    <option value="emergency_repairs">{t.expenses.catEmergency}</option>
                    <option value="water">{t.expenses.catWater}</option>
                    <option value="electricity">{t.expenses.catElectricity}</option>
                    <option value="other">{t.expenses.catOther}</option>
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.amount} (DH) *</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={amount}
                  onChange={e => setAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.building}</label>
                <select
                  value={buildingCode}
                  onChange={e => setBuildingCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white"
                >
                  <option value="ALL">{t.expenses.allResidence}</option>
                  {buildings.map(b => (
                    <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.date}</label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.supplier}</label>
                <input
                  type="text"
                  value={supplier}
                  onChange={e => setSupplier(e.target.value)}
                  placeholder="شركة OTIS، ليدك، ريضال..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.invoiceRef}</label>
                <input
                  type="text"
                  value={invoiceRef}
                  onChange={e => setInvoiceRef(e.target.value)}
                  placeholder="FAC-2026-081"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.method}</label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white"
                >
                  <option value="bank_transfer">{t.payments.methodTransfer}</option>
                  <option value="check">{t.payments.methodCheck}</option>
                  <option value="cash">{t.payments.methodCash}</option>
                </select>
              </div>
            </div>

            {/* Live Duplicate Warning Banner */}
            {duplicateExpenseCheck.isDuplicate && (
              <div className="p-3.5 rounded-xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex items-start gap-3 animate-in fade-in">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs w-full">
                  <div className="font-bold flex items-center justify-between text-amber-900">
                    <span className="flex items-center gap-1.5">
                      ⚠️ {lang === 'ar' ? 'تنبيه تكرار المصروف: نفقة مشابهة مسجلة مسبقاً!' : 'Attention : Dépense similaire déjà enregistrée !'}
                    </span>
                    <span className="text-[10px] bg-amber-200/80 text-amber-900 font-bold px-2 py-0.5 rounded-md">
                      {lang === 'ar' ? 'نظام التحقق الذكي' : 'Détection doublon'}
                    </span>
                  </div>
                  <p className="text-amber-800 leading-relaxed">
                    {lang === 'ar' ? duplicateExpenseCheck.messageAr : duplicateExpenseCheck.messageFr}
                  </p>
                  {duplicateExpenseCheck.existingExpense && (
                    <div className="mt-1.5 p-2 bg-white/90 rounded-lg border border-amber-200 text-[11px] font-mono flex flex-wrap items-center gap-x-4 gap-y-1">
                      <span>{lang === 'ar' ? 'العنوان:' : 'Intitulé :'} <strong>{duplicateExpenseCheck.existingExpense.title}</strong></span>
                      <span>{lang === 'ar' ? 'المبلغ:' : 'Montant :'} <strong>{duplicateExpenseCheck.existingExpense.amount} DH</strong></span>
                      <span>{lang === 'ar' ? 'التاريخ:' : 'Date :'} <strong>{duplicateExpenseCheck.existingExpense.date}</strong></span>
                      {duplicateExpenseCheck.existingExpense.invoiceRef && (
                        <span>{lang === 'ar' ? 'رقم الفاتورة:' : 'N° Facture :'} <strong>{duplicateExpenseCheck.existingExpense.invoiceRef}</strong></span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Monthly Financial Reconciliation Banner (حساب كل شهر على حدة) */}
      <div className="bg-gradient-to-br from-[#0f172a] via-[#0f172a] to-[#0a8591] text-white p-5 rounded-2xl shadow-sm space-y-4 border border-[#0d5262]">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1.5 rounded-lg bg-white/10 text-rose-200">
                <Calendar className="w-4 h-4" />
              </span>
              <h2 className="text-sm sm:text-base font-black">
                {lang === 'ar' ? 'المحاسبة الشهرية: مصاريف ومداخيل كل شهر على حدة' : 'Comptabilité Mensuelle: Dépenses & Recettes par Mois'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-[#1e3a8a] text-white text-xs font-bold border border-white/20">
                {monthLabel}
              </span>
            </div>
            <p className="text-xs text-rose-100/80 mt-1">
              {lang === 'ar' 
                ? 'مقارنة دقيقة وفورية بين مصاريف هذا الشهر ومداخيله لتحديد الفائض أو العجز المالي للشهر' 
                : 'Comparaison directe entre dépenses et recettes du mois pour déterminer le solde net'}
            </p>
          </div>

          {/* Month Switcher Controls */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {[
              { key: '2026-05', labelAr: 'ماي 2026', labelFr: 'Mai 2026' },
              { key: '2026-06', labelAr: 'يونيو 2026', labelFr: 'Juin 2026' },
              { key: '2026-07', labelAr: 'يوليوز 2026', labelFr: 'Juillet 2026' },
              { key: '2026-08', labelAr: 'غشت 2026', labelFr: 'Août 2026' },
              { key: '2026-09', labelAr: 'شتنبر 2026', labelFr: 'Septembre 2026' },
            ].map(m => (
              <button
                key={m.key}
                type="button"
                id={`btn-exp-month-${m.key}`}
                onClick={() => setFilterMonth(m.key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  filterMonth === m.key
                    ? 'bg-white text-[#0a8591] shadow-xs'
                    : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
              >
                <span>{lang === 'ar' ? m.labelAr : m.labelFr}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" title="فائض مالي إيجابي" />
              </button>
            ))}

            <select
              id="select-exp-month-dropdown"
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-bold rounded-xl border border-white/20 bg-[#0f172a] text-white focus:outline-none cursor-pointer"
            >
              <optgroup label={lang === 'ar' ? 'الشهور المتاحة' : 'Mois Disponibles'}>
                {availableMonths.map(opt => (
                  <option key={opt.key} value={opt.key}>
                    {lang === 'ar' ? opt.labelAr : opt.labelFr}
                  </option>
                ))}
              </optgroup>
              <option value="ALL">{lang === 'ar' ? '📊 جميع الشهور (الإجمالي الشامل)' : '📊 Tous les mois'}</option>
            </select>
          </div>
        </div>

        {/* 3 Metric Mini Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Month Expenses */}
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-xl border border-white/10">
            <span className="text-xs text-slate-300 font-bold block mb-1">
              {lang === 'ar' ? `💸 مصاريف ${monthLabel}` : `Dépenses ${monthLabel}`}
            </span>
            <div className="text-2xl font-black text-rose-300 font-mono">
              {monthExpenseTotal.toLocaleString()} <span className="text-xs text-slate-300">DH</span>
            </div>
            <span className="text-[11px] text-slate-300 mt-1 block">
              {monthExpenses.length} {lang === 'ar' ? 'فواتير ونفقات مسجلة' : 'factures'}
            </span>
          </div>

          {/* Month Income */}
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-xl border border-white/10">
            <span className="text-xs text-emerald-300 font-bold block mb-1">
              {lang === 'ar' ? `💰 مداخيل ${monthLabel}` : `Recettes ${monthLabel}`}
            </span>
            <div className="text-2xl font-black text-emerald-300 font-mono">
              {monthIncomeTotal.toLocaleString()} <span className="text-xs text-emerald-200">DH</span>
            </div>
            <span className="text-[11px] text-emerald-200 mt-1 block">
              {monthPayments.length} {lang === 'ar' ? 'عمليات أداء محصلة' : 'paiements'}
            </span>
          </div>

          {/* Month Net Balance */}
          <div className={`p-4 rounded-xl border ${
            monthNetBalance >= 0 
              ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-100' 
              : 'bg-rose-500/20 border-rose-400/40 text-rose-100'
          }`}>
            <span className="text-xs font-bold block mb-1">
              {lang === 'ar' ? `⚖️ الرصيد الصافي لشهر ${monthLabel}` : `Solde Net ${monthLabel}`}
            </span>
            <div className="text-2xl font-black font-mono">
              {monthNetBalance >= 0 ? '+' : ''}{monthNetBalance.toLocaleString()} <span className="text-xs">DH</span>
            </div>
            <span className={`text-[11px] font-bold mt-1 inline-block px-2 py-0.5 rounded ${
              monthNetBalance >= 0 ? 'bg-emerald-800 text-emerald-100' : 'bg-rose-900 text-rose-100'
            }`}>
              {monthNetBalance >= 0 
                ? (lang === 'ar' ? 'فائض مالي إيجابي لشهر ' + monthLabel : 'Excédent budgétaire') 
                : (lang === 'ar' ? 'عجز مالي في الشهر' : 'Déficit mensuel')}
            </span>
          </div>
        </div>
      </div>

      {/* Filters & Total */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        {/* Type Filter Pills */}
        <div className="flex items-center gap-2 flex-wrap pb-2 border-b border-slate-100">
          <span className="text-xs font-bold text-slate-600">
            {lang === 'ar' ? 'نوع القيد المالي:' : 'Type de dépense:'}
          </span>
          <button
            type="button"
            id="filter-type-all"
            onClick={() => setFilterType('ALL')}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'ALL'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            {lang === 'ar' ? 'جميع المصاريف والنفقات' : 'Toutes les dépenses'}
          </button>
          <button
            type="button"
            id="filter-type-invoices"
            onClick={() => setFilterType('INVOICES')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'INVOICES'
                ? 'bg-purple-700 text-white shadow-2xs'
                : 'bg-purple-50 hover:bg-purple-100 text-purple-800'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'فواتير ومقتنيات وخدمات' : 'Factures & Achats'}</span>
          </button>
          <button
            type="button"
            id="filter-type-salaries"
            onClick={() => setFilterType('SALARIES')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'SALARIES'
                ? 'bg-sky-700 text-white shadow-2xs'
                : 'bg-sky-50 hover:bg-sky-100 text-sky-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'أجور العمال ووكيل الاتحاد' : 'Salaires du personnel'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder={t.expenses.searchPlaceholder}
              className="w-full ps-9 pe-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-800"
            />
          </div>

          <div>
            <select
              value={filterCategory}
              onChange={e => setFilterCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-800 font-medium"
            >
              <option value="ALL">{t.expenses.filterCategory}</option>
              <optgroup label="أبواب المصاريف الرسمية">
                <option value="worker_salaries">1. {t.expenses.catWorkerSalaries}</option>
                <option value="syndic_fees">2. {t.expenses.catSyndicAgent}</option>
                <option value="cleaning_supplies">3. {t.expenses.catCleaningSupplies}</option>
                <option value="electrical_supplies">4. {t.expenses.catElectricalSupplies}</option>
                <option value="hardware_droguerie">5. {t.expenses.catHardwareDroguerie}</option>
                <option value="building_materials">6. {t.expenses.catBuildingMaterials}</option>
                <option value="irrigation_tools">7. {t.expenses.catIrrigationTools}</option>
                <option value="office_stationery">8. {t.expenses.catOfficeStationery}</option>
                <option value="lawyer_fees">9. {t.expenses.catLawyerFees}</option>
                <option value="bailiff_fees">10. {t.expenses.catBailiffFees}</option>
              </optgroup>
              <optgroup label="أخرى">
                <option value="emergency_repairs">{t.expenses.catEmergency}</option>
                <option value="water">{t.expenses.catWater}</option>
                <option value="electricity">{t.expenses.catElectricity}</option>
              </optgroup>
            </select>
          </div>

          <div>
            <select
              value={filterMonth}
              onChange={e => setFilterMonth(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-800 font-medium"
            >
              <option value="ALL">{lang === 'ar' ? '📅 جميع شهور المصاريف' : 'Tous les mois'}</option>
              {availableMonths.map(opt => (
                <option key={opt.key} value={opt.key}>
                  {lang === 'ar' ? opt.labelAr : opt.labelFr}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-red-50 border border-red-200 text-xs">
            <span className="text-red-900 font-medium">مجموع المصاريف:</span>
            <span className="font-extrabold text-red-800 font-mono text-sm">
              {totalFilteredExpenses.toLocaleString()} DH
            </span>
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap text-xs text-start border-collapse">
            <thead>
              <tr className="bg-[#0a8591] text-white font-bold">
                <th className="p-3.5 text-start">{t.expenses.category}</th>
                <th className="p-3.5 text-start">{t.expenses.titleLabel}</th>
                <th className="p-3.5 text-start">{t.expenses.amount}</th>
                <th className="p-3.5 text-start">{t.expenses.building}</th>
                <th className="p-3.5 text-start">{t.expenses.supplier}</th>
                <th className="p-3.5 text-start">{t.expenses.invoiceRef}</th>
                <th className="p-3.5 text-start">{t.expenses.date}</th>
                {!isOwner && (
                  <th className="p-3.5 text-center">
                    {lang === 'ar' ? 'تغيير / مسح بالخطأ' : t.expenses.actions}
                  </th>
                )}
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={isOwner ? 7 : 8} className="text-center py-8 text-slate-400">
                    لا توجد مصاريف مطابقة للبحث
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((exp) => {
                  const isWorkerSalary = exp.category === 'worker_salaries' || exp.category === 'syndic_fees';
                  return (
                    <tr key={exp.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                            {getCategoryIcon(exp.category)}
                            <span>{getCategoryLabel(exp.category)}</span>
                          </div>
                          {isWorkerSalary ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-sky-100/70 text-sky-800 font-bold text-[10px]">
                              <Users className="w-2.5 h-2.5" />
                              <span>{lang === 'ar' ? 'أجرة عامل / سانديك' : 'Salaire'}</span>
                            </span>
                          ) : exp.invoiceRef ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-purple-100/70 text-purple-800 font-bold text-[10px]">
                              <Receipt className="w-2.5 h-2.5" />
                              <span>{lang === 'ar' ? 'فاتورة معتمدة' : 'Facture'}</span>
                            </span>
                          ) : null}
                        </div>
                      </td>
                      <td className="p-3 font-medium text-slate-900">
                        <div>{exp.title}</div>
                        {exp.paidBy && (
                          <div className="text-[10px] text-slate-400">
                            {lang === 'ar' ? `الأداء: ${exp.paidBy}` : `Payé par: ${exp.paidBy}`}
                          </div>
                        )}
                      </td>
                      <td className="p-3 font-extrabold text-red-700 font-mono text-sm">
                        {exp.amount.toLocaleString()} DH
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[11px] font-mono">
                          {exp.buildingCode === 'ALL' ? t.expenses.allResidence : exp.buildingCode}
                        </span>
                      </td>
                      <td className="p-3 text-slate-700 font-medium">
                        {exp.supplier}
                      </td>
                      <td className="p-3 font-mono text-slate-500 text-[11px]">
                        {exp.invoiceRef ? (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 font-bold">
                            {exp.invoiceRef}
                          </span>
                        ) : '-'}
                      </td>
                      <td className="p-3 text-slate-500 font-mono">
                        <div>{exp.date}</div>
                        {(exp.executedAtTime || exp.createdAt) && (
                          <div className="text-[10px] text-emerald-700 font-sans font-medium flex items-center gap-1 mt-0.5">
                            <Clock className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                            <span>{exp.executedAtTime || (exp.createdAt ? new Date(exp.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '')}</span>
                          </div>
                        )}
                      </td>
                      {!isOwner && (
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* زر التغيير والتعديل */}
                            <button
                              type="button"
                              id={`btn-edit-expense-${exp.id}`}
                              onClick={() => handleOpenEdit(exp)}
                              className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 hover:text-emerald-900 transition-colors cursor-pointer border border-emerald-200"
                              title={lang === 'ar' ? 'تعديل وتغيير الفاتورة أو المصروف المسجل بالخطأ' : 'Modifier la dépense'}
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            {/* زر المسح والحذف */}
                            <button
                              type="button"
                              id={`btn-delete-expense-${exp.id}`}
                              onClick={() => setDeletingExpense(exp)}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-800 transition-colors cursor-pointer border border-rose-200"
                              title={lang === 'ar' ? 'مسح الفاتورة أو المصروف المسجل بالخطأ' : 'Supprimer la dépense'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Expense / Invoice Modal (تعديل وتصحيح الفاتورة أو المصروف) */}
      {!isOwner && editingExpense && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-600/30 text-emerald-400">
                  <Edit2 className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base sm:text-lg font-bold">
                    {lang === 'ar' ? 'تعديل وتصحيح الفاتورة أو المصروف المسجل' : 'Modifier la facture / dépense enregistrée'}
                  </h2>
                  <p className="text-xs text-slate-300">
                    {lang === 'ar' 
                      ? 'تصحيح أي بيانات تم إدخالها عن طريق الخطأ (المبلغ، التاريخ، المورد أو العامل، الفئة)' 
                      : 'Correction des informations enregistrées par erreur'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingExpense(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.titleLabel} *</label>
                  <input
                    type="text"
                    required
                    value={editTitle}
                    onChange={e => setEditTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.category} *</label>
                  <select
                    value={editCategory}
                    onChange={e => setEditCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white font-medium"
                  >
                    <optgroup label="أبواب المصاريف الرسمية">
                      <option value="worker_salaries">1. {t.expenses.catWorkerSalaries}</option>
                      <option value="syndic_fees">2. {t.expenses.catSyndicAgent}</option>
                      <option value="cleaning_supplies">3. {t.expenses.catCleaningSupplies}</option>
                      <option value="electrical_supplies">4. {t.expenses.catElectricalSupplies}</option>
                      <option value="hardware_droguerie">5. {t.expenses.catHardwareDroguerie}</option>
                      <option value="building_materials">6. {t.expenses.catBuildingMaterials}</option>
                      <option value="irrigation_tools">7. {t.expenses.catIrrigationTools}</option>
                      <option value="office_stationery">8. {t.expenses.catOfficeStationery}</option>
                      <option value="lawyer_fees">9. {t.expenses.catLawyerFees}</option>
                      <option value="bailiff_fees">10. {t.expenses.catBailiffFees}</option>
                    </optgroup>
                    <optgroup label="مصاريف وخدمات أخرى">
                      <option value="emergency_repairs">{t.expenses.catEmergency}</option>
                      <option value="water">{t.expenses.catWater}</option>
                      <option value="electricity">{t.expenses.catElectricity}</option>
                      <option value="other">{t.expenses.catOther}</option>
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.amount} (DH) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={editAmount}
                    onChange={e => setEditAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'تاريخ الأداء والصرف (المحاسبة الشهرية) *' : 'Date de dépense *'}
                  </label>
                  <input
                    type="date"
                    required
                    value={editDate}
                    onChange={e => setEditDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.building}</label>
                  <select
                    value={editBuildingCode}
                    onChange={e => setEditBuildingCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white"
                  >
                    <option value="ALL">{t.expenses.allResidence}</option>
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'المورد أو العامل المستفيد' : t.expenses.supplier}
                  </label>
                  <input
                    type="text"
                    value={editSupplier}
                    onChange={e => setEditSupplier(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.invoiceRef}</label>
                  <input
                    type="text"
                    value={editInvoiceRef}
                    onChange={e => setEditInvoiceRef(e.target.value)}
                    placeholder="FAC-2026-081"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.expenses.method}</label>
                  <select
                    value={editPaymentMethod}
                    onChange={e => setEditPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white"
                  >
                    <option value="bank_transfer">{t.payments.methodTransfer}</option>
                    <option value="check">{t.payments.methodCheck}</option>
                    <option value="cash">{t.payments.methodCash}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'الجهة المؤدية' : 'Payé par'}
                  </label>
                  <input
                    type="text"
                    value={editPaidBy}
                    onChange={e => setEditPaidBy(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingExpense(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ التعديلات والتصحيح' : t.common.save}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Expense / Invoice Confirmation Modal (مسح الفاتورة أو المصروف المسجل بالخطأ) */}
      {!isOwner && deletingExpense && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-rose-200 overflow-hidden my-8">
            <div className="bg-rose-600 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-white/20 text-white">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base font-bold">
                    {lang === 'ar' ? 'مسح الفاتورة أو المصروف المسجل بالخطأ' : 'Suppression de la dépense'}
                  </h2>
                  <p className="text-xs text-rose-100">
                    {lang === 'ar' ? 'تأكيد الحذف النهائي من سجلات المحاسبة' : 'Confirmation de suppression'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeletingExpense(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'ar' 
                  ? 'هل أنت متأكد من رغبتك في مسح هذا القيد المالي المسجل عن طريق الخطأ؟ سيتم حذفه نهائياً وتحديث إجمالي المصاريف والمحاسبة الشهرية ورصيد الخزينة تلقائياً.'
                  : 'Êtes-vous sûr de vouloir supprimer cette dépense ? Les soldes et totaux mensuels seront recalculés.'}
              </p>

              {/* Details summary */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{t.expenses.titleLabel}:</span>
                  <span className="font-bold text-slate-900">{deletingExpense.title}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{t.expenses.amount}:</span>
                  <span className="font-extrabold text-red-700 font-mono text-sm">
                    {deletingExpense.amount.toLocaleString()} DH
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{t.expenses.date}:</span>
                  <span className="font-mono text-slate-700">{deletingExpense.date}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'المورد / العامل:' : 'Bénéficiaire:'}</span>
                  <span className="font-medium text-slate-800">{deletingExpense.supplier}</span>
                </div>
                {deletingExpense.invoiceRef && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{t.expenses.invoiceRef}:</span>
                    <span className="font-mono text-slate-800 font-bold">{deletingExpense.invoiceRef}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeletingExpense(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء التراجع' : t.common.cancel}
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete-expense"
                  onClick={handleConfirmDelete}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تأكيد المسح النهائي' : t.common.delete}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Official Expenses PDF / Excel Export Modal */}
      <ExpensesExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        expenses={filteredExpenses}
        buildings={buildings}
        lang={lang}
        filterCategory={filterCategory}
        getCategoryLabel={getCategoryLabel}
        getMethodLabel={getMethodLabel}
        currentUser={currentUser}
      />

      {/* Quick Add Floating Action Button */}
      {!isOwner && (
        <button
          onClick={() => setIsQuickAddOpen(true)}
          className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 w-14 h-14 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-2xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 cursor-pointer z-40"
          title={lang === 'ar' ? 'إضافة مصروف سريع' : 'Ajout rapide'}
        >
          <Plus className="w-7 h-7" />
        </button>
      )}

      {/* Quick Add Modal */}
      {isQuickAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
                <Zap className="w-5 h-5 text-emerald-500" />
                {lang === 'ar' ? 'إضافة مصروف سريع' : 'Ajout Rapide'}
              </h3>
              <button
                onClick={() => setIsQuickAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleQuickSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {lang === 'ar' ? 'الوصف *' : 'Description *'}
                </label>
                <input
                  type="text"
                  required
                  value={quickTitle}
                  onChange={e => setQuickTitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثل: شراء مصابيح' : 'Ex: Achat ampoules'}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none focus:bg-white"
                  autoFocus
                />
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {lang === 'ar' ? 'المبلغ (درهم) *' : 'Montant (DH) *'}
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="1"
                  value={quickAmount}
                  onChange={e => setQuickAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="0.00"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-emerald-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {lang === 'ar' ? 'التصنيف *' : 'Catégorie *'}
                </label>
                <select
                  value={quickCategory}
                  onChange={e => setQuickCategory(e.target.value as ExpenseCategory)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none focus:bg-white"
                >
                  <option value="electricity">{getCategoryLabel('electricity')}</option>
                  <option value="water">{getCategoryLabel('water')}</option>
                  <option value="cleaning_supplies">{getCategoryLabel('cleaning_supplies')}</option>
                  <option value="hardware_droguerie">{getCategoryLabel('hardware_droguerie')}</option>
                  <option value="emergency_repairs">{getCategoryLabel('emergency_repairs')}</option>
                  <option value="worker_salaries">{getCategoryLabel('worker_salaries')}</option>
                  <option value="syndic_fees">{getCategoryLabel('syndic_fees')}</option>
                  <option value="other">{getCategoryLabel('other')}</option>
                </select>
              </div>

              {/* Quick Add Live Duplicate Warning */}
              {quickDuplicateExpenseCheck.isDuplicate && (
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-[11px] flex items-start gap-2 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="font-bold block text-amber-900">
                      ⚠️ {lang === 'ar' ? 'مصروف مالي مشابه مسجل مسبقاً!' : 'Dépense similaire déjà enregistrée !'}
                    </span>
                    <p className="text-amber-800 leading-tight">
                      {lang === 'ar' ? quickDuplicateExpenseCheck.messageAr : quickDuplicateExpenseCheck.messageFr}
                    </p>
                  </div>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Check className="w-5 h-5" />
                  {t.common.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Anti-Duplicate Warning Confirmation Modal */}
      {duplicateExpenseModal && (
        <DuplicateWarningModal
          isOpen={duplicateExpenseModal.isOpen}
          onClose={() => setDuplicateExpenseModal(null)}
          onConfirm={duplicateExpenseModal.onConfirm}
          lang={lang}
          type="expense"
          existingExpense={duplicateExpenseModal.existingExpense}
          candidateExpense={duplicateExpenseModal.candidateExpense}
          customMessage={duplicateExpenseModal.customMessage}
        />
      )}
    </div>
  );
};
