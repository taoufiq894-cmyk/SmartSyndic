import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ManualMonthlyRecord, Expense, Payment 
} from '../types';
import { 
  getAvailableMonthsList, 
  ARABIC_MONTH_NAMES, 
  FRENCH_MONTH_NAMES, 
  computeMonthlyFinanceSummary,
  getCarriedForwardBalance
} from '../utils/monthlyFinanceUtils';
import { 
  Calendar, FileSpreadsheet, Printer, Save, RefreshCw, CheckCircle2, 
  ArrowLeft, ArrowRight, DollarSign, TrendingUp, TrendingDown, 
  Users, Briefcase, Scale, Shield, Sparkles, AlertCircle, FileText,
  Calculator, Download, ChevronRight, ChevronLeft, Check, Edit3, HelpCircle
} from 'lucide-react';
import { CalendarDays as HeaderIcon } from 'lucide-react';

export const MonthlyBreakdownSheetView: React.FC = () => {
  const { 
    lang, currentUser, manualMonthlyRecords, upsertManualMonthlyRecord,
    payments, expenses, employees, apartments, showToast, setActiveSection 
  } = useApp();

  const isAr = lang === 'ar';
  const printRef = useRef<HTMLDivElement | null>(null);

  // Month Selection - Default to reference month '2026-05'
  const availableMonths = useMemo(() => {
    return getAvailableMonthsList(payments, expenses, manualMonthlyRecords);
  }, [payments, expenses, manualMonthlyRecords]);

  const [selectedMonthKey, setSelectedMonthKey] = useState<string>('2026-05');
  const [activeTab, setActiveTab] = useState<'sheet' | 'all_months' | 'print'>('sheet');

  // Month metadata
  const [selectedYear, selectedMonthNum] = useMemo(() => {
    const parts = selectedMonthKey.split('-');
    return [parts[0] || '2026', parts[1] || '05'];
  }, [selectedMonthKey]);

  const monthLabel = useMemo(() => {
    return isAr 
      ? `${ARABIC_MONTH_NAMES[selectedMonthNum] || selectedMonthNum} ${selectedYear}`
      : `${FRENCH_MONTH_NAMES[selectedMonthNum] || selectedMonthNum} ${selectedYear}`;
  }, [selectedMonthNum, selectedYear, isAr]);

  // Existing manual record if found
  const existingRecord = useMemo(() => {
    return manualMonthlyRecords.find(r => r.monthKey === selectedMonthKey);
  }, [manualMonthlyRecords, selectedMonthKey]);

  // Baseline system summary for the selected month
  const systemSummary = useMemo(() => {
    return computeMonthlyFinanceSummary(payments, expenses, apartments, selectedMonthKey, 'ALL', manualMonthlyRecords);
  }, [payments, expenses, apartments, selectedMonthKey, manualMonthlyRecords]);

  // Auto-calculated baseline expense categories from system expenses
  const autoBreakdown = useMemo(() => {
    const monthExpenses = expenses.filter(e => (e.date || '').startsWith(selectedMonthKey));
    
    let workerSalaries = 0;
    let syndicFees = 0;
    let lawyerFees = 0;
    let bailiffFees = 0;
    let droguerie = 0;
    let otherExp = 0;

    monthExpenses.forEach(exp => {
      const amt = Number(exp.amount) || 0;
      const cat = exp.category;
      const title = (exp.title || '').toLowerCase();

      if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
        syndicFees += amt;
      } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
        lawyerFees += amt;
      } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
        bailiffFees += amt;
      } else if (
        cat === 'hardware_droguerie' || cat === 'cleaning_supplies' || cat === 'electrical_supplies' ||
        cat === 'supplies' || title.includes('عقاقير') || title.includes('droguerie') || title.includes('لوازم')
      ) {
        droguerie += amt;
      } else if (cat === 'worker_salaries' || cat === 'cleaning_company' || cat === 'security_company' || title.includes('أجر') || title.includes('حراس') || title.includes('نظاف')) {
        workerSalaries += amt;
      } else {
        otherExp += amt;
      }
    });

    // Default syndic remuneration to 4000 if not recorded
    if (syndicFees === 0) {
      syndicFees = 4000;
    }
    // Default workers to 8800 if not recorded
    if (workerSalaries === 0) {
      workerSalaries = 8800;
    }

    return {
      workerSalaries,
      syndicFees,
      lawyerFees,
      bailiffFees,
      droguerie,
      otherExp
    };
  }, [expenses, selectedMonthKey]);

  // Track which month & record version was loaded into the form to avoid overwriting active user typing
  const loadedMonthKeyRef = useRef<string | null>(null);
  const loadedRecordIdRef = useRef<string | null>(null);
  const loadedUpdatedAtRef = useRef<string | null>(null);

  // Form State for the 10 requested fields (dynamically loaded from storage / baseline)
  const [openingBalance, setOpeningBalance] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.openingBalance === 'number' ? rec.openingBalance : 0;
  });
  const [income, setIncome] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.totalIncome === 'number' ? rec.totalIncome : 0;
  });
  const [workerSalaries, setWorkerSalaries] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    const b = rec?.breakdownExpenses;
    return typeof b?.workerSalaries === 'number' ? b.workerSalaries : (typeof b?.salaries === 'number' ? b.salaries : 0);
  });
  const [syndicFees, setSyndicFees] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.breakdownExpenses?.syndicAndDeputyFees === 'number' ? rec.breakdownExpenses.syndicAndDeputyFees : 0;
  });
  const [lawyerFees, setLawyerFees] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.breakdownExpenses?.lawyerFees === 'number' ? rec.breakdownExpenses.lawyerFees : 0;
  });
  const [bailiffFees, setBailiffFees] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.breakdownExpenses?.bailiffFees === 'number' ? rec.breakdownExpenses.bailiffFees : 0;
  });
  const [hardwareDroguerie, setHardwareDroguerie] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    const b = rec?.breakdownExpenses;
    return typeof b?.hardwareDroguerie === 'number' ? b.hardwareDroguerie : (typeof b?.supplies === 'number' ? b.supplies : 0);
  });
  const [otherExpenses, setOtherExpenses] = useState<number>(() => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === '2026-05');
    return typeof rec?.breakdownExpenses?.otherExpenses === 'number' ? rec.breakdownExpenses.otherExpenses : 0;
  });
  const [notes, setNotes] = useState<string>('');
  const [isSavedFeedback, setIsSavedFeedback] = useState<boolean>(false);

  // Sync inputs ONLY when selected month changes OR when record was saved/reset externally
  useEffect(() => {
    const isNewMonth = loadedMonthKeyRef.current !== selectedMonthKey;
    const isRecordExternalUpdate = existingRecord && (
      loadedRecordIdRef.current !== existingRecord.id || 
      loadedUpdatedAtRef.current !== existingRecord.updatedAt
    );

    if (isNewMonth || isRecordExternalUpdate) {
      loadedMonthKeyRef.current = selectedMonthKey;
      loadedRecordIdRef.current = existingRecord?.id || null;
      loadedUpdatedAtRef.current = existingRecord?.updatedAt || null;

      if (existingRecord) {
        const op = typeof existingRecord.openingBalance === 'number' 
          ? existingRecord.openingBalance 
          : systemSummary.previousCarriedBalance;
        setOpeningBalance(op);
        setIncome(typeof existingRecord.totalIncome === 'number' ? existingRecord.totalIncome : systemSummary.totalIncome);
        setNotes(existingRecord.notes || (isAr ? `الحساب المالي المفصل لشهر ${monthLabel}` : `Bilan financier de ${monthLabel}`));

        const bExp = existingRecord.breakdownExpenses || {};
        const wSal = typeof bExp.workerSalaries === 'number' ? bExp.workerSalaries : (typeof bExp.salaries === 'number' ? bExp.salaries : autoBreakdown.workerSalaries);
        const sFees = typeof bExp.syndicAndDeputyFees === 'number' ? bExp.syndicAndDeputyFees : autoBreakdown.syndicFees;
        const lFees = typeof bExp.lawyerFees === 'number' ? bExp.lawyerFees : autoBreakdown.lawyerFees;
        const bFees = typeof bExp.bailiffFees === 'number' ? bExp.bailiffFees : autoBreakdown.bailiffFees;
        const hDrog = typeof bExp.hardwareDroguerie === 'number' ? bExp.hardwareDroguerie : (typeof bExp.supplies === 'number' ? bExp.supplies : autoBreakdown.droguerie);

        setWorkerSalaries(wSal);
        setSyndicFees(sFees);
        setLawyerFees(lFees);
        setBailiffFees(bFees);
        setHardwareDroguerie(hDrog);

        if (typeof bExp.otherExpenses === 'number') {
          setOtherExpenses(bExp.otherExpenses);
        } else {
          const specificSum = wSal + sFees + lFees + bFees + hDrog;
          const remaining = Math.max(0, existingRecord.totalExpenses - specificSum);
          setOtherExpenses(remaining);
        }
      } else {
        setOpeningBalance(systemSummary.previousCarriedBalance);
        setIncome(systemSummary.totalIncome);
        setWorkerSalaries(autoBreakdown.workerSalaries);
        setSyndicFees(autoBreakdown.syndicFees);
        setLawyerFees(autoBreakdown.lawyerFees);
        setBailiffFees(autoBreakdown.bailiffFees);
        setHardwareDroguerie(autoBreakdown.droguerie);
        
        const specificSum = autoBreakdown.workerSalaries + autoBreakdown.syndicFees + autoBreakdown.lawyerFees + autoBreakdown.bailiffFees + autoBreakdown.droguerie;
        const remaining = Math.max(0, systemSummary.totalExpenses - specificSum);
        setOtherExpenses(autoBreakdown.otherExp || remaining);
        setNotes(isAr ? `الحساب المالي المفصل لشهر ${monthLabel}` : `Bilan financier de ${monthLabel}`);
      }
    }
  }, [selectedMonthKey, existingRecord, systemSummary.previousCarriedBalance, systemSummary.totalIncome, systemSummary.totalExpenses, autoBreakdown, isAr, monthLabel]);

  // Computed Values based on requested formulas:
  // 1. مجموع المداخيل مع إضافة المنقول = المنقول + المداخيل
  const totalAvailableIncomeWithCarried = useMemo(() => {
    return openingBalance + income;
  }, [openingBalance, income]);

  // 2. مجموع المصاريف = أجرة العمال + أجرة الوكيل ونائبه + أتعاب المحامي + أتعاب المفوض القضائي + العقاقير + مصاريف أخرى
  const totalExpensesSum = useMemo(() => {
    return workerSalaries + syndicFees + lawyerFees + bailiffFees + hardwareDroguerie + otherExpenses;
  }, [workerSalaries, syndicFees, lawyerFees, bailiffFees, hardwareDroguerie, otherExpenses]);

  // 3. صافي الشهر الخالص (مداخيل - مصاريف)
  const netMonthlySurplus = useMemo(() => {
    return income - totalExpensesSum;
  }, [income, totalExpensesSum]);

  // 4. الباقي من الشهر (الرصيد النهائي المرحل) = مجموع المداخيل مع إضافة المنقول - مجموع المصاريف
  const finalRemainingBalance = useMemo(() => {
    return totalAvailableIncomeWithCarried - totalExpensesSum;
  }, [totalAvailableIncomeWithCarried, totalExpensesSum]);

  // 5. حساب النسب المئوية الدقيقة لكل بند من مجموع المصاريف (%)
  const expensePercentages = useMemo(() => {
    if (totalExpensesSum <= 0) {
      return { workerPct: '0.0', syndicPct: '0.0', lawyerPct: '0.0', bailiffPct: '0.0', drogueriePct: '0.0', otherPct: '0.0', diversePct: '0.0' };
    }
    const diverseTotal = hardwareDroguerie + otherExpenses;
    return {
      workerPct: ((workerSalaries / totalExpensesSum) * 100).toFixed(1),
      syndicPct: ((syndicFees / totalExpensesSum) * 100).toFixed(1),
      lawyerPct: ((lawyerFees / totalExpensesSum) * 100).toFixed(1),
      bailiffPct: ((bailiffFees / totalExpensesSum) * 100).toFixed(1),
      drogueriePct: ((hardwareDroguerie / totalExpensesSum) * 100).toFixed(1),
      otherPct: ((otherExpenses / totalExpensesSum) * 100).toFixed(1),
      diversePct: ((diverseTotal / totalExpensesSum) * 100).toFixed(1)
    };
  }, [totalExpensesSum, workerSalaries, syndicFees, lawyerFees, bailiffFees, hardwareDroguerie, otherExpenses]);

  // Handle Save
  const handleSaveSheet = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const timestampIso = new Date().toISOString();
    loadedUpdatedAtRef.current = timestampIso;

    upsertManualMonthlyRecord({
      monthKey: selectedMonthKey,
      openingBalance,
      totalIncome: income,
      totalExpenses: totalExpensesSum,
      closingBalance: finalRemainingBalance,
      isUserModified: true,
      breakdownIncome: {
        regularFees: income,
        otherIncome: 0
      },
      breakdownExpenses: {
        salaries: workerSalaries,
        workerSalaries,
        syndicAndDeputyFees: syndicFees,
        lawyerFees,
        bailiffFees,
        hardwareDroguerie,
        otherExpenses,
        supplies: hardwareDroguerie,
        utilities: otherExpenses
      },
      notes: notes || (isAr ? `جدول الحساب المالي المفصل لشهر ${monthLabel}` : `Bilan financier de ${monthLabel}`),
      recordedBy: currentUser?.name || 'وكيل السانديك'
    });

    setIsSavedFeedback(true);
    setTimeout(() => setIsSavedFeedback(false), 3000);

    if (showToast) {
      showToast(
        isAr 
          ? `تم حفظ وتثبيت جدول الحساب المالي لشهر ${monthLabel} بنجاح! الرصيد المتبقي: ${finalRemainingBalance.toLocaleString()} درهم`
          : `Fiche financière de ${monthLabel} enregistrée avec succès. Solde: ${finalRemainingBalance.toLocaleString()} DH`,
        { type: 'success' }
      );
    }
  };

  // Quick navigation between months
  const navigateMonth = (direction: 'prev' | 'next') => {
    const currentIndex = availableMonths.findIndex(m => m.key === selectedMonthKey);
    if (currentIndex === -1) return;
    const nextIndex = direction === 'next' ? currentIndex - 1 : currentIndex + 1;
    if (nextIndex >= 0 && nextIndex < availableMonths.length) {
      setSelectedMonthKey(availableMonths[nextIndex].key);
    }
  };

  // Print Report
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-400 to-sky-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
              <Calculator className="w-6 h-6 text-indigo-700" />
              <span>{isAr ? 'جدول الحساب المالي الشهري المفصل' : 'Tableau de Caisse & Bilan Mensuel'}</span>
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            {isAr 
              ? 'المنقول • المداخيل • أجور العمال • أتعاب الوكيل ونائبه • المحامي • المفوض القضائي • العقاقير • مجموع المداخيل مع المنقول • مجموع المصاريف • الباقي من الشهر'
              : 'Report • Recettes • Salaires • Syndic • Avocat • Huissier • Droguerie • Total Disponible • Dépenses • Solde Restant'}
          </p>
        </div>

        {/* Tab Switcher & Print Action */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('sheet')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'sheet'
                ? 'bg-indigo-700 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>{isAr ? 'حساب الشهر المحدد' : 'Fiche du Mois'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('all_months')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'all_months'
                ? 'bg-indigo-700 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{isAr ? 'الجدول المقارن لكافة الأشهر' : 'Tableau Comparatif'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('print')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'print'
                ? 'bg-indigo-700 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{isAr ? 'معاينة الطباعة وPDF 🖨️' : 'Imprimer / PDF'}</span>
          </button>
        </div>
      </div>

      {/* Month Navigation & Selector Toolbar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-white/10 text-amber-300">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-slate-300 font-bold uppercase">
              {isAr ? 'الشهر المالي قيد المعالجة' : 'Mois budgétaire actif'}
            </div>
            <div className="text-lg font-black text-white flex items-center gap-2">
              <span>{monthLabel}</span>
              {selectedMonthKey === '2026-05' && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                  {isAr ? 'الشهر المرجعي الأساسي' : 'Mois Référence'}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick previous month button */}
          <button
            type="button"
            onClick={() => navigateMonth('prev')}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            title={isAr ? 'الشهر السابق' : 'Mois précédent'}
          >
            {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>

          {/* Month Dropdown Selector */}
          <select
            value={selectedMonthKey}
            onChange={e => setSelectedMonthKey(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold border border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-400 cursor-pointer"
          >
            {availableMonths.map(m => (
              <option key={m.key} value={m.key} className="bg-slate-900 text-white">
                {isAr ? m.labelAr : m.labelFr}
              </option>
            ))}
          </select>

          {/* Quick next month button */}
          <button
            type="button"
            onClick={() => navigateMonth('next')}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
            title={isAr ? 'الشهر الموالي' : 'Mois suivant'}
          >
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>

          {/* Auto fill / Reset button */}
          <button
            type="button"
            onClick={() => {
              setOpeningBalance(systemSummary.previousCarriedBalance);
              setIncome(systemSummary.totalIncome);
              setWorkerSalaries(autoBreakdown.workerSalaries);
              setSyndicFees(autoBreakdown.syndicFees);
              setLawyerFees(autoBreakdown.lawyerFees);
              setBailiffFees(autoBreakdown.bailiffFees);
              setHardwareDroguerie(autoBreakdown.droguerie);
              setOtherExpenses(autoBreakdown.otherExp);
              if (showToast) showToast(isAr ? 'تم استرجاع القيم التلقائية من النظام' : 'Données réinitialisées');
            }}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-amber-300 transition-all cursor-pointer"
            title={isAr ? 'إعادة ضبط القيم من وصولات وفواتير النظام' : 'Réinitialiser'}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: THE INTERACTIVE MONTHLY BREAKDOWN SHEET */}
      {/* ========================================================= */}
      {activeTab === 'sheet' && (
        <form onSubmit={handleSaveSheet} className="space-y-6 animate-in fade-in duration-200">
          
          {/* THE 10 EXACT REQUESTED BOXES (الخانات العشر المحددة بدقة) */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

            {/* 1. المنقول (الرصيد المنقول السابق) */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 border-2 border-indigo-200 shadow-xs relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-indigo-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-md bg-indigo-600 text-white text-[11px] font-bold flex items-center justify-center">1</span>
                  <span>{isAr ? 'المنقول (الرصيد السابق)' : 'Report Antérieur'}</span>
                </span>
                <span className="text-[10px] bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'الخانة 1' : 'Case 1'}
                </span>
              </div>
              <div className="mt-3">
                <div className="relative">
                  <input
                    type="number"
                    value={openingBalance}
                    onChange={e => setOpeningBalance(Number(e.target.value) || 0)}
                    className="w-full text-xl sm:text-2xl font-black font-mono text-indigo-950 bg-white/80 border border-indigo-300 rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                  />
                  <span className="absolute end-3 top-2.5 text-xs font-bold text-indigo-700">DH</span>
                </div>
                <div className="text-[11px] text-indigo-700 font-medium mt-1">
                  {isAr ? 'الفائض المنقول من نهاية الشهر السابق' : 'Solde reporté du mois précédent'}
                </div>
              </div>
            </div>

            {/* 2. المداخيل */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 shadow-xs relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-emerald-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-md bg-emerald-600 text-white text-[11px] font-bold flex items-center justify-center">2</span>
                  <span>{isAr ? 'المداخيل (مقبوضات الشهر)' : 'Recettes du Mois'}</span>
                </span>
                <span className="text-[10px] bg-emerald-200 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'الخانة 2' : 'Case 2'}
                </span>
              </div>
              <div className="mt-3">
                <div className="relative">
                  <input
                    type="number"
                    value={income}
                    onChange={e => setIncome(Number(e.target.value) || 0)}
                    className="w-full text-xl sm:text-2xl font-black font-mono text-emerald-950 bg-white/80 border border-emerald-300 rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  />
                  <span className="absolute end-3 top-2.5 text-xs font-bold text-emerald-700">DH</span>
                </div>
                <div className="text-[11px] text-emerald-700 font-medium mt-1">
                  {isAr ? 'مجموع اشتراكات ووصولات الملاك المستخلصة' : 'Cotisations et paiements encaissés'}
                </div>
              </div>
            </div>

            {/* 3. مجموع المداخيل مع إضافة المنقول (1 + 2) */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-900 to-slate-900 text-white border-2 border-cyan-700 shadow-sm relative overflow-hidden md:col-span-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-cyan-200 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{isAr ? 'مجموع المداخيل مع إضافة المنقول' : 'Total Disponible (Report + Recettes)'}</span>
                </span>
                <span className="text-[10px] bg-cyan-800/80 text-cyan-200 px-2 py-0.5 rounded-full font-mono font-bold">
                  {isAr ? 'المنقول + المداخيل' : 'Case 1 + 2'}
                </span>
              </div>
              <div className="mt-2 flex items-baseline justify-between">
                <div className="text-2xl sm:text-3xl font-black font-mono text-cyan-300">
                  {totalAvailableIncomeWithCarried.toLocaleString()} <span className="text-sm font-bold text-cyan-100">DH</span>
                </div>
                <div className="text-xs font-mono text-cyan-200 hidden sm:block">
                  ({openingBalance.toLocaleString()} + {income.toLocaleString()})
                </div>
              </div>
              <div className="text-[11px] text-cyan-200 mt-1">
                {isAr ? 'إجمالي السيولة المالية الإجمالية المتوفرة تحت تصرف الصندوق خلال الشهر' : 'Total des disponibilités financières du mois'}
              </div>
            </div>

          </div>

          {/* مصاريف الشهر التفصيلية (أجرة العمال، أجرة الوكيل ونائبه، أتعاب المحامي، المفوض، العقاقير) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-rose-600" />
                <h3 className="text-sm sm:text-base font-black text-slate-900">
                  {isAr ? 'تفصيل بنود مصاريف ونفقات الشهر:' : 'Ventilation Détaillée des Dépenses:'}
                </h3>
              </div>
              <span className="text-xs font-mono font-bold text-rose-800 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
                {isAr ? 'المجموع الجزئي للمصاريف:' : 'Total Dépenses:'} {totalExpensesSum.toLocaleString()} DH
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              
              {/* 4. أجرة العمال */}
              <div className="p-3.5 rounded-xl bg-rose-50/60 border border-rose-200 space-y-1.5">
                <label className="text-xs font-black text-rose-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-rose-700" />
                    <span>{isAr ? 'أجرة العمال' : 'Salaires des Ouvriers'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-rose-700 bg-white px-2 py-0.5 rounded border border-rose-200 font-mono">
                      {expensePercentages.workerPct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      {isAr ? 'حراس ونظافة' : 'Personnel'}
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={workerSalaries}
                    onChange={e => setWorkerSalaries(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-rose-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-rose-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'رواتب عمال الحراسة والنظافة والبستنة' : 'Sécurité, nettoyage, jardinier'}
                </div>
              </div>

              {/* 5. أجرة الوكيل و نائبه */}
              <div className="p-3.5 rounded-xl bg-amber-50/60 border border-amber-200 space-y-1.5">
                <label className="text-xs font-black text-amber-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-amber-700" />
                    <span>{isAr ? 'أجرة الوكيل و نائبه' : 'Rémunération Syndic & Adjoint'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-amber-800 bg-white px-2 py-0.5 rounded border border-amber-200 font-mono">
                      {expensePercentages.syndicPct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      4,000 DH
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={syndicFees}
                    onChange={e => setSyndicFees(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-amber-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'أتعاب التسيير الإداري لوكيل الاتحاد ونائبه' : 'Honoraires mensuels du syndic'}
                </div>
              </div>

              {/* 6. أتعاب المحامي */}
              <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1.5">
                <label className="text-xs font-black text-blue-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-blue-700" />
                    <span>{isAr ? 'أتعاب المحامي' : 'Honoraires Avocat'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-blue-800 bg-white px-2 py-0.5 rounded border border-blue-200 font-mono">
                      {expensePercentages.lawyerPct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      {isAr ? 'قضايا ونزاعات' : 'Contentieux'}
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={lawyerFees}
                    onChange={e => setLawyerFees(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-blue-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'المتابعات القضائية لاستخلاص الديون' : 'Recouvrement judiciaire'}
                </div>
              </div>

              {/* 7. أتعاب المفوض القضائي */}
              <div className="p-3.5 rounded-xl bg-purple-50/60 border border-purple-200 space-y-1.5">
                <label className="text-xs font-black text-purple-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-purple-700" />
                    <span>{isAr ? 'أتعاب المفوض القضائي' : 'Frais Huissier de Justice'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-purple-800 bg-white px-2 py-0.5 rounded border border-purple-200 font-mono">
                      {expensePercentages.bailiffPct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      {isAr ? 'تبليغات وإنذارات' : 'Significations'}
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={bailiffFees}
                    onChange={e => setBailiffFees(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-purple-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-purple-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'الإنذارات القانونية ومعاينات الإقامة' : 'Constats & notifications'}
                </div>
              </div>

              {/* 8. العقاقير بمختلفها */}
              <div className="p-3.5 rounded-xl bg-orange-50/60 border border-orange-200 space-y-1.5">
                <label className="text-xs font-black text-orange-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-orange-700" />
                    <span>{isAr ? 'العقاقير بمختلفها' : 'Droguerie & Quincaillerie'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-orange-800 bg-white px-2 py-0.5 rounded border border-orange-200 font-mono">
                      {expensePercentages.drogueriePct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      {isAr ? 'مواد ولوازم' : 'Fournitures'}
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={hardwareDroguerie}
                    onChange={e => setHardwareDroguerie(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-orange-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-orange-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'مواد النظافة، الكهرباء، والسباكة والصيانة' : 'Produits entretien, ampoules, plomberie'}
                </div>
              </div>

              {/* مصاريف أخرى للمطابقة (ماء، كهرباء، صيانة مضخات) */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5">
                <label className="text-xs font-black text-slate-800 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-slate-600" />
                    <span>{isAr ? 'مصاريف أخرى (ماء، كهرباء، صيانة)' : 'Autres Charges (Eau/Élec)'}</span>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-black text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-200 font-mono">
                      {expensePercentages.otherPct}%
                    </span>
                    <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">
                      {isAr ? 'فواتير مشتركة' : 'Factures'}
                    </span>
                  </div>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={otherExpenses}
                    onChange={e => setOtherExpenses(Number(e.target.value) || 0)}
                    className="w-full text-base font-black font-mono text-slate-900 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-slate-600 focus:outline-none"
                  />
                  <span className="absolute end-2.5 top-2 text-xs font-bold text-slate-400">DH</span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {isAr ? 'إنارة السلالم، مضخات الماء المشتركة' : 'Charges communes résiduelles'}
                </div>
              </div>

            </div>
          </div>

          {/* FINAL RESULTS SUMMARY: 9. مجموع المصاريف & 10. الباقي من الشهر */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 9. مجموع المصاريف */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-rose-900 to-red-950 text-white shadow-sm border border-rose-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-rose-200 flex items-center gap-1.5">
                  <TrendingDown className="w-4 h-4 text-rose-400" />
                  <span>{isAr ? 'مجموع المصاريف (الخانة 3)' : 'Total Général des Dépenses'}</span>
                </span>
                <span className="text-[10px] bg-rose-800 text-rose-200 px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'مجموع بنود النفقات' : 'Somme des charges'}
                </span>
              </div>
              <div className="text-3xl font-black font-mono text-white">
                {totalExpensesSum.toLocaleString()} <span className="text-sm font-bold text-rose-300">DH</span>
              </div>
              <div className="text-xs text-rose-200 mt-2">
                {isAr 
                  ? `أجرة العمال (${workerSalaries.toLocaleString()}) + أتعاب الوكيل (${syndicFees.toLocaleString()}) + المحامي (${lawyerFees.toLocaleString()}) + المفوض (${bailiffFees.toLocaleString()}) + العقاقير (${hardwareDroguerie.toLocaleString()}) + أخرى (${otherExpenses.toLocaleString()})`
                  : 'Total de toutes les dépenses décaissées ce mois'}
              </div>
            </div>

            {/* 10. الباقي من الشهر (الرصيد النهائي المرحل) */}
            <div className={`p-5 rounded-2xl shadow-sm border text-white ${
              finalRemainingBalance >= 0 
                ? 'bg-gradient-to-br from-emerald-900 via-teal-950 to-emerald-900 border-emerald-700' 
                : 'bg-gradient-to-br from-red-900 via-rose-950 to-red-900 border-red-700'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black flex items-center gap-1.5 text-emerald-200">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>{isAr ? 'الباقي من الشهر (الرصيد النهائي المرحل)' : 'Solde Restant du Mois (Reporté)'}</span>
                </span>
                <span className="text-[10px] bg-white/20 text-white px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'التحفة المرحّلة' : 'Solde de clôture'}
                </span>
              </div>
              <div className="text-3xl sm:text-4xl font-black font-mono text-amber-300">
                {finalRemainingBalance >= 0 ? '+' : ''}{finalRemainingBalance.toLocaleString()} <span className="text-sm font-bold text-white">DH</span>
              </div>
              <div className="text-xs text-emerald-100 mt-2 flex items-center gap-1.5">
                <span>
                  {isAr 
                    ? `المعادلة المحاسبية: ${totalAvailableIncomeWithCarried.toLocaleString()} (المنقول+المداخيل) - ${totalExpensesSum.toLocaleString()} (المصاريف) = ${finalRemainingBalance.toLocaleString()} DH`
                    : `Formule: Total disponible (${totalAvailableIncomeWithCarried.toLocaleString()}) - Dépenses (${totalExpensesSum.toLocaleString()}) = ${finalRemainingBalance.toLocaleString()} DH`}
                </span>
              </div>
            </div>

          </div>

          {/* Notes & Explanation */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {isAr ? 'ملاحظات وتفاصيل السانديك لهذا الشهر:' : 'Observations et remarques:'}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder={isAr ? 'مثال: تم سداد رواتب الحراسة والنظافة وأتعاب السانديك (4000 DH) وشراء مستلزمات العقاقير...' : 'Remarques...'}
              className="w-full text-xs rounded-xl border border-slate-300 px-3 py-2 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
            />
          </div>

          {/* Save Action Bar */}
          <div className="flex items-center justify-end gap-3 pt-2">
            {isSavedFeedback && (
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{isAr ? 'تم الحفظ والتحديث في السلسلة المحاسبية بنجاح!' : 'Enregistré avec succès!'}</span>
              </span>
            )}

            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-indigo-700 hover:bg-indigo-800 active:bg-indigo-900 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{isAr ? 'حفظ وتثبيت هذا الشهر في السجل المالي 💾' : 'Enregistrer et valider ce mois'}</span>
            </button>
          </div>
        </form>
      )}

      {/* ========================================================= */}
      {/* TAB 2: FULL COMPARATIVE TABLE OF ALL MONTHS */}
      {/* ========================================================= */}
      {activeTab === 'all_months' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-200">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-black text-slate-900">
                {isAr ? 'الجدول المقارن لكافة الأشهر (السلسلة المحاسبية الشاملة)' : 'Tableau comparatif de tous les mois'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {isAr ? 'عرض الأعمدة العشرة المحاسبية عبر كافة الأشهر مع تسلسل ترحيل الأرصدة' : 'Toutes les colonnes comptables et reports'}
              </p>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5 self-start sm:self-auto"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isAr ? 'طباعة الجدول' : 'Imprimer'}</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-start">
              <thead className="bg-slate-100 text-slate-800 border-b border-slate-200">
                <tr>
                  <th className="p-2.5 font-black text-start">{isAr ? 'الشهر' : 'Mois'}</th>
                  <th className="p-2.5 font-black text-end text-indigo-900">{isAr ? 'المنقول (1)' : 'Report (1)'}</th>
                  <th className="p-2.5 font-black text-end text-emerald-900">{isAr ? 'المداخيل (2)' : 'Recettes (2)'}</th>
                  <th className="p-2.5 font-black text-end text-cyan-900 bg-cyan-50/50">{isAr ? 'المجموع (1+2)' : 'Total (1+2)'}</th>
                  <th className="p-2.5 font-black text-end text-rose-900">{isAr ? 'أجرة العمال' : 'Salaires'}</th>
                  <th className="p-2.5 font-black text-end text-amber-900">{isAr ? 'أجرة الوكيل' : 'Syndic'}</th>
                  <th className="p-2.5 font-black text-end text-blue-900">{isAr ? 'المحامي' : 'Avocat'}</th>
                  <th className="p-2.5 font-black text-end text-purple-900">{isAr ? 'المفوض' : 'Huissier'}</th>
                  <th className="p-2.5 font-black text-end text-orange-900">{isAr ? 'العقاقير' : 'Droguerie'}</th>
                  <th className="p-2.5 font-black text-end text-rose-950 bg-rose-50/50">{isAr ? 'مجموع المصاريف' : 'Dépenses'}</th>
                  <th className="p-2.5 font-black text-end text-emerald-950 bg-emerald-50/50">{isAr ? 'الباقي من الشهر' : 'Solde Final'}</th>
                  <th className="p-2.5 font-black text-center">{isAr ? 'إجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {manualMonthlyRecords.map(r => {
                  const [y, m] = r.monthKey.split('-');
                  const mName = isAr ? `${ARABIC_MONTH_NAMES[m] || m} ${y}` : `${FRENCH_MONTH_NAMES[m] || m} ${y}`;
                  const opening = Number(r.openingBalance) || 0;
                  const inc = Number(r.totalIncome) || 0;
                  const totalWithCarried = opening + inc;
                  const bExp = r.breakdownExpenses || {};
                  const wSalaries = bExp.workerSalaries ?? bExp.salaries ?? 8800;
                  const sFees = bExp.syndicAndDeputyFees ?? 4000;
                  const lFees = bExp.lawyerFees ?? 0;
                  const bFees = bExp.bailiffFees ?? 0;
                  const hDroguerie = bExp.hardwareDroguerie ?? bExp.supplies ?? 4000;
                  const expTotal = Number(r.totalExpenses) || 0;
                  const closing = r.closingBalance !== undefined ? r.closingBalance : (totalWithCarried - expTotal);

                  return (
                    <tr 
                      key={r.id} 
                      className={`hover:bg-indigo-50/40 transition-colors ${
                        r.monthKey === selectedMonthKey ? 'bg-indigo-50/80 font-bold' : ''
                      }`}
                    >
                      <td className="p-2.5 font-sans font-bold text-slate-900 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{mName}</span>
                        </div>
                      </td>
                      <td className="p-2.5 text-end text-slate-700">{opening.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-emerald-700 font-bold">+{inc.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-cyan-950 bg-cyan-50/50 font-black">{totalWithCarried.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-slate-700">{wSalaries.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-slate-700">{sFees.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-slate-700">{lFees.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-slate-700">{bFees.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-slate-700">{hDroguerie.toLocaleString()}</td>
                      <td className="p-2.5 text-end text-rose-700 font-bold bg-rose-50/50">-{expTotal.toLocaleString()}</td>
                      <td className="p-2.5 text-end font-black text-indigo-950 bg-emerald-50/60">
                        <span className={`px-2 py-0.5 rounded ${closing >= 0 ? 'text-emerald-950 font-black' : 'text-rose-950'}`}>
                          {closing.toLocaleString()} DH
                        </span>
                      </td>
                      <td className="p-2.5 text-center font-sans">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedMonthKey(r.monthKey);
                            setActiveTab('sheet');
                          }}
                          className="px-2 py-1 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[11px] font-bold transition-all cursor-pointer inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>{isAr ? 'تعديل' : 'Éditer'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: OFFICIAL PRINT & PDF EXPORT DOCUMENT */}
      {/* ========================================================= */}
      {activeTab === 'print' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs print:hidden">
            <span className="text-xs font-bold text-slate-700">
              {isAr ? 'معاينة المستند الرسمي قبل الطباعة أو الحفظ كـ PDF' : 'Aperçu du document imprimable'}
            </span>
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              <span>{isAr ? 'طباعة المستند / حفظ كـ PDF 🖨️' : 'Imprimer / Exporter PDF'}</span>
            </button>
          </div>

          <div ref={printRef} className="bg-white p-6 sm:p-10 rounded-2xl border border-slate-200 shadow-sm space-y-6 text-slate-900 print:border-none print:shadow-none print:p-0">
            {/* Document Header */}
            <div className="border-b-2 border-slate-900 pb-5">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {isAr ? 'المملكة المغربية • اتحاد الملاك المشتركين' : 'Royaume du Maroc • Copropriété'}
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-950 mt-1">
                    {isAr ? 'إقامة المرجان GH 34 • جدول الحساب المالي الشهري المفصل' : 'Résidence Al Morjane GH 34 • Bilan Financier Mensuel'}
                  </h2>
                  <div className="text-xs font-bold text-indigo-900 mt-1">
                    {isAr ? `بيان العمليات والتدفقات المالية لشهر: ${monthLabel}` : `État des flux financiers pour le mois de: ${monthLabel}`}
                  </div>
                </div>

                <div className="text-end text-xs space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div><span className="font-bold">{isAr ? 'تاريخ التحرير:' : 'Date:'}</span> {new Date().toLocaleDateString(isAr ? 'ar-MA' : 'fr-FR')}</div>
                  <div><span className="font-bold">{isAr ? 'المرجع:' : 'Réf:'}</span> FIN-{selectedMonthKey}</div>
                  <div><span className="font-bold">{isAr ? 'المحرر:' : 'Par:'}</span> {currentUser?.name || 'وكيل السانديك'}</div>
                </div>
              </div>
            </div>

            {/* Official Accounting 10-Box Summary Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-start border-2 border-slate-900">
                <thead className="bg-slate-200 text-slate-950 border-b-2 border-slate-900 font-black">
                  <tr>
                    <th className="p-2.5 border-e border-slate-300 text-center w-12">#</th>
                    <th className="p-2.5 border-e border-slate-300 text-start">{isAr ? 'البيان المحاسبي' : 'Rubrique'}</th>
                    <th className="p-2.5 border-e border-slate-300 text-end w-36">{isAr ? 'المبلغ (درهم)' : 'Montant (DH)'}</th>
                    <th className="p-2.5 text-start">{isAr ? 'التفاصيل والملاحظات' : 'Détails & Justifications'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300 font-mono">
                  
                  {/* 1. المنقول */}
                  <tr className="bg-indigo-50/50">
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">1</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300 text-indigo-950">
                      {isAr ? 'المنقول (الرصيد المنقول السابق)' : 'Report Antérieur (Solde Précédent)'}
                    </td>
                    <td className="p-2.5 text-end font-black text-indigo-900 border-e border-slate-300">
                      {openingBalance.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {isAr ? 'الرصيد المالي المنقول من إقفال الشهر السابق' : 'Solde reporté du mois antérieur'}
                    </td>
                  </tr>

                  {/* 2. المداخيل */}
                  <tr className="bg-emerald-50/50">
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">2</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300 text-emerald-950">
                      {isAr ? 'المداخيل (مقبوضات الشهر)' : 'Recettes Mensuelles Encaissées'}
                    </td>
                    <td className="p-2.5 text-end font-black text-emerald-800 border-e border-slate-300">
                      +{income.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {isAr ? 'واجبات الاشتراك والاشتراكات المستخلصة من الملاك' : 'Cotisations et arriérés recouvrés'}
                    </td>
                  </tr>

                  {/* 3. مجموع المداخيل مع إضافة المنقول */}
                  <tr className="bg-slate-900 text-white font-black">
                    <td className="p-2.5 text-center font-sans border-e border-slate-700">3</td>
                    <td className="p-2.5 font-sans border-e border-slate-700 text-cyan-300">
                      {isAr ? 'مجموع المداخيل مع إضافة المنقول (1 + 2)' : 'Total Général Disponible (1 + 2)'}
                    </td>
                    <td className="p-2.5 text-end text-cyan-300 border-e border-slate-700 text-sm">
                      {totalAvailableIncomeWithCarried.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-cyan-100 text-[11px]">
                      {isAr ? 'إجمالي السيولة المالية الكلية المتوفرة خلال هذا الشهر' : 'Total des disponibilités en caisse'}
                    </td>
                  </tr>

                  {/* 4. أجرة العمال */}
                  <tr>
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">4</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                      {isAr ? 'أجرة العمال' : 'Salaires des Ouvriers'}
                    </td>
                    <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                      -{workerSalaries.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {isAr ? 'رواتب عمال الحراسة والنظافة والبستاني وفق جدول التنقيط' : 'Salaires gardiens, agents de nettoyage'}
                    </td>
                  </tr>

                  {/* 5. أجرة الوكيل ونائبه */}
                  <tr>
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">5</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                      {isAr ? 'أجرة الوكيل و نائبه' : 'Rémunération du Syndic & Adjoint'}
                    </td>
                    <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                      -{syndicFees.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {isAr ? 'أتعاب الإدارة والتدبير المعتمدة (4000 درهم شهرياً)' : 'Frais de gestion et administration'}
                    </td>
                  </tr>

                  {/* 6. أتعاب المحامي */}
                  <tr>
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">6</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                      {isAr ? 'أتعاب المحامي' : 'Honoraires Avocat'}
                    </td>
                    <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                      -{lawyerFees.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {lawyerFees > 0 ? (isAr ? 'الملفات القضائية ونزاعات التحصيل' : 'Contentieux') : (isAr ? 'لا توجد مصاريف قضائية خلال هذا الشهر' : 'Néant')}
                    </td>
                  </tr>

                  {/* 7. أتعاب المفوض القضائي */}
                  <tr>
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">7</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                      {isAr ? 'أتعاب المفوض القضائي' : 'Frais Huissier de Justice'}
                    </td>
                    <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                      -{bailiffFees.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {bailiffFees > 0 ? (isAr ? 'تبليغ الإنذارات والمعاينات الرسمية' : 'Significations') : (isAr ? 'لا توجد إجراءات تبليغ خلال هذا الشهر' : 'Néant')}
                    </td>
                  </tr>

                  {/* 8. العقاقير بمختلفها */}
                  <tr>
                    <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">8</td>
                    <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                      {isAr ? 'العقاقير بمختلفها' : 'Droguerie & Quincaillerie'}
                    </td>
                    <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                      -{hardwareDroguerie.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-slate-700">
                      {isAr ? 'مواد التنظيف، مصابيح السلالم، مستلزمات السباكة والكهرباء' : 'Produits d\'entretien, ampoules, plomberie'}
                    </td>
                  </tr>

                  {/* مصاريف أخرى إن وجدت */}
                  {otherExpenses > 0 && (
                    <tr>
                      <td className="p-2.5 text-center font-bold font-sans border-e border-slate-300">+</td>
                      <td className="p-2.5 font-bold font-sans border-e border-slate-300">
                        {isAr ? 'مصاريف أخرى (كهرباء وماء مشترك وصيانة)' : 'Autres Charges (Électricité/Eau/Pannes)'}
                      </td>
                      <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-300">
                        -{otherExpenses.toLocaleString()} DH
                      </td>
                      <td className="p-2.5 font-sans text-slate-700">
                        {isAr ? 'فواتير استهلاك المرافق المشتركة وصيانة المضخات' : 'Charges d\'exploitation communes'}
                      </td>
                    </tr>
                  )}

                  {/* 9. مجموع المصاريف */}
                  <tr className="bg-rose-100/90 text-rose-950 font-black border-t-2 border-slate-400">
                    <td className="p-2.5 text-center font-sans border-e border-slate-300">9</td>
                    <td className="p-2.5 font-sans border-e border-slate-300">
                      {isAr ? 'مجموع المصاريف الإجمالية' : 'Total Général des Dépenses'}
                    </td>
                    <td className="p-2.5 text-end text-rose-900 border-e border-slate-300 text-sm">
                      -{totalExpensesSum.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 font-sans text-xs">
                      {isAr ? 'مجموع كافة المبالغ المؤداة والمصروفة خلال الشهر' : 'Total des décaissements du mois'}
                    </td>
                  </tr>

                  {/* 10. الباقي من الشهر */}
                  <tr className="bg-emerald-100 text-emerald-950 font-black border-t-2 border-slate-900 text-sm">
                    <td className="p-3 text-center font-sans border-e border-slate-400">10</td>
                    <td className="p-3 font-sans border-e border-slate-400">
                      {isAr ? 'الباقي من الشهر (الرصيد النهائي المرحل)' : 'Solde Restant du Mois (Reporté)'}
                    </td>
                    <td className="p-3 text-end font-black text-emerald-950 border-e border-slate-400 text-base">
                      {finalRemainingBalance >= 0 ? '+' : ''}{finalRemainingBalance.toLocaleString()} DH
                    </td>
                    <td className="p-3 font-sans text-xs">
                      {isAr ? 'المعادلة: (مجموع المداخيل مع المنقول) - (مجموع المصاريف) = الرصيد المرحل للشهر الموالي' : 'Formule: Total disponible - Total dépenses = Solde'}
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>

            {/* Official Signatures */}
            <div className="pt-8 border-t-2 border-slate-400 grid grid-cols-2 gap-8 text-center text-xs">
              <div className="p-4 rounded-xl border border-dashed border-slate-400 min-h-[110px] flex flex-col justify-between">
                <span className="font-bold text-slate-800">{isAr ? 'توقيع وخاتم وكيل السانديك' : 'Cachet et signature du Syndic'}</span>
                <span className="text-[11px] text-slate-400">{isAr ? '(المصادقة الرسمية)' : '(Visa officiel)'}</span>
              </div>
              <div className="p-4 rounded-xl border border-dashed border-slate-400 min-h-[110px] flex flex-col justify-between">
                <span className="font-bold text-slate-800">{isAr ? 'تأشيرة ومصادقة مجلس الملاك' : 'Conseil Syndical'}</span>
                <span className="text-[11px] text-slate-400">{isAr ? '(المراقبة والتدقيق)' : '(Contrôle)'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
