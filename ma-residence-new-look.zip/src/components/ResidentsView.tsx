import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Resident } from '../types';
import { Users2, Plus, Search, Phone, MessageSquare, Car, Trash2, Edit2, Check, X, Lock, Printer, FileSpreadsheet, Download, AlertTriangle, Mail, UploadCloud, RotateCcw } from 'lucide-react';
import { exportResidentsToExcel } from '../utils/exportUtils';
import { ResidentsExportModal } from './ResidentsExportModal';
import { ExcelImportModal } from './ExcelImportModal';
import { ResidentsExcelImportModal } from './ResidentsExcelImportModal';
import { OwnersDuesExcelModal } from './OwnersDuesExcelModal';
import { getApartmentDebtStatus } from '../utils/debtUtils';
import { Users as HeaderIcon } from 'lucide-react';

export const ResidentsView: React.FC = () => {
  const { t, lang, currentUser, residents, buildings, apartments, payments, addResident, updateResident, deleteResident, purgeOldResidentData } = useApp();
  
  const isOwner = currentUser?.role === 'resident';

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('ALL');
  const [filterBuilding, setFilterBuilding] = useState('ALL');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState('ALL');
  const [purgedMessage, setPurgedMessage] = useState<string | null>(null);

  const handlePurgeOldResidents = () => {
    if (isOwner) return;
    const confirmMsg = lang === 'ar' 
      ? 'هل أنت متأكد من مسح كافة الأسماء والبيانات القديمة للسكان والملاك القدامى لإفساح المجال للائحة الاسمية الجديدة؟'
      : 'Êtes-vous sûr de vouloir effacer toutes les anciennes données de résidents pour renouveler la liste nominative ?';
    if (window.confirm(confirmMsg)) {
      const res = purgeOldResidentData();
      const msg = lang === 'ar' 
        ? `تم مسح بيانات السكان القدامى بنجاح (${res.countPurged} شقة جاهزة للائحة الجديدة)`
        : `Anciennes données purgées avec succès (${res.countPurged} appartements prêts pour la nouvelle liste)`;
      setPurgedMessage(msg);
      setTimeout(() => setPurgedMessage(null), 6000);
    }
  };

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isResidentsImportModalOpen, setIsResidentsImportModalOpen] = useState(false);
  const [isOwnersDuesModalOpen, setIsOwnersDuesModalOpen] = useState(false);
  const [ownersDuesTab, setOwnersDuesTab] = useState<'export' | 'import'>('import');
  const [residentToDelete, setResidentToDelete] = useState<Resident | null>(null);

  // Form
  const [fullName, setFullName] = useState('');
  const [type, setType] = useState<'owner' | 'tenant'>('owner');
  const [buildingCode, setBuildingCode] = useState(buildings[0]?.code || 'GH34 A');
  const [apartmentNumber, setApartmentNumber] = useState('01');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cin, setCin] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [familyMembersCount, setFamilyMembersCount] = useState(3);
  const [entryDate, setEntryDate] = useState(new Date().toISOString().slice(0, 10));

  const handleOpenNew = () => {
    if (isOwner) return;
    setEditingId(null);
    setFullName('');
    setType('owner');
    setBuildingCode(buildings[0]?.code || 'GH34 A');
    setApartmentNumber('01');
    setPhone('+212 6');
    setEmail('');
    setCin('');
    setVehiclePlate('');
    setFamilyMembersCount(3);
    setEntryDate(new Date().toISOString().slice(0, 10));
    setIsFormOpen(true);
  };

  const handleOpenEdit = (res: Resident) => {
    if (isOwner) return;
    setEditingId(res.id);
    setFullName(res.fullName);
    setType(res.type);
    setBuildingCode(res.buildingCode);
    setApartmentNumber(res.apartmentNumber);
    setPhone(res.phone);
    setEmail(res.email || '');
    setCin(res.cin || '');
    setVehiclePlate(res.vehiclePlate || '');
    setFamilyMembersCount(res.familyMembersCount || 1);
    setEntryDate(res.entryDate || new Date().toISOString().slice(0, 10));
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!fullName.trim() || !phone.trim()) return;

    if (editingId) {
      updateResident(editingId, {
        fullName,
        type,
        buildingCode,
        apartmentNumber,
        phone,
        email,
        cin,
        vehiclePlate,
        familyMembersCount: Number(familyMembersCount),
        entryDate,
      });
    } else {
      addResident({
        fullName,
        type,
        buildingCode,
        apartmentNumber,
        phone,
        email,
        cin,
        vehiclePlate,
        familyMembersCount: Number(familyMembersCount),
        entryDate,
      });
    }
    setIsFormOpen(false);
  };

  const filteredResidents = residents.filter(r => {
    const matchesSearch = 
      r.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.buildingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.apartmentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.vehiclePlate && r.vehiclePlate.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.cin && r.cin.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = filterType === 'ALL' || r.type === filterType;
    const matchesBuilding = filterBuilding === 'ALL' || r.buildingCode === filterBuilding;

    let matchesStatus = true;
    if (filterPaymentStatus !== 'ALL') {
      const apt = apartments.find(a => 
        a.buildingCode.replace(/\s+/g, '').toUpperCase() === r.buildingCode.replace(/\s+/g, '').toUpperCase() &&
        a.number.replace(/\D/g, '') === r.apartmentNumber.replace(/\D/g, '')
      );
      const aptDebt = apt ? getApartmentDebtStatus(apt, payments) : { unpaidMonths: 0 };
      
      if (filterPaymentStatus === 'UP_TO_DATE') {
        matchesStatus = aptDebt.unpaidMonths === 0;
      } else if (filterPaymentStatus === 'LATE') {
        matchesStatus = aptDebt.unpaidMonths > 0 && aptDebt.unpaidMonths <= 4;
      } else if (filterPaymentStatus === 'VERY_LATE') {
        matchesStatus = aptDebt.unpaidMonths > 4;
      } else if (filterPaymentStatus === 'ANY_LATE') {
        matchesStatus = aptDebt.unpaidMonths > 0;
      }
    }

    return matchesSearch && matchesType && matchesBuilding && matchesStatus;
  });

  const delayedResidents = useMemo(() => {
    return residents.filter(res => {
      const apt = apartments.find(a => 
        a.buildingCode.replace(/\s+/g, '').toUpperCase() === res.buildingCode.replace(/\s+/g, '').toUpperCase() &&
        a.number.replace(/\D/g, '') === res.apartmentNumber.replace(/\D/g, '')
      );
      if (!apt) return false;
      const aptDebt = getApartmentDebtStatus(apt, payments);
      return aptDebt.unpaidMonths > 4;
    });
  }, [residents, apartments, payments]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border-2 border-[#92e8dd] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.residents.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">{t.residents.subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Owners Dues Excel Button (Export / Import) */}
          <button
            type="button"
            id="btn-residents-owners-dues-excel"
            onClick={() => {
              setOwnersDuesTab('import');
              setIsOwnersDuesModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-bold transition-all shadow-xs border border-emerald-400/30 cursor-pointer"
            title={lang === 'ar' ? 'خانة استيراد وتصدير مستحقات الملاك على صيغة Excel' : 'Importer/Exporter les arriérés des copropriétaires (Excel)'}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>{lang === 'ar' ? 'مستحقات الملاك (Excel) 📗' : 'Arriérés Excel'}</span>
          </button>

          {/* Export PDF Button */}
          <button
            type="button"
            id="btn-open-residents-pdf-modal"
            onClick={() => setIsExportModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold transition-all border border-slate-300 cursor-pointer shadow-2xs"
            title={t.residents.exportTooltip}
          >
            <Printer className="w-4 h-4 text-slate-700" />
            <span>{t.residents.exportPdf}</span>
          </button>

          {/* Export Excel (CSV) Button */}
          <button
            type="button"
            id="btn-direct-residents-excel"
            onClick={() => exportResidentsToExcel(filteredResidents, buildings, lang, filterBuilding, filterType)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold transition-all border border-slate-300 cursor-pointer shadow-2xs"
            title={t.residents.exportTooltip}
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            <span>{t.residents.exportExcel}</span>
          </button>

          {/* Dedicated Resident List Excel Import (Primary Initial Setup) */}
          {!isOwner && (
            <button
              type="button"
              id="btn-open-residents-list-excel-import"
              onClick={() => setIsResidentsImportModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-black transition-all shadow-sm shadow-emerald-700/20 cursor-pointer"
              title={lang === 'ar' ? 'استيراد قائمة السكان من ملف Excel لتسهيل إدخال البيانات الأولية للنظام' : 'Importer la liste des résidents via Excel'}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
              <span>{lang === 'ar' ? 'استيراد السكان (Excel) 📥' : 'Importer Résidents (Excel)'}</span>
            </button>
          )}

          {/* Import Owners / Apartments Excel Button */}
          {!isOwner && (
            <button
              type="button"
              id="btn-open-residents-excel-import"
              onClick={() => setIsImportModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-bold transition-all border border-slate-200 cursor-pointer shadow-2xs"
              title={lang === 'ar' ? 'استيراد وإدخال بيانات الملاك والشقق من ملف Excel' : 'Importer les données des propriétaires via Excel'}
            >
              <UploadCloud className="w-4 h-4 text-[#0a8591]" />
              <span>{lang === 'ar' ? 'استيراد الشقق والملاك' : 'Importer Lots'}</span>
            </button>
          )}

          {/* Reset / Purge Old Names Button */}
          {!isOwner && (
            <button
              type="button"
              id="btn-purge-old-residents"
              onClick={handlePurgeOldResidents}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs font-bold transition-all border border-amber-200 cursor-pointer shadow-2xs"
              title={lang === 'ar' ? 'مسح كافة بيانات وأسماء السكان القدامى لتسجيل اللائحة الجديدة' : 'Purger les anciens résidents pour renouveler la liste'}
            >
              <RotateCcw className="w-4 h-4 text-amber-700" />
              <span>{lang === 'ar' ? 'مسح الأسماء القديمة' : 'Purger anciens'}</span>
            </button>
          )}

          {!isOwner ? (
            <button
              onClick={handleOpenNew}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-sm shadow-[#0a8591]/20 self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.residents.addBtn}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>{lang === 'ar' ? 'وضع الاطلاع فقط' : 'Mode Consultation'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Purged Notification Banner */}
      {purgedMessage && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-3 rounded-xl flex items-center justify-between text-xs font-bold shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{purgedMessage}</span>
          </div>
          <button onClick={() => setPurgedMessage(null)} className="text-emerald-700 hover:text-emerald-900 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Alert Banner for delayed residents (>4 months) */}
      {!isOwner && delayedResidents.length > 0 && (
        <div className="bg-rose-50 border-r-4 border-l-4 border-rose-500 p-4 rounded-xl shadow-xs animate-in fade-in slide-in-from-top-2">
          <div className="flex items-start">
            <AlertTriangle className="w-5 h-5 text-rose-600 mt-0.5 shrink-0" />
            <div className="mx-3 flex-1">
              <h3 className="text-sm font-bold text-rose-900">
                {lang === 'ar' ? 'تنبيه: متأخرات فوق 4 أشهر 🔴' : 'Alerte : Retards de plus de 4 mois 🔴'}
              </h3>
              <p className="text-xs text-rose-700 mt-1">
                {lang === 'ar' 
                  ? `يوجد ${delayedResidents.length} شقة / ساكن تأخروا عن دفع واجبات السانديك لأكثر من 4 أشهر:`
                  : `Il y a ${delayedResidents.length} appartement(s) / résident(s) ayant un retard de paiement de plus de 4 mois :`}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {delayedResidents.map(r => {
                   const apt = apartments.find(a => 
                     a.buildingCode.replace(/\s+/g, '').toUpperCase() === r.buildingCode.replace(/\s+/g, '').toUpperCase() &&
                     a.number.replace(/\D/g, '') === r.apartmentNumber.replace(/\D/g, '')
                   );
                   const debt = apt ? getApartmentDebtStatus(apt, payments) : { unpaidMonths: 0 };
                   return (
                     <span key={r.id} className="inline-flex items-center px-2 py-1 rounded bg-white text-rose-800 text-[11px] font-bold border border-rose-200 shadow-2xs">
                       {r.buildingCode} - {lang === 'ar' ? 'شقة' : 'Apt'} {r.apartmentNumber} 
                       <span className="mx-1 text-rose-400">|</span> 
                       {debt.unpaidMonths} {lang === 'ar' ? 'أشهر' : 'mois'}
                     </span>
                   )
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Form Modal / Box */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-[#0a8591] shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-[#0a8591] flex items-center gap-2">
              <Users2 className="w-5 h-5 text-[#0a8591]" />
              <span>{editingId ? t.common.edit : t.residents.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.name} *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder={lang === 'ar' ? 'الاسم الكامل للساكن' : 'Nom complet du résident'}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.type} *</label>
                <select
                  value={type}
                  onChange={e => setType(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white"
                >
                  <option value="owner">{t.residents.owner}</option>
                  <option value="tenant">{t.residents.tenant}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.building} *</label>
                <select
                  value={buildingCode}
                  onChange={e => setBuildingCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                >
                  <optgroup label="المجموعة الأولى: عمارات GH A (من GH 34 A إلى GH 43 A)">
                    {buildings
                      .filter(b => b.code.endsWith('A'))
                      .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                      .map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                  </optgroup>
                  <optgroup label="المجموعة الثانية: عمارات GH B (من GH 34 B إلى GH 43 B)">
                    {buildings
                      .filter(b => b.code.endsWith('B'))
                      .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                      .map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.apartment} *</label>
                <input
                  type="text"
                  required
                  value={apartmentNumber}
                  onChange={e => setApartmentNumber(e.target.value)}
                  placeholder="01"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.phone} *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+212 661-889900"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">{t.residents.cin} *</label>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    {lang === 'ar' ? 'ضروري لدخول المالك للتطبيق' : 'Requis pour accès'}
                  </span>
                </div>
                <input
                  type="text"
                  value={cin}
                  onChange={e => setCin(e.target.value.toUpperCase())}
                  placeholder="BE452310"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none uppercase font-mono font-bold"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  {lang === 'ar' 
                    ? '💡 رقم البطاقة الوطنية (CIN) هو الرمز السري المعتمد الذي يمكن المالك من الدخول لتطبيق الإقامة.' 
                    : '💡 Le N° CIN est utilisé par le copropriétaire pour s\'authentifier sur l\'application.'}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.vehicle}</label>
                <input
                  type="text"
                  value={vehiclePlate}
                  onChange={e => setVehiclePlate(e.target.value)}
                  placeholder="12345 | أ | 6"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.residents.email}</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="resident@gmail.com"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={lang === 'ar' ? 'بحث بالاسم، رقم الشقة، رقم الهاتف...' : 'Recherche par nom, apt, tél...'}
            className="w-full ps-9 pe-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
          />
        </div>

        <div>
          <select
            value={filterPaymentStatus}
            onChange={e => setFilterPaymentStatus(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#0a8591] font-bold text-slate-700"
          >
            <option value="ALL">{lang === 'ar' ? 'جميع حالات الأداء' : 'Tous les états de paiement'}</option>
            <option value="UP_TO_DATE">{lang === 'ar' ? '✅ وضعية سليمة (بدون ديون)' : '✅ À jour (Sans dette)'}</option>
            <option value="ANY_LATE">{lang === 'ar' ? '⚠️ لديه متأخرات' : '⚠️ A des retards'}</option>
            <option value="LATE">{lang === 'ar' ? '⏳ متأخر (1 - 4 أشهر)' : '⏳ En retard (1 - 4 mois)'}</option>
            <option value="VERY_LATE">{lang === 'ar' ? '🔴 متأخر جداً (+4 أشهر)' : '🔴 Très en retard (+4 mois)'}</option>
          </select>
        </div>

        <div>
          <select
            value={filterBuilding}
            onChange={e => setFilterBuilding(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#0a8591] font-bold"
          >
            <option value="ALL">جميع العمارات</option>
            <optgroup label="المجموعة الأولى: عمارات GH A (من GH 34 A إلى GH 43 A)">
              {buildings
                .filter(b => b.code.endsWith('A'))
                .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                .map(b => (
                  <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                ))}
            </optgroup>
            <optgroup label="المجموعة الثانية: عمارات GH B (من GH 34 B إلى GH 43 B)">
              {buildings
                .filter(b => b.code.endsWith('B'))
                .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                .map(b => (
                  <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                ))}
            </optgroup>
          </select>
        </div>

        <div>
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
          >
            <option value="ALL">{t.residents.filterType}</option>
            <option value="owner">{t.residents.owner}</option>
            <option value="tenant">{t.residents.tenant}</option>
          </select>
        </div>
      </div>

      {/* Residents Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredResidents.map((res) => {
          const apt = apartments.find(a => 
            a.buildingCode.replace(/\s+/g, '').toUpperCase() === res.buildingCode.replace(/\s+/g, '').toUpperCase() &&
            a.number.replace(/\D/g, '') === res.apartmentNumber.replace(/\D/g, '')
          );
          const aptDebt = apt ? getApartmentDebtStatus(apt, payments) : { unpaidMonths: 0, totalBalanceDue: 0, isBlocked: false, isPaid: false };

          return (
            <div 
              key={res.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-[#0a8591]/40 transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-sm text-slate-900">{res.fullName}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        res.type === 'owner' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {res.type === 'owner' ? t.residents.owner : t.residents.tenant}
                      </span>
                      {!aptDebt.isPaid && aptDebt.unpaidMonths > 0 && (
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black shadow-2xs border ${
                          aptDebt.unpaidMonths > 4 
                            ? 'bg-rose-700 text-white border-rose-800 ring-1 ring-rose-300' 
                            : 'bg-amber-600 text-white border-amber-700'
                        }`}>
                          {aptDebt.unpaidMonths > 4
                            ? (lang === 'ar' ? `⛔ دخول معلق (${aptDebt.unpaidMonths} أشهر)` : `⛔ Accès Suspendu (${aptDebt.unpaidMonths} mois)`)
                            : (lang === 'ar' ? `✅ دخول متاح (${aptDebt.unpaidMonths} أشهر تأخير)` : `✅ Accès Autorisé (${aptDebt.unpaidMonths} mois)`)}
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-500 font-mono mt-1">
                      {res.cin ? `CIN: ${res.cin}` : ''}
                    </div>
                  </div>

                  {!isOwner && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(res)}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-emerald-700 cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setResidentToDelete(res)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                        title={lang === 'ar' ? 'حذف الساكن' : 'Supprimer'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Residence placement & Delay Status */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 mb-3 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{t.residents.building} / {t.residents.apartment}:</span>
                    <span className="font-bold text-emerald-800 font-mono">
                      {res.buildingCode} - شقة {res.apartmentNumber}
                    </span>
                  </div>

                    {/* الوضعية المالية */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                      <span className="text-slate-600 font-semibold">{lang === 'ar' ? 'الوضعية المالية:' : 'Situation financière:'}</span>
                      {aptDebt.isPaid ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                          <Check className="w-3 h-3 text-emerald-700" />
                          <span>{lang === 'ar' ? 'خالص (0 تأخير 🟢)' : 'À jour 🟢'}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-100 text-rose-950 font-black text-[11px] border border-rose-300">
                          <AlertTriangle className="w-3 h-3 text-rose-700" />
                          <span>{lang === 'ar' ? `${aptDebt.unpaidMonths} أشهر مستحقة 🔴` : `${aptDebt.unpaidMonths} mois dûs 🔴`}</span>
                        </span>
                      )}
                    </div>

                  {res.vehiclePlate && (
                    <div className="flex items-center justify-between text-slate-600 pt-1 border-t border-slate-200/60">
                      <span className="flex items-center gap-1 text-slate-500">
                        <Car className="w-3 h-3" />
                        <span>{t.residents.vehicle}:</span>
                      </span>
                      <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-[11px]">
                        {res.vehiclePlate}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Quick Phone, WhatsApp & Email */}
              <div className="pt-3 border-t border-slate-100 flex items-center gap-2 flex-wrap">
                <a
                  href={`tel:${res.phone}`}
                  className="flex-1 py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-slate-600" />
                  <span dir="ltr">{res.phone}</span>
                </a>

                <a
                  href={`https://wa.me/${res.phone.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition-colors"
                  title={t.residents.whatsapp}
                >
                  <MessageSquare className="w-4 h-4" />
                </a>

                {res.email && (
                  <a
                    href={`mailto:${res.email}`}
                    className="p-2 rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-800 transition-colors"
                    title="البريد الإلكتروني"
                  >
                    <Mail className="w-4 h-4" />
                  </a>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Official Residents PDF / Excel Export Modal */}
      <ResidentsExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        residents={filteredResidents}
        buildings={buildings}
        lang={lang}
        filterBuilding={filterBuilding}
        filterType={filterType}
        currentUser={currentUser}
      />

      {/* Dedicated Resident List Excel Import Modal */}
      <ResidentsExcelImportModal
        isOpen={isResidentsImportModalOpen}
        onClose={() => setIsResidentsImportModalOpen(false)}
      />

      {/* Excel Bulk Import Modal */}
      <ExcelImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
      />

      {/* Owners Dues Excel Modal (Export & Import) */}
      <OwnersDuesExcelModal
        isOpen={isOwnersDuesModalOpen}
        onClose={() => setIsOwnersDuesModalOpen(false)}
        defaultTab={ownersDuesTab}
      />

      {/* In-App Delete Confirmation Modal */}
      {residentToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'تأكيد حذف الساكن' : 'Confirmation de suppression'}
            </h3>
            
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar' 
                ? `هل أنت متأكد من حذف الساكن "${residentToDelete.fullName}" (شقة ${residentToDelete.apartmentNumber} - ${residentToDelete.buildingCode})؟`
                : `Êtes-vous sûr de vouloir supprimer le résident "${residentToDelete.fullName}" ?`}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setResidentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteResident(residentToDelete.id);
                  setResidentToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تأكيد الحذف' : 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
