import React, { useState, useEffect, useMemo } from 'react';
import { 
  Send, 
  Bot, 
  Settings2, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Clock, 
  MessageSquare, 
  Mail,
  Users, 
  ShieldAlert, 
  FileText,
  Smartphone,
  Info,
  Edit2,
  Check,
  X,
  ExternalLink,
  Copy
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getApartmentDebtStatus, getUnpaidMonthsList } from '../utils/debtUtils';
import { Apartment } from '../types';

export interface AutoReminderConfig {
  isEnabled: boolean;
  thresholdMonths: number; // e.g. 6 months
  autoSendFrequencyDays: number; // e.g. 15 or 30 days
  channel: 'both' | 'whatsapp' | 'email';
  customWhatsAppTemplate: string;
  customEmailSubjectTemplate: string;
  customEmailBodyTemplate: string;
  lastRunDate?: string;
  sentHistory: {
    id: string;
    apartmentId: string;
    apartmentNumber: string;
    buildingCode: string;
    ownerName: string;
    phone: string;
    email: string;
    channel: 'whatsapp' | 'email' | 'both';
    unpaidMonths: number;
    totalAmount: number;
    sentAt: string;
    status: 'sent' | 'queued' | 'skipped_no_contact';
    messageText: string;
  }[];
}

const STORAGE_KEY_REMINDER_CONFIG = 'ma_auto_reminder_config_v2';

export const DEFAULT_LEGAL_WHATSAPP_TEMPLATE = 
`*إشعار قانوني وتذكير رسمي بمستحقات السانديك - إقامة المرجان* ⚖️

السلام عليكم ورحمة الله،
السيد(ة) المحترم(ة): *{OWNER_NAME}*
🏢 الشقة: *{BUILDING_CODE} - شقة رقم {APARTMENT_NUM}*

نود تذكيركم بمقتضى القانون 18.00 المتعلق بنظام الملكية المشتركة، بوجود متأخرات مستحقة بذمتكم لفائدة صندوق اتحاد الملاك (السانديك):

📅 *الشهور غير المؤداة:* {UNPAID_MONTHS_LIST}
⚠️ *إجمالي مدة التأخر:* {MONTHS_COUNT} أشهر (تجاوزت الحد القانوني المحدد بـ 6 أشهر)
💰 *المبلغ الإجمالي المستحق الأداء:* {TOTAL_DUE} درهم

📌 *حساب الأداء البنكي (السانديك):*
• البنك: التجاري وفا بنك (Attijariwafa bank)
• الحساب: اتحاد ملاك إقامة المرجان
• رقم RIB: 007 780 0001234567890123 45

نرجو منكم التفضل بتسوية هذه الوضعية عاجلاً لتفادي أي مساطر قانونية ولضمان استمرارية الخدمات الأساسية للإقامة (نظافة، حراسة، وصيانة المرافق المشتركة).

في حال كنتم قد قمتم بالتحويل مؤخراً، يرجى موافاتنا بوصل الأداء.
شاكرين لكم حسن تفهمكم وتعاونكم.

✍️ *إدارة اتحاد الملاك - إقامة المرجان*`;

export const DEFAULT_LEGAL_EMAIL_SUBJECT_TEMPLATE = 
`إشعار قانوني وتذكير رسمي بمستحقات السانديك - {BUILDING_CODE} شقة رقم {APARTMENT_NUM}`;

export const DEFAULT_LEGAL_EMAIL_BODY_TEMPLATE = 
`إلى السيد(ة) المحترم(ة): {OWNER_NAME}
مالك(ة) الشقة رقم: {APARTMENT_NUM} ({BUILDING_CODE})
أبواب مراكش، المنطقة 10، السكن المتوسط، إقامة المرجان، مراكش - المملكة المغربية

الموضوع: إشعار قانوني وتذكير رسمي بتسوية واجبات الملكية المشتركة (السانديك)
المرجع: القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية

تحية طيبة وبعد،

يشرف مكتب اتحاد الملاك المشتركين (السانديك) لإقامة المرجان أن يوجه إليكم هذا الإشعار التذكيري بخصوص متأخرات واجبات الاشتراك الشهري العالقة بذمتكم، والتي تجاوزت مدة 6 أشهر:

• بيان الشهور غير المؤداة: {UNPAID_MONTHS_LIST}
• مدة التأخر الإجمالية: {MONTHS_COUNT} أشهر
• إجمالي المبلغ المستحق الأداء: {TOTAL_DUE} درهم مغربي

نلتمس منكم التكرم بأداء المبلغ المستحق في أقرب الآجال عبر التحويل للحساب البنكي الرسمي لاتحاد الملاك:
- اسم الحساب: اتحاد ملاك إقامة المرجان
- البنك: التجاري وفا بنك (Attijariwafa bank)
- رقم الحساب البنكي (RIB): 007 780 0001234567890123 45

إن مساهمتكم المنتظمة هي الضامن الوحيد لاستمرار خدمات النظافة، الحراسة، صيانة المرافق والإنارة المشتركة.

في حال سدادكم للمبلغ مؤخراً، يرجى الرد على هذا البريد بنسخة من وصل التحويل البنكي لتسوية سجلكم المحاسبي.

وتقبلوا فائق التقدير والاحترام.

إدارة اتحاد الملاك - إقامة المرجان
الهاتف: 0661000000 | البريد: contact@residence-elmarjane.ma`;

export const AutoReminderModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { apartments, updateApartment, payments, residents, lang } = useApp();

  const [config, setConfig] = useState<AutoReminderConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_REMINDER_CONFIG);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      isEnabled: true,
      thresholdMonths: 6,
      autoSendFrequencyDays: 15,
      channel: 'both',
      customWhatsAppTemplate: DEFAULT_LEGAL_WHATSAPP_TEMPLATE,
      customEmailSubjectTemplate: DEFAULT_LEGAL_EMAIL_SUBJECT_TEMPLATE,
      customEmailBodyTemplate: DEFAULT_LEGAL_EMAIL_BODY_TEMPLATE,
      sentHistory: []
    };
  });

  const [activeTab, setActiveTab] = useState<'eligible' | 'preview_whatsapp' | 'preview_email' | 'settings' | 'history'>('eligible');
  const [selectedApartmentId, setSelectedApartmentId] = useState<string>('');
  const [simulatedSending, setSimulatedSending] = useState(false);
  const [sendSuccessMsg, setSendSuccessMsg] = useState<string | null>(null);
  const [channelFilter, setChannelFilter] = useState<'all' | 'has_phone' | 'has_email'>('all');
  const [editingContactAptId, setEditingContactAptId] = useState<string | null>(null);
  const [editPhoneVal, setEditPhoneVal] = useState('');
  const [editEmailVal, setEditEmailVal] = useState('');
  const [copiedMsg, setCopiedMsg] = useState(false);

  // Save config
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REMINDER_CONFIG, JSON.stringify(config));
    } catch {
      // ignore
    }
  }, [config]);

  // Compute all eligible overdue apartments (unpaidMonths > thresholdMonths)
  const eligibleOverdueList = useMemo(() => {
    const list: {
      apt: Apartment;
      debt: ReturnType<typeof getApartmentDebtStatus>;
      unpaidList: ReturnType<typeof getUnpaidMonthsList>;
      ownerName: string;
      phone: string;
      email: string;
      isOverThreshold: boolean;
    }[] = [];

    apartments.forEach(apt => {
      if (apt.isSyndicOffice || (apt.buildingCode === 'GH 34 A' && apt.number === '01')) return;

      const debt = getApartmentDebtStatus(apt, payments);
      // 6 months and above as per legal threshold rule (>= thresholdMonths)
      if (!debt.isPaid && debt.unpaidMonths >= config.thresholdMonths) {
        const unpaidList = getUnpaidMonthsList(debt.unpaidMonths);
        const res = residents.find(
          r => r.buildingCode.trim().toLowerCase() === apt.buildingCode.trim().toLowerCase() &&
               r.apartmentNumber.trim() === apt.number.trim()
        );
        const ownerName = apt.ownerName || res?.fullName || (lang === 'ar' ? `مالك شقة ${apt.number} (${apt.buildingCode})` : `Propriétaire Appt ${apt.number}`);
        const phone = apt.ownerPhone || apt.residentPhone || res?.phone || '';
        const email = apt.ownerEmail || apt.residentEmail || res?.email || '';

        list.push({
          apt,
          debt,
          unpaidList,
          ownerName,
          phone,
          email,
          isOverThreshold: true
        });
      }
    });

    // Sort by largest unpaid months first
    return list.sort((a, b) => b.debt.unpaidMonths - a.debt.unpaidMonths);
  }, [apartments, payments, residents, config.thresholdMonths, lang]);

  // Set default selected apartment for preview
  useEffect(() => {
    if (eligibleOverdueList.length > 0 && !selectedApartmentId) {
      setSelectedApartmentId(eligibleOverdueList[0].apt.id);
    }
  }, [eligibleOverdueList, selectedApartmentId]);

  const selectedItem = useMemo(() => {
    return eligibleOverdueList.find(i => i.apt.id === selectedApartmentId) || eligibleOverdueList[0];
  }, [eligibleOverdueList, selectedApartmentId]);

  // Construct WhatsApp text for a specific item
  const buildWhatsAppMessage = (item: typeof eligibleOverdueList[0] | undefined) => {
    if (!item) return '';
    const monthsText = item.unpaidList.map(u => u.labelAr).join('، ');
    return (config.customWhatsAppTemplate || DEFAULT_LEGAL_WHATSAPP_TEMPLATE)
      .replace(/{OWNER_NAME}/g, item.ownerName)
      .replace(/{BUILDING_CODE}/g, item.apt.buildingCode)
      .replace(/{APARTMENT_NUM}/g, item.apt.number)
      .replace(/{UNPAID_MONTHS_LIST}/g, monthsText)
      .replace(/{MONTHS_COUNT}/g, String(item.debt.unpaidMonths))
      .replace(/{TOTAL_DUE}/g, item.debt.totalBalanceDue.toLocaleString());
  };

  // Construct Email Subject
  const buildEmailSubject = (item: typeof eligibleOverdueList[0] | undefined) => {
    if (!item) return '';
    return (config.customEmailSubjectTemplate || DEFAULT_LEGAL_EMAIL_SUBJECT_TEMPLATE)
      .replace(/{OWNER_NAME}/g, item.ownerName)
      .replace(/{BUILDING_CODE}/g, item.apt.buildingCode)
      .replace(/{APARTMENT_NUM}/g, item.apt.number)
      .replace(/{MONTHS_COUNT}/g, String(item.debt.unpaidMonths))
      .replace(/{TOTAL_DUE}/g, item.debt.totalBalanceDue.toLocaleString());
  };

  // Construct Email Body
  const buildEmailBody = (item: typeof eligibleOverdueList[0] | undefined) => {
    if (!item) return '';
    const monthsText = item.unpaidList.map(u => u.labelAr).join('، ');
    return (config.customEmailBodyTemplate || DEFAULT_LEGAL_EMAIL_BODY_TEMPLATE)
      .replace(/{OWNER_NAME}/g, item.ownerName)
      .replace(/{BUILDING_CODE}/g, item.apt.buildingCode)
      .replace(/{APARTMENT_NUM}/g, item.apt.number)
      .replace(/{UNPAID_MONTHS_LIST}/g, monthsText)
      .replace(/{MONTHS_COUNT}/g, String(item.debt.unpaidMonths))
      .replace(/{TOTAL_DUE}/g, item.debt.totalBalanceDue.toLocaleString());
  };

  // Build WhatsApp URL
  const getWhatsAppUrlForItem = (item: typeof eligibleOverdueList[0]) => {
    const rawPhone = item.phone.replace(/\D/g, '');
    const cleanPhone = rawPhone 
      ? (rawPhone.startsWith('0') ? '212' + rawPhone.slice(1) : rawPhone.startsWith('212') ? rawPhone : '212' + rawPhone) 
      : '';
    const text = buildWhatsAppMessage(item);
    return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
  };

  // Build Email Mailto URL
  const getEmailUrlForItem = (item: typeof eligibleOverdueList[0]) => {
    const subject = encodeURIComponent(buildEmailSubject(item));
    const body = encodeURIComponent(buildEmailBody(item));
    return `mailto:${item.email || ''}?subject=${subject}&body=${body}`;
  };

  // Save Inline Contact Edit (Phone / Email)
  const handleSaveContact = (aptId: string) => {
    updateApartment(aptId, {
      ownerPhone: editPhoneVal,
      ownerEmail: editEmailVal
    });
    setEditingContactAptId(null);
  };

  // Auto-Dispatch all eligible
  const handleAutoDispatchAll = (targetChannel: 'both' | 'whatsapp' | 'email' = config.channel) => {
    if (eligibleOverdueList.length === 0) return;
    setSimulatedSending(true);

    const now = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const newLogs: AutoReminderConfig['sentHistory'] = [];

    eligibleOverdueList.forEach(item => {
      const msg = targetChannel === 'email' ? buildEmailBody(item) : buildWhatsAppMessage(item);
      const hasPhone = Boolean(item.phone);
      const hasEmail = Boolean(item.email);
      let status: 'sent' | 'queued' | 'skipped_no_contact' = 'sent';

      if (targetChannel === 'whatsapp' && !hasPhone) status = 'skipped_no_contact';
      if (targetChannel === 'email' && !hasEmail) status = 'skipped_no_contact';
      if (targetChannel === 'both' && !hasPhone && !hasEmail) status = 'skipped_no_contact';

      newLogs.push({
        id: `log-${Date.now()}-${item.apt.id}`,
        apartmentId: item.apt.id,
        apartmentNumber: item.apt.number,
        buildingCode: item.apt.buildingCode,
        ownerName: item.ownerName,
        phone: item.phone,
        email: item.email,
        channel: targetChannel,
        unpaidMonths: item.debt.unpaidMonths,
        totalAmount: item.debt.totalBalanceDue,
        sentAt: now,
        status,
        messageText: msg
      });
    });

    setTimeout(() => {
      setConfig(prev => ({
        ...prev,
        lastRunDate: now,
        sentHistory: [...newLogs, ...prev.sentHistory].slice(0, 150)
      }));
      setSimulatedSending(false);
      setSendSuccessMsg(
        lang === 'ar'
          ? `تم تفعيل وتجهيز دورة الإشعارات التلقائية بنجاح لـ ${eligibleOverdueList.length} مالك متأخر لأكثر من ${config.thresholdMonths} أشهر عبر (${targetChannel === 'both' ? 'واتساب والبريد الإلكتروني' : targetChannel === 'whatsapp' ? 'واتساب' : 'البريد الإلكتروني'}).`
          : `Rappels automatiques déclenchés pour ${eligibleOverdueList.length} copropriétaires (+${config.thresholdMonths} mois).`
      );
      setTimeout(() => setSendSuccessMsg(null), 6000);
    }, 800);
  };

  // Filtered display list
  const filteredList = useMemo(() => {
    if (channelFilter === 'has_phone') return eligibleOverdueList.filter(i => i.phone);
    if (channelFilter === 'has_email') return eligibleOverdueList.filter(i => i.email);
    return eligibleOverdueList;
  }, [eligibleOverdueList, channelFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white flex items-center justify-between gap-4 border-b border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-inner shrink-0">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-xl font-black">
                  {lang === 'ar' ? 'إشعارات التذكير التلقائية عبر واتساب والبريد الإلكتروني (+6 أشهر)' : 'Rappels Automatiques WhatsApp & Email (+6 Mois)'}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                  {config.isEnabled ? (lang === 'ar' ? '⚡ التذكير التلقائي مفعّل' : '⚡ Actif') : (lang === 'ar' ? 'معطل' : 'Désactivé')}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                {lang === 'ar' 
                  ? 'إرسال إنذارات وتذكيرات قانونية تلقائياً عبر واتساب أو البريد الإلكتروني لأي مالك تجاوز 6 أشهر من عدم الأداء وفقاً للقانون 18.00.' 
                  : 'Envoi automatique de rappels formels par WhatsApp ou Email aux copropriétaires avec plus de 6 mois d’arriérés.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm font-bold transition-all cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        {/* Success Banner */}
        {sendSuccessMsg && (
          <div className="bg-emerald-600 text-white px-5 py-3 text-xs font-bold flex items-center gap-2 justify-between animate-in slide-in-from-top shrink-0">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{sendSuccessMsg}</span>
            </div>
            <button onClick={() => setSendSuccessMsg(null)} className="text-white/80 hover:text-white cursor-pointer">✕</button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center justify-between px-5 pt-3 border-b border-slate-200 bg-slate-50/70 text-xs font-bold gap-2 overflow-x-auto shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('eligible')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'eligible'
                  ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>{lang === 'ar' ? `المتأخرون (+${config.thresholdMonths} أشهر)` : `Débiteurs (+${config.thresholdMonths} mois)`}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-mono">
                {eligibleOverdueList.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('preview_whatsapp')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'preview_whatsapp'
                  ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? 'معاينة رسالة واتساب' : 'Aperçu WhatsApp'}</span>
            </button>

            <button
              onClick={() => setActiveTab('preview_email')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'preview_email'
                  ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Mail className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ar' ? 'معاينة البريد الإلكتروني' : 'Aperçu Email'}</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'settings'
                  ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Settings2 className="w-4 h-4" />
              <span>{lang === 'ar' ? 'إعدادات وقوالب الإشعارات' : 'Paramètres & Modèles'}</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'history'
                  ? 'border-emerald-600 text-emerald-800 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>{lang === 'ar' ? 'سجل الإرسال' : 'Historique'}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-mono">
                {config.sentHistory.length}
              </span>
            </button>
          </div>

          {/* Bulk Automation Trigger Buttons */}
          <div className="flex items-center gap-2 pb-1.5 shrink-0">
            <button
              type="button"
              disabled={simulatedSending || eligibleOverdueList.length === 0}
              onClick={() => handleAutoDispatchAll('both')}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white text-xs font-black flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title={lang === 'ar' ? 'إرسال الإشعارات لجميع المتأخرين عبر القناتين' : 'Envoyer à tous'}
            >
              {simulatedSending ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{lang === 'ar' ? 'جاري الإرسال...' : 'Envoi...'}</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? '⚡ تشغيل التذكير التلقائي الآن' : 'Déclencher Tout'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* TAB 1: ELIGIBLE OVERDUE OWNERS (> 6 MONTHS) */}
          {activeTab === 'eligible' && (
            <div className="space-y-4">
              
              {/* Info & Rule Summary Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-50 via-amber-50 to-rose-50 border border-rose-200 text-slate-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-200/80 text-rose-900 flex items-center justify-center shrink-0">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-black text-rose-950 flex items-center gap-2">
                      <span>{lang === 'ar' ? `المتأخرون لأكثر من ${config.thresholdMonths} أشهر (الحد القانوني للملكية المشتركة)` : `Arriérés de plus de ${config.thresholdMonths} mois`}</span>
                      <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold">
                        {eligibleOverdueList.length} {lang === 'ar' ? 'شقة مستهدفة' : 'lots'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-700 mt-0.5">
                      {lang === 'ar'
                        ? 'يمكنك التذكير بنقرة واحدة عبر واتساب (WhatsApp) أو فتح رسالة بريد إلكتروني رسمية (Email) مجهزة بالكامل.'
                        : 'Envoyez un rappel direct par WhatsApp ou préparez un email formel en un clic.'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-start sm:text-end">
                    <div className="text-[10px] text-rose-800 font-bold">{lang === 'ar' ? 'مجموع ديون هذه الفئة:' : 'Total arriérés :'}</div>
                    <div className="text-base sm:text-lg font-black font-mono text-rose-700">
                      {eligibleOverdueList.reduce((sum, i) => sum + i.debt.totalBalanceDue, 0).toLocaleString()} DH
                    </div>
                  </div>
                </div>
              </div>

              {/* Channel Filter Pills */}
              <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-bold text-slate-500">{lang === 'ar' ? 'تصفية القنوات:' : 'Filtre :'}</span>
                  <button
                    onClick={() => setChannelFilter('all')}
                    className={`px-2.5 py-1 rounded-lg font-bold text-xs cursor-pointer ${
                      channelFilter === 'all' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {lang === 'ar' ? `الكل (${eligibleOverdueList.length})` : `Tous (${eligibleOverdueList.length})`}
                  </button>
                  <button
                    onClick={() => setChannelFilter('has_phone')}
                    className={`px-2.5 py-1 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer ${
                      channelFilter === 'has_phone' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    }`}
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>{lang === 'ar' ? `يتوفر على هاتف/واتساب (${eligibleOverdueList.filter(i => i.phone).length})` : 'Avec WhatsApp'}</span>
                  </button>
                  <button
                    onClick={() => setChannelFilter('has_email')}
                    className={`px-2.5 py-1 rounded-lg font-bold text-xs flex items-center gap-1 cursor-pointer ${
                      channelFilter === 'has_email' ? 'bg-blue-700 text-white' : 'bg-blue-50 text-blue-800 border border-blue-200'
                    }`}
                  >
                    <Mail className="w-3 h-3" />
                    <span>{lang === 'ar' ? `يتوفر على إيميل (${eligibleOverdueList.filter(i => i.email).length})` : 'Avec Email'}</span>
                  </button>
                </div>

                {/* Bulk Email Launcher */}
                {eligibleOverdueList.filter(i => i.email).length > 0 && (
                  <a
                    href={`mailto:${eligibleOverdueList.filter(i => i.email).map(i => i.email).join(',')}?subject=${encodeURIComponent('إشعار تذكيري جماعي بمستحقات السانديك - إقامة المرجان')}&body=${encodeURIComponent('السادة الملاك المحترمين، يرجى التكرم بتسوية واجبات السانديك المتأخرة لأكثر من 6 أشهر...')}`}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-2xs"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'إرسال بريد جماعي لجميع العناوين المتوفرة ✉️' : 'Email groupé'}</span>
                  </a>
                )}
              </div>

              {/* List */}
              {filteredList.length === 0 ? (
                <div className="py-12 px-4 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                  <div className="text-sm font-bold text-slate-800">
                    {lang === 'ar' ? 'لا توجد شقق مطابقة للشروط حالياً' : 'Aucun résultat correspondant.'}
                  </div>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    {lang === 'ar' 
                      ? 'جميع الشقق مسواة أو لا تتجاوز الحد المحدد من عدم الأداء.' 
                      : 'Tous les appartements sont à jour ou sous le seuil critique.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-2xs">
                    {filteredList.map((item) => {
                      const isSelected = selectedItem?.apt.id === item.apt.id;
                      const whatsappUrl = getWhatsAppUrlForItem(item);
                      const emailUrl = getEmailUrlForItem(item);
                      const isEditingThis = editingContactAptId === item.apt.id;

                      return (
                        <div
                          key={item.apt.id}
                          onClick={() => {
                            setSelectedApartmentId(item.apt.id);
                          }}
                          className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors cursor-pointer ${
                            isSelected ? 'bg-emerald-50/50 border-s-4 border-emerald-600' : 'hover:bg-slate-50/80'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <span className="w-11 h-11 rounded-2xl bg-rose-100 text-rose-900 font-mono font-black flex items-center justify-center text-sm border border-rose-300 shrink-0 shadow-2xs">
                              {item.apt.number}
                            </span>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-black text-slate-900 text-sm">{item.apt.buildingCode} - شقة {item.apt.number}</span>
                                <span className="px-2.5 py-0.5 rounded-full bg-rose-700 text-white font-mono font-black text-[11px] shadow-2xs">
                                  {item.debt.unpaidMonths} {lang === 'ar' ? 'أشهر متبقية في ذمته' : 'mois'}
                                </span>
                              </div>

                              <div className="text-xs text-slate-700 flex items-center gap-2 flex-wrap font-bold">
                                <span className="text-slate-900">{item.ownerName}</span>
                              </div>

                              {/* Contact Details (Phone & Email) with Inline Quick Edit */}
                              {isEditingThis ? (
                                <div className="flex items-center gap-2 flex-wrap pt-1.5" onClick={(e) => e.stopPropagation()}>
                                  <input
                                    type="tel"
                                    placeholder="الهاتف: 06XXXXXXXX"
                                    value={editPhoneVal}
                                    onChange={(e) => setEditPhoneVal(e.target.value)}
                                    className="px-2.5 py-1 text-xs border border-emerald-400 rounded-lg bg-white font-mono"
                                  />
                                  <input
                                    type="email"
                                    placeholder="البريد: user@example.com"
                                    value={editEmailVal}
                                    onChange={(e) => setEditEmailVal(e.target.value)}
                                    className="px-2.5 py-1 text-xs border border-blue-400 rounded-lg bg-white font-mono"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleSaveContact(item.apt.id)}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>حفظ</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingContactAptId(null)}
                                    className="px-2 py-1 bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                                  >
                                    إلغاء
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-3 text-[11px] text-slate-500 flex-wrap">
                                  <span className="flex items-center gap-1 font-mono">
                                    <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                                    {item.phone ? (
                                      <span className="text-slate-800 font-bold">{item.phone}</span>
                                    ) : (
                                      <span className="text-rose-500 italic">{lang === 'ar' ? 'بدون هاتف' : 'Sans tél'}</span>
                                    )}
                                  </span>

                                  <span>•</span>

                                  <span className="flex items-center gap-1 font-mono">
                                    <Mail className="w-3.5 h-3.5 text-blue-600" />
                                    {item.email ? (
                                      <span className="text-slate-800 font-bold">{item.email}</span>
                                    ) : (
                                      <span className="text-slate-400 italic">{lang === 'ar' ? 'بدون بريد إلكتروني' : 'Sans email'}</span>
                                    )}
                                  </span>

                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEditingContactAptId(item.apt.id);
                                      setEditPhoneVal(item.phone || '');
                                      setEditEmailVal(item.email || '');
                                    }}
                                    className="text-[10px] text-slate-600 hover:text-emerald-700 font-bold flex items-center gap-0.5 underline cursor-pointer"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                    <span>{lang === 'ar' ? 'تعديل الاتصال' : 'Modifier'}</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right: Total Debt & Quick WhatsApp / Email Buttons */}
                          <div className="flex items-center justify-between md:justify-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                            <div className="text-start md:text-end">
                              <div className="text-sm font-black font-mono text-rose-700">
                                {item.debt.totalBalanceDue.toLocaleString()} DH
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {item.debt.monthlyFee} DH / {lang === 'ar' ? 'شهر' : 'mois'}
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              {/* Direct WhatsApp */}
                              <a
                                href={whatsappUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer"
                                title={lang === 'ar' ? 'إرسال تذكير فوري عبر واتساب' : 'Envoyer WhatsApp'}
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                                <span>{lang === 'ar' ? 'واتساب 💬' : 'WhatsApp'}</span>
                              </a>

                              {/* Direct Email */}
                              <a
                                href={emailUrl}
                                onClick={(e) => e.stopPropagation()}
                                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer ${
                                  item.email 
                                    ? 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white' 
                                    : 'bg-slate-100 hover:bg-blue-50 text-blue-700 border border-blue-200'
                                }`}
                                title={lang === 'ar' ? 'إرسال تذكير رسمي عبر البريد الإلكتروني' : 'Envoyer par Email'}
                              >
                                <Mail className="w-3.5 h-3.5" />
                                <span>{lang === 'ar' ? 'إيميل ✉️' : 'Email'}</span>
                              </a>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PREVIEW WHATSAPP MESSAGE */}
          {activeTab === 'preview_whatsapp' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div>
                  <label className="text-xs font-bold text-slate-700 block">
                    {lang === 'ar' ? 'اختر شقة لمعاينة رسالة الواتساب المجهزة لها:' : 'Sélectionnez un appartement :'}
                  </label>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'ar' ? 'يتم تعويض اسم المالك، الشهور، المبلغ المستحق، وحساب البنك تلقائياً.' : 'Les variables sont remplacées automatiquement.'}
                  </p>
                </div>

                <select
                  value={selectedApartmentId}
                  onChange={(e) => setSelectedApartmentId(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-600"
                >
                  {eligibleOverdueList.map(i => (
                    <option key={i.apt.id} value={i.apt.id}>
                      {i.apt.buildingCode} - شقة {i.apt.number} ({i.ownerName} - {i.debt.unpaidMonths} أشهر)
                    </option>
                  ))}
                </select>
              </div>

              {/* WhatsApp Bubble Preview */}
              <div className="bg-slate-100 p-4 sm:p-6 rounded-3xl border border-slate-200 flex justify-center">
                <div className="w-full max-w-lg bg-[#dcf8c6] text-slate-900 p-4 sm:p-5 rounded-2xl rounded-tr-xs shadow-md border border-emerald-200/60 text-xs sm:text-sm font-sans whitespace-pre-wrap leading-relaxed">
                  {buildWhatsAppMessage(selectedItem) || (lang === 'ar' ? 'لا يوجد نص للمعاينة' : 'Aucun texte')}
                </div>
              </div>

              {/* Actions */}
              {selectedItem && (
                <div className="flex items-center justify-end gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(buildWhatsAppMessage(selectedItem));
                      setCopiedMsg(true);
                      setTimeout(() => setCopiedMsg(false), 3000);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedMsg ? (lang === 'ar' ? 'تم نسخ النص! ✓' : 'Copié !') : (lang === 'ar' ? 'نسخ النص' : 'Copier')}</span>
                  </button>

                  <a
                    href={getWhatsAppUrlForItem(selectedItem)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>{lang === 'ar' ? `إرسال إلى ${selectedItem.ownerName} عبر واتساب` : 'Envoyer via WhatsApp'}</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: PREVIEW EMAIL MESSAGE */}
          {activeTab === 'preview_email' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div>
                  <label className="text-xs font-bold text-slate-700 block">
                    {lang === 'ar' ? 'اختر شقة لمعاينة الإشعار الرسمي عبر البريد الإلكتروني:' : 'Sélectionnez un appartement :'}
                  </label>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'ar' ? 'رسالة قانونية رسمية موثقة وفق مقتضيات قانون الملكية المشتركة 18.00.' : 'Email officiel selon la loi 18.00.'}
                  </p>
                </div>

                <select
                  value={selectedApartmentId}
                  onChange={(e) => setSelectedApartmentId(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-blue-600"
                >
                  {eligibleOverdueList.map(i => (
                    <option key={i.apt.id} value={i.apt.id}>
                      {i.apt.buildingCode} - شقة {i.apt.number} ({i.ownerName})
                    </option>
                  ))}
                </select>
              </div>

              {/* Email Client Preview Box */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-xs">
                <div className="bg-slate-50 p-3.5 border-b border-slate-200 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-500 w-16">{lang === 'ar' ? 'إلى (To):' : 'À :'}</span>
                    <span className="font-bold font-mono text-slate-900">{selectedItem?.email || (lang === 'ar' ? '(البريد الإلكتروني للساكن غير مسجل بعد)' : '(Email non renseigné)')}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-500 w-16">{lang === 'ar' ? 'الموضوع:' : 'Objet :'}</span>
                    <span className="font-black text-blue-900">{buildEmailSubject(selectedItem)}</span>
                  </div>
                </div>

                <div className="p-5 whitespace-pre-wrap font-sans text-slate-800 leading-relaxed bg-slate-50/30">
                  {buildEmailBody(selectedItem)}
                </div>
              </div>

              {/* Actions */}
              {selectedItem && (
                <div className="flex items-center justify-end gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(`${buildEmailSubject(selectedItem)}\n\n${buildEmailBody(selectedItem)}`);
                      setCopiedMsg(true);
                      setTimeout(() => setCopiedMsg(false), 3000);
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedMsg ? (lang === 'ar' ? 'تم نسخ نص البريد! ✓' : 'Copié !') : (lang === 'ar' ? 'نسخ نص الإيميل' : 'Copier')}</span>
                  </button>

                  <a
                    href={getEmailUrlForItem(selectedItem)}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
                  >
                    <Mail className="w-4 h-4" />
                    <span>{lang === 'ar' ? `فتح برنامج البريد وإرسال الإشعار إلى ${selectedItem.ownerName}` : 'Ouvrir client Email'}</span>
                  </a>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: AUTOMATION SETTINGS & TEMPLATES */}
          {activeTab === 'settings' && (
            <div className="space-y-5">
              
              {/* Toggle switch */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Bot className="w-4 h-4 text-emerald-600" />
                    <span>{lang === 'ar' ? 'تفعيل نظام التذكير الأوتوماتيكي الدوري' : 'Activer les rappels programmés'}</span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {lang === 'ar' 
                      ? 'عند التفعيل، يقوم النظام بتجهيز الإشعارات لأي مالك يتجاوز 6 أشهر من عدم الأداء بصورة دورية.' 
                      : 'Génération automatique des notifications pour les arriérés dépassant 6 mois.'}
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.isEnabled}
                    onChange={(e) => setConfig(prev => ({ ...prev, isEnabled: e.target.checked }))}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Threshold & Channel Configuration */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span>{lang === 'ar' ? 'الحد القانوني للتأخر (بالأشهر):' : 'Seuil d’arriérés (mois) :'}</span>
                  </label>
                  <select
                    value={config.thresholdMonths}
                    onChange={(e) => setConfig(prev => ({ ...prev, thresholdMonths: Number(e.target.value) }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value={3}>{lang === 'ar' ? '3 أشهر فما فوق' : '3 mois et plus'}</option>
                    <option value={6}>{lang === 'ar' ? '6 أشهر فما فوق (الافتراضي القانوني ⚖️)' : '6 mois et plus (Règle légale)'}</option>
                    <option value={9}>{lang === 'ar' ? '9 أشهر فما فوق' : '9 mois et plus'}</option>
                    <option value={12}>{lang === 'ar' ? 'سنة واحدة فما فوق (12 شهراً)' : '1 an et plus'}</option>
                  </select>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-teal-600" />
                    <span>{lang === 'ar' ? 'قناة الإرسال المعتمدة:' : 'Canal d\'envoi :'}</span>
                  </label>
                  <select
                    value={config.channel}
                    onChange={(e) => setConfig(prev => ({ ...prev, channel: e.target.value as any }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value="both">{lang === 'ar' ? 'واتساب والبريد الإلكتروني معاً 🚀' : 'WhatsApp & Email'}</option>
                    <option value="whatsapp">{lang === 'ar' ? 'واتساب فقط (WhatsApp) 💬' : 'WhatsApp uniquement'}</option>
                    <option value="email">{lang === 'ar' ? 'البريد الإلكتروني فقط (Email) ✉️' : 'Email uniquement'}</option>
                  </select>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span>{lang === 'ar' ? 'وتيرة التذكير التلقائي:' : 'Fréquence de rappel :'}</span>
                  </label>
                  <select
                    value={config.autoSendFrequencyDays}
                    onChange={(e) => setConfig(prev => ({ ...prev, autoSendFrequencyDays: Number(e.target.value) }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value={7}>{lang === 'ar' ? 'كل 7 أيام (أسبوعياً)' : 'Tous les 7 jours'}</option>
                    <option value={15}>{lang === 'ar' ? 'كل 15 يوماً (مرتان بالشهر)' : 'Tous les 15 jours'}</option>
                    <option value={30}>{lang === 'ar' ? 'كل 30 يوماً (شهرياً)' : 'Tous les 30 jours'}</option>
                  </select>
                </div>
              </div>

              {/* Template Editor - WhatsApp */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-700" />
                    <span>{lang === 'ar' ? 'قالب رسالة واتساب (WhatsApp):' : 'Modèle message WhatsApp :'}</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setConfig(prev => ({ ...prev, customWhatsAppTemplate: DEFAULT_LEGAL_WHATSAPP_TEMPLATE }))}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? 'استعادة قالب واتساب الافتراضي' : 'Rétablir défaut'}
                  </button>
                </div>

                <textarea
                  rows={6}
                  value={config.customWhatsAppTemplate}
                  onChange={(e) => setConfig(prev => ({ ...prev, customWhatsAppTemplate: e.target.value }))}
                  className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:ring-2 focus:ring-emerald-600 leading-relaxed text-slate-800"
                />
              </div>

              {/* Template Editor - Email */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-blue-700" />
                    <span>{lang === 'ar' ? 'قالب البريد الإلكتروني (Email):' : 'Modèle Email :'}</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setConfig(prev => ({ 
                      ...prev, 
                      customEmailSubjectTemplate: DEFAULT_LEGAL_EMAIL_SUBJECT_TEMPLATE,
                      customEmailBodyTemplate: DEFAULT_LEGAL_EMAIL_BODY_TEMPLATE 
                    }))}
                    className="text-[10px] text-blue-700 hover:text-blue-900 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? 'استعادة قالب الإيميل الافتراضي' : 'Rétablir défaut'}
                  </button>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'موضوع البريد الإلكتروني (Subject):' : 'Objet :'}</span>
                  <input
                    type="text"
                    value={config.customEmailSubjectTemplate}
                    onChange={(e) => setConfig(prev => ({ ...prev, customEmailSubjectTemplate: e.target.value }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:ring-2 focus:ring-blue-600 text-slate-800"
                  />
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'نص رسالة البريد (Email Body):' : 'Corps du message :'}</span>
                  <textarea
                    rows={7}
                    value={config.customEmailBodyTemplate}
                    onChange={(e) => setConfig(prev => ({ ...prev, customEmailBodyTemplate: e.target.value }))}
                    className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:ring-2 focus:ring-blue-600 leading-relaxed text-slate-800"
                  />
                </div>

                <div className="text-[11px] text-slate-500 space-y-1">
                  <div className="font-bold text-slate-700">{lang === 'ar' ? 'المتغيرات الذكية المتاحة للاستخدام في النصين:' : 'Variables disponibles :'}</div>
                  <div className="flex items-center gap-1.5 flex-wrap font-mono text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{OWNER_NAME}"} (اسم المالك)</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{BUILDING_CODE}"} (العمارة)</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{APARTMENT_NUM}"} (رقم الشقة)</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{UNPAID_MONTHS_LIST}"} (الشهور غير المؤداة)</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{MONTHS_COUNT}"} (عدد الأشهر)</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{TOTAL_DUE}"} (المبلغ الإجمالي)</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 5: HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                <span>{lang === 'ar' ? `سجل الإشعارات والتذكيرات المرسلة (${config.sentHistory.length}):` : `Historique (${config.sentHistory.length}) :`}</span>
                {config.sentHistory.length > 0 && (
                  <button
                    onClick={() => setConfig(prev => ({ ...prev, sentHistory: [] }))}
                    className="text-[10px] text-rose-600 hover:text-rose-800 cursor-pointer"
                  >
                    {lang === 'ar' ? 'مسح السجل' : 'Effacer'}
                  </button>
                )}
              </div>

              {config.sentHistory.length === 0 ? (
                <div className="py-12 px-4 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-1">
                  <Clock className="w-8 h-8 text-slate-400 mx-auto" />
                  <div className="text-xs font-bold text-slate-700">{lang === 'ar' ? 'لا يوجد أي سجل إرسال سابق' : 'Aucun historique'}</div>
                  <p className="text-[11px] text-slate-500">{lang === 'ar' ? 'سيتم حفظ كافة الإشعارات التلقائية هنا.' : 'Les envois apparaîtront ici.'}</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-2xs">
                  {config.sentHistory.map((item) => (
                    <div key={item.id} className="p-3 sm:p-4 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{item.buildingCode} - شقة {item.apartmentNumber}</span>
                          <span className="text-slate-500">({item.ownerName})</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>{item.sentAt}</span>
                          <span>•</span>
                          <span className="font-bold text-rose-700">{item.unpaidMonths} {lang === 'ar' ? 'أشهر' : 'mois'} ({item.totalAmount.toLocaleString()} DH)</span>
                          <span>•</span>
                          <span className="font-mono">{item.channel === 'both' ? 'واتساب + إيميل' : item.channel === 'whatsapp' ? 'واتساب' : 'إيميل'}</span>
                        </div>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        item.status === 'sent' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {item.status === 'sent' ? (lang === 'ar' ? 'تم الإشعار بنجاح 🟢' : 'Envoyé 🟢') : (lang === 'ar' ? 'بدون وسيلة اتصال ⚠️' : 'Non envoyé')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs shrink-0">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <Info className="w-4 h-4 text-slate-400" />
            <span>{lang === 'ar' ? 'نظام التذكير التلقائي الذكي - سانديك إقامة المرجان' : 'Système de Rappel Automatique Syndic'}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs cursor-pointer shadow-2xs"
          >
            {lang === 'ar' ? 'إغلاق' : 'Fermer'}
          </button>
        </div>

      </div>
    </div>
  );
};
