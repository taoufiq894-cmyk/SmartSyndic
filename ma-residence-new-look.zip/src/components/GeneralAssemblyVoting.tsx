import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Vote, CheckCircle2, XCircle, MinusCircle, Users, BarChart3, 
  ShieldCheck, Scale, FileText, Printer, Plus, Trash2, 
  Lock, Unlock, Clock, AlertTriangle, Sparkles, Filter, 
  Search, ChevronDown, ChevronUp, RefreshCw, Send, Check, 
  Eye, Building, MessageSquare, ArrowRight, ShieldAlert, Award
} from 'lucide-react';
import { 
  AssemblyResolution, VoteChoice, ResolutionCategory, 
  MajorityRequired, AssemblyType, ResolutionStatus 
} from '../types';

export const GeneralAssemblyVoting: React.FC = () => {
  const { 
    lang, currentUser, apartments, assemblyResolutions, 
    castResolutionVote, addAssemblyResolution, updateAssemblyResolution, 
    deleteAssemblyResolution, setAssemblyResolutionStatus, resetAssemblyResolutionVotes 
  } = useApp();

  const isAr = lang === 'ar';
  const isAdmin = currentUser?.role !== 'resident';

  // Active view mode: 'voter' (resident voting form) | 'admin' (live administration dashboard)
  const [viewMode, setViewMode] = useState<'voter' | 'admin'>(isAdmin ? 'admin' : 'voter');

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Simulation apartment selector for admin/syndic when testing the voter form
  const [simulatedApartmentId, setSimulatedApartmentId] = useState<string>(() => {
    if (currentUser?.role === 'resident' && currentUser.apartment) {
      return `${currentUser.building || 'GH 34 A'}-${currentUser.apartment}`;
    }
    return 'GH 34 A-01';
  });

  // State for adding a new resolution
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTitleAr, setNewTitleAr] = useState('');
  const [newTitleFr, setNewTitleFr] = useState('');
  const [newDescAr, setNewDescAr] = useState('');
  const [newDescFr, setNewDescFr] = useState('');
  const [newCategory, setNewCategory] = useState<ResolutionCategory>('financial');
  const [newMajority, setNewMajority] = useState<MajorityRequired>('absolute');
  const [newAssemblyType, setNewAssemblyType] = useState<AssemblyType>('ordinary');

  // State for user comments while voting
  const [voteComments, setVoteComments] = useState<Record<string, string>>({});
  const [expandedDetailsId, setExpandedDetailsId] = useState<string | null>(null);

  // State for official PV printing modal
  const [isPvModalOpen, setIsPvModalOpen] = useState(false);

  // Total apartments in Residence (320 units: 20 buildings x 16 units)
  const totalResidenceApartments = 320;

  // Selected apartment info for current voter
  const currentVoterInfo = useMemo(() => {
    if (currentUser?.role === 'resident') {
      const aptNum = currentUser.apartment || currentUser.username.replace(/[^\d]/g, '');
      const bldg = currentUser.building || 'GH 34 A';
      return {
        name: currentUser.name || `مالك الشقة ${aptNum}`,
        apartmentNumber: aptNum,
        buildingCode: bldg,
        isOwner: true
      };
    }

    // If admin is simulating
    const [bldg, apt] = simulatedApartmentId.split('-');
    const matchingApt = apartments.find(a => 
      a.buildingCode.replace(/\s+/g, '') === bldg.replace(/\s+/g, '') && 
      a.number === apt
    );
    return {
      name: matchingApt?.ownerName || `المالك شقة ${apt} (${bldg})`,
      apartmentNumber: apt || '01',
      buildingCode: bldg || 'GH 34 A',
      isOwner: true
    };
  }, [currentUser, simulatedApartmentId, apartments]);

  // Overall General Assembly Quorum and Participation Stats
  const assemblyStats = useMemo(() => {
    const uniqueVoters = new Set<string>();
    let totalVotesCount = 0;
    let totalFor = 0;
    let totalAgainst = 0;
    let totalAbstain = 0;

    assemblyResolutions.forEach(res => {
      res.votes.forEach(v => {
        const key = `${v.buildingCode}-${v.apartmentNumber}`;
        uniqueVoters.add(key);
        totalVotesCount++;
        if (v.choice === 'for') totalFor++;
        else if (v.choice === 'against') totalAgainst++;
        else if (v.choice === 'abstain') totalAbstain++;
      });
    });

    const participatingApartments = uniqueVoters.size;
    const quorumPercentage = Number(((participatingApartments / totalResidenceApartments) * 100).toFixed(1));
    // Moroccan Law 18.00 requires at least half the co-ownership shares for 1st assembly
    const isQuorumAchieved = participatingApartments >= Math.ceil(totalResidenceApartments / 2);

    return {
      totalResolutions: assemblyResolutions.length,
      activeResolutions: assemblyResolutions.filter(r => r.status === 'active').length,
      participatingApartments,
      quorumPercentage,
      isQuorumAchieved,
      totalVotesCount,
      totalFor,
      totalAgainst,
      totalAbstain,
      approvalRate: totalVotesCount > 0 ? Math.round((totalFor / totalVotesCount) * 100) : 0
    };
  }, [assemblyResolutions, totalResidenceApartments]);

  // Filtered Resolutions
  const filteredResolutions = useMemo(() => {
    return assemblyResolutions.filter(res => {
      const matchSearch = 
        (res.titleAr && res.titleAr.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (res.titleFr && res.titleFr.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (res.descriptionAr && res.descriptionAr.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchCat = categoryFilter === 'all' || res.category === categoryFilter;
      const matchStatus = statusFilter === 'all' || res.status === statusFilter;

      return matchSearch && matchCat && matchStatus;
    });
  }, [assemblyResolutions, searchQuery, categoryFilter, statusFilter]);

  // Handle vote submit
  const handleCastVote = (resolutionId: string, choice: VoteChoice) => {
    const comment = voteComments[resolutionId];
    castResolutionVote(resolutionId, choice, comment);
  };

  // Handle creating a new resolution
  const handleCreateResolution = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleAr.trim()) return;

    addAssemblyResolution({
      assemblyYear: 2026,
      assemblyType: newAssemblyType,
      titleAr: newTitleAr.trim(),
      titleFr: newTitleFr.trim() || newTitleAr.trim(),
      descriptionAr: newDescAr.trim(),
      descriptionFr: newDescFr.trim() || newDescAr.trim(),
      category: newCategory,
      status: 'active',
      majorityRequired: newMajority
    });

    setIsAddModalOpen(false);
    setNewTitleAr('');
    setNewTitleFr('');
    setNewDescAr('');
    setNewDescFr('');
  };

  // Helper for category badge styling and translations
  const getCategoryMeta = (cat: ResolutionCategory) => {
    switch (cat) {
      case 'financial':
        return { 
          labelAr: 'مالي وميزانية', 
          labelFr: 'Financier & Budget', 
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200' 
        };
      case 'works':
        return { 
          labelAr: 'أشغال وإصلاحات', 
          labelFr: 'Travaux & Rénovation', 
          bg: 'bg-amber-50 text-amber-800 border-amber-200' 
        };
      case 'security':
        return { 
          labelAr: 'أمن وحراسة', 
          labelFr: 'Sécurité & Gardiennage', 
          bg: 'bg-blue-50 text-blue-800 border-blue-200' 
        };
      case 'management':
        return { 
          labelAr: 'تسيير ومكتب السانديك', 
          labelFr: 'Gestion & Syndic', 
          bg: 'bg-purple-50 text-purple-800 border-purple-200' 
        };
      case 'statute':
        return { 
          labelAr: 'نظام الملكية المشتركة', 
          labelFr: 'Règlement de copropriété', 
          bg: 'bg-rose-50 text-rose-800 border-rose-200' 
        };
      default:
        return { 
          labelAr: 'عام', 
          labelFr: 'Général', 
          bg: 'bg-slate-50 text-slate-800 border-slate-200' 
        };
    }
  };

  const getMajorityLabel = (maj: MajorityRequired) => {
    switch (maj) {
      case 'absolute':
        return isAr ? 'أغلبية مطلقة (المادة 24 من القانون 18.00)' : 'Majorité absolue (Art 24)';
      case 'unanimous':
        return isAr ? 'إجماع الملاك (المادة 25)' : 'Unanimité (Art 25)';
      case 'simple':
      default:
        return isAr ? 'أغلبية نسبية بسيطة' : 'Majorité simple';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Assembly Status & View Mode Switcher */}
      <div className="bg-gradient-to-r from-slate-900 via-[#0f172a] to-[#0a8591] text-white rounded-2xl p-5 sm:p-6 shadow-md border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-rose-500/20 text-rose-200 border border-rose-400/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="w-2 h-2 rounded-full bg-emerald-400 -ms-3.5" />
                {isAr ? 'جلسة تصويت نشطة ومباشرة' : 'Session de vote en direct'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/10 text-white border border-white/20">
                {isAr ? 'الجمع العام العادي لسنة 2026' : 'Assemblée Générale Ordinaire 2026'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-400/20 text-amber-200 border border-amber-400/30">
                {isAr ? 'وفق القانون المغربي 18.00' : 'Loi 18.00'}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
              <Vote className="w-7 h-7 text-rose-300 shrink-0" />
              <span>{isAr ? 'تصويت وقرارات الجمع العام لإقامة المرجان' : 'Votes et Résolutions de l\'Assemblée Générale'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-rose-100/80 max-w-3xl leading-relaxed">
              {isAr 
                ? 'نموذج إلكتروني موحد يتيح لجميع الملاك والسكان التعبير عن أصواتهم على القرارات المصيرية، مع بث لحظي للنتائج ومؤشرات النصاب القانوني لإدارة السانديك.'
                : 'Système électronique permettant aux copropriétaires d\'exprimer leurs votes en temps réel avec suivi instantané du quorum.'}
            </p>
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center gap-2 p-1.5 bg-black/40 backdrop-blur-sm rounded-xl border border-white/15 self-start lg:self-center">
            <button
              type="button"
              id="btn-switch-voter-mode"
              onClick={() => setViewMode('voter')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-black transition-all cursor-pointer ${
                viewMode === 'voter' 
                  ? 'bg-white text-slate-900 shadow-md' 
                  : 'text-rose-100 hover:text-white hover:bg-white/10'
              }`}
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{isAr ? 'نموذج تصويت الساكن' : 'Bulletin de Vote'}</span>
            </button>

            <button
              type="button"
              id="btn-switch-admin-mode"
              onClick={() => setViewMode('admin')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-black transition-all cursor-pointer ${
                viewMode === 'admin' 
                  ? 'bg-[#0a8591] text-white shadow-md border border-rose-300/40' 
                  : 'text-rose-100 hover:text-white hover:bg-white/10'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-rose-300" />
              <span>{isAr ? 'لوحة الإدارة والنتائج الحية' : 'Tableau de bord Résultats'}</span>
            </button>
          </div>
        </div>

        {/* Live Quorum & Key Performance Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-5 border-t border-white/10">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[11px] font-bold text-rose-200/90 uppercase">
              {isAr ? 'معدل النصاب القانوني' : 'Quorum Légal'}
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl sm:text-2xl font-black text-white">{assemblyStats.quorumPercentage}%</span>
              <span className="text-xs text-rose-200">({assemblyStats.participatingApartments}/{totalResidenceApartments})</span>
            </div>
            <div className="text-[10px] font-semibold text-emerald-300 mt-0.5 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>{assemblyStats.isQuorumAchieved ? (isAr ? 'مكتمل وفق القانون' : 'Quorum atteint') : (isAr ? 'قيد التجميع' : 'En attente')}</span>
            </div>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[11px] font-bold text-rose-200/90 uppercase">
              {isAr ? 'القرارات المعروضة' : 'Résolutions'}
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl sm:text-2xl font-black text-white">{assemblyStats.totalResolutions}</span>
              <span className="text-xs text-emerald-300">{assemblyStats.activeResolutions} {isAr ? 'نشط' : 'actives'}</span>
            </div>
            <div className="text-[10px] text-rose-200 mt-0.5">
              {isAr ? 'قابلة للتصويت الفوري' : 'Ouvertes au vote'}
            </div>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[11px] font-bold text-rose-200/90 uppercase">
              {isAr ? 'إجمالي الأصوات المسجلة' : 'Total Suffrages'}
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl sm:text-2xl font-black text-white">{assemblyStats.totalVotesCount}</span>
              <span className="text-xs text-rose-200">{isAr ? 'صوت' : 'votes'}</span>
            </div>
            <div className="text-[10px] text-emerald-300 mt-0.5">
              {assemblyStats.totalFor} {isAr ? 'موافق' : 'pour'} / {assemblyStats.totalAgainst} {isAr ? 'معارض' : 'contre'}
            </div>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <div className="text-[11px] font-bold text-rose-200/90 uppercase">
              {isAr ? 'نسبة الموافقة العامة' : 'Taux d\'approbation'}
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-xl sm:text-2xl font-black text-emerald-300">{assemblyStats.approvalRate}%</span>
              <span className="text-xs text-rose-200">{isAr ? 'متوسط عام' : 'moyen'}</span>
            </div>
            <div className="text-[10px] text-slate-300 mt-0.5">
              {isAr ? 'مؤشر إيجابي للثقة' : 'Indicateur de confiance'}
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* VIEW 1: RESIDENT VOTING FORM (نموذج تصويت الساكن / المالك)                */}
      {/* ========================================================================= */}
      {viewMode === 'voter' && (
        <div className="space-y-6">
          {/* Resident Identity Card */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-[#92e8dd] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#0a8591] to-[#0a8591] text-white flex items-center justify-center font-black text-lg shadow-sm shrink-0">
                {currentVoterInfo.apartmentNumber}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-black text-slate-900 text-base">
                    {currentVoterInfo.name}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {isAr ? 'مالك مشترك مصرح له' : 'Copropriétaire éligible'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium">
                  {isAr 
                    ? `العمارة: ${currentVoterInfo.buildingCode} • الشقة: ${currentVoterInfo.apartmentNumber} • حصة تصويت واحدة كاملة` 
                    : `Immeuble: ${currentVoterInfo.buildingCode} • Appt: ${currentVoterInfo.apartmentNumber}`}
                </p>
              </div>
            </div>

            {/* If syndic/admin, allow simulating voting for any apartment */}
            {isAdmin && (
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <span className="font-bold text-slate-700 whitespace-nowrap">
                  {isAr ? 'تجربة التصويت باسم الشقة:' : 'Simuler vote pour:'}
                </span>
                <select
                  value={simulatedApartmentId}
                  onChange={(e) => setSimulatedApartmentId(e.target.value)}
                  className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-bold text-slate-900 text-xs focus:ring-2 focus:ring-[#0a8591]"
                >
                  <option value="GH 34 A-01">GH 34 A - شقة 01 (أحمد الإدريسي)</option>
                  <option value="GH 34 A-02">GH 34 A - شقة 02 (رشيد الفاسي)</option>
                  <option value="GH 34 A-03">GH 34 A - شقة 03 (فاطمة بنسعيد)</option>
                  <option value="GH 34 A-05">GH 34 A - شقة 05 (سعيد التازي)</option>
                  <option value="GH 34 B-01">GH 34 B - شقة 01 (يوسف العلمي)</option>
                  <option value="GH 34 B-04">GH 34 B - شقة 04 (كريم الناصري)</option>
                  <option value="GH 34 C-02">GH 34 C - شقة 02 (حميد الزهري)</option>
                  <option value="GH 38 B-03">GH 38 B - شقة 03 (محمد أيت بلعربي)</option>
                </select>
              </div>
            )}
          </div>

          {/* Resolutions Voting List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#0a8591]" />
                <span>{isAr ? 'القرارات المعروضة للتصويت في هذا الجمع العام:' : 'Résolutions soumises au vote:'}</span>
              </h3>
              <span className="text-xs font-bold text-slate-500">
                {assemblyResolutions.filter(r => r.status === 'active').length} {isAr ? 'قرارات نشطة قابلة للتصويت' : 'résolutions ouvertes'}
              </span>
            </div>

            {filteredResolutions.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500 space-y-3">
                <Vote className="w-12 h-12 mx-auto text-slate-300" />
                <p className="font-bold text-sm">{isAr ? 'لا توجد قرارات مطابقة للتصفية حالياً' : 'Aucune résolution trouvée'}</p>
              </div>
            ) : (
              filteredResolutions.map((res, index) => {
                const catMeta = getCategoryMeta(res.category);
                const userVote = res.votes.find(v => 
                  v.apartmentNumber === currentVoterInfo.apartmentNumber && 
                  v.buildingCode.replace(/\s+/g, '') === currentVoterInfo.buildingCode.replace(/\s+/g, '')
                );
                const isClosed = res.status === 'closed';

                return (
                  <div 
                    key={res.id} 
                    className={`bg-white rounded-2xl border-2 transition-all p-5 sm:p-6 shadow-xs ${
                      userVote 
                        ? 'border-emerald-200 bg-emerald-50/20' 
                        : isClosed 
                          ? 'border-slate-200 opacity-80' 
                          : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-black">
                            {index + 1}
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${catMeta.bg}`}>
                            {isAr ? catMeta.labelAr : catMeta.labelFr}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {getMajorityLabel(res.majorityRequired)}
                          </span>
                          {isClosed ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-200 text-slate-700">
                              <Lock className="w-3 h-3" />
                              {isAr ? 'التصويت مغلق' : 'Clôturé'}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                              <Unlock className="w-3 h-3" />
                              {isAr ? 'باب التصويت مفتوح' : 'Vote ouvert'}
                            </span>
                          )}
                        </div>

                        <h4 className="text-base sm:text-lg font-black text-slate-900 leading-snug">
                          {isAr ? res.titleAr : res.titleFr}
                        </h4>
                        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                          {isAr ? res.descriptionAr : res.descriptionFr}
                        </p>
                      </div>

                      {/* Vote Status Indicator */}
                      {userVote && (
                        <div className="shrink-0 self-start p-3 rounded-xl bg-white border border-emerald-200 shadow-2xs">
                          <div className="flex items-center gap-2">
                            {userVote.choice === 'for' ? (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-black bg-emerald-600 text-white">
                                <CheckCircle2 className="w-4 h-4" />
                                {isAr ? 'صوّتت بـ: موافق ✅' : 'Votre vote: POUR'}
                              </span>
                            ) : userVote.choice === 'against' ? (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-black bg-rose-600 text-white">
                                <XCircle className="w-4 h-4" />
                                {isAr ? 'صوّتت بـ: معارض ❌' : 'Votre vote: CONTRE'}
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-black bg-slate-600 text-white">
                                <MinusCircle className="w-4 h-4" />
                                {isAr ? 'صوّتت بـ: ممتنع ➖' : 'Votre vote: ABSTENTION'}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 font-medium mt-1">
                            {new Date(userVote.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Voting Action Buttons (Form) */}
                    {!isClosed ? (
                      <div className="pt-3 border-t border-slate-100 space-y-3">
                        <div className="text-xs font-bold text-slate-700">
                          {userVote 
                            ? (isAr ? 'تعديل خيار تصويتك (التصويت لا يزال مفتوحاً):' : 'Modifier votre vote :')
                            : (isAr ? 'حدد خيار تصويتك على هذا القرار المقترح:' : 'Exprimez votre vote pour cette résolution :')}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                          <button
                            type="button"
                            onClick={() => handleCastVote(res.id, 'for')}
                            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-black text-sm transition-all cursor-pointer border-2 ${
                              userVote?.choice === 'for'
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                                : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300'
                            }`}
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{isAr ? 'موافق / مع (Pour)' : 'POUR (Oui)'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCastVote(res.id, 'against')}
                            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-black text-sm transition-all cursor-pointer border-2 ${
                              userVote?.choice === 'against'
                                ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                                : 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100 hover:border-rose-300'
                            }`}
                          >
                            <XCircle className="w-4 h-4" />
                            <span>{isAr ? 'غير موافق / ضد (Contre)' : 'CONTRE (Non)'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleCastVote(res.id, 'abstain')}
                            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-black text-sm transition-all cursor-pointer border-2 ${
                              userVote?.choice === 'abstain'
                                ? 'bg-slate-700 text-white border-slate-700 shadow-sm'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                            }`}
                          >
                            <MinusCircle className="w-4 h-4" />
                            <span>{isAr ? 'ممتنع عن التصويت (Abstention)' : 'ABSTENTION'}</span>
                          </button>
                        </div>

                        {/* Optional Comment / Reservation */}
                        <div className="pt-2">
                          <label className="text-[11px] font-bold text-slate-500 block mb-1 flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                            <span>{isAr ? 'ملاحظة أو تحفظ رسمي لتسجيله في محضر الجمع العام (اختياري):' : 'Observation ou réserve officielle (optionnelle) :'}</span>
                          </label>
                          <input
                            type="text"
                            value={voteComments[res.id] || userVote?.comment || ''}
                            onChange={(e) => setVoteComments({ ...voteComments, [res.id]: e.target.value })}
                            placeholder={isAr ? 'أدخل أي ملاحظة أو تحفظ حول هذا القرار ليتم تدوينها بمحضر الجلسة...' : 'Ex: Réserve sur le montant ou calendrier...'}
                            className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50/70 focus:bg-white focus:ring-2 focus:ring-[#0a8591] focus:border-transparent transition-all"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="pt-3 border-t border-slate-100 text-xs text-slate-500 font-medium">
                        {isAr ? 'تم إغلاق التصويت على هذا القرار من طرف رئاسة الجمع العام.' : 'Le vote pour cette résolution a été clôturé par la présidence.'}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW 2: SYNDIC REAL-TIME RESULTS DASHBOARD (لوحة الإدارة والنتائج اللحظية) */}
      {/* ========================================================================= */}
      {viewMode === 'admin' && (
        <div className="space-y-6">
          {/* Action Toolbar & Filters */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2 flex-wrap flex-1">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isAr ? 'بحث في القرارات المقترحة...' : 'Rechercher une résolution...'}
                  className="w-full text-xs ps-9 pe-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-[#0a8591]"
                />
              </div>

              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-700"
              >
                <option value="all">{isAr ? 'جميع الفئات' : 'Toutes les catégories'}</option>
                <option value="financial">{isAr ? 'مالي وميزانية' : 'Financier'}</option>
                <option value="works">{isAr ? 'أشغال وإصلاحات' : 'Travaux'}</option>
                <option value="security">{isAr ? 'أمن وحراسة' : 'Sécurité'}</option>
                <option value="management">{isAr ? 'تسيير وسانديك' : 'Gestion'}</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-700"
              >
                <option value="all">{isAr ? 'جميع الحالات' : 'Tous les états'}</option>
                <option value="active">{isAr ? 'نشط ومفتوح' : 'Actif'}</option>
                <option value="closed">{isAr ? 'مغلق' : 'Clôturé'}</option>
              </select>
            </div>

            {/* Syndic Action Buttons */}
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                id="btn-open-add-resolution"
                onClick={() => setIsAddModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-[#0a8591] hover:bg-[#0b6a78] text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                <span>{isAr ? 'إضافة مقترح قرار جديد' : 'Nouvelle résolution'}</span>
              </button>

              <button
                type="button"
                id="btn-open-pv-modal"
                onClick={() => setIsPvModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer whitespace-nowrap"
              >
                <Printer className="w-4 h-4 text-rose-300" />
                <span>{isAr ? 'محضر التصويت الرسمي (P.V)' : 'P.V Officiel'}</span>
              </button>
            </div>
          </div>

          {/* Resolutions Live Results List */}
          <div className="space-y-5">
            {filteredResolutions.map((res, index) => {
              const catMeta = getCategoryMeta(res.category);
              const totalVotes = res.votes.length;
              const forVotes = res.votes.filter(v => v.choice === 'for').length;
              const againstVotes = res.votes.filter(v => v.choice === 'against').length;
              const abstainVotes = res.votes.filter(v => v.choice === 'abstain').length;

              const forPct = totalVotes > 0 ? Math.round((forVotes / totalVotes) * 100) : 0;
              const againstPct = totalVotes > 0 ? Math.round((againstVotes / totalVotes) * 100) : 0;
              const abstainPct = totalVotes > 0 ? Math.round((abstainVotes / totalVotes) * 100) : 0;

              // Determination of outcome based on majority requirement
              let isAdopted = false;
              if (res.majorityRequired === 'absolute') {
                isAdopted = forPct > 50;
              } else if (res.majorityRequired === 'simple') {
                isAdopted = forVotes > againstVotes;
              } else {
                isAdopted = forVotes > 0 && againstVotes === 0;
              }

              const isExpanded = expandedDetailsId === res.id;

              return (
                <div key={res.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-5 sm:p-6 space-y-4">
                    {/* Top Row: Meta badges and Syndic controls */}
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="w-6 h-6 rounded-full bg-[#0a8591] text-white flex items-center justify-center text-xs font-black">
                            {index + 1}
                          </span>
                          <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${catMeta.bg}`}>
                            {isAr ? catMeta.labelAr : catMeta.labelFr}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
                            {getMajorityLabel(res.majorityRequired)}
                          </span>
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black ${
                            res.status === 'active' 
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                              : 'bg-slate-200 text-slate-700'
                          }`}>
                            {res.status === 'active' ? (
                              <>
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                {isAr ? 'نشط ومباشر' : 'En direct'}
                              </>
                            ) : (
                              <>
                                <Lock className="w-3 h-3" />
                                {isAr ? 'مغلق ومحسوم' : 'Clôturé'}
                              </>
                            )}
                          </span>
                        </div>

                        <h3 className="text-base sm:text-lg font-black text-slate-900">
                          {isAr ? res.titleAr : res.titleFr}
                        </h3>
                        <p className="text-xs sm:text-sm text-slate-600 max-w-4xl">
                          {isAr ? res.descriptionAr : res.descriptionFr}
                        </p>
                      </div>

                      {/* Syndic Quick Controls */}
                      <div className="flex items-center gap-1.5 shrink-0 self-start">
                        <button
                          type="button"
                          onClick={() => setAssemblyResolutionStatus(res.id, res.status === 'active' ? 'closed' : 'active')}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                            res.status === 'active'
                              ? 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                          }`}
                          title={res.status === 'active' ? (isAr ? 'إغلاق التصويت' : 'Clôturer') : (isAr ? 'إعادة فتح التصويت' : 'Rouvrir')}
                        >
                          {res.status === 'active' ? <Lock className="w-3.5 h-3.5 text-amber-700" /> : <Unlock className="w-3.5 h-3.5 text-emerald-700" />}
                          <span>{res.status === 'active' ? (isAr ? 'إغلاق التصويت' : 'Clôturer') : (isAr ? 'فتح التصويت' : 'Ouvrir')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(isAr ? 'هل أنت متأكد من حذف هذا القرار المقترح؟' : 'Supprimer cette résolution ?')) {
                              deleteAssemblyResolution(res.id);
                            }
                          }}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-xl"
                          title={isAr ? 'حذف القرار' : 'Supprimer'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Live Results Bar & Percentages */}
                    <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <div className="flex items-center gap-4">
                          <span className="text-emerald-700 flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4" />
                            {isAr ? 'موافق:' : 'Pour :'} {forVotes} ({forPct}%)
                          </span>
                          <span className="text-rose-700 flex items-center gap-1">
                            <XCircle className="w-4 h-4" />
                            {isAr ? 'معارض:' : 'Contre :'} {againstVotes} ({againstPct}%)
                          </span>
                          <span className="text-slate-600 flex items-center gap-1">
                            <MinusCircle className="w-4 h-4" />
                            {isAr ? 'ممتنع:' : 'Abstention :'} {abstainVotes} ({abstainPct}%)
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-slate-500 font-medium">
                            {isAr ? 'مجموع الأصوات:' : 'Total votes :'} {totalVotes}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[11px] font-black ${
                            totalVotes === 0 
                              ? 'bg-slate-200 text-slate-700' 
                              : isAdopted 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : 'bg-rose-100 text-rose-800'
                          }`}>
                            {totalVotes === 0 
                              ? (isAr ? 'في انتظار الأصوات' : 'En attente') 
                              : isAdopted 
                                ? (isAr ? 'مصادق عليه بالأغلبية ✅' : 'Adopté') 
                                : (isAr ? 'غير مصادق عليه ❌' : 'Rejeté')}
                          </span>
                        </div>
                      </div>

                      {/* Multi-segment Progress Bar */}
                      <div className="w-full h-3 rounded-full bg-slate-200 overflow-hidden flex">
                        {forPct > 0 && (
                          <div 
                            style={{ width: `${forPct}%` }} 
                            className="bg-emerald-500 h-full transition-all duration-500" 
                            title={`موافق: ${forPct}%`}
                          />
                        )}
                        {againstPct > 0 && (
                          <div 
                            style={{ width: `${againstPct}%` }} 
                            className="bg-rose-500 h-full transition-all duration-500" 
                            title={`معارض: ${againstPct}%`}
                          />
                        )}
                        {abstainPct > 0 && (
                          <div 
                            style={{ width: `${abstainPct}%` }} 
                            className="bg-slate-400 h-full transition-all duration-500" 
                            title={`ممتنع: ${abstainPct}%`}
                          />
                        )}
                      </div>
                    </div>

                    {/* Expandable Voter Breakdown */}
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => setExpandedDetailsId(isExpanded ? null : res.id)}
                        className="text-xs font-bold text-slate-700 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                        <span>
                          {isExpanded 
                            ? (isAr ? 'إخفاء السجل التفصيلي للمصوتين' : 'Masquer le détail des votants')
                            : (isAr ? `عرض السجل التفصيلي للمصوتين (${totalVotes} شقة مسجلة)` : `Afficher le détail des votants (${totalVotes})`)}
                        </span>
                      </button>

                      {isExpanded && (
                        <div className="mt-3 overflow-x-auto rounded-xl border border-slate-200">
                          <table className="w-full text-xs text-start">
                            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                              <tr>
                                <th className="p-2.5 text-start">{isAr ? 'العمارة والشقة' : 'Immeuble & Appt'}</th>
                                <th className="p-2.5 text-start">{isAr ? 'الساكن / المالك' : 'Copropriétaire'}</th>
                                <th className="p-2.5 text-start">{isAr ? 'خيار التصويت' : 'Vote'}</th>
                                <th className="p-2.5 text-start">{isAr ? 'التوقيت' : 'Heure'}</th>
                                <th className="p-2.5 text-start">{isAr ? 'ملاحظة أو تحفظ' : 'Observation / Réserve'}</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 bg-white">
                              {res.votes.length === 0 ? (
                                <tr>
                                  <td colSpan={5} className="p-4 text-center text-slate-400 font-medium">
                                    {isAr ? 'لم يتم تسجيل أي صوت بعد على هذا القرار' : 'Aucun vote enregistré'}
                                  </td>
                                </tr>
                              ) : (
                                res.votes.map(vote => (
                                  <tr key={vote.id} className="hover:bg-slate-50">
                                    <td className="p-2.5 font-bold text-slate-900">
                                      {vote.buildingCode} - {isAr ? 'شقة' : 'Appt'} {vote.apartmentNumber}
                                    </td>
                                    <td className="p-2.5 text-slate-700 font-medium">{vote.userName}</td>
                                    <td className="p-2.5">
                                      {vote.choice === 'for' ? (
                                        <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                                          <CheckCircle2 className="w-3.5 h-3.5" />
                                          {isAr ? 'موافق' : 'Pour'}
                                        </span>
                                      ) : vote.choice === 'against' ? (
                                        <span className="inline-flex items-center gap-1 font-bold text-rose-700">
                                          <XCircle className="w-3.5 h-3.5" />
                                          {isAr ? 'معارض' : 'Contre'}
                                        </span>
                                      ) : (
                                        <span className="inline-flex items-center gap-1 font-bold text-slate-600">
                                          <MinusCircle className="w-3.5 h-3.5" />
                                          {isAr ? 'ممتنع' : 'Abstention'}
                                        </span>
                                      )}
                                    </td>
                                    <td className="p-2.5 text-slate-500 font-mono">
                                      {new Date(vote.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </td>
                                    <td className="p-2.5 text-slate-600 italic">
                                      {vote.comment || '-'}
                                    </td>
                                  </tr>
                                ))
                              )}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ADD NEW GENERAL ASSEMBLY RESOLUTION                               */}
      {/* ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#0a8591] text-white flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-lg">
                    {isAr ? 'إضافة قرار جديد للتصويت بالجمع العام' : 'Nouvelle Résolution de l\'A.G'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {isAr ? 'صياغة مشروع القرار وفق بنود جدول الأعمال والقانون 18.00' : 'Formulation du projet de résolution'}
                  </p>
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateResolution} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isAr ? 'عنوان القرار (بالعربية) *' : 'Titre de la résolution (Arabe) *'}
                </label>
                <input
                  required
                  type="text"
                  value={newTitleAr}
                  onChange={(e) => setNewTitleAr(e.target.value)}
                  placeholder={isAr ? 'مثال: المصادقة على صباغة العمارات GH 34 و GH 35' : 'Ex: Approbation travaux ravalement'}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isAr ? 'عنوان القرار (بالفرنسية) - اختياري' : 'Titre (Français) - Optionnel'}
                </label>
                <input
                  type="text"
                  value={newTitleFr}
                  onChange={(e) => setNewTitleFr(e.target.value)}
                  placeholder="Ex: Travaux de ravalement des façades"
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isAr ? 'فئة القرار' : 'Catégorie'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as ResolutionCategory)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591]"
                  >
                    <option value="financial">{isAr ? 'مالي وميزانية' : 'Financier & Budget'}</option>
                    <option value="works">{isAr ? 'أشغال وإصلاحات كبرى' : 'Grands Travaux'}</option>
                    <option value="security">{isAr ? 'أمن وحراسة ونظافة' : 'Sécurité & Hygiène'}</option>
                    <option value="management">{isAr ? 'تسيير وتجديد الثقة بالسانديك' : 'Gestion & Syndic'}</option>
                    <option value="statute">{isAr ? 'تعديل نظام الملكية المشتركة' : 'Règlement copropriété'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isAr ? 'نوع الأغلبية المطلوبة للمصادقة' : 'Majorité requise'}
                  </label>
                  <select
                    value={newMajority}
                    onChange={(e) => setNewMajority(e.target.value as MajorityRequired)}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591]"
                  >
                    <option value="absolute">{isAr ? 'أغلبية مطلقة (نصف الحصص + 1)' : 'Majorité absolue'}</option>
                    <option value="simple">{isAr ? 'أغلبية نسبية بسيطة (أكثرية الأصوات)' : 'Majorité simple'}</option>
                    <option value="unanimous">{isAr ? 'إجماع الملاك (100%)' : 'Unanimité'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isAr ? 'شرح وتفاصيل القرار والمبررات (بالعربية) *' : 'Description détaillée & Motivations *'}
                </label>
                <textarea
                  required
                  rows={3}
                  value={newDescAr}
                  onChange={(e) => setNewDescAr(e.target.value)}
                  placeholder={isAr ? 'اكتب تفاصيل المقترح، الكلفة التقديرية، الأهداف، وبنود الاتفاقية...' : 'Détails du projet...'}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-[#0a8591]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-black shadow-md cursor-pointer"
                >
                  {isAr ? 'نشر القرار وفتح التصويت فوراً' : 'Publier et ouvrir le vote'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: OFFICIAL GENERAL ASSEMBLY MINUTES (P.V OFFICIEL DE L'A.G)         */}
      {/* ========================================================================= */}
      {isPvModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in fade-in space-y-6 max-h-[92vh] overflow-y-auto print:p-0 print:border-none print:shadow-none">
            {/* Header with Print button */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 print:hidden">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#0a8591]" />
                <h3 className="font-black text-slate-900 text-base">
                  {isAr ? 'محضر نتائج تصويت الجمع العام الرسمي (P.V)' : 'Procès-Verbal Officiel de l\'A.G'}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#0a8591] text-white text-xs font-black shadow-xs hover:bg-[#0b6a78] cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isAr ? 'طباعة المحضر' : 'Imprimer'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPvModalOpen(false)}
                  className="text-slate-400 hover:text-slate-700 text-base font-bold p-1.5 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Official Printable PV Sheet */}
            <div className="space-y-6 text-slate-900 text-start">
              {/* Header Letterhead */}
              <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
                <div className="text-xs font-bold text-slate-500 tracking-wider uppercase">المملكة المغربية • إقامة المرجان</div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-950">
                  {isAr ? 'محضر اجتماع الجمع العام العادي للملاك المشتركين' : 'Procès-Verbal de l\'Assemblée Générale Ordinaire'}
                </h1>
                <div className="text-xs font-semibold text-slate-700">
                  {isAr ? 'سنة 2026 • المنعقد بمقر مكتب السانديك GH 34 A شقة 01' : 'Exercice 2026 • Siège du Syndic'}
                </div>
              </div>

              {/* Quorum Statement */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                <div className="font-black text-slate-900">{isAr ? 'بيان النصاب القانوني والحضور:' : 'Constatation du Quorum :'}</div>
                <div className="text-slate-700 leading-relaxed">
                  {isAr ? (
                    <>
                      بناءً على مقتضيات الظهير الشريف رقم 1.02.298 بتنفيذ القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية، 
                      بلغ عدد الشقق المشاركة في التصويت <strong>{assemblyStats.participatingApartments}</strong> شقة من أصل <strong>{totalResidenceApartments}</strong> شقة، 
                      بنسبة مشاركة بلغت <strong>{assemblyStats.quorumPercentage}%</strong>، مما يثبت اكتمال النصاب القانوني اللازم لصحة المداولات والقرارات.
                    </>
                  ) : (
                    <>
                      Conformément à la loi 18.00, le quorum est constaté avec {assemblyStats.participatingApartments} appartements sur {totalResidenceApartments} ({assemblyStats.quorumPercentage}%).
                    </>
                  )}
                </div>
              </div>

              {/* Resolutions Summary Table */}
              <div className="space-y-3">
                <h4 className="text-sm font-black text-slate-900">
                  {isAr ? 'جدول نتائج التصويت على القرارات المقترحة:' : 'Résultats détaillés des votes :'}
                </h4>

                <div className="border border-slate-300 rounded-xl overflow-hidden">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                      <tr>
                        <th className="p-2.5 text-start w-10">#</th>
                        <th className="p-2.5 text-start">{isAr ? 'موضوع القرار' : 'Objet de la résolution'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'موافق' : 'Pour'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'معارض' : 'Contre'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'ممتنع' : 'Abs.'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'النتيجة القانونية' : 'Décision'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {assemblyResolutions.map((res, i) => {
                        const total = res.votes.length;
                        const forV = res.votes.filter(v => v.choice === 'for').length;
                        const agV = res.votes.filter(v => v.choice === 'against').length;
                        const abV = res.votes.filter(v => v.choice === 'abstain').length;
                        const isOk = forV > agV;

                        return (
                          <tr key={res.id}>
                            <td className="p-2.5 font-bold text-center">{i + 1}</td>
                            <td className="p-2.5 font-bold text-slate-900">
                              {isAr ? res.titleAr : res.titleFr}
                              <div className="text-[10px] text-slate-500 font-normal">
                                {getMajorityLabel(res.majorityRequired)}
                              </div>
                            </td>
                            <td className="p-2.5 text-center text-emerald-800 font-bold">{forV}</td>
                            <td className="p-2.5 text-center text-rose-800 font-bold">{agV}</td>
                            <td className="p-2.5 text-center text-slate-600 font-bold">{abV}</td>
                            <td className="p-2.5 text-center font-black">
                              <span className={`px-2 py-0.5 rounded text-[10px] ${isOk ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                                {isOk ? (isAr ? 'مصادق عليه' : 'Adopté') : (isAr ? 'مرفوض' : 'Rejeté')}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Signatures Block */}
              <div className="pt-8 border-t border-slate-300 grid grid-cols-3 gap-6 text-center text-xs">
                <div className="space-y-10">
                  <div className="font-bold text-slate-700">{isAr ? 'رئيس الجلسة (السانديك العام)' : 'Président de séance (Syndic)'}</div>
                  <div className="text-slate-400 italic text-[11px]">{isAr ? '[خاتم وتوقيع السانديك]' : '[Signature & Cachet]'}</div>
                </div>
                <div className="space-y-10">
                  <div className="font-bold text-slate-700">{isAr ? 'فاحص الأصوات (ممثل الملاك)' : 'Scrutateur (Copropriétaire)'}</div>
                  <div className="text-slate-400 italic text-[11px]">{isAr ? '[توقيع فاحص الأصوات]' : '[Signature]'}</div>
                </div>
                <div className="space-y-10">
                  <div className="font-bold text-slate-700">{isAr ? 'كاتب الجلسة' : 'Secrétaire de séance'}</div>
                  <div className="text-slate-400 italic text-[11px]">{isAr ? '[توقيع الكاتب]' : '[Signature]'}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
