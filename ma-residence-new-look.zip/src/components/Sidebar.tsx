import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  LayoutDashboard, Building2, KeyRound, HandCoins, ReceiptText, 
  Wrench, Landmark, Download, LogOut, Wallet, 
  ShieldCheck, X, ChevronRight, Sparkles, MapPin
} from 'lucide-react';

interface SidebarProps {
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
  onOpenBackup?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  isOpenMobile = false, 
  onCloseMobile = () => {},
  onOpenBackup = () => {},
}) => {
  const { 
    lang, activeSection, setActiveSection, currentUser, logout,
    apartments, openTicketsCount
  } = useApp();

  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  // Close mobile drawer on ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpenMobile) {
        onCloseMobile();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpenMobile, onCloseMobile]);

  // The 5-6 Essential Core Destinations
  const primaryNavItems = isOwner ? [
    { 
      id: 'dashboard', 
      label: isAr ? 'لوحة القيادة' : 'Tableau de bord', 
      desc: isAr ? 'الملخص والوضعية العامة' : 'Aperçu général',
      icon: LayoutDashboard,
      tone: 'from-emerald-400 to-emerald-600'
    },
    { 
      id: 'apartments', 
      label: isAr ? 'شقتي ووضعيتي' : 'Mon Appartement', 
      desc: isAr ? 'البيانات والمستحقات' : 'Statut & Cotisations',
      icon: KeyRound,
      tone: 'from-indigo-400 to-indigo-600'
    },
    { 
      id: 'payments', 
      label: isAr ? 'الوصولات والمداخيل' : 'Mes Reçus', 
      desc: isAr ? 'سجل الأداء والوصولات' : 'Historique des paiements',
      icon: HandCoins,
      tone: 'from-amber-400 to-amber-600'
    },
    { 
      id: 'expenses', 
      label: isAr ? 'مصاريف الإقامة' : 'Dépenses', 
      desc: isAr ? 'شفافية نفقات التسيير' : 'Charges communes',
      icon: ReceiptText,
      tone: 'from-rose-400 to-rose-600'
    },
    { 
      id: 'two-years-report', 
      label: isAr ? 'حصيلة 2025 و 2026' : 'Bilan 2 Ans (2025-2026)', 
      desc: isAr ? 'التقرير المالي المعتمد' : 'Bilan financier officiel',
      icon: Landmark,
      tone: 'from-amber-400 to-amber-600',
      featured: true 
    },
    { 
      id: 'operations', 
      label: isAr ? 'الشكايات والإعلانات' : 'Réclamations & Avis', 
      desc: isAr ? 'الصيانة وبلاغات الإقامة' : 'Pannes & Annonces',
      icon: Wrench,
      tone: 'from-sky-400 to-sky-600',
      badge: openTicketsCount > 0 ? openTicketsCount : null
    },
  ] : [
    { 
      id: 'dashboard', 
      label: isAr ? 'لوحة القيادة' : 'Tableau de bord', 
      desc: isAr ? 'الملخص والسيولة والعمليات' : 'Trésorerie & Actions rapides',
      icon: LayoutDashboard,
      tone: 'from-emerald-400 to-emerald-600'
    },
    { 
      id: 'payments', 
      label: isAr ? 'المداخيل والوصولات' : 'Recettes & Reçus', 
      desc: isAr ? 'تحصيل الواجبات والوصولات' : 'Encaissement des cotisations',
      icon: HandCoins,
      tone: 'from-amber-400 to-amber-600'
    },
    { 
      id: 'ledger', 
      label: isAr ? 'المداخيل والمصاريف الشهرية' : 'Recettes & Dépenses du mois', 
      desc: isAr ? 'الإدخال الشهري وترحيل الرصيد' : 'Saisie mensuelle & report du solde',
      icon: Wallet,
      tone: 'from-teal-400 to-teal-600'
    },
    { 
      id: 'expenses', 
      label: isAr ? 'المصاريف والتحملات' : 'Dépenses & Factures', 
      desc: isAr ? 'نفقات التسيير والصيانة' : 'Frais de gestion & Entretien',
      icon: ReceiptText,
      tone: 'from-rose-400 to-rose-600'
    },
    { 
      id: 'apartments', 
      label: isAr ? 'الشقق والملاك والمتأخرات' : 'Copropriétaires & Impayés', 
      desc: isAr ? '320 شقة ومتابعة المتأخرين' : '320 lots & Suivi des retards',
      icon: Building2,
      tone: 'from-indigo-400 to-indigo-600',
      badge: apartments.length > 0 ? apartments.length : null
    },
    { 
      id: 'two-years-report', 
      label: isAr ? 'حصيلة سنتي 2025 و 2026' : 'Bilan 2 Ans (2025-2026)', 
      desc: isAr ? 'التقرير المالي الشامل للجمع' : 'Rapport officiel complet',
      icon: Landmark,
      tone: 'from-amber-400 to-amber-600',
      featured: true 
    },
    { 
      id: 'operations', 
      label: isAr ? 'الخدمات والعمليات' : 'Services & Opérations', 
      desc: isAr ? 'الصيانة، الإعلانات، والعمال' : 'Maintenance, Annonces & Staff',
      icon: Wrench,
      tone: 'from-sky-400 to-sky-600',
      badge: openTicketsCount > 0 ? openTicketsCount : null
    },
  ];

  const handleSelectSection = (id: string) => {
    setActiveSection(id);
    if (isOpenMobile) {
      onCloseMobile();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-40 lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside 
        className={`
          fixed lg:sticky top-0 lg:top-20 inset-y-0 ${isAr ? 'right-0' : 'left-0'} 
          w-72 sm:w-80 bg-white/95 backdrop-blur-xl border-${isAr ? 'l' : 'r'} border-slate-200/80
          z-50 lg:z-10 flex flex-col justify-between p-4 sm:p-5 shadow-xl lg:shadow-none
          transition-transform duration-300 ease-in-out shrink-0 rounded-none lg:rounded-3xl lg:border lg:my-0 lg:h-[calc(100vh-6rem)]
          ${isOpenMobile ? 'translate-x-0' : (isAr ? 'translate-x-full lg:translate-x-0' : '-translate-x-full lg:translate-x-0')}
        `}
      >
        {/* Top Header / Brand in Mobile */}
        <div className="space-y-4 flex-1 min-h-0 overflow-y-auto overscroll-contain pb-3 -me-1 pe-1">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 lg:hidden">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-800 text-amber-300 flex items-center justify-center font-bold text-sm shadow-xs">
                M
              </div>
              <div>
                <div className="font-bold text-sm text-slate-900 leading-tight">إقامة المرجان</div>
                <div className="text-[10px] text-slate-500 font-medium">أبواب مراكش - المنطقة 10</div>
              </div>
            </div>
            <button
              onClick={onCloseMobile}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Residence Badge Info (Desktop) */}
          <div className="hidden lg:block p-3 rounded-2xl bg-gradient-to-br from-emerald-800 via-emerald-900 to-emerald-950 text-white shadow-md relative overflow-hidden">
            <div className="absolute -top-8 -end-8 w-24 h-24 rounded-full bg-amber-400/20 blur-2xl anim-float" />
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300">
                {isAr ? 'إقامة المرجان السكنية' : 'Résidence Al Morjane'}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-800/80 text-amber-300 border border-emerald-700/60">
                مراكش
              </span>
            </div>
            <div className="font-bold text-xs text-white/95 leading-snug">
              {isAr ? 'السكن المتوسط · أبواب مراكش' : 'Moyen Standing · Abwab Marrakech'}
            </div>
            <div className="flex items-center justify-between text-[10px] text-emerald-200/80 mt-2 pt-2 border-t border-emerald-800/80 font-mono">
              <span>20 عمارة</span>
              <span>·</span>
              <span>320 شقة ومحل</span>
              <span>·</span>
              <span>المنطقة 10</span>
            </div>
          </div>

          {/* Navigation Title */}
          <div className="px-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {isAr ? 'رحلة التسيير الأساسية' : 'Navigation Principale'}
          </div>

          {/* Primary Streamlined Menu Links */}
          <nav className="space-y-1.5">
            {primaryNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id || 
                (item.id === 'operations' && ['operations', 'maintenance', 'notices', 'employees', 'archive'].includes(activeSection)) ||
                (item.id === 'two-years-report' && ['two-years-report', 'bilan-2ans', 'report-2025-2026'].includes(activeSection));

              if (item.featured) {
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectSection(item.id)}
                    className={`
                      w-full text-start p-3 rounded-2xl transition-all cursor-pointer relative group flex items-center justify-between
                      ${isActive 
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20 font-black border border-amber-400' 
                        : 'bg-amber-50/80 hover:bg-amber-100/90 text-amber-950 border border-amber-200/90 shadow-2xs'
                      }
                    `}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`icon-wiggle w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isActive ? 'bg-slate-950 text-amber-400' : 'bg-gradient-to-br from-amber-400 to-amber-600 text-white shadow-sm'}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-extrabold text-xs sm:text-sm tracking-tight truncate flex items-center gap-1.5">
                          <span>{item.label}</span>
                          <Sparkles className="w-3 h-3 text-amber-700 anim-bob" />
                        </div>
                        <div className={`text-[10px] truncate ${isActive ? 'text-slate-900 font-medium' : 'text-amber-800'}`}>
                          {item.desc}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-amber-200/80 text-amber-900 shrink-0">
                      25/26
                    </span>
                  </button>
                );
              }

              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectSection(item.id)}
                  className={`
                    w-full text-start px-3.5 py-2.5 rounded-2xl transition-all cursor-pointer relative flex items-center justify-between group
                    ${isActive 
                      ? 'bg-gradient-to-l from-emerald-900 to-emerald-700 text-white font-bold shadow-md shadow-emerald-900/25' 
                      : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100/80 font-medium'
                    }
                  `}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`icon-wiggle w-9 h-9 rounded-xl flex items-center justify-center shrink-0 bg-gradient-to-br ${(item as any).tone} text-white shadow-sm transition-all ${isActive ? 'ring-2 ring-white/40 scale-105' : 'opacity-90 group-hover:opacity-100'}`}>
                      <Icon className="w-[18px] h-[18px]" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm tracking-tight truncate">
                        {item.label}
                      </div>
                      <div className={`text-[10px] truncate ${isActive ? 'text-emerald-200' : 'text-slate-400 group-hover:text-slate-500'}`}>
                        {item.desc}
                      </div>
                    </div>
                  </div>

                  {item.badge !== null && item.badge !== undefined && (
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${isActive ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'}`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom User Profile & Utility Bar */}
        <div className="pt-4 border-t border-slate-200/80 space-y-2 shrink-0">
          {/* Quick Backup Trigger */}
          {!isOwner && (
            <button
              type="button"
              onClick={onOpenBackup}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-emerald-800 hover:bg-emerald-50/60 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Download className="w-3.5 h-3.5 text-emerald-700" />
                <span>{isAr ? 'نسخة احتياطية للبيانات' : 'Sauvegarde des données'}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">JSON</span>
            </button>
          )}

          {/* User Profile Card */}
          <div className="p-2.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-bold text-xs shrink-0">
                <ShieldCheck className="w-4 h-4 text-amber-300" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {currentUser?.name || (isOwner ? 'مقيم بالإقامة' : 'وكيل السانديك')}
                </div>
                <div className="text-[10px] text-slate-500 truncate">
                  {isOwner ? 'اطلاع واستشارة' : 'إدارة وتسيير معتمد'}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={logout}
              title={isAr ? 'تسجيل الخروج' : 'Déconnexion'}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer shrink-0"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
