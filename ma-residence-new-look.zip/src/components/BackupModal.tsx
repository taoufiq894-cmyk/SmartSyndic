import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Database, 
  Download, 
  Upload, 
  RefreshCw, 
  Check, 
  X, 
  Cloud, 
  Trash2, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  History, 
  Sparkles, 
  RotateCcw, 
  HardDrive, 
  Save, 
  FileJson, 
  ExternalLink, 
  Eye, 
  Info,
  Layers,
  ArrowDownToLine,
  ArrowUpFromLine,
  Zap
} from 'lucide-react';
import { 
  getSupabaseConfig, 
  extractProjectRef, 
  checkSupabaseProjectStatus, 
  SupabaseTestResult 
} from '../supabase';
import { pullResidenceFromSupabase, pushResidenceToSupabase, ResidenceSyncPayload } from '../services/supabaseSync';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ParsedBackupInfo {
  source: 'supabase_cloud' | 'local_system' | 'unknown';
  projectRef?: string;
  exportedAt?: string;
  version?: string;
  counts: {
    buildings: number;
    apartments: number;
    residents: number;
    payments: number;
    expenses: number;
    employees: number;
    maintenanceTickets: number;
    notices: number;
    visitors: number;
    archivedPayments: number;
    archivedExpenses: number;
    manualMonthlyRecords?: number;
  };
  rawJsonString: string;
}

interface SafetySnapshot {
  savedAt: string;
  reason: string;
  recordCount: number;
  jsonString: string;
}

const SAFETY_SNAPSHOT_KEY = 'ma_residence_emergency_safety_snapshot';

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose }) => {
  const { 
    t, 
    currentUser, 
    lang,
    buildings,
    apartments,
    residents,
    employees,
    maintenanceTickets,
    periodicMaintenances,
    payments,
    expenses,
    visitors,
    notices,
    archivedPayments,
    archivedExpenses,
    archiveBatches,
    manualMonthlyRecords,
    users,
    exportDataAsJSON, 
    restoreDataFromJSON, 
    resetToFactoryData, 
    clearCloudAndLocalData,
    pushToSupabaseNow,
    syncWithSupabase,
    lastCloudSync,
    isCloudSyncing,
    saveAllDataExplicitly
  } = useApp();

  // Navigation tab: 'supabase_backup' | 'restore_disaster' | 'safety_snapshots' | 'danger_zone'
  const [activeTab, setActiveTab] = useState<'supabase_backup' | 'restore_disaster' | 'safety_snapshots' | 'danger_zone'>('supabase_backup');

  // Supabase Connection test state
  const [connectionStatus, setConnectionStatus] = useState<SupabaseTestResult | null>(null);
  const [isTestingConnection, setIsTestingConnection] = useState<boolean>(false);
  const [isExportingSupabase, setIsExportingSupabase] = useState<boolean>(false);
  const [isRestoringFromCloud, setIsRestoringFromCloud] = useState<boolean>(false);
  const [isDeletingAll, setIsDeletingAll] = useState<boolean>(false);

  // File upload & inspection state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isReadingFile, setIsReadingFile] = useState<boolean>(false);
  const [parsedFileInfo, setParsedFileInfo] = useState<ParsedBackupInfo | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [restoreProgress, setRestoreProgress] = useState<string | null>(null);
  const [operationFeedback, setOperationFeedback] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);

  // Safety snapshot state
  const [lastSafetySnapshot, setLastSafetySnapshot] = useState<SafetySnapshot | null>(null);
  const [isRollingBack, setIsRollingBack] = useState<boolean>(false);

  // Load existing safety snapshot on modal open
  useEffect(() => {
    if (isOpen) {
      loadExistingSafetySnapshot();
      runSupabasePing();
      setOperationFeedback(null);
      setParsedFileInfo(null);
      setFileError(null);
    }
  }, [isOpen]);

  const loadExistingSafetySnapshot = () => {
    try {
      const stored = localStorage.getItem(SAFETY_SNAPSHOT_KEY);
      if (stored) {
        const parsed: SafetySnapshot = JSON.parse(stored);
        setLastSafetySnapshot(parsed);
      }
    } catch {
      setLastSafetySnapshot(null);
    }
  };

  const createSafetySnapshot = (reasonText: string): SafetySnapshot => {
    const currentData = {
      buildings,
      apartments,
      residents,
      employees,
      maintenanceTickets,
      periodicMaintenances,
      payments,
      expenses,
      visitors,
      notices,
      archivedPayments,
      archivedExpenses,
      archiveBatches,
      manualMonthlyRecords,
      users: users.map(u => ({ ...u, password: '***' }))
    };
    const jsonString = JSON.stringify(currentData);
    const totalCount = 
      buildings.length + 
      apartments.length + 
      residents.length + 
      payments.length + 
      expenses.length +
      manualMonthlyRecords.length;

    const snapshot: SafetySnapshot = {
      savedAt: new Date().toISOString(),
      reason: reasonText,
      recordCount: totalCount,
      jsonString
    };

    try {
      localStorage.setItem(SAFETY_SNAPSHOT_KEY, JSON.stringify(snapshot));
      setLastSafetySnapshot(snapshot);
    } catch (e) {
      console.warn('Could not store full safety snapshot in localStorage:', e);
    }
    return snapshot;
  };

  // Ping Supabase
  const runSupabasePing = async () => {
    setIsTestingConnection(true);
    try {
      const res = await checkSupabaseProjectStatus();
      setConnectionStatus(res);
    } catch (e: any) {
      setConnectionStatus({
        success: false,
        message: e?.message || 'Erreur de connexion Supabase'
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  // Supabase Config details
  const supabaseCfg = useMemo(() => getSupabaseConfig(), []);
  const projectRef = useMemo(() => extractProjectRef(supabaseCfg.url), [supabaseCfg.url]);

  // Current Live App Stats
  const liveStats = useMemo(() => {
    return {
      buildings: buildings.length,
      apartments: apartments.length,
      residents: residents.length,
      payments: payments.length,
      expenses: expenses.length,
      tickets: maintenanceTickets.length,
      employees: employees.length,
      notices: notices.length,
      archived: archivedPayments.length + archivedExpenses.length,
      manualMonthlyRecords: manualMonthlyRecords.length
    };
  }, [buildings, apartments, residents, payments, expenses, maintenanceTickets, employees, notices, archivedPayments, archivedExpenses, manualMonthlyRecords]);

  // Handler: Create & Export Backup of current Supabase Database
  const handleExportSupabaseDatabase = async () => {
    setIsExportingSupabase(true);
    setOperationFeedback(null);

    try {
      // 1. First attempt to pull directly from Supabase Cloud
      const cloudResult = await pullResidenceFromSupabase();
      let targetPayload: any = null;
      let isLiveFromCloud = false;

      if (cloudResult.success && cloudResult.data && Object.keys(cloudResult.data).length > 0) {
        targetPayload = cloudResult.data;
        isLiveFromCloud = true;
      } else {
        // If cloud table was empty or not yet seeded, push local active sync payload so user gets a comprehensive backup
        targetPayload = {
          buildings,
          apartments,
          residents,
          payments,
          expenses,
          employees,
          maintenanceTickets,
          periodicMaintenances,
          notices,
          visitors,
          archivedPayments,
          archivedExpenses,
          archiveBatches,
          manualMonthlyRecords,
          lastSyncedAt: new Date().toISOString()
        };
        // Auto-seed to Supabase as well
        pushResidenceToSupabase(targetPayload).catch(() => {});
      }

      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = `${String(now.getHours()).padStart(2, '0')}h${String(now.getMinutes()).padStart(2, '0')}m`;

      const backupFileContent = {
        metadata: {
          source: 'supabase_cloud_database',
          backupType: 'supabase_json_export',
          projectRef: projectRef || 'dcbadrrjxdppjjqsaztp',
          supabaseUrl: supabaseCfg.url,
          exportedAt: now.toISOString(),
          version: '2.0',
          residenceName: 'إقامة المرجان - Résidence Al Morjane',
          isLiveCloudRead: isLiveFromCloud,
          recordCounts: {
            buildings: targetPayload.buildings?.length || buildings.length,
            apartments: targetPayload.apartments?.length || apartments.length,
            residents: targetPayload.residents?.length || residents.length,
            payments: targetPayload.payments?.length || payments.length,
            expenses: targetPayload.expenses?.length || expenses.length,
            employees: targetPayload.employees?.length || employees.length,
            maintenanceTickets: targetPayload.maintenanceTickets?.length || maintenanceTickets.length,
            notices: targetPayload.notices?.length || notices.length,
            visitors: targetPayload.visitors?.length || visitors.length,
            archivedRecords: (targetPayload.archivedPayments?.length || 0) + (targetPayload.archivedExpenses?.length || 0),
            manualMonthlyRecords: targetPayload.manualMonthlyRecords?.length || manualMonthlyRecords.length
          }
        },
        data: targetPayload
      };

      const jsonBlob = new Blob([JSON.stringify(backupFileContent, null, 2)], { type: 'application/json' });
      const downloadUrl = URL.createObjectURL(jsonBlob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `RESIDENCE_AL_MORJANE_BACKUP_${dateStr}_${timeStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);

      setOperationFeedback({
        type: 'success',
        message: lang === 'ar'
          ? '✅ تم بنجاح إنشاء وتصدير النسخة الاحتياطية الشاملة بصيغة JSON!'
          : '✅ Sauvegarde complète générée et téléchargée avec succès en JSON !'
      });
    } catch (err: any) {
      console.error('Backup export failed:', err);
      setOperationFeedback({
        type: 'error',
        message: (lang === 'ar' ? 'فشل تصدير النسخة الاحتياطية: ' : 'Échec de l\'export de sauvegarde: ') + (err?.message || String(err))
      });
    } finally {
      setIsExportingSupabase(false);
    }
  };

  // Handler: Inspect JSON File before restoring
  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsReadingFile(true);
    setFileError(null);
    setParsedFileInfo(null);
    setOperationFeedback(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const rawJsonString = evt.target?.result as string;
        if (!rawJsonString || !rawJsonString.trim()) {
          throw new Error(lang === 'ar' ? 'ملف النسخة الاحتياطية فارغ!' : 'Fichier de sauvegarde vide !');
        }

        const parsed = JSON.parse(rawJsonString);
        const root = parsed.data || parsed.databaseTables || parsed;

        // Check whether this file has minimum valid residence entities
        const bCount = Array.isArray(root.buildings) ? root.buildings.length : 0;
        const aCount = Array.isArray(root.apartments) ? root.apartments.length : 0;
        const rCount = Array.isArray(root.residents) ? root.residents.length : 0;
        const pCount = Array.isArray(root.payments) ? root.payments.length : 0;
        const eCount = Array.isArray(root.expenses) ? root.expenses.length : 0;
        const empCount = Array.isArray(root.employees) ? root.employees.length : 0;
        const tCount = Array.isArray(root.maintenanceTickets) ? root.maintenanceTickets.length : 0;
        const nCount = Array.isArray(root.notices) ? root.notices.length : 0;
        const vCount = Array.isArray(root.visitors) ? root.visitors.length : 0;
        const apCount = Array.isArray(root.archivedPayments) ? root.archivedPayments.length : 0;
        const aeCount = Array.isArray(root.archivedExpenses) ? root.archivedExpenses.length : 0;
        const mCount = Array.isArray(root.manualMonthlyRecords) ? root.manualMonthlyRecords.length : 0;

        const totalRecords = bCount + aCount + rCount + pCount + eCount + mCount;

        if (totalRecords === 0) {
          throw new Error(
            lang === 'ar' 
              ? 'الملف لا يحتوي على سجلات متوافقة (عمارات، شقق، ملاك، وصولات أو مصاريف).' 
              : 'Format invalide: aucune donnée de résidence reconnue.'
          );
        }

        const isSupabaseSource = 
          parsed.metadata?.source?.includes('supabase') || 
          parsed.source?.includes('supabase') || 
          !!parsed.metadata?.projectRef;

        setParsedFileInfo({
          source: isSupabaseSource ? 'supabase_cloud' : 'local_system',
          projectRef: parsed.metadata?.projectRef || parsed.projectRef,
          exportedAt: parsed.metadata?.exportedAt || parsed.exportDate,
          version: parsed.metadata?.version || parsed.version || '2.0',
          counts: {
            buildings: bCount,
            apartments: aCount,
            residents: rCount,
            payments: pCount,
            expenses: eCount,
            employees: empCount,
            maintenanceTickets: tCount,
            notices: nCount,
            visitors: vCount,
            archivedPayments: apCount,
            archivedExpenses: aeCount,
            manualMonthlyRecords: mCount
          },
          rawJsonString
        });
      } catch (err: any) {
        setFileError(err?.message || (lang === 'ar' ? 'خطأ في قراءة ملف JSON' : 'Erreur de lecture du fichier JSON'));
      } finally {
        setIsReadingFile(false);
      }
    };

    reader.onerror = () => {
      setIsReadingFile(false);
      setFileError(lang === 'ar' ? 'تعذر فتح الملف المختار' : 'Impossible d\'ouvrir le fichier sélectionné');
    };

    reader.readAsText(file);
  };

  // Handler: Execute Restore (Local + Optional Supabase Sync)
  const handleExecuteRestore = async (syncToSupabaseAlso: boolean) => {
    if (!parsedFileInfo) return;

    setRestoreProgress(lang === 'ar' ? 'جاري إنشاء نقطة أمان احتياطية قبل الاستعادة...' : 'Création du point de restauration de sécurité...');

    // 1. Create safety snapshot first so user can rollback in case of any mistake or error
    createSafetySnapshot(
      lang === 'ar' 
        ? `نقطة أمان تلقائية قبل استعادة ملف (${parsedFileInfo.source === 'supabase_cloud' ? 'سحابي' : 'JSON'})` 
        : 'Point de sécurité automatique avant restauration'
    );

    setRestoreProgress(lang === 'ar' ? 'جاري فك وتطبيق البيانات واستبدال السجلات...' : 'Application des données...');

    // 2. Restore local application state & localStorage
    const success = restoreDataFromJSON(parsedFileInfo.rawJsonString);
    if (!success) {
      setOperationFeedback({
        type: 'error',
        message: lang === 'ar' 
          ? 'حدث خطأ غير متوقع أثناء معالجة بيانات الملف!' 
          : 'Échec de l\'application des données.'
      });
      setRestoreProgress(null);
      return;
    }

    saveAllDataExplicitly();

    // 3. If requested, sync immediately with Supabase database
    if (syncToSupabaseAlso) {
      setRestoreProgress(lang === 'ar' ? 'جاري رفع البيانات المستعادة إلى قاعدة بيانات Supabase السحابية...' : 'Synchronisation Cloud avec Supabase...');
      try {
        const parsed = JSON.parse(parsedFileInfo.rawJsonString);
        const root = parsed.data || parsed.databaseTables || parsed;
        const pushPayload: ResidenceSyncPayload = {
          buildings: root.buildings || buildings,
          apartments: root.apartments || apartments,
          residents: root.residents || residents,
          payments: root.payments || payments,
          expenses: root.expenses || expenses,
          employees: root.employees || employees,
          maintenanceTickets: root.maintenanceTickets || maintenanceTickets,
          notices: root.notices || notices,
          visitors: root.visitors || visitors,
          archivedPayments: root.archivedPayments || archivedPayments,
          archivedExpenses: root.archivedExpenses || archivedExpenses,
          archiveBatches: root.archiveBatches || archiveBatches,
          manualMonthlyRecords: root.manualMonthlyRecords || manualMonthlyRecords,
          lastSyncedAt: new Date().toISOString()
        };

        const pushRes = await pushResidenceToSupabase(pushPayload);
        if (pushRes.success) {
          setOperationFeedback({
            type: 'success',
            message: lang === 'ar'
              ? '🎉 تم بنجاح استعادة كافة البيانات داخل التطبيق وتحديث قاعدة بيانات Supabase السحابية فورياً!'
              : '🎉 Restauration locale et synchronisation avec Supabase réussies !'
          });
        } else {
          setOperationFeedback({
            type: 'info',
            message: (lang === 'ar' 
              ? 'تم استعادة البيانات محلياً بنجاح، لكن حدث تنبيه أثناء الرفع إلى Supabase: ' 
              : 'Données restaurées localement, mais alerte Supabase: ') + (pushRes.error || '')
          });
        }
      } catch (err: any) {
        setOperationFeedback({
          type: 'info',
          message: lang === 'ar'
            ? 'تم استعادة البيانات محلياً، ويمكنك رفعها لاحقاً إلى السحابة عبر زر المزامنة.'
            : 'Données restaurées en local.'
        });
      }
    } else {
      setOperationFeedback({
        type: 'success',
        message: lang === 'ar'
          ? '✅ تم استعادة البيانات محلياً بنجاح (دون تعديل السحابة).'
          : '✅ Données restaurées localement avec succès.'
      });
    }

    setRestoreProgress(null);
    setParsedFileInfo(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Handler: One-Click Emergency Restore from Supabase Cloud to App
  const handleRestoreDirectlyFromSupabaseCloud = async () => {
    const confirmMsg = lang === 'ar'
      ? 'هل أنت متأكد من استعادة التطبيق مباشرة من آخر نسخة متزامنة في سحابة Supabase؟ سيتم حفظ نقطة أمان للتراجع أولاً.'
      : 'Voulez-vous restaurer l\'application directement depuis la dernière version Cloud Supabase ?';

    if (!confirm(confirmMsg)) return;

    setIsRestoringFromCloud(true);
    setOperationFeedback(null);

    // Save rollback snapshot
    createSafetySnapshot(lang === 'ar' ? 'نقطة أمان قبل الاستعادة المباشرة من Supabase' : 'Point de sécurité avant restauration Supabase');

    try {
      const res = await syncWithSupabase();
      if (res.success) {
        setOperationFeedback({
          type: 'success',
          message: lang === 'ar'
            ? '🎉 تم بنجاح استعادة كامل السجلات من سحابة Supabase ومطابقتها بالتطبيق!'
            : '🎉 Données restaurées avec succès depuis Supabase !'
        });
      } else {
        setOperationFeedback({
          type: 'error',
          message: (lang === 'ar' ? 'فشلت الاستعادة من Supabase: ' : 'Échec de restauration Supabase: ') + (res.error || '')
        });
      }
    } catch (err: any) {
      setOperationFeedback({
        type: 'error',
        message: (lang === 'ar' ? 'خطأ في الاتصال بسحابة Supabase: ' : 'Erreur Supabase: ') + (err?.message || String(err))
      });
    } finally {
      setIsRestoringFromCloud(false);
    }
  };

  // Handler: Rollback to last Safety Snapshot
  const handleRollbackSnapshot = () => {
    if (!lastSafetySnapshot) return;

    const confirmMsg = lang === 'ar'
      ? `هل أنت متأكد من التراجع واستعادة نقطة الأمان المحفوظة بتاريخ ${new Date(lastSafetySnapshot.savedAt).toLocaleTimeString('ar-MA')}؟`
      : 'Voulez-vous annuler et revenir au point de sécurité précédent ?';

    if (!confirm(confirmMsg)) return;

    setIsRollingBack(true);
    try {
      const success = restoreDataFromJSON(lastSafetySnapshot.jsonString);
      if (success) {
        saveAllDataExplicitly();
        // optionally sync to Supabase
        pushToSupabaseNow().catch(() => {});
        setOperationFeedback({
          type: 'success',
          message: lang === 'ar'
            ? '↩️ تم التراجع بنجاح واستعادة نقطة الأمان السابقة!'
            : '↩️ Annulation réussie, retour au point de sécurité précédent !'
        });
      } else {
        throw new Error('Échec de lecture de la sauvegarde');
      }
    } catch (err: any) {
      setOperationFeedback({
        type: 'error',
        message: lang === 'ar' ? 'فشل التراجع عن التغييرات!' : 'Échec du retour en arrière.'
      });
    } finally {
      setIsRollingBack(false);
    }
  };

  // Handler: Manual Safety Snapshot Creation
  const handleManualSafetySnapshot = () => {
    createSafetySnapshot(lang === 'ar' ? 'نقطة أمان يدوية بطلب من السانديك' : 'Point de sécurité manuel');
    setOperationFeedback({
      type: 'success',
      message: lang === 'ar' 
        ? '🛡️ تم بنجاح إنشاء وحفظ نقطة أمان جديدة للتطبيق! يمكنك التراجع إليها في أي لحظة.'
        : '🛡️ Nouveau point de sécurité enregistré avec succès !'
    });
  };

  // Handler: Delete All Data
  const handleDeleteAllCloudAndLocal = async () => {
    const msg = lang === 'ar'
      ? '⚠️ تحذير نهائي وقاطع: هل أنت متأكد من حذف وإفراغ جميع البيانات من التطبيق ومن منصة Supabase السحابية نهائياً؟'
      : '⚠️ Attention : Voulez-vous supprimer définitivement toutes les données de l\'application et de Supabase ?';
    
    if (confirm(msg)) {
      createSafetySnapshot(lang === 'ar' ? 'نقطة أمان قبل تصفير التطبيق والسحابة' : 'Point de sécurité avant suppression');
      setIsDeletingAll(true);
      const res = await clearCloudAndLocalData();
      setIsDeletingAll(false);
      if (res.success) {
        alert(lang === 'ar' ? 'تم حذف وتصفير جميع البيانات السحابية والمحلية بنجاح!' : 'Toutes les données ont été supprimées avec succès !');
        onClose();
      } else {
        alert((lang === 'ar' ? 'تم تصفير التطبيق، وحدث تنبيه سحابي: ' : 'Erreur Cloud: ') + (res.error || ''));
        onClose();
      }
    }
  };

  // Handler: Factory Reset
  const handleReset = () => {
    if (confirm(lang === 'ar' ? 'هل أنت متأكد من استعادة البيانات الافتراضية الأولية للإقامة؟' : 'Voulez-vous réinitialiser les données locales par défaut ?')) {
      createSafetySnapshot(lang === 'ar' ? 'نقطة أمان قبل إعادة ضبط المصنع' : 'Point de sécurité avant réinitialisation');
      resetToFactoryData();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white flex items-center justify-between gap-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-500/30 shrink-0">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  {lang === 'ar' ? 'النسخ الاحتياطي السحابي واستعادة البيانات' : 'Sauvegarde Cloud & Restauration'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold">
                  JSON + Cloud
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 font-medium">
                {lang === 'ar'
                  ? 'تصدير نسخة احتياطية بصيغة JSON من قاعدة البيانات السحابية مع حماية واستعادة البيانات عند حدوث خطأ'
                  : 'Exportez la base Cloud en JSON avec restauration d\'urgence en cas d\'erreur'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-colors cursor-pointer shrink-0"
            title={t.common.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation Ribbon */}
        <div className="bg-slate-100/90 px-6 py-2.5 border-b border-slate-200 flex items-center justify-between gap-2 overflow-x-auto shrink-0">
          <div className="flex items-center gap-1.5 min-w-max">
            <button
              type="button"
              onClick={() => { setActiveTab('supabase_backup'); setOperationFeedback(null); }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'supabase_backup'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              <Cloud className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'تصدير نسخة احتياطية (JSON)' : 'Sauvegarde (JSON)'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('restore_disaster'); setOperationFeedback(null); }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'restore_disaster'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              <ArrowUpFromLine className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'استعادة البيانات ومعالجة الأخطاء' : 'Restauration & Dépannage'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('safety_snapshots'); setOperationFeedback(null); }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                activeTab === 'safety_snapshots'
                  ? 'bg-indigo-700 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'نقاط الأمان والتراجع (Rollback)' : 'Points de sécurité'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('danger_zone'); setOperationFeedback(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'danger_zone'
                  ? 'bg-rose-700 text-white shadow-xs'
                  : 'text-rose-700 hover:text-rose-900 hover:bg-rose-50'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'إعادة التعيين' : 'Réinitialisation'}</span>
            </button>
          </div>
        </div>

        {/* Global Feedback Banner */}
        {operationFeedback && (
          <div className={`mx-6 mt-4 p-3.5 rounded-2xl border flex items-center justify-between text-xs font-bold animate-in fade-in ${
            operationFeedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : operationFeedback.type === 'error'
              ? 'bg-rose-50 border-rose-300 text-rose-950'
              : 'bg-blue-50 border-blue-300 text-blue-950'
          }`}>
            <div className="flex items-center gap-2">
              {operationFeedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : operationFeedback.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span>{operationFeedback.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setOperationFeedback(null)}
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Restore in progress overlay */}
        {restoreProgress && (
          <div className="mx-6 mt-4 p-4 rounded-2xl bg-blue-50 border border-blue-300 text-blue-950 text-xs font-bold flex items-center gap-3 animate-pulse">
            <RefreshCw className="w-5 h-5 text-blue-600 animate-spin shrink-0" />
            <div>{restoreProgress}</div>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: SUPABASE BACKUP & JSON EXPORT */}
          {activeTab === 'supabase_backup' && (
            <div className="space-y-5">
              
              {/* Informative Hero */}
              <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 p-5 rounded-2xl border border-emerald-200">
                <div className="flex items-start gap-3.5">
                  <div className="p-2.5 rounded-xl bg-emerald-700 text-white shrink-0 mt-0.5">
                    <Cloud className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-emerald-950">
                      {lang === 'ar' ? 'إنشاء نسخة احتياطية وتصديرها بصيغة JSON' : 'Génération et Export de Sauvegarde JSON'}
                    </h3>
                    <p className="text-xs text-emerald-900/80 mt-1 leading-relaxed">
                      {lang === 'ar'
                        ? 'تتيح لك هذه الميزة جلب كامل قاعدة بيانات الإقامة المحفوظة في السحابة وحفظها في ملف JSON مستقل على جهازك، يحتوي على جميع عمارات الإقامة الـ 20، الشقق، الملاك، وصولات الأداء، والمصاريف.'
                        : 'Permet d\'exporter l\'intégralité des tables stockées sur le Cloud dans un fichier JSON complet pour vos archives et votre sécurité.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Real-time Records Overview */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700">
                    {lang === 'ar' ? '📊 ملخص السجلات المتضمنة في النسخة الاحتياطية:' : '📊 Aperçu des données à sauvegarder :'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'العمارات السكنية' : 'Immeubles'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.buildings} (20 عمارة)</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'الشقق والمحلات' : 'Appartements'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.apartments}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'الملاك والسكان' : 'Copropriétaires'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.residents}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'وصولات الأداء' : 'Reçus / Paiements'}</div>
                    <div className="text-base font-black text-emerald-800 mt-0.5 font-mono">{liveStats.payments}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'فواتير المصاريف' : 'Dépenses'}</div>
                    <div className="text-base font-black text-rose-800 mt-0.5 font-mono">{liveStats.expenses}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'عمليات الصيانة' : 'Maintenance'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.tickets}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'المستخدمين والموظفين' : 'Personnel'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.employees}</div>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-bold">{lang === 'ar' ? 'الأرشيف التاريخي' : 'Archives'}</div>
                    <div className="text-base font-black text-slate-900 mt-0.5 font-mono">{liveStats.archived}</div>
                  </div>
                  <div className="bg-emerald-50/60 p-3 rounded-xl border border-emerald-200 col-span-2 sm:col-span-1">
                    <div className="text-[10px] text-emerald-800 font-bold">{lang === 'ar' ? 'السجل والتقرير المالي' : 'Registre mensuel'}</div>
                    <div className="text-base font-black text-emerald-900 mt-0.5 font-mono">{liveStats.manualMonthlyRecords} {lang === 'ar' ? 'شهراً' : 'mois'}</div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                
                {/* Primary Button: Supabase Cloud JSON Export */}
                <button
                  type="button"
                  onClick={handleExportSupabaseDatabase}
                  disabled={isExportingSupabase}
                  className="p-5 rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-800 hover:from-emerald-500 hover:to-teal-600 text-white shadow-lg shadow-emerald-700/20 transition-all flex flex-col items-center justify-center text-center gap-3 group cursor-pointer border border-emerald-400/30 disabled:opacity-60"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white/15 text-white flex items-center justify-center group-hover:scale-110 transition-transform">
                    {isExportingSupabase ? (
                      <RefreshCw className="w-6 h-6 animate-spin text-white" />
                    ) : (
                      <ArrowDownToLine className="w-6 h-6 text-white" />
                    )}
                  </div>
                  <div>
                    <div className="font-black text-sm text-white">
                      {lang === 'ar' ? 'تصدير نسخة احتياطية سحابية (JSON) 📥' : 'Exporter la Sauvegarde Cloud (JSON)'}
                    </div>
                    <div className="text-[11px] text-emerald-100/80 mt-1 font-medium">
                      {lang === 'ar' ? 'جلب بيانات السحابة وتنزيل ملف JSON فوري' : 'Téléchargement direct avec métadonnées'}
                    </div>
                  </div>
                </button>

                {/* Secondary Button: Local Full App JSON Export */}
                <button
                  type="button"
                  onClick={() => {
                    exportDataAsJSON();
                    setOperationFeedback({
                      type: 'success',
                      message: lang === 'ar' ? '✅ تم تصدير النسخة الشاملة للتطبيق بصيغة JSON بنجاح!' : '✅ Sauvegarde complète locale exportée avec succès !'
                    });
                  }}
                  className="p-5 rounded-2xl bg-slate-50 hover:bg-slate-100/90 text-slate-800 border border-slate-300 shadow-xs transition-all flex flex-col items-center justify-center text-center gap-3 group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <FileJson className="w-6 h-6 text-slate-700" />
                  </div>
                  <div>
                    <div className="font-black text-sm text-slate-900">
                      {lang === 'ar' ? 'تصدير نسخة شاملة من النظام (كامل الأرشيف)' : 'Sauvegarde Système Complète (Avec Archives)'}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 font-medium">
                      {lang === 'ar' ? 'تتضمن كل السجلات المحلية والتاريخية' : 'Inclut les archives et paramètres'}
                    </div>
                  </div>
                </button>

              </div>
            </div>
          )}

          {/* TAB 2: DISASTER RECOVERY & RESTORE ON ERROR */}
          {activeTab === 'restore_disaster' && (
            <div className="space-y-5">
              
              {/* Emergency Banner */}
              <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-blue-50 p-4 rounded-2xl border border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-blue-700 text-white shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-blue-950">
                      {lang === 'ar' ? 'استعادة البيانات في حال حدوث خطأ (Disaster Recovery)' : 'Restauration en cas d\'erreur ou de panne'}
                    </h3>
                    <p className="text-xs text-blue-900/80 mt-0.5 leading-relaxed">
                      {lang === 'ar'
                        ? 'في حال حدوث خطأ غير مقصود، فقدان للبيانات، أو تلف في متصفحك، يمكنك استعادة كافة السجلات فوراً من ملف نسخة احتياطية سابق، أو استعادتها بضغطة واحدة من آخر نسخة محفوظة في سحابة Supabase.'
                        : 'Restaurez facilement votre base de données à partir d\'un fichier JSON ou directement depuis la dernière copie Supabase.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Option A: One-Click Restore from Cloud */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Cloud className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-black text-slate-900">
                      {lang === 'ar' ? 'استعادة فورية من السحابة مباشرة' : 'Restauration directe depuis le Cloud'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    {lang === 'ar' 
                      ? 'جلب آخر نسخة سليمة من قاعدة البيانات واستبدال البيانات المحلية المعطوبة مع حفظ نقطة أمان' 
                      : 'Récupère la copie saine depuis le Cloud pour corriger les erreurs locales.'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleRestoreDirectlyFromSupabaseCloud}
                  disabled={isRestoringFromCloud}
                  className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 text-white text-xs font-black transition-all shadow-sm cursor-pointer flex items-center gap-2 shrink-0 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRestoringFromCloud ? 'animate-spin' : ''}`} />
                  <span>{lang === 'ar' ? 'استعادة من السحابة الآن ⚡' : 'Restaurer depuis le Cloud'}</span>
                </button>
              </div>

              {/* Option B: Restore from Local JSON File with Pre-inspection */}
              <div className="space-y-3">
                <span className="block text-xs font-bold text-slate-800">
                  {lang === 'ar' ? 'أو استيراد واستعادة ملف نسخة احتياطية (JSON):' : 'Ou importer un fichier de sauvegarde (JSON) :'}
                </span>

                {/* Dropzone / File trigger */}
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="p-6 rounded-2xl border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50 hover:bg-blue-50/40 transition-all text-center flex flex-col items-center justify-center gap-2.5 cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-800 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ArrowUpFromLine className="w-6 h-6 text-blue-700" />
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-800">
                      {lang === 'ar' ? 'انقر لاختيار ملف النسخة الاحتياطية (.json) من جهازك' : 'Cliquez pour sélectionner le fichier JSON'}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {lang === 'ar' ? 'يقبل ملفات النسخ الاحتياطية وملفات JSON الشاملة' : 'Compatible avec tous les fichiers de sauvegarde JSON'}
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleFileSelected}
                    className="hidden"
                  />
                </div>

                {isReadingFile && (
                  <div className="p-3 text-xs text-blue-700 font-bold flex items-center gap-2 justify-center">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{lang === 'ar' ? 'جاري فحص وتدقيق بنية الملف...' : 'Analyse du fichier en cours...'}</span>
                  </div>
                )}

                {fileError && (
                  <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{fileError}</span>
                  </div>
                )}

                {/* Parsed Inspection Card */}
                {parsedFileInfo && (
                  <div className="p-4 rounded-2xl bg-slate-900 text-white border border-slate-700 space-y-3 animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="text-xs font-black">
                          {lang === 'ar' ? 'نتيجة فحص الملف: ملف سليم ومتوافق' : 'Fichier validé avec succès'}
                        </span>
                      </div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold border border-emerald-500/30">
                        {parsedFileInfo.source === 'supabase_cloud' ? 'Cloud Backup' : 'System Backup'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'العمارات' : 'Immeubles'}</span>
                        <span className="font-mono font-bold text-white">{parsedFileInfo.counts.buildings}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'الشقق والملاك' : 'Appartements'}</span>
                        <span className="font-mono font-bold text-white">{parsedFileInfo.counts.apartments}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'السكان' : 'Résidents'}</span>
                        <span className="font-mono font-bold text-white">{parsedFileInfo.counts.residents}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'الوصولات' : 'Paiements'}</span>
                        <span className="font-mono font-bold text-emerald-400">{parsedFileInfo.counts.payments}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'المصاريف' : 'Dépenses'}</span>
                        <span className="font-mono font-bold text-rose-400">{parsedFileInfo.counts.expenses}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'الصيانة' : 'Maintenance'}</span>
                        <span className="font-mono font-bold text-white">{parsedFileInfo.counts.maintenanceTickets}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'تاريخ التصدير' : 'Date'}</span>
                        <span className="font-mono text-[10px] text-slate-300">
                          {parsedFileInfo.exportedAt ? new Date(parsedFileInfo.exportedAt).toLocaleDateString('ar-MA') : 'N/A'}
                        </span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'أشهر السجل المالي' : 'Mois registre'}</span>
                        <span className="font-mono font-bold text-amber-400">{parsedFileInfo.counts.manualMonthlyRecords || 0}</span>
                      </div>
                      <div className="bg-white/5 p-2 rounded-lg">
                        <span className="text-[10px] text-slate-400 block">{lang === 'ar' ? 'نقطة الأمان' : 'Sécurité'}</span>
                        <span className="text-[10px] text-emerald-300 font-bold">تلقائية (Rollback)</span>
                      </div>
                    </div>

                    {/* Restore Action Buttons */}
                    <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => handleExecuteRestore(true)}
                        className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-black text-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Cloud className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'استعادة للتطبيق + تحديث السحابة فوراً 🚀' : 'Restaurer & Synchroniser Cloud'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleExecuteRestore(false)}
                        className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <HardDrive className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'استعادة محلية فقط' : 'Local seulement'}</span>
                      </button>
                    </div>

                  </div>
                )}

              </div>

            </div>
          )}

          {/* TAB 3: SAFETY SNAPSHOTS & ROLLBACK */}
          {activeTab === 'safety_snapshots' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-indigo-50 via-slate-50 to-indigo-50 p-4 rounded-2xl border border-indigo-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-indigo-700 text-white shrink-0 mt-0.5">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-indigo-950">
                      {lang === 'ar' ? 'نقاط الأمان والحماية والتراجع الفوري (Safety Rollback)' : 'Points de Sécurité & Retour Arrière'}
                    </h3>
                    <p className="text-xs text-indigo-900/80 mt-0.5 leading-relaxed">
                      {lang === 'ar'
                        ? 'يقوم النظام تلقائياً بإنشاء وحفظ نقطة أمان سريعة قبل أي عملية استعادة أو تصفير، لتمكينك من التراجع الفوري إلى حالتك السابقة في حال حدوث أي خطأ.'
                        : 'Une sauvegarde locale automatique est générée avant chaque opération pour vous permettre d\'annuler immédiatement en cas d\'erreur.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Status of current safety snapshot */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">
                    {lang === 'ar' ? 'نقطة الأمان المحفوظة حالياً للتراجع:' : 'Dernier point de sécurité disponible :'}
                  </span>
                  {lastSafetySnapshot ? (
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                      🟢 جاهزة للتراجع
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-md bg-slate-200 text-slate-600 text-[10px] font-bold">
                      لا توجد نقطة سابقة
                    </span>
                  )}
                </div>

                {lastSafetySnapshot ? (
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="font-bold text-slate-900">{lastSafetySnapshot.reason}</div>
                      <div className="text-slate-500 font-mono text-[11px]">
                        {new Date(lastSafetySnapshot.savedAt).toLocaleString('ar-MA')}
                      </div>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {lang === 'ar' ? 'إجمالي السجلات المحفوظة في النقطة:' : 'Total enregistrements sauvegardés:'}{' '}
                      <span className="font-mono font-bold text-slate-800">{lastSafetySnapshot.recordCount}</span>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={handleRollbackSnapshot}
                        disabled={isRollingBack}
                        className="w-full py-2.5 px-4 rounded-xl bg-indigo-700 hover:bg-indigo-600 active:bg-indigo-800 text-white text-xs font-black transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className={`w-3.5 h-3.5 ${isRollingBack ? 'animate-spin' : ''}`} />
                        <span>{lang === 'ar' ? '↩️ تراجع واستعادة نقطة الأمان الأخيرة الآن' : 'Annuler et revenir en arrière'}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">
                    {lang === 'ar' 
                      ? 'لم يتم تسجيل نقطة أمان بعد. يمكنك حفظ نقطة أمان جديدة يدوياً بالزر أدناه.' 
                      : 'Aucun point de sécurité enregistré.'}
                  </p>
                )}

                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={handleManualSafetySnapshot}
                    className="px-4 py-2 rounded-xl bg-white border border-indigo-200 hover:bg-indigo-50 text-indigo-700 text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? '📌 حفظ نقطة أمان جديدة الآن' : 'Créer un point de sécurité'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DANGER ZONE (RESET / PURGE) */}
          {activeTab === 'danger_zone' && (
            <div className="space-y-4">
              <div className="bg-rose-50 p-4 rounded-2xl border border-rose-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-rose-600 text-white shrink-0 mt-0.5">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-rose-950">
                      {lang === 'ar' ? 'إجراءات حساسة (إعادة التعيين والتصفير)' : 'Zone de Danger & Réinitialisation'}
                    </h3>
                    <p className="text-xs text-rose-900/80 mt-0.5 leading-relaxed">
                      {lang === 'ar'
                        ? 'تتيح لك هذه الخيارات إعادة ضبط التطبيق أو إفراغ قاعدة بيانات Supabase. يوصى دائماً بتصدير نسخة احتياطية أولاً.'
                        : 'Réinitialisez les données locales ou supprimez définitivement la base Cloud.'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {lang === 'ar' ? 'استعادة البيانات الافتراضية الأولية' : 'Réinitialiser aux valeurs par défaut'}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      {lang === 'ar' ? 'إعادة العمارات والشقق والسكان إلى الحالة النموذجية النظيفة' : 'Restaure l\'état propre initial'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all shadow-2xs cursor-pointer flex items-center gap-1.5 shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                    <span>{t.backup.resetBtn}</span>
                  </button>
                </div>

                <div className="p-4 rounded-2xl border border-rose-200 bg-rose-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-black text-rose-900">
                      {lang === 'ar' ? 'حذف جميع البيانات من التطبيق والسحابة' : 'Supprimer toutes les données (App + Cloud)'}
                    </div>
                    <div className="text-[11px] text-rose-700 mt-0.5">
                      {lang === 'ar' ? 'إفراغ كامل لقاعدة البيانات السحابية والمحلية (إجراء لا رجعة فيه)' : 'Action irréversible'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleDeleteAllCloudAndLocal}
                    disabled={isDeletingAll}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black transition-all shadow-sm cursor-pointer flex items-center gap-1.5 shrink-0 disabled:opacity-50"
                  >
                    {isDeletingAll ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                    <span>{lang === 'ar' ? 'تصفير شامل' : 'Supprimer tout'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="font-semibold">
              {lang === 'ar' ? 'حماية البيانات والنسخ الاحتياطي JSON مفعل' : 'Protection JSON & Cloud active'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
          >
            {t.common.close}
          </button>
        </div>

      </div>
    </div>
  );
};
