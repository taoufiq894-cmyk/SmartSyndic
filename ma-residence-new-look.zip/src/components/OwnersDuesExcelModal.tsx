import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  FileSpreadsheet, Download, Upload, CheckCircle2, AlertCircle, 
  X, Filter, FileCheck, ArrowRight, ArrowLeft, RefreshCw, Eye,
  Building, DollarSign, Users, AlertTriangle, HelpCircle, FileText
} from 'lucide-react';
import { exportOwnersDuesToExcel } from '../utils/exportUtils';
import { 
  readExcelFile, 
  autoDetectFieldMapping, 
  processImportData,
  generateOwnersExcelTemplate,
  ExcelImportFieldMapping,
  ImportSummary,
  ParsedOwnerRow
} from '../utils/excelImportUtils';
import { getApartmentDebtStatus } from '../utils/debtUtils';

interface OwnersDuesExcelModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'export' | 'import';
  initialBuildingFilter?: string;
}

export const OwnersDuesExcelModal: React.FC<OwnersDuesExcelModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'export',
  initialBuildingFilter = 'ALL'
}) => {
  const {
    lang,
    t,
    apartments,
    payments,
    buildings,
    residents,
    importOwnersFromExcelData
  } = useApp();
  const isAr = lang === 'ar';

  const [activeTab, setActiveTab] = useState<'export' | 'import'>(defaultTab);

  // --- Export State ---
  const [exportBuilding, setExportBuilding] = useState<string>(initialBuildingFilter);
  const [onlyDebtors, setOnlyDebtors] = useState<boolean>(false);
  const [exportFormat, setExportFormat] = useState<'xlsx' | 'csv'>('xlsx');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportSuccessMsg, setExportSuccessMsg] = useState<string | null>(null);

  // --- Import State ---
  type ImportStep = 'upload' | 'mapping' | 'preview' | 'success';
  const [importStep, setImportStep] = useState<ImportStep>('upload');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isLoadingFile, setIsLoadingFile] = useState<boolean>(false);
  const [importError, setImportError] = useState<string | null>(null);

  // Sheets data
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [sheetsRawData, setSheetsRawData] = useState<Record<string, { headers: string[]; rows: any[][] }>>({});

  // Column mapping
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ExcelImportFieldMapping>({
    buildingCode: '',
    apartmentNumber: '',
    ownerName: '',
    ownerPhone: '',
    ownerCin: '',
    ownerEmail: '',
    addressOrNotes: '',
    floor: '',
    monthlyFee: '',
    status: '',
    residentName: '',
    residentPhone: '',
    unpaidMonthsCount: '',
    balanceDue: ''
  });

  // Summary and preview
  const [importSummary, setImportSummary] = useState<ImportSummary | null>(null);
  const [previewFilter, setPreviewFilter] = useState<'ALL' | 'existing' | 'new' | 'invalid'>('ALL');
  const [previewSearch, setPreviewSearch] = useState<string>('');
  const [updateDebtsOption, setUpdateDebtsOption] = useState<boolean>(true);
  const [syncResidentsOption, setSyncResidentsOption] = useState<boolean>(true);

  // Success summary
  const [importResult, setImportResult] = useState<{
    apartmentsUpdated: number;
    residentsUpdated: number;
    apartmentsCreated: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // --- Quick calculations for Export Preview ---
  const eligibleApts = apartments.filter(apt => {
    if (exportBuilding === 'ALL') return true;
    if (exportBuilding === 'GROUP_A') return apt.buildingCode.endsWith('A') || apt.buildingCode.endsWith(' A');
    if (exportBuilding === 'GROUP_B') return apt.buildingCode.endsWith('B') || apt.buildingCode.endsWith(' B');
    return apt.buildingCode === exportBuilding;
  });

  let totalDuesSum = 0;
  let debtorsCount = 0;
  let settledCount = 0;

  eligibleApts.forEach(apt => {
    const debt = getApartmentDebtStatus(apt, payments);
    if (!debt.isOffice) {
      totalDuesSum += debt.totalBalanceDue;
      if (debt.totalBalanceDue > 0) debtorsCount++;
      else settledCount++;
    }
  });

  const exportCount = onlyDebtors ? debtorsCount : eligibleApts.length;

  // --- Export Handler ---
  const handleExport = () => {
    setIsExporting(true);
    setExportSuccessMsg(null);
    try {
      exportOwnersDuesToExcel({
        apartments,
        payments,
        buildings,
        lang: isAr ? 'ar' : 'fr',
        filterBuilding: exportBuilding,
        onlyDebtors,
        fileFormat: exportFormat
      });
      setExportSuccessMsg(
        isAr 
          ? `تم استخراج وتحميل كشف مستحقات الملاك بنجاح (${exportCount} شقة)`
          : `Fichier des arriérés exporté avec succès (${exportCount} lots)`
      );
      setTimeout(() => setExportSuccessMsg(null), 5000);
    } catch (err: any) {
      console.error(err);
      alert(isAr ? 'حدث خطأ أثناء تصدير الملف' : 'Erreur lors de l\'exportation');
    } finally {
      setIsExporting(false);
    }
  };

  // --- Import File Processor ---
  const handleFileProcess = async (selectedFile: File) => {
    setIsLoadingFile(true);
    setImportError(null);
    try {
      const parsed = await readExcelFile(selectedFile);
      if (parsed.sheetNames.length === 0) {
        throw new Error(isAr ? 'الملف فارغ أو غير مدعوم' : 'Le fichier est vide ou non valide');
      }

      setImportFile(selectedFile);
      setSheetNames(parsed.sheetNames);
      setSheetsRawData(parsed.sheetsData);

      const firstSheet = parsed.sheetNames[0];
      setSelectedSheet(firstSheet);

      const sheetData = parsed.sheetsData[firstSheet];
      setHeaders(sheetData.headers);

      const autoMap = autoDetectFieldMapping(sheetData.headers);
      setMapping(autoMap);

      if (autoMap.buildingCode && autoMap.apartmentNumber && autoMap.ownerName) {
        const resSummary = processImportData(
          sheetData.headers,
          sheetData.rows,
          autoMap,
          apartments,
          buildings
        );
        setImportSummary(resSummary);
        setImportStep('preview');
      } else {
        setImportStep('mapping');
      }
    } catch (err: any) {
      console.error(err);
      setImportError(err?.message || (isAr ? 'حدث خطأ أثناء معالجة الملف' : 'Erreur de traitement'));
    } finally {
      setIsLoadingFile(false);
    }
  };

  const handleApplyImport = () => {
    if (!importSummary) return;

    const validRows = importSummary.parsedData.filter(r => r.matchType !== 'invalid');
    if (validRows.length === 0) {
      setImportError(isAr ? 'لا توجد بيانات صالحة للاستيراد' : 'Aucune donnée valide à importer');
      return;
    }

    const payload = validRows.map(r => ({
      buildingCode: r.buildingCode,
      apartmentNumber: r.apartmentNumber,
      ownerName: r.ownerName,
      ownerPhone: r.ownerPhone,
      ownerCin: r.ownerCin,
      ownerEmail: r.ownerEmail,
      addressOrNotes: r.addressOrNotes,
      floor: r.floor,
      monthlyFee: r.monthlyFee,
      status: r.status,
      residentName: r.residentName,
      residentPhone: r.residentPhone,
      unpaidMonthsCount: r.unpaidMonthsCount,
      balanceDue: r.balanceDue
    }));

    const stats = importOwnersFromExcelData(payload, {
      updateApartments: true,
      syncResidents: syncResidentsOption,
      createMissingApartments: false,
      overwriteExistingPhones: true,
      updateDebts: updateDebtsOption
    });

    setImportResult(stats);
    setImportStep('success');
  };

  const resetImport = () => {
    setImportStep('upload');
    setImportFile(null);
    setImportError(null);
    setImportSummary(null);
    setImportResult(null);
    setPreviewSearch('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl border border-sky-100 max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header with Light Sea Blue Palette */}
        <div className="bg-gradient-to-r from-sky-600 via-cyan-600 to-blue-600 text-white p-5 sm:p-6 flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-xs border border-white/20">
              <FileSpreadsheet className="w-6 h-6 sm:w-7 sm:h-7 text-sky-100" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-xl font-black tracking-tight">
                  {isAr ? 'خانة مستحقات الملاك على صيغة Excel' : 'Gestion des Arriérés Propriétaires (Excel)'}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/20 text-white border border-white/30">
                  20 {isAr ? 'عمارة' : 'Bâtiments'} | 320 {isAr ? 'شقة' : 'Lots'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-sky-100 mt-1 font-medium">
                {isAr 
                  ? 'استخراج وتصدير أو استيراد وتحديث مستحقات وديون الملاك بالكامل بملف Excel' 
                  : 'Exportation et importation complète des cotisations et arriérés au format Excel'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title={isAr ? 'إغلاق' : 'Fermer'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-sky-100 bg-sky-50/50 p-2 gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('export')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'export'
                ? 'bg-white text-sky-700 shadow-sm border border-sky-200'
                : 'text-slate-600 hover:text-sky-700 hover:bg-white/60'
            }`}
          >
            <Download className="w-4 h-4 text-sky-600" />
            <span>{isAr ? '📥 تصدير واستخراج كشف المستحقات (Excel)' : '📥 Exporter les Arriérés (Excel)'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('import')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'import'
                ? 'bg-white text-sky-700 shadow-sm border border-sky-200'
                : 'text-slate-600 hover:text-sky-700 hover:bg-white/60'
            }`}
          >
            <Upload className="w-4 h-4 text-cyan-600" />
            <span>{isAr ? '📤 استيراد وتحديث المستحقات من Excel' : '📤 Importer depuis Excel'}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">

          {/* ======================= TAB 1: EXPORT DUES ======================= */}
          {activeTab === 'export' && (
            <div className="space-y-6">
              {/* Quick Info & Stats Banner */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-sky-50/80 border border-sky-200 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-xs text-sky-700 font-bold mb-1">
                    <span>{isAr ? 'الشقق المشمولة' : 'Lots Inclus'}</span>
                    <Building className="w-4 h-4 text-sky-500" />
                  </div>
                  <div className="text-2xl font-black text-sky-900 font-mono">
                    {exportCount} <span className="text-xs font-normal text-sky-600">{isAr ? 'شقة' : 'lots'}</span>
                  </div>
                  <div className="text-[11px] text-sky-600 mt-1 font-medium">
                    {onlyDebtors 
                      ? (isAr ? 'المتأخرون عن الأداء فقط' : 'Seulement débiteurs')
                      : (isAr ? `${eligibleApts.length} شقة إجمالاً` : `${eligibleApts.length} au total`)}
                  </div>
                </div>

                <div className="bg-rose-50/80 border border-rose-200 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-xs text-rose-700 font-bold mb-1">
                    <span>{isAr ? 'مجموع المستحقات والديون' : 'Total Arriérés Dus'}</span>
                    <DollarSign className="w-4 h-4 text-rose-500" />
                  </div>
                  <div className="text-2xl font-black text-rose-700 font-mono">
                    {totalDuesSum.toLocaleString()} <span className="text-xs font-normal text-rose-500">DH</span>
                  </div>
                  <div className="text-[11px] text-rose-600 mt-1 font-medium">
                    {debtorsCount} {isAr ? 'شقة مديونة حالياً' : 'lots débiteurs'}
                  </div>
                </div>

                <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4">
                  <div className="flex items-center justify-between text-xs text-emerald-700 font-bold mb-1">
                    <span>{isAr ? 'الوضعية السليمة' : 'Situation Réglée'}</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-2xl font-black text-emerald-700 font-mono">
                    {settledCount} <span className="text-xs font-normal text-emerald-500">{isAr ? 'خالص' : 'à jour'}</span>
                  </div>
                  <div className="text-[11px] text-emerald-600 mt-1 font-medium">
                    {eligibleApts.length > 0 ? Math.round((settledCount / eligibleApts.length) * 100) : 0}% {isAr ? 'نسبة الاستخلاص' : 'Taux'}
                  </div>
                </div>
              </div>

              {/* Export Configuration Controls */}
              <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-5 space-y-4">
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-2">
                  <Filter className="w-4 h-4 text-sky-600" />
                  <span>{isAr ? 'خيارات وتخصيص كشف المستحقات' : 'Filtres et Options d\'Exportation'}</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Building Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {isAr ? 'تحديد العمارات المشمولة' : 'Bâtiments Inclus'}
                    </label>
                    <select
                      value={exportBuilding}
                      onChange={(e) => setExportBuilding(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-sky-500 focus:outline-none"
                    >
                      <option value="ALL">
                        {isAr ? '🏢 جميع الـ 20 عمارة (GH 34 A إلى GH 43 B)' : '🏢 Tous les 20 Bâtiments (GH 34 A à GH 43 B)'}
                      </option>
                      <option value="GROUP_A">
                        {isAr ? '🔵 المجموعة الأولى A فقط (GH 34 A إلى GH 43 A)' : '🔵 Groupe A (GH 34 A à GH 43 A)'}
                      </option>
                      <option value="GROUP_B">
                        {isAr ? '🟢 المجموعة الثانية B فقط (GH 34 B إلى GH 43 B)' : '🟢 Groupe B (GH 34 B à GH 43 B)'}
                      </option>
                      <optgroup label={isAr ? 'العمارات الفردية (المجموعة A)' : 'Bâtiments Groupe A'}>
                        {buildings.filter(b => b.code.endsWith('A') || b.code.endsWith(' A')).map(b => (
                          <option key={b.id} value={b.code}>{b.code} - {b.name}</option>
                        ))}
                      </optgroup>
                      <optgroup label={isAr ? 'العمارات الفردية (المجموعة B)' : 'Bâtiments Groupe B'}>
                        {buildings.filter(b => b.code.endsWith('B') || b.code.endsWith(' B')).map(b => (
                          <option key={b.id} value={b.code}>{b.code} - {b.name}</option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  {/* Format Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {isAr ? 'صيغة الملف المطلوب' : 'Format du fichier'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setExportFormat('xlsx')}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          exportFormat === 'xlsx'
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <FileSpreadsheet className="w-4 h-4" />
                        <span>Excel (.xlsx)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setExportFormat('csv')}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          exportFormat === 'csv'
                            ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <FileText className="w-4 h-4" />
                        <span>CSV (UTF-8)</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Filter Checkbox: Debtors Only */}
                <div className="pt-2 border-t border-slate-200">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={onlyDebtors}
                      onChange={(e) => setOnlyDebtors(e.target.checked)}
                      className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 border-slate-300 cursor-pointer"
                    />
                    <span className="text-xs font-black text-slate-800">
                      {isAr 
                        ? 'تصدير المتأخرين فقط (استثناء الشقق الخالصة ومكتب السانديك)'
                        : 'Exporter uniquement les débiteurs (exclure les appartements à jour)'}
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-500 mr-6 mt-0.5">
                    {isAr 
                      ? 'عند تفعيل هذا الخيار، سيحتوي الملف فقط على الشقق التي بذمتها ديون ومستحقات غير مؤداة'
                      : 'Le fichier ne contiendra que les copropriétaires ayant des arriérés impayés'}
                  </p>
                </div>
              </div>

              {/* Success Message Banner */}
              {exportSuccessMsg && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{exportSuccessMsg}</span>
                </div>
              )}

              {/* What does the Excel contain? (Detailed Preview of columns) */}
              <div className="bg-sky-50/40 border border-sky-100 rounded-2xl p-4 space-y-2">
                <div className="text-xs font-bold text-sky-900 flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-sky-600" />
                  <span>{isAr ? 'محتويات كشف المستحقات المصدّر في ملف Excel:' : 'Contenu du rapport d\'arriérés Excel:'}</span>
                </div>
                <div className="flex flex-wrap gap-1.5 text-[11px]">
                  {[
                    isAr ? 'رمز العمارة' : 'Bâtiment',
                    isAr ? 'رقم الشقة' : 'N° Lot',
                    isAr ? 'اسم المالك' : 'Nom Propriétaire',
                    isAr ? 'رقم الهاتف' : 'Téléphone',
                    isAr ? 'بطاقة التعريف CIN' : 'CIN',
                    isAr ? 'الواجب الشهري (150 DH)' : 'Cotisation',
                    isAr ? 'عدد أشهر التأخير' : 'Mois d\'arriérés',
                    isAr ? 'إجمالي المستحقات (DH)' : 'Total Dû',
                    isAr ? 'الوضعية المالية (خالص/مديون)' : 'Statut',
                    isAr ? 'تفصيل الشهور المستحقة' : 'Mois impayés',
                    isAr ? 'آخر تاريخ أداء' : 'Dernier paiement',
                    isAr ? 'الملاحظات' : 'Notes'
                  ].map((col, idx) => (
                    <span key={idx} className="px-2 py-0.5 bg-white border border-sky-200 rounded-md text-sky-800 font-medium">
                      {col}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="button"
                  onClick={handleExport}
                  disabled={isExporting || exportCount === 0}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white text-xs sm:text-sm font-black shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {isAr 
                      ? `تحميل كشف المستحقات الآن (${exportCount} شقة)` 
                      : `Télécharger le fichier Excel (${exportCount} lots)`}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* ======================= TAB 2: IMPORT DUES ======================= */}
          {activeTab === 'import' && (
            <div className="space-y-6">

              {/* Step 1: Upload File */}
              {importStep === 'upload' && (
                <div className="space-y-5">
                  {/* Download Template Banner */}
                  <div className="bg-gradient-to-r from-sky-50 to-cyan-50 border border-sky-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="text-xs font-black text-sky-900 flex items-center gap-1.5">
                        <Download className="w-4 h-4 text-sky-600" />
                        <span>{isAr ? 'تحميل نموذج Excel المعتمد لمستحقات الملاك' : 'Modèle Excel certifié'}</span>
                      </div>
                      <p className="text-[11px] text-sky-700">
                        {isAr 
                          ? 'يمكنك تحميل ملف جاهز يحتوي مسبقاً على جميع شقق الإقامة الـ 320 لتعديل المستحقات والبيانات بسهولة'
                          : 'Téléchargez le modèle pré-rempli avec les 320 lots pour mise à jour facile'}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => generateOwnersExcelTemplate(apartments, buildings, isAr ? 'ar' : 'fr', true)}
                      className="px-3.5 py-2 rounded-xl bg-white border border-sky-300 text-sky-800 hover:bg-sky-100 text-xs font-bold transition-colors cursor-pointer shrink-0 shadow-2xs flex items-center justify-center gap-1.5"
                    >
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                      <span>{isAr ? 'تحميل النموذج بالبيانات الحالية' : 'Télécharger le modèle'}</span>
                    </button>
                  </div>

                  {/* Drag and Drop Zone */}
                  <div
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => {
                      e.preventDefault();
                      setIsDragging(false);
                      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                        handleFileProcess(e.dataTransfer.files[0]);
                      }
                    }}
                    className={`border-2 border-dashed rounded-3xl p-8 sm:p-10 text-center transition-all cursor-pointer ${
                      isDragging 
                        ? 'border-sky-500 bg-sky-50/80 scale-[1.01]' 
                        : 'border-slate-300 hover:border-sky-400 bg-slate-50/50 hover:bg-sky-50/30'
                    }`}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".xlsx, .xls, .csv"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          handleFileProcess(e.target.files[0]);
                        }
                      }}
                    />

                    <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-sky-100 text-sky-600 flex items-center justify-center shadow-xs">
                      {isLoadingFile ? (
                        <RefreshCw className="w-8 h-8 animate-spin text-sky-600" />
                      ) : (
                        <Upload className="w-8 h-8 text-sky-600" />
                      )}
                    </div>

                    <h4 className="text-sm sm:text-base font-black text-slate-800 mb-1">
                      {isAr ? 'اسحب ملف Excel أو اضغط لتحديد الملف' : 'Glissez le fichier Excel ici ou cliquez'}
                    </h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto mb-3">
                      {isAr 
                        ? 'يدعم ملفات .xlsx و .xls و .csv التي تحتوي على أعمدة العمارة، رقم الشقة، اسم المالك، المستحقات أو الديون'
                        : 'Prend en charge .xlsx, .xls, .csv avec colonnes bâtiment, n° appartement, propriétaire, arriérés'}
                    </p>
                    <span className="inline-block px-3 py-1 bg-white border border-slate-200 rounded-full text-[11px] font-bold text-slate-600 shadow-2xs">
                      {isAr ? 'فحص ومطابقة آلية مع الـ 20 عمارة' : 'Vérification automatique pour 20 bâtiments'}
                    </span>
                  </div>

                  {importError && (
                    <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                      <span>{importError}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Step 2: Mapping if auto-detect didn't find all required */}
              {importStep === 'mapping' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-medium flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    <span>
                      {isAr 
                        ? 'يرجى تحديد الأعمدة المطابقة للبيانات في ملف Excel للمتابعة:' 
                        : 'Veuillez faire correspondre les colonnes de votre fichier Excel:'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود رمز العمارة *' : 'Colonne Code Bâtiment *'}
                      </label>
                      <select
                        value={mapping.buildingCode}
                        onChange={(e) => setMapping({ ...mapping, buildingCode: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود رقم الشقة *' : 'Colonne N° Appartement *'}
                      </label>
                      <select
                        value={mapping.apartmentNumber}
                        onChange={(e) => setMapping({ ...mapping, apartmentNumber: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود اسم المالك *' : 'Colonne Nom Propriétaire *'}
                      </label>
                      <select
                        value={mapping.ownerName}
                        onChange={(e) => setMapping({ ...mapping, ownerName: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود المستحقات / الديون (درهم)' : 'Colonne Montant Dû (DH)'}
                      </label>
                      <select
                        value={mapping.balanceDue}
                        onChange={(e) => setMapping({ ...mapping, balanceDue: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود عدد الشهور غير المؤداة' : 'Colonne Mois d\'arriérés'}
                      </label>
                      <select
                        value={mapping.unpaidMonthsCount}
                        onChange={(e) => setMapping({ ...mapping, unpaidMonthsCount: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        {isAr ? 'عمود رقم الهاتف' : 'Colonne Téléphone'}
                      </label>
                      <select
                        value={mapping.ownerPhone}
                        onChange={(e) => setMapping({ ...mapping, ownerPhone: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white"
                      >
                        <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-between pt-4">
                    <button
                      type="button"
                      onClick={resetImport}
                      className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                    >
                      {isAr ? 'رجوع' : 'Retour'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const sheetData = sheetsRawData[selectedSheet];
                        if (sheetData) {
                          const resSummary = processImportData(
                            sheetData.headers,
                            sheetData.rows,
                            mapping,
                            apartments,
                            buildings
                          );
                          setImportSummary(resSummary);
                          setImportStep('preview');
                        }
                      }}
                      disabled={!mapping.buildingCode || !mapping.apartmentNumber || !mapping.ownerName}
                      className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold disabled:opacity-50"
                    >
                      {isAr ? 'معاينة البيانات المستوردة' : 'Aperçu des données'}
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Preview */}
              {importStep === 'preview' && importSummary && (
                <div className="space-y-4">
                  {/* Summary Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="bg-sky-50 border border-sky-200 rounded-xl p-3 text-center">
                      <span className="text-[11px] text-sky-700 font-bold block">{isAr ? 'إجمالي الأسطر' : 'Total Lignes'}</span>
                      <span className="text-xl font-black text-sky-950">{importSummary.totalRows}</span>
                    </div>

                    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-center">
                      <span className="text-[11px] text-emerald-700 font-bold block">{isAr ? 'مطابقة للشقق الحالية' : 'Lots Correspondants'}</span>
                      <span className="text-xl font-black text-emerald-700">{importSummary.matchingApartments}</span>
                    </div>

                    <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-3 text-center">
                      <span className="text-[11px] text-cyan-700 font-bold block">{isAr ? 'الأسطر الصالحة' : 'Lignes Valides'}</span>
                      <span className="text-xl font-black text-cyan-700">{importSummary.validRows}</span>
                    </div>

                    <div className="bg-rose-50 border border-rose-200 rounded-xl p-3 text-center">
                      <span className="text-[11px] text-rose-700 font-bold block">{isAr ? 'أخطاء التحقق' : 'Lignes Invalides'}</span>
                      <span className="text-xl font-black text-rose-700">{importSummary.invalidRows}</span>
                    </div>
                  </div>

                  {/* Options */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-wrap gap-4 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                      <input
                        type="checkbox"
                        checked={updateDebtsOption}
                        onChange={(e) => setUpdateDebtsOption(e.target.checked)}
                        className="rounded text-sky-600"
                      />
                      <span>{isAr ? 'تحديث مبالغ المستحقات والديون للشقق' : 'Mettre à jour les arriérés/dettes'}</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                      <input
                        type="checkbox"
                        checked={syncResidentsOption}
                        onChange={(e) => setSyncResidentsOption(e.target.checked)}
                        className="rounded text-sky-600"
                      />
                      <span>{isAr ? 'مزامنة وتحديث دليل السكان تلقائياً' : 'Synchroniser l\'annuaire des résidents'}</span>
                    </label>
                  </div>

                  {/* Preview Table */}
                  <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-72 overflow-y-auto overflow-x-auto">
                    <table className="w-full whitespace-nowrap text-right text-xs">
                      <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0">
                        <tr>
                          <th className="p-2.5">#</th>
                          <th className="p-2.5">{isAr ? 'العمارة' : 'Bâtiment'}</th>
                          <th className="p-2.5">{isAr ? 'الشقة' : 'Appt'}</th>
                          <th className="p-2.5">{isAr ? 'المالك' : 'Propriétaire'}</th>
                          <th className="p-2.5">{isAr ? 'الهاتف' : 'Tél'}</th>
                          <th className="p-2.5">{isAr ? 'أشهر التأخير' : 'Arriérés'}</th>
                          <th className="p-2.5">{isAr ? 'المستحقات (DH)' : 'Dû (DH)'}</th>
                          <th className="p-2.5">{isAr ? 'المطابقة' : 'Statut'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {importSummary.parsedData.slice(0, 50).map((row) => (
                          <tr key={row.rowNumber} className={row.matchType === 'invalid' ? 'bg-rose-50/60' : 'hover:bg-slate-50'}>
                            <td className="p-2 text-slate-500 font-mono">{row.rowNumber}</td>
                            <td className="p-2 font-bold text-slate-800">{row.buildingCode}</td>
                            <td className="p-2 font-mono font-bold text-sky-700">{row.apartmentNumber}</td>
                            <td className="p-2 text-slate-800 font-medium">{row.ownerName}</td>
                            <td className="p-2 text-slate-600 font-mono text-[11px]">{row.ownerPhone || '-'}</td>
                            <td className="p-2 font-mono text-amber-700 font-bold">{row.unpaidMonthsCount ?? 0}</td>
                            <td className="p-2 font-mono text-rose-700 font-black">{row.balanceDue ?? 0} DH</td>
                            <td className="p-2">
                              {row.matchType === 'existing' && (
                                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                                  {isAr ? 'مطابق ✅' : 'Existant'}
                                </span>
                              )}
                              {row.matchType === 'new' && (
                                <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 font-bold text-[10px]">
                                  {isAr ? 'جديد 🆕' : 'Nouveau'}
                                </span>
                              )}
                              {row.matchType === 'invalid' && (
                                <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-bold text-[10px]" title={row.validationErrors.join(', ')}>
                                  {isAr ? 'خطأ ⚠️' : 'Erreur'}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {importSummary.parsedData.length > 50 && (
                    <p className="text-[11px] text-slate-400 text-center">
                      {isAr ? `يتم عرض أول 50 سطراً من أصل ${importSummary.parsedData.length} سطر` : `Affichage des 50 premières lignes sur ${importSummary.parsedData.length}`}
                    </p>
                  )}

                  {/* Actions */}
                  <div className="flex justify-between pt-3">
                    <button
                      type="button"
                      onClick={resetImport}
                      className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      {isAr ? 'إلغاء واختيار ملف آخر' : 'Recommencer'}
                    </button>
                    <button
                      type="button"
                      onClick={handleApplyImport}
                      disabled={importSummary.validRows === 0}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-700 hover:to-sky-700 text-white text-xs sm:text-sm font-black shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{isAr ? `تأكيد استيراد وتحديث (${importSummary.validRows} شقة)` : `Confirmer l'importation (${importSummary.validRows})`}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Step 4: Success */}
              {importStep === 'success' && importResult && (
                <div className="py-8 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-md animate-in zoom-in-75">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-base sm:text-lg font-black text-slate-800">
                    {isAr ? 'تم استيراد وتحديث مستحقات وبيانات الملاك بنجاح!' : 'Importation réussie avec succès !'}
                  </h3>
                  <div className="flex justify-center gap-4 text-xs font-bold text-slate-600">
                    <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl">
                      {isAr ? `${importResult.apartmentsUpdated} شقة تم تحديثها` : `${importResult.apartmentsUpdated} appartements mis à jour`}
                    </span>
                    <span className="px-3 py-1 bg-sky-50 text-sky-800 border border-sky-200 rounded-xl">
                      {isAr ? `${importResult.residentsUpdated} ساكن تم تحديثه` : `${importResult.residentsUpdated} résidents synchronisés`}
                    </span>
                  </div>

                  <div className="pt-4 flex justify-center gap-3">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs sm:text-sm font-black shadow-md cursor-pointer"
                    >
                      {isAr ? 'تم، إغلاق النافذة' : 'Fermer'}
                    </button>
                    <button
                      type="button"
                      onClick={resetImport}
                      className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      {isAr ? 'استيراد ملف إضافي' : 'Importer un autre fichier'}
                    </button>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
