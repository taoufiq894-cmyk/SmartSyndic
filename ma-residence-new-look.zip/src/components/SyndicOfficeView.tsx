import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SyndicAIAssistant } from './SyndicAIAssistant';
import { GeneralAssemblyVoting } from './GeneralAssemblyVoting';
import { 
  Building2, Shield, MapPin, Phone, Mail, Clock, 
  FileText, Scale, Users, Bot, Sparkles, ExternalLink, 
  CheckCircle2, AlertCircle, Wrench, ShieldCheck, HeartHandshake,
  ShieldAlert, Lock, Vote, Calculator
} from 'lucide-react';

export const SyndicOfficeView: React.FC = () => {
  const { lang, currentUser, buildings, apartments, residents, setActiveSection } = useApp();
  const isAr = lang === 'ar';

  const isOwner = currentUser?.role === 'resident';
  const [activeSubTab, setActiveSubTab] = useState<'ai' | 'info' | 'voting'>(isOwner ? 'voting' : 'ai');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border-2 border-[#92e8dd] shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="icon-wiggle anim-bob w-12 h-12 rounded-2xl gradient-flow text-white flex items-center justify-center shadow-md shrink-0">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {isAr ? 'مكتب السانديك وإدارة الإقامة' : 'Bureau du Syndic & Administration'}
                </h1>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#0a8591]" />
                  {isAr ? 'GH 34 A - شقة 01' : 'GH 34 A - Appt 01'}
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 anim-bob" />
                  {isAr ? 'مزود بالذكاء الاصطناعي' : 'IA Intégrée'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                {isAr 
                  ? 'بوابة الإدارة العامة، المقر الإداري، والمساعد الذكي بالذكاء الاصطناعي (Gemini) لخدمة السانديك' 
                  : 'Siège administratif, gestion générale et assistant intelligent (Gemini) au service du syndic'}
              </p>
            </div>
          </div>

          {/* Quick Sub-Tab Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl border border-slate-200/80 self-start md:self-center overflow-x-auto max-w-full">
            <button
              type="button"
              id="tab-syndic-voting"
              onClick={() => setActiveSubTab('voting')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeSubTab === 'voting'
                  ? 'bg-[#0a8591] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              <Vote className="w-4 h-4" />
              <span>{isAr ? 'تصويت وقرارات الجمع العام 🗳️' : 'Votes & Décisions A.G 🗳️'}</span>
            </button>
            {!isOwner && (
              <>
                <button
                  type="button"
                  id="tab-syndic-ai"
                  onClick={() => setActiveSubTab('ai')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    activeSubTab === 'ai'
                      ? 'bg-[#0a8591] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                  }`}
                >
                  <Bot className="w-4 h-4" />
                  <span>{isAr ? 'المساعد الذكي (AI)' : 'Assistant IA'}</span>
                </button>
                <button
                  type="button"
                  id="tab-syndic-info"
                  onClick={() => setActiveSubTab('info')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    activeSubTab === 'info'
                      ? 'bg-[#0a8591] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  <span>{isAr ? 'بطاقة ومعلومات المكتب' : 'Infos & Siège'}</span>
                </button>
                <button
                  type="button"
                  id="tab-syndic-residents"
                  onClick={() => setActiveSection('residents')}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap text-slate-600 hover:text-slate-900 hover:bg-white/60`}
                >
                  <Users className="w-4 h-4" />
                  <span>{isAr ? 'إدارة السكان 👨‍👩‍👧‍👦' : 'Résidents'}</span>
                </button>
                <button
                  type="button"
                  id="tab-syndic-budget-simulator"
                  onClick={() => setActiveSection('budget-simulator')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap text-purple-700 bg-purple-50 hover:bg-purple-100 border border-purple-200 shadow-2xs"
                  title={isAr ? 'محاكاة الميزانية التقديرية للسنة القادمة وأثرها على واجبات السنديك' : 'Simulateur du budget'}
                >
                  <Calculator className="w-4 h-4" />
                  <span>{isAr ? 'محاكاة الميزانية القادمة 🧮' : 'Simulateur Budget'}</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Content View based on active tab */}
      {activeSubTab === 'voting' ? (
        <GeneralAssemblyVoting />
      ) : activeSubTab === 'ai' && !isOwner ? (
        <div className="space-y-6">
          {/* Notice: AI exclusively on this page */}
          <div className="bg-[#e9fbf8] border border-[#92e8dd] rounded-2xl p-4 text-xs sm:text-sm text-slate-900 flex items-start gap-3 shadow-2xs">
            <div className="w-8 h-8 rounded-xl bg-[#0a8591] text-white flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4 text-amber-200" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-[#0a8591] mb-0.5">
                {isAr ? 'الخانة الرسمية للذكاء الاصطناعي بمكتب السانديك' : 'Espace officiel d\'intelligence artificielle'}
              </h4>
              <p className="text-slate-700 leading-relaxed">
                {isAr 
                  ? 'تم تخصيص هذه الخانة حصرياً في صفحة مكتب السانديك لمساعدتكم في صياغة الإعلانات الرسمية، توجيه الإنذارات للمتأخرين وفق مقتضيات القانون 18.00، إعداد تقارير ومحاضر الجموع العامة، وتحليل ميزانية ونفقات الإقامة.' 
                  : 'Cet espace est exclusivement dédié au bureau du syndic pour assister dans la rédaction administrative, juridique et financière.'}
              </p>
            </div>
          </div>

          {/* DEDICATED AI BOX FOR SYNDIC OFFICE */}
          <SyndicAIAssistant />
        </div>
      ) : (
        /* Administrative Office Profile View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Bureau Details */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-5">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-700" />
                <span>{isAr ? 'المقر الإداري لمكتب السانديك' : 'Siège administratif du Syndic'}</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                  <div className="text-xs font-bold text-slate-500 uppercase">
                    {isAr ? 'الموقع والعنوان الدقيق' : 'Adresse exacte'}
                  </div>
                  <div className="text-sm font-bold text-slate-900">
                    {isAr ? 'عمارة GH 34 A - الطابق الأرضي - الشقة 01' : 'Immeuble GH 34 A - RDC - Appartement 01'}
                  </div>
                  <div className="text-xs text-slate-500">
                    {isAr ? 'إقامة المرجان - المجموعة السكنية A' : 'Résidence Al Morjane - Groupe A'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1">
                  <div className="text-xs font-bold text-slate-500 uppercase">
                    {isAr ? 'أوقات الاستقبال والمداومة' : 'Horaires d\'ouverture'}
                  </div>
                  <div className="text-sm font-bold text-slate-900">
                    {isAr ? 'من الإثنين إلى السبت (09:00 - 13:00 / 15:00 - 19:00)' : 'Du Lundi au Samedi (09h-13h / 15h-19h)'}
                  </div>
                  <div className="text-xs text-emerald-700 font-semibold">
                    {isAr ? 'مداومة هاتفية مفتوحة للحالات الطارئة 24/7' : 'Permanence d\'urgence 24/7'}
                  </div>
                </div>
              </div>

              {/* Tasks & Responsibilities according to law 18.00 */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                  <Scale className="w-4 h-4 text-emerald-700" />
                  <span>{isAr ? 'المهام القانونية لمكتب السانديك (القانون رقم 18.00)' : 'Missions du Syndic (Loi 18.00)'}</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-700">
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isAr ? 'تنفيذ قرارات الجمع العام ونظام الملكية المشتركة وضمان حسن الجوار.' : 'Exécution des décisions de l\'Assemblée Générale.'}</span>
                  </div>
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isAr ? 'حفظ وصيانة الأجزاء المشتركة (المصاعد، الإنارة، المضخات، النظافة، الحراسة).' : 'Maintenance et entretien des parties communes.'}</span>
                  </div>
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isAr ? 'تحصيل المساهمات والتكاليف المشتركة ومتابعة المتأخرات قانونياً.' : 'Recouvrement des cotisations et suivi des impayés.'}</span>
                  </div>
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50/60 border border-emerald-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{isAr ? 'مسك السجلات المحاسبية والمالية وإعداد التقرير المالي السنوي.' : 'Tenue de la comptabilité et bilans financiers réguliers.'}</span>
                  </div>
                </div>
              </div>

              {/* Action Button: Open Location Map */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                <span className="text-xs text-slate-500">
                  {isAr ? 'يمكنك استعراض الموقع الجغرافي الدقيق ومشاركته عبر الواتساب' : 'Visualisez la position GPS exacte'}
                </span>
                <button
                  type="button"
                  onClick={() => setActiveSection('location')}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-cyan-300" />
                  <span>{isAr ? 'فتح موقع الإقامة والمكتب (GPS)' : 'Ouvrir la Localisation'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Stats Sidebar Card */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{isAr ? 'نطاق تسيير السانديك' : 'Périmètre de gestion'}</span>
              </h4>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-600 font-medium">{isAr ? 'العمارات المدارة:' : 'Immeubles :'}</span>
                  <span className="font-bold text-slate-900">20 عمارة (GH34A - GH43B)</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-600 font-medium">{isAr ? 'الشقق السكنية:' : 'Logements :'}</span>
                  <span className="font-bold text-slate-900">319 شقة + 1 مكتب السانديك</span>
                </div>
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-slate-600 font-medium">{isAr ? 'الملاك المسجلون:' : 'Résidents :'}</span>
                  <span className="font-bold text-slate-900">{residents.length}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-900">
                  <Bot className="w-4 h-4 text-emerald-700" />
                  <span>{isAr ? 'المساعد الذكي متاح 24/7' : 'Assistant IA disponible'}</span>
                </div>
                <p className="text-emerald-800 leading-relaxed text-[11px]">
                  {isAr 
                    ? 'اضغط على تبويب «المساعد الذكي (AI)» لبدء صياغة الوثائق والاستشارات القانونية فوراً.' 
                    : 'Cliquez sur l\'onglet Assistant IA pour générer des courriers et PV instantanément.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
