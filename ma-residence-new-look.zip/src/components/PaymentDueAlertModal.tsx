import React, { useState, useEffect, useMemo } from 'react';
import { 
  Bell, 
  Send, 
  MessageSquare, 
  Mail, 
  Smartphone, 
  Settings2, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw, 
  Search, 
  Filter, 
  Building2, 
  Home, 
  CreditCard, 
  Copy, 
  Edit2, 
  Check, 
  X, 
  Sparkles, 
  ExternalLink,
  ShieldCheck,
  DollarSign,
  Users
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PaymentDueAlertConfig, PaymentDueNotificationLog, UpcomingDueResidentItem } from '../types/paymentDueAlertTypes';
import { 
  STORAGE_KEY_DUE_ALERT_CONFIG, 
  INITIAL_DUE_ALERT_CONFIG, 
  getActiveDueCycleInfo, 
  getUpcomingDueResidents, 
  populateDueTemplate, 
  buildDueWhatsAppUrl, 
  buildDueEmailUrl, 
  buildDueSmsUrl,
  DEFAULT_DUE_WHATSAPP_TEMPLATE_AR,
  DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR,
  DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR,
  DEFAULT_DUE_SMS_TEMPLATE_AR,
  DEFAULT_DUE_WHATSAPP_TEMPLATE_FR,
  DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_FR,
  DEFAULT_DUE_EMAIL_BODY_TEMPLATE_FR,
  DEFAULT_DUE_SMS_TEMPLATE_FR
} from '../utils/paymentDueAlertUtils';

interface PaymentDueAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentDueAlertModal: React.FC<PaymentDueAlertModalProps> = ({ isOpen, onClose }) => {
  const { lang, apartments, updateApartment, payments, residents, buildings } = useApp();

  // Load configuration from localStorage
  const [config, setConfig] = useState<PaymentDueAlertConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DUE_ALERT_CONFIG);
      if (saved) {
        return { ...INITIAL_DUE_ALERT_CONFIG, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return INITIAL_DUE_ALERT_CONFIG;
  });

  // Save config
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DUE_ALERT_CONFIG, JSON.stringify(config));
    } catch {
      // ignore
    }
  }, [config]);

  const [activeTab, setActiveTab] = useState<'residents' | 'preview' | 'settings' | 'history'>('residents');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBuilding, setFilterBuilding] = useState('ALL');
  const [filterChannel, setFilterChannel] = useState<'ALL' | 'HAS_PHONE' | 'HAS_EMAIL'>('ALL');
  const [selectedResidentAptId, setSelectedResidentAptId] = useState<string>('');
  const [previewChannel, setPreviewChannel] = useState<'whatsapp' | 'email' | 'sms'>('whatsapp');
  
  const [isSendingBatch, setIsSendingBatch] = useState(false);
  const [batchSuccessMsg, setBatchSuccessMsg] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Inline Contact Edit State
  const [editingAptId, setEditingAptId] = useState<string | null>(null);
  const [editPhone, setEditPhone] = useState('');
  const [editEmail, setEditEmail] = useState('');

  // Active cycle info
  const dueCycle = useMemo(() => getActiveDueCycleInfo(config), [config]);

  // List of upcoming due residents
  const upcomingResidents = useMemo(() => {
    return getUpcomingDueResidents(apartments, payments, residents, config, lang);
  }, [apartments, payments, residents, config, lang]);

  // Set default selected resident for preview
  useEffect(() => {
    if (upcomingResidents.length > 0 && !selectedResidentAptId) {
      setSelectedResidentAptId(upcomingResidents[0].apartment.id);
    }
  }, [upcomingResidents, selectedResidentAptId]);

  // Filtered residents
  const filteredResidents = useMemo(() => {
    return upcomingResidents.filter(item => {
      const cleanBld = item.apartment.buildingCode.trim().toUpperCase();
      const matchesBld = filterBuilding === 'ALL' || cleanBld === filterBuilding.trim().toUpperCase();
      
      const cleanSearch = searchTerm.trim().toLowerCase();
      const matchesSearch = !cleanSearch || 
        item.apartment.number.toLowerCase().includes(cleanSearch) ||
        item.apartment.buildingCode.toLowerCase().includes(cleanSearch) ||
        item.residentName.toLowerCase().includes(cleanSearch) ||
        item.phone.includes(cleanSearch) ||
        item.email.toLowerCase().includes(cleanSearch);

      let matchesChannel = true;
      if (filterChannel === 'HAS_PHONE') matchesChannel = Boolean(item.phone);
      if (filterChannel === 'HAS_EMAIL') matchesChannel = Boolean(item.email);

      return matchesBld && matchesSearch && matchesChannel;
    });
  }, [upcomingResidents, filterBuilding, searchTerm, filterChannel]);

  const selectedItem = useMemo(() => {
    return upcomingResidents.find(i => i.apartment.id === selectedResidentAptId) || upcomingResidents[0];
  }, [upcomingResidents, selectedResidentAptId]);

  // Save inline contact edit
  const handleSaveContact = (aptId: string) => {
    updateApartment(aptId, {
      ownerPhone: editPhone,
      ownerEmail: editEmail,
      residentPhone: editPhone,
      residentEmail: editEmail
    });
    setEditingAptId(null);
  };

  // Copy text helper
  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 3000);
  };

  // Batch trigger for alerts
  const handleTriggerBatchAlerts = (targetChannel: 'both' | 'whatsapp' | 'email' | 'sms' = config.preferredChannel) => {
    if (upcomingResidents.length === 0) return;
    setIsSendingBatch(true);

    const now = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const newLogs: PaymentDueNotificationLog[] = [];

    upcomingResidents.forEach(item => {
      const template = targetChannel === 'email' 
        ? (config.emailBodyTemplateAr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR) 
        : targetChannel === 'sms' 
        ? (config.smsTemplateAr || DEFAULT_DUE_SMS_TEMPLATE_AR) 
        : (config.whatsappTemplateAr || DEFAULT_DUE_WHATSAPP_TEMPLATE_AR);
      
      const msg = populateDueTemplate(template, item, config, lang);
      const hasPhone = Boolean(item.phone);
      const hasEmail = Boolean(item.email);

      let status: PaymentDueNotificationLog['status'] = 'sent';
      if (targetChannel === 'whatsapp' && !hasPhone) status = 'skipped_no_contact';
      if (targetChannel === 'sms' && !hasPhone) status = 'skipped_no_contact';
      if (targetChannel === 'email' && !hasEmail) status = 'skipped_no_contact';
      if (targetChannel === 'both' && !hasPhone && !hasEmail) status = 'skipped_no_contact';

      newLogs.push({
        id: `due-log-${Date.now()}-${item.apartment.id}`,
        apartmentId: item.apartment.id,
        apartmentNumber: item.apartment.number,
        buildingCode: item.apartment.buildingCode,
        residentName: item.residentName,
        phone: item.phone,
        email: item.email,
        channel: targetChannel,
        periodMonth: item.periodKey,
        periodLabel: lang === 'ar' ? item.periodLabelAr : item.periodLabelFr,
        amount: item.totalDue,
        dueDate: item.dueDateFormatted,
        daysRemaining: item.daysRemaining,
        status,
        sentAt: now,
        messagePreview: msg
      });
    });

    setTimeout(() => {
      setConfig(prev => ({
        ...prev,
        lastBatchDispatchDate: now,
        logs: [...newLogs, ...prev.logs].slice(0, 200)
      }));
      setIsSendingBatch(false);
      setBatchSuccessMsg(
        lang === 'ar'
          ? `تم إرسال وتوثيق تنبيهات اقتراب موعد السداد لـ ${upcomingResidents.length} ساكن لشهر ${dueCycle.periodLabelAr} بنجاح!`
          : `Notifications d'échéance envoyées et enregistrées pour ${upcomingResidents.length} résidents (${dueCycle.periodLabelFr}) !`
      );
      setTimeout(() => setBatchSuccessMsg(null), 6000);
    }, 800);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-950 text-white flex items-center justify-between gap-4 border-b border-emerald-800/40 shrink-0">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shadow-inner shrink-0">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-xl font-black truncate">
                  {lang === 'ar' ? 'نظام التنبيهات وإشعارات اقتراب موعد سداد السانديك' : 'Système de Notifications d\'Échéance de Syndic'}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                  {config.isEnabled ? (lang === 'ar' ? '🟢 النظام مفعّل' : '🟢 Actif') : (lang === 'ar' ? 'معطل' : 'Désactivé')}
                </span>
              </div>
              <p className="text-xs text-emerald-200/90 mt-1 truncate">
                {lang === 'ar'
                  ? `إشعار السكان عبر البريد الإلكتروني والرسائل قبل حلول موعد الاستحقاق الشهري (${dueCycle.dueDateFormattedAr})`
                  : `Notification des résidents par Email et WhatsApp à l'approche de l'échéance (${dueCycle.dueDateFormattedFr})`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm font-bold transition-all cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        {/* Success Banner */}
        {batchSuccessMsg && (
          <div className="bg-emerald-700 text-white px-5 py-3 text-xs font-bold flex items-center gap-2 justify-between animate-in slide-in-from-top shrink-0">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{batchSuccessMsg}</span>
            </div>
            <button onClick={() => setBatchSuccessMsg(null)} className="text-white/80 hover:text-white cursor-pointer">✕</button>
          </div>
        )}

        {/* Tab Navigation & Fast Dispatch */}
        <div className="flex items-center justify-between px-5 pt-3 border-b border-slate-200 bg-slate-50 text-xs font-bold gap-2 overflow-x-auto shrink-0">
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('residents')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'residents'
                  ? 'border-emerald-600 text-emerald-900 bg-white rounded-t-xl shadow-2xs font-black'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? 'السكان المعنيون بالتنبيه' : 'Résidents à Notifier'}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-mono">
                {upcomingResidents.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('preview')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'preview'
                  ? 'border-emerald-600 text-emerald-900 bg-white rounded-t-xl shadow-2xs font-black'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-4 h-4 text-teal-600" />
              <span>{lang === 'ar' ? 'معاينة الرسائل والإيميلات' : 'Aperçu des Messages'}</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'settings'
                  ? 'border-emerald-600 text-emerald-900 bg-white rounded-t-xl shadow-2xs font-black'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Settings2 className="w-4 h-4 text-slate-600" />
              <span>{lang === 'ar' ? 'إعدادات موعد السداد والقوالب' : 'Paramètres & Modèles'}</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`px-3.5 py-2.5 border-b-2 transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'history'
                  ? 'border-emerald-600 text-emerald-900 bg-white rounded-t-xl shadow-2xs font-black'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ar' ? 'سجل التنبيهات' : 'Historique'}</span>
              <span className="px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-mono">
                {config.logs.length}
              </span>
            </button>
          </div>

          {/* Quick Dispatch Batch Trigger */}
          <div className="flex items-center gap-2 pb-1.5 shrink-0">
            <button
              type="button"
              disabled={isSendingBatch || upcomingResidents.length === 0}
              onClick={() => handleTriggerBatchAlerts('both')}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white text-xs font-black flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title={lang === 'ar' ? 'إرسال تنبيهات اقتراب السداد لجميع السكان عبر الواتساب والإيميل' : 'Notifier tous les résidents'}
            >
              {isSendingBatch ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{lang === 'ar' ? 'جاري الإرسال...' : 'Envoi...'}</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? '⚡ إشعار جميع المعنيين الآن' : 'Notifier Tout'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* ================= TAB 1: RESIDENTS TO NOTIFY ================= */}
          {activeTab === 'residents' && (
            <div className="space-y-4">
              
              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-2xs">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-emerald-800">{lang === 'ar' ? 'موعد الاستحقاق الشهري القادم:' : 'Prochaine échéance :'}</div>
                    <div className="text-sm font-black text-emerald-950 font-mono">{dueCycle.dueDateFormattedAr}</div>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center shrink-0 shadow-2xs">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-blue-800">{lang === 'ar' ? 'عدد الشقق غير المؤدية للشهر:' : 'Lots à notifier :'}</div>
                    <div className="text-sm font-black text-blue-950 font-mono">
                      {upcomingResidents.length} {lang === 'ar' ? 'شقة' : 'lots'}
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                    <DollarSign className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-amber-800">{lang === 'ar' ? 'إجمالي المبالغ المنتظرة:' : 'Montant total attendu :'}</div>
                    <div className="text-sm font-black text-amber-950 font-mono">
                      {upcomingResidents.reduce((s, i) => s + i.totalDue, 0).toLocaleString()} DH
                    </div>
                  </div>
                </div>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 bg-slate-50 p-2.5 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 flex-1 flex-wrap">
                  {/* Search */}
                  <div className="relative flex-1 min-w-[160px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder={lang === 'ar' ? 'بحث برقم الشقة أو الاسم أو الهاتف...' : 'Recherche...'}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full ps-8 pe-3 py-1.5 text-xs bg-white border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-600 focus:outline-hidden"
                    />
                  </div>

                  {/* Building Filter */}
                  <select
                    value={filterBuilding}
                    onChange={(e) => setFilterBuilding(e.target.value)}
                    className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-200 rounded-xl text-slate-700"
                  >
                    <option value="ALL">{lang === 'ar' ? 'جميع العمارات (10 عمارات)' : 'Tous les immeubles'}</option>
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </select>

                  {/* Channel Filter */}
                  <select
                    value={filterChannel}
                    onChange={(e) => setFilterChannel(e.target.value as any)}
                    className="px-3 py-1.5 text-xs font-bold bg-white border border-slate-200 rounded-xl text-slate-700"
                  >
                    <option value="ALL">{lang === 'ar' ? 'كل وسائل الاتصال' : 'Tous les canaux'}</option>
                    <option value="HAS_PHONE">{lang === 'ar' ? 'يتوفر على هاتف / واتساب 💬' : 'Avec téléphone'}</option>
                    <option value="HAS_EMAIL">{lang === 'ar' ? 'يتوفر على بريد إلكتروني ✉️' : 'Avec email'}</option>
                  </select>
                </div>

                {/* Bulk Email Trigger */}
                {upcomingResidents.filter(i => i.email).length > 0 && (
                  <a
                    href={`mailto:${upcomingResidents.filter(i => i.email).map(i => i.email).join(',')}?subject=${encodeURIComponent(`تذكير ودي بموعد سداد مستحقات السانديك - شهر ${dueCycle.periodLabelAr}`)}&body=${encodeURIComponent(`السادة السكان الأفاضل، نذكركم بحلول موعد سداد واجبات السانديك لشهر ${dueCycle.periodLabelAr} قبل تاريخ ${dueCycle.dueDateFormattedAr}. للحساب البنكي: ${config.bankRib}`)}`}
                    className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-2xs cursor-pointer shrink-0"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'بريد جماعي لكافة العناوين ✉️' : 'Email groupé'}</span>
                  </a>
                )}
              </div>

              {/* Residents List */}
              {filteredResidents.length === 0 ? (
                <div className="py-12 px-4 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
                  <div className="text-sm font-bold text-slate-800">
                    {lang === 'ar' ? 'لا توجد شقق مستحقة للتنبيه حالياً' : 'Aucun résident à notifier.'}
                  </div>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    {lang === 'ar'
                      ? 'جميع الشقق مسواة لشهر ' + dueCycle.periodLabelAr + ' أو لا توجد نتائج مطابقة لخيارات البحث.'
                      : 'Tous les appartements sont à jour pour la période.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-2xs">
                    {filteredResidents.map((item) => {
                      const isSelected = selectedResidentAptId === item.apartment.id;
                      const whatsappUrl = buildDueWhatsAppUrl(item, config, lang);
                      const emailUrl = buildDueEmailUrl(item, config, lang);
                      const smsUrl = buildDueSmsUrl(item, config, lang);
                      const isEditingThis = editingAptId === item.apartment.id;

                      const formattedWhatsAppText = populateDueTemplate(
                        lang === 'ar' ? (config.whatsappTemplateAr || DEFAULT_DUE_WHATSAPP_TEMPLATE_AR) : (config.whatsappTemplateFr || DEFAULT_DUE_WHATSAPP_TEMPLATE_FR),
                        item,
                        config,
                        lang
                      );

                      return (
                        <div
                          key={item.apartment.id}
                          onClick={() => setSelectedResidentAptId(item.apartment.id)}
                          className={`p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors cursor-pointer ${
                            isSelected ? 'bg-emerald-50/60 border-s-4 border-emerald-600' : 'hover:bg-slate-50/80'
                          }`}
                        >
                          {/* Left: Apt info & Contact */}
                          <div className="flex items-start gap-3">
                            <span className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-950 font-mono font-black flex items-center justify-center text-sm border border-emerald-300 shrink-0 shadow-2xs">
                              {item.apartment.number}
                            </span>

                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-black text-slate-900 text-sm">
                                  {item.apartment.buildingCode} - شقة {item.apartment.number}
                                </span>
                                <span className="px-2 py-0.5 rounded-full bg-emerald-700 text-white font-mono font-bold text-[10px]">
                                  {item.dueDateFormatted}
                                </span>
                                <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                                  {item.daysRemaining > 0 ? (lang === 'ar' ? `متبقي ${item.daysRemaining} أيام` : `Reste ${item.daysRemaining}j`) : (lang === 'ar' ? 'الأجل اليوم!' : 'Aujourd\'hui')}
                                </span>
                              </div>

                              <div className="text-xs font-bold text-slate-800">
                                {item.residentName}
                              </div>

                              {/* Contact Info or Inline Edit */}
                              {isEditingThis ? (
                                <div className="flex items-center gap-2 flex-wrap pt-1.5" onClick={(e) => e.stopPropagation()}>
                                  <input
                                    type="tel"
                                    placeholder="الهاتف: 06XXXXXXXX"
                                    value={editPhone}
                                    onChange={(e) => setEditPhone(e.target.value)}
                                    className="px-2.5 py-1 text-xs border border-emerald-400 rounded-lg bg-white font-mono"
                                  />
                                  <input
                                    type="email"
                                    placeholder="البريد: user@example.com"
                                    value={editEmail}
                                    onChange={(e) => setEditEmail(e.target.value)}
                                    className="px-2.5 py-1 text-xs border border-blue-400 rounded-lg bg-white font-mono"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleSaveContact(item.apartment.id)}
                                    className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>حفظ</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingAptId(null)}
                                    className="px-2 py-1 bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                                  >
                                    إلغاء
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-3 text-[11px] text-slate-500 flex-wrap">
                                  <span className="flex items-center gap-1 font-mono">
                                    <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                                    {item.phone ? (
                                      <span className="text-slate-800 font-bold">{item.phone}</span>
                                    ) : (
                                      <span className="text-rose-500 italic">{lang === 'ar' ? 'بدون هاتف' : 'Sans tél'}</span>
                                    )}
                                  </span>

                                  <span>•</span>

                                  <span className="flex items-center gap-1 font-mono">
                                    <Mail className="w-3.5 h-3.5 text-blue-600" />
                                    {item.email ? (
                                      <span className="text-slate-800 font-bold">{item.email}</span>
                                    ) : (
                                      <span className="text-slate-400 italic">{lang === 'ar' ? 'بدون بريد' : 'Sans email'}</span>
                                    )}
                                  </span>

                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEditingAptId(item.apartment.id);
                                      setEditPhone(item.phone || '');
                                      setEditEmail(item.email || '');
                                    }}
                                    className="text-[10px] text-slate-600 hover:text-emerald-700 font-bold flex items-center gap-0.5 underline cursor-pointer"
                                  >
                                    <Edit2 className="w-3 h-3" />
                                    <span>{lang === 'ar' ? 'تعديل الاتصال' : 'Modifier'}</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right: Amount & 1-Click Notification Actions */}
                          <div className="flex items-center justify-between md:justify-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                            <div className="text-start md:text-end">
                              <div className="text-sm font-black font-mono text-emerald-900">
                                {item.totalDue.toLocaleString()} DH
                              </div>
                              <div className="text-[10px] text-slate-500">
                                {item.periodLabelAr}
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5">
                              {/* WhatsApp Direct Send */}
                              <a
                                href={whatsappUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1 transition-all shadow-2xs cursor-pointer"
                                title={lang === 'ar' ? 'إرسال تنبيه عبر واتساب' : 'Envoyer WhatsApp'}
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                                <span>{lang === 'ar' ? 'واتساب' : 'WhatsApp'}</span>
                              </a>

                              {/* Email Direct Send */}
                              <a
                                href={emailUrl}
                                onClick={(e) => e.stopPropagation()}
                                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all shadow-2xs cursor-pointer ${
                                  item.email 
                                    ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                                    : 'bg-slate-100 hover:bg-blue-50 text-blue-700 border border-blue-200'
                                }`}
                                title={lang === 'ar' ? 'إرسال إشعار رسمي بالبريد الإلكتروني' : 'Envoyer par Email'}
                              >
                                <Mail className="w-3.5 h-3.5" />
                                <span>{lang === 'ar' ? 'إيميل' : 'Email'}</span>
                              </a>

                              {/* SMS Direct Send */}
                              {item.phone && (
                                <a
                                  href={smsUrl}
                                  onClick={(e) => e.stopPropagation()}
                                  className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                                  title={lang === 'ar' ? 'إرسال رسالة قصيرة SMS' : 'SMS'}
                                >
                                  <Smartphone className="w-3.5 h-3.5 text-slate-700" />
                                </a>
                              )}

                              {/* Copy Text */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCopyText(formattedWhatsAppText, item.apartment.id);
                                }}
                                className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
                                title={lang === 'ar' ? 'نسخ نص الرسالة' : 'Copier texte'}
                              >
                                {copiedId === item.apartment.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* ================= TAB 2: LIVE MESSAGE PREVIEWS ================= */}
          {activeTab === 'preview' && (
            <div className="space-y-4">
              
              {/* Resident Selector & Channel Switcher */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="space-y-0.5">
                  <label className="text-xs font-bold text-slate-800 block">
                    {lang === 'ar' ? 'اختر الشقة للمعاينة الحية:' : 'Sélectionnez un résident :'}
                  </label>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'ar' ? 'يتم تعويض الاسم والمبلغ ورقم الشقة والحساب البنكي تلقائياً.' : 'Les variables sont remplacées dynamiquement.'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedResidentAptId}
                    onChange={(e) => setSelectedResidentAptId(e.target.value)}
                    className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-600"
                  >
                    {upcomingResidents.map(i => (
                      <option key={i.apartment.id} value={i.apartment.id}>
                        {i.apartment.buildingCode} - شقة {i.apartment.number} ({i.residentName})
                      </option>
                    ))}
                  </select>

                  <div className="flex items-center p-1 bg-slate-200 rounded-xl gap-1">
                    <button
                      type="button"
                      onClick={() => setPreviewChannel('whatsapp')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                        previewChannel === 'whatsapp' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreviewChannel('email')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                        previewChannel === 'email' ? 'bg-blue-700 text-white shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <Mail className="w-3 h-3" />
                      <span>Email</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreviewChannel('sms')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer ${
                        previewChannel === 'sms' ? 'bg-slate-800 text-white shadow-2xs' : 'text-slate-700'
                      }`}
                    >
                      <Smartphone className="w-3 h-3" />
                      <span>SMS</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Preview Content */}
              {selectedItem ? (
                <div className="space-y-3">
                  
                  {/* WhatsApp Bubble Preview */}
                  {previewChannel === 'whatsapp' && (
                    <div className="bg-slate-100 p-4 sm:p-6 rounded-3xl border border-slate-200 flex justify-center">
                      <div className="w-full max-w-lg bg-[#dcf8c6] text-slate-900 p-4 sm:p-5 rounded-2xl rounded-tr-xs shadow-md border border-emerald-200/60 text-xs sm:text-sm font-sans whitespace-pre-wrap leading-relaxed">
                        {populateDueTemplate(
                          lang === 'ar' ? (config.whatsappTemplateAr || DEFAULT_DUE_WHATSAPP_TEMPLATE_AR) : (config.whatsappTemplateFr || DEFAULT_DUE_WHATSAPP_TEMPLATE_FR),
                          selectedItem,
                          config,
                          lang
                        )}
                      </div>
                    </div>
                  )}

                  {/* Email Preview */}
                  {previewChannel === 'email' && (
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden text-xs">
                      <div className="bg-slate-50 p-3.5 border-b border-slate-200 space-y-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-500 w-16">{lang === 'ar' ? 'إلى (To):' : 'À :'}</span>
                          <span className="font-bold font-mono text-slate-900">
                            {selectedItem.email || (lang === 'ar' ? '(البريد الإلكتروني للساكن غير مسجل بعد)' : '(Email non renseigné)')}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-500 w-16">{lang === 'ar' ? 'الموضوع:' : 'Objet :'}</span>
                          <span className="font-black text-blue-900">
                            {populateDueTemplate(
                              lang === 'ar' ? (config.emailSubjectTemplateAr || DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR) : (config.emailSubjectTemplateFr || DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_FR),
                              selectedItem,
                              config,
                              lang
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="p-5 whitespace-pre-wrap font-sans text-slate-800 leading-relaxed bg-slate-50/30">
                        {populateDueTemplate(
                          lang === 'ar' ? (config.emailBodyTemplateAr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR) : (config.emailBodyTemplateFr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_FR),
                          selectedItem,
                          config,
                          lang
                        )}
                      </div>
                    </div>
                  )}

                  {/* SMS Preview */}
                  {previewChannel === 'sms' && (
                    <div className="bg-slate-100 p-4 sm:p-6 rounded-3xl border border-slate-200 flex justify-center">
                      <div className="w-full max-w-md bg-white text-slate-900 p-4 rounded-2xl shadow-md border border-slate-300 text-xs font-mono whitespace-pre-wrap leading-relaxed">
                        <div className="text-[10px] text-slate-400 font-bold mb-1">SMS Message (160 Chars)</div>
                        {populateDueTemplate(
                          lang === 'ar' ? (config.smsTemplateAr || DEFAULT_DUE_SMS_TEMPLATE_AR) : (config.smsTemplateFr || DEFAULT_DUE_SMS_TEMPLATE_FR),
                          selectedItem,
                          config,
                          lang
                        )}
                      </div>
                    </div>
                  )}

                  {/* Preview Actions */}
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        const template = previewChannel === 'email' 
                          ? (config.emailBodyTemplateAr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR) 
                          : previewChannel === 'sms' 
                          ? (config.smsTemplateAr || DEFAULT_DUE_SMS_TEMPLATE_AR) 
                          : (config.whatsappTemplateAr || DEFAULT_DUE_WHATSAPP_TEMPLATE_AR);
                        handleCopyText(populateDueTemplate(template, selectedItem, config, lang), 'preview-copy');
                      }}
                      className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{copiedId === 'preview-copy' ? (lang === 'ar' ? 'تم النسخ بنجاح! ✓' : 'Copié !') : (lang === 'ar' ? 'نسخ النص' : 'Copier')}</span>
                    </button>

                    {previewChannel === 'whatsapp' && (
                      <a
                        href={buildDueWhatsAppUrl(selectedItem, config, lang)}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? `إرسال للساكن (${selectedItem.residentName})` : 'Envoyer'}</span>
                      </a>
                    )}

                    {previewChannel === 'email' && (
                      <a
                        href={buildDueEmailUrl(selectedItem, config, lang)}
                        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'فتح تطبيق البريد والإرسال' : 'Ouvrir Email'}</span>
                      </a>
                    )}
                  </div>

                </div>
              ) : null}

            </div>
          )}

          {/* ================= TAB 3: SETTINGS & TEMPLATES ================= */}
          {activeTab === 'settings' && (
            <div className="space-y-5">
              
              {/* Toggle Switch */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex items-center justify-between gap-4">
                <div className="space-y-0.5">
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Bell className="w-4 h-4 text-emerald-600" />
                    <span>{lang === 'ar' ? 'تفعيل نظام التنبيهات الدورية باقتراب موعد السداد' : 'Activer les rappels d\'échéance'}</span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {lang === 'ar'
                      ? 'يقوم النظام بجدولة وتجهيز التنبيهات وإشعار السكان عبر البريد الإلكتروني والرسائل قبل حلول موعد الاستحقاق الشهري.'
                      : 'Préparation et envoi automatique des notifications avant la date limite mensuelle.'}
                  </p>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.isEnabled}
                    onChange={(e) => setConfig(prev => ({ ...prev, isEnabled: e.target.checked }))}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>

              {/* Due Date and Notification Window Parameters */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-emerald-700" />
                    <span>{lang === 'ar' ? 'يوم الاستحقاق الشهري لسداد السانديك:' : 'Jour d\'échéance mensuelle :'}</span>
                  </label>
                  <select
                    value={config.dueDayOfMonth}
                    onChange={(e) => setConfig(prev => ({ ...prev, dueDayOfMonth: Number(e.target.value) }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value={1}>{lang === 'ar' ? 'اليوم 1 من كل شهر' : 'Le 1er du mois'}</option>
                    <option value={5}>{lang === 'ar' ? 'اليوم 5 من كل شهر' : 'Le 5 du mois'}</option>
                    <option value={10}>{lang === 'ar' ? 'اليوم 10 من كل شهر (الافتراضي 📅)' : 'Le 10 du mois (Par défaut)'}</option>
                    <option value={15}>{lang === 'ar' ? 'اليوم 15 من كل شهر' : 'Le 15 du mois'}</option>
                    <option value={20}>{lang === 'ar' ? 'اليوم 20 من كل شهر' : 'Le 20 du mois'}</option>
                  </select>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span>{lang === 'ar' ? 'توقيت التنبيه المسبق:' : 'Délai d\'alerte :'}</span>
                  </label>
                  <select
                    value={config.remindDaysBefore[0] || 7}
                    onChange={(e) => setConfig(prev => ({ ...prev, remindDaysBefore: [Number(e.target.value), 3, 0] }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value={3}>{lang === 'ar' ? 'قبل 3 أيام من الأجل' : '3 jours avant'}</option>
                    <option value={5}>{lang === 'ar' ? 'قبل 5 أيام من الأجل' : '5 jours avant'}</option>
                    <option value={7}>{lang === 'ar' ? 'قبل 7 أيام من الأجل (أسبوع مسبقاً 🔔)' : '7 jours avant (Recommandé)'}</option>
                    <option value={10}>{lang === 'ar' ? 'قبل 10 أيام من الأجل' : '10 jours avant'}</option>
                  </select>
                </div>

                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Send className="w-4 h-4 text-teal-600" />
                    <span>{lang === 'ar' ? 'القنوات المعتمدة للإشعار:' : 'Canaux d\'envoi :'}</span>
                  </label>
                  <select
                    value={config.preferredChannel}
                    onChange={(e) => setConfig(prev => ({ ...prev, preferredChannel: e.target.value as any }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value="both">{lang === 'ar' ? 'واتساب + البريد الإلكتروني معاً 🚀' : 'WhatsApp & Email'}</option>
                    <option value="whatsapp">{lang === 'ar' ? 'واتساب فقط (WhatsApp)' : 'WhatsApp uniquement'}</option>
                    <option value="email">{lang === 'ar' ? 'البريد الإلكتروني فقط (Email)' : 'Email uniquement'}</option>
                    <option value="sms">{lang === 'ar' ? 'الرسائل القصيرة (SMS)' : 'SMS uniquement'}</option>
                  </select>
                </div>

              </div>

              {/* Bank & Contact Details */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
                <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-700" />
                  <span>{lang === 'ar' ? 'بيانات الحساب البنكي والاتصال للسانديك (تظهر تلقائياً في التنبيهات):' : 'Coordonnées bancaires & Contact du Syndic :'}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'اسم البنك:' : 'Banque :'}</span>
                    <input
                      type="text"
                      value={config.bankName}
                      onChange={(e) => setConfig(prev => ({ ...prev, bankName: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-medium"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'اسم الحساب:' : 'Titulaire :'}</span>
                    <input
                      type="text"
                      value={config.bankAccountName}
                      onChange={(e) => setConfig(prev => ({ ...prev, bankAccountName: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-medium"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'رقم الحساب (RIB):' : 'RIB :'}</span>
                    <input
                      type="text"
                      value={config.bankRib}
                      onChange={(e) => setConfig(prev => ({ ...prev, bankRib: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-mono font-bold"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'هاتف التواصل بالسانديك:' : 'Tél Syndic :'}</span>
                    <input
                      type="text"
                      value={config.contactPhone}
                      onChange={(e) => setConfig(prev => ({ ...prev, contactPhone: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-mono"
                    />
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'البريد الإلكتروني للسانديك:' : 'Email Syndic :'}</span>
                    <input
                      type="text"
                      value={config.contactEmail}
                      onChange={(e) => setConfig(prev => ({ ...prev, contactEmail: e.target.value }))}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Template Editor - WhatsApp */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-700" />
                    <span>{lang === 'ar' ? 'قالب رسالة الواتساب (WhatsApp):' : 'Modèle WhatsApp :'}</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setConfig(prev => ({ ...prev, whatsappTemplateAr: DEFAULT_DUE_WHATSAPP_TEMPLATE_AR }))}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? 'استعادة القالب الافتراضي' : 'Rétablir défaut'}
                  </button>
                </div>

                <textarea
                  rows={6}
                  value={config.whatsappTemplateAr}
                  onChange={(e) => setConfig(prev => ({ ...prev, whatsappTemplateAr: e.target.value }))}
                  className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-emerald-600 leading-relaxed text-slate-800"
                />
              </div>

              {/* Template Editor - Email */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-blue-700" />
                    <span>{lang === 'ar' ? 'قالب البريد الإلكتروني (Email):' : 'Modèle Email :'}</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setConfig(prev => ({ 
                      ...prev, 
                      emailSubjectTemplateAr: DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR,
                      emailBodyTemplateAr: DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR 
                    }))}
                    className="text-[10px] text-blue-700 hover:text-blue-900 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? 'استعادة القالب الافتراضي' : 'Rétablir défaut'}
                  </button>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'موضوع البريد الإلكتروني (Subject):' : 'Objet :'}</span>
                  <input
                    type="text"
                    value={config.emailSubjectTemplateAr}
                    onChange={(e) => setConfig(prev => ({ ...prev, emailSubjectTemplateAr: e.target.value }))}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-600 text-slate-800"
                  />
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-600 block mb-1">{lang === 'ar' ? 'نص رسالة البريد (Email Body):' : 'Corps du message :'}</span>
                  <textarea
                    rows={7}
                    value={config.emailBodyTemplateAr}
                    onChange={(e) => setConfig(prev => ({ ...prev, emailBodyTemplateAr: e.target.value }))}
                    className="w-full p-3 text-xs font-mono rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-600 leading-relaxed text-slate-800"
                  />
                </div>

                <div className="text-[11px] text-slate-500 space-y-1">
                  <div className="font-bold text-slate-700">{lang === 'ar' ? 'المتغيرات الذكية المتاحة في القوالب:' : 'Variables disponibles :'}</div>
                  <div className="flex items-center gap-1.5 flex-wrap font-mono text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{RESIDENT_NAME}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{BUILDING_CODE}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{APARTMENT_NUM}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{PERIOD_LABEL}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{DUE_DATE}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{DAYS_LEFT_LABEL}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{AMOUNT_MAD}"}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">{"{BANK_RIB}"}</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ================= TAB 4: NOTIFICATION HISTORY ================= */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                <span>{lang === 'ar' ? `سجل التنبيهات المرسلة (${config.logs.length}):` : `Historique des alertes (${config.logs.length}) :`}</span>
                {config.logs.length > 0 && (
                  <button
                    onClick={() => setConfig(prev => ({ ...prev, logs: [] }))}
                    className="text-[10px] text-rose-600 hover:text-rose-800 cursor-pointer font-bold"
                  >
                    {lang === 'ar' ? 'مسح السجل' : 'Effacer l\'historique'}
                  </button>
                )}
              </div>

              {config.logs.length === 0 ? (
                <div className="py-12 px-4 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-1">
                  <Clock className="w-8 h-8 text-slate-400 mx-auto" />
                  <div className="text-xs font-bold text-slate-700">{lang === 'ar' ? 'لا يوجد أي تنبيه مسجل حالياً' : 'Aucun historique'}</div>
                  <p className="text-[11px] text-slate-500">{lang === 'ar' ? 'سيتم توثيق كافة التنبيهات والإشعارات المرسلة هنا.' : 'Les notifications envoyées apparaîtront ici.'}</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-2xs">
                  {config.logs.map((log) => (
                    <div key={log.id} className="p-3 sm:p-4 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{log.buildingCode} - شقة {log.apartmentNumber}</span>
                          <span className="text-slate-500">({log.residentName})</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>{log.sentAt}</span>
                          <span>•</span>
                          <span className="font-bold text-emerald-800">{log.periodLabel} ({log.amount.toLocaleString()} DH)</span>
                          <span>•</span>
                          <span className="font-mono">{log.channel === 'both' ? 'واتساب + بريد' : log.channel === 'whatsapp' ? 'واتساب' : log.channel === 'email' ? 'بريد' : 'SMS'}</span>
                        </div>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        log.status === 'sent' 
                          ? 'bg-emerald-100 text-emerald-800' 
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {log.status === 'sent' ? (lang === 'ar' ? 'تم التنبيه بنجاح 🟢' : 'Envoyé 🟢') : (lang === 'ar' ? 'بدون بيانات اتصال ⚠️' : 'Non envoyé')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs shrink-0">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{lang === 'ar' ? 'نظام التنبيهات وإشعارات الأداء - سانديك إقامة المرجان' : 'Système d\'Échéance Syndic'}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs cursor-pointer shadow-2xs"
          >
            {lang === 'ar' ? 'إغلاق' : 'Fermer'}
          </button>
        </div>

      </div>
    </div>
  );
};
