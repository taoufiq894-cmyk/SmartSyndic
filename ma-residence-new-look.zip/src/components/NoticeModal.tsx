import React from 'react';
import { useApp } from '../context/AppContext';
import { Printer, X, Megaphone, Users, Building2 } from 'lucide-react';

export const NoticeModal: React.FC = () => {
  const { selectedNotice, setSelectedNotice } = useApp();

  if (!selectedNotice) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 print:shadow-none print:border-none print:w-full print:max-w-none">
        
        {/* Controls */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between no-print modal-controls print:hidden">
          <div className="flex items-center gap-2 font-bold text-sm">
            <Megaphone className="w-4 h-4 text-amber-400" />
            <span>معاينة الإعلان الرسمي للتعليق / Avis d'Affichage</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة الإعلان (Print)</span>
            </button>

            <button
              onClick={() => setSelectedNotice(null)}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Notice Sheet */}
        <div className="p-8 sm:p-12 bg-white print:p-6 text-slate-900" id="syndic-notice-paper">
          
          {/* Header */}
          <div className="border-b-4 border-double border-emerald-800 pb-4 mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-black text-xl">
                MA
              </div>
              <div>
                <h2 className="text-xl font-black text-emerald-950">إقامة المرجان</h2>
                <div className="text-xs font-bold text-slate-600">SYNDICAT DES COPROPRIÉTAIRES</div>
              </div>
            </div>

            <div className="text-end text-xs text-slate-500 font-mono">
              <div>تاريخ النشر: {selectedNotice.publishDate}</div>
              <div>المرجع: AVIS-{selectedNotice.id.slice(-4).toUpperCase()}</div>
            </div>
          </div>

          {/* Banner */}
          <div className="text-center my-6 py-4 bg-emerald-50 border-y-2 border-emerald-800">
            <h1 className="text-2xl font-black text-emerald-950 tracking-wide mb-1">
              {selectedNotice.title}
            </h1>
            <div className="text-xs font-bold text-emerald-800 uppercase">
              AVIS OFFICIEL AUX RÉSIDENTS ET COPROPRIÉTAIRES
            </div>
          </div>

          {/* Target audience badge */}
          <div className="mb-6 flex justify-center">
            <span className="px-4 py-1 rounded-full bg-slate-100 border border-slate-300 text-xs font-bold text-slate-800">
              المعنيون: {
                selectedNotice.targetAudience === 'owners' ? 'السادة الملاك المشتركون' :
                selectedNotice.targetAudience === 'tenants' ? 'السادة المكترون والقاطنون' :
                selectedNotice.targetAudience === 'specific_building' ? `سكان عمارة ${selectedNotice.buildingCode}` : 'كافة سكان وملاك الإقامة'
              }
            </span>
          </div>

          {/* Body Content */}
          <div className="text-sm leading-loose text-slate-800 font-medium whitespace-pre-line p-6 bg-slate-50/50 rounded-2xl border border-slate-200 mb-8 min-h-[160px]">
            {selectedNotice.content}
          </div>

          {/* Closing & Signature */}
          <div className="flex justify-between items-end pt-4 border-t border-slate-200 text-xs">
            <div className="text-slate-500 text-[11px]">
              حرر بمراكش في: {selectedNotice.publishDate}
            </div>

            <div className="text-center">
              <div className="font-bold text-emerald-950 text-sm mb-1">وكيل اتحاد الملاك (السانديك)</div>
              <div className="text-slate-600 font-medium">{selectedNotice.author}</div>
              <div className="mt-4 border-b border-dashed border-slate-400 w-36 mx-auto"></div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
