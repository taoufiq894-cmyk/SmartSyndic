import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Home, ShieldCheck, ArrowLeft, ArrowRight, MapPin } from 'lucide-react';

interface ResidenceImageGalleryProps {
  isAr?: boolean;
  onSelectPortal: (portal: 'owner' | 'syndic') => void;
}

export const ResidenceImageGallery: React.FC<ResidenceImageGalleryProps> = ({ isAr = true, onSelectPortal }) => {
  const images = [
    {
      id: 1,
      src: '/morjane_facade.jpg',
      alt: 'Résidence Al Morjane - Façade principale et architecture marocaine moderne',
      locationAr: 'أبواب مراكش • المنطقة 10 • الواجهة الرئيسية والمعمار الأصيل',
      locationFr: 'Abwab Marrakech • Zone 10 • Façade Principale & Architecture'
    },
    {
      id: 2,
      src: '/morjane_bougainvillea.jpg',
      alt: 'Résidence Al Morjane - Jardins, allées et bougainvillier fleuri',
      locationAr: 'أبواب مراكش • المنطقة 10 • الحدائق والمسارات الخضراء المزهرة',
      locationFr: 'Abwab Marrakech • Zone 10 • Jardins & Allées Fleuries'
    },
    {
      id: 3,
      src: '/morjane_main_avenue.jpg',
      alt: 'Résidence Al Morjane - Façades ocre et avenue principale',
      locationAr: 'أبواب مراكش • المنطقة 10 • الشارع الرئيسي وفضاء الإقامة',
      locationFr: 'Abwab Marrakech • Zone 10 • Avenue Principale & Espaces'
    },
    {
      id: 4,
      src: '/morjane_night_gate.jpg',
      alt: 'Résidence Al Morjane - Entrée principale et poste de garde de nuit',
      locationAr: 'أبواب مراكش • المنطقة 10 • المدخل الرئيسي والحراسة المستمرة',
      locationFr: 'Abwab Marrakech • Zone 10 • Entrée Sécurisée 24/7'
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  // Smooth automatic transition between real photos every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [images.length]);

  return (
    <div className="w-full">
      {/* REAL ANIMATED IMAGES WITH DYNAMIC LOCATION CHIP & STRETCH DOTS */}
      <div className="relative w-full rounded-3xl overflow-hidden bg-slate-950 shadow-2xl border-2 border-[#ff8240]/30 group">
        
        {/* Dynamic Image Container */}
        <div className="relative aspect-[16/9] sm:aspect-[21/9] md:aspect-[24/9] min-h-[320px] sm:min-h-[400px] md:min-h-[460px] w-full flex flex-col justify-between p-3.5 sm:p-6 overflow-hidden">
          
          {/* Animated Background Slides with Ken Burns gentle zoom */}
          {images.map((img, idx) => {
            const isActive = idx === currentIndex;
            return (
              <div
                key={img.id}
                className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                  isActive ? 'opacity-100 z-0' : 'opacity-0 -z-10 pointer-events-none'
                }`}
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  referrerPolicy="no-referrer"
                  className={`w-full h-full object-cover select-none ${
                    isActive ? (idx % 2 === 0 ? 'animate-kenburns' : 'animate-kenburns-alt') : ''
                  }`}
                />
              </div>
            );
          })}

          {/* Dual Soft Vignette Gradients */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/40 pointer-events-none z-10" />

          {/* TOP BAR: FLOATING DYNAMIC LOCATION CHIP (EXACTLY LIKE 00:00 - 00:04 IN THE VIDEO) */}
          <div className="relative z-20 flex items-center justify-between w-full">
            <motion.div 
              key={currentIndex}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4 }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/55 backdrop-blur-md text-white text-[11px] sm:text-xs font-bold border border-white/20 shadow-lg"
            >
              <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span className="truncate max-w-[220px] sm:max-w-none">
                {isAr ? images[currentIndex].locationAr : images[currentIndex].locationFr}
              </span>
            </motion.div>

            {/* STRETCHED ANIMATED PAGINATION PILL DOTS (MATCHING VIDEO 00:01) */}
            <div className="flex items-center gap-1.5 bg-black/55 backdrop-blur-md px-2.5 py-1.5 rounded-full border border-white/20">
              {images.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setCurrentIndex(i)}
                  className="relative p-0.5 cursor-pointer focus:outline-none"
                  aria-label={`Slide ${i + 1}`}
                >
                  <div className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === currentIndex 
                      ? 'w-6 bg-white shadow-xs' 
                      : 'w-1.5 bg-white/40 hover:bg-white/70'
                  }`} />
                </button>
              ))}
            </div>
          </div>

          {/* BOTTOM CONTROLS: INTERACTIVE PORTAL CARDS OVER PHOTO */}
          <div className="relative z-20 w-full max-w-lg mx-auto mt-auto pt-6">
            <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5">
              
              {/* Portal 1: Co-owners Portal (بوابة الملاك) */}
              <motion.button
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.96 }}
                type="button"
                id="portal-btn-owner"
                onClick={() => onSelectPortal('owner')}
                className="group/portal px-3.5 py-2.5 sm:py-3 rounded-2xl bg-white/95 hover:bg-white backdrop-blur-xl border border-slate-200 text-slate-900 shadow-xl transition-all cursor-pointer flex items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 group-hover/portal:bg-[#9a3412] text-slate-800 group-hover/portal:text-white flex items-center justify-center shrink-0 transition-colors shadow-2xs">
                    <Home className="w-4 h-4" />
                  </div>
                  <div className="text-start leading-tight min-w-0">
                    <span className="text-xs sm:text-sm font-black text-slate-900 truncate block">
                      {isAr ? 'بوابة الملاك' : 'Copropriétaires'}
                    </span>
                    <span className="text-[10px] text-slate-500 font-semibold truncate block">
                      {isAr ? 'كشف الشقة والوصولات' : 'Accès résident'}
                    </span>
                  </div>
                </div>
                <div className="text-slate-400 group-hover/portal:text-[#9a3412] shrink-0">
                  {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </div>
              </motion.button>

              {/* Portal 2: Syndic Portal (بوابة السنديك) */}
              <motion.button
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.96 }}
                type="button"
                id="portal-btn-syndic"
                onClick={() => onSelectPortal('syndic')}
                className="group/portal px-3.5 py-2.5 sm:py-3 rounded-2xl bg-[#9a3412] hover:bg-[#852d0f] backdrop-blur-xl border border-[#9a3412] text-white shadow-xl shadow-[#9a3412]/30 transition-all cursor-pointer flex items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-white/20 group-hover/portal:bg-white/30 text-white flex items-center justify-center shrink-0 transition-colors shadow-inner">
                    <ShieldCheck className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-start leading-tight min-w-0">
                    <span className="text-xs sm:text-sm font-black text-white truncate block">
                      {isAr ? 'بوابة السنديك' : 'Portail Syndic'}
                    </span>
                    <span className="text-[10px] text-amber-200 font-semibold truncate block">
                      {isAr ? 'لوحة القيادة والتسيير' : 'Console de gestion'}
                    </span>
                  </div>
                </div>
                <div className="text-white/80 group-hover/portal:text-white shrink-0">
                  {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </div>
              </motion.button>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

