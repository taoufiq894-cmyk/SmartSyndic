import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, UserRole } from '../types';
import { Shield, Plus, Search, Trash2, Edit2, Check, X, Key, UserCheck, Lock } from 'lucide-react';
import { UserCog as HeaderIcon } from 'lucide-react';

export const UsersView: React.FC = () => {
  const { t, lang, users, currentUser, addUser, updateUser, deleteUser } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('syndic_admin');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');

  const handleOpenNew = () => {
    setEditingId(null);
    setName('');
    setUsername('');
    setPassword('');
    setRole('syndic_admin');
    setPhone('');
    setEmail('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (u: User) => {
    setEditingId(u.id);
    setName(u.name);
    setUsername(u.username);
    setPassword(u.password);
    setRole(u.role);
    setPhone(u.phone || '');
    setEmail(u.email || '');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !username.trim() || !password.trim()) return;

    if (editingId) {
      updateUser(editingId, {
        name,
        username,
        password,
        role,
        phone,
        email,
      });
    } else {
      addUser({
        name,
        username,
        password,
        role,
        phone,
        email,
      });
    }
    setIsFormOpen(false);
  };

  const getRoleBadge = (r: UserRole) => {
    switch (r) {
      case 'super_admin':
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">{t.users.roleSuperAdmin}</span>;
      case 'syndic_admin':
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd]">{t.users.roleSyndicAdmin}</span>;
      case 'supervisor':
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-cyan-100 text-cyan-800">{t.users.roleSupervisor}</span>;
      case 'guard':
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800">{t.users.roleGuard}</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800">{t.users.roleAccountant}</span>;
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.phone && u.phone.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border-2 border-[#92e8dd] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-violet-400 to-violet-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.users.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">{t.users.subtitle}</p>
        </div>

        <button
          onClick={handleOpenNew}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t.users.addBtn}</span>
        </button>
      </div>

      {/* Form Modal / Box */}
      {isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-[#0a8591] shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-[#0a8591] flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#0a8591]" />
              <span>{editingId ? t.common.edit : t.users.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.users.name} *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder={lang === 'ar' ? 'الاسم الكامل' : 'Nom complet'}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.users.username} *</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="admin_gh34"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.users.password} *</label>
                <input
                  type="text"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.users.role} *</label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white"
                >
                  <option value="super_admin">{t.users.roleSuperAdmin}</option>
                  <option value="syndic_admin">{t.users.roleSyndicAdmin}</option>
                  <option value="supervisor">{t.users.roleSupervisor}</option>
                  <option value="guard">{t.users.roleGuard}</option>
                  <option value="accountant">{t.users.roleAccountant}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">الهاتف</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+212 600-000000"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="user@residence.ma"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="relative w-full max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="البحث عن مستخدم..."
              className="w-full ps-9 pe-3 py-1.5 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0a8591]"
            />
          </div>

          <div className="text-xs text-slate-500 font-medium">
            المجموع: <span className="font-bold text-slate-900">{filteredUsers.length}</span> مستخدم
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap text-xs text-start border-collapse">
            <thead>
              <tr className="bg-[#0a8591] text-white font-bold">
                <th className="p-3.5 text-start">{t.users.name}</th>
                <th className="p-3.5 text-start">{t.users.username}</th>
                <th className="p-3.5 text-start">{t.users.role}</th>
                <th className="p-3.5 text-start">كلمة المرور</th>
                <th className="p-3.5 text-start">الهاتف</th>
                <th className="p-3.5 text-start">آخر تسجيل دخول</th>
                <th className="p-3.5 text-center">{t.users.actions}</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3 font-bold text-slate-900 flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#e9fbf8] text-[#0a8591] flex items-center justify-center font-bold text-xs border border-[#92e8dd]">
                      {u.name.charAt(0)}
                    </div>
                    <span>{u.name}</span>
                    {u.id === currentUser?.id && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#e9fbf8] text-[#0a8591] font-normal border border-[#92e8dd]">
                        (أنت)
                      </span>
                    )}
                  </td>
                  <td className="p-3 font-mono text-slate-700">
                    {u.username}
                  </td>
                  <td className="p-3">
                    {getRoleBadge(u.role)}
                  </td>
                  <td className="p-3 font-mono text-slate-500">
                    <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {u.password}
                    </span>
                  </td>
                  <td className="p-3 text-slate-600 font-mono">
                    {u.phone || '-'}
                  </td>
                  <td className="p-3 text-slate-500 font-mono text-[11px]">
                    {u.lastLogin || '-'}
                  </td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(u)}
                        className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-emerald-700"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      {u.id !== currentUser?.id && (
                        <button
                          onClick={() => {
                            if (confirm(t.users.deleteConfirm)) deleteUser(u.id);
                          }}
                          className="p-1 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
