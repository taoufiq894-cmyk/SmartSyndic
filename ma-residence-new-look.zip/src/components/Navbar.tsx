import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Building2, Menu, ShieldCheck, MapPin, 
  Landmark, Wallet, Sparkles, ChevronDown, 
  HandCoins, ReceiptText, LayoutDashboard, Wrench, KeyRound
} from 'lucide-react';

interface NavbarProps {
  onToggleMobileSidebar: () => void;
  isMobileSidebarOpen?: boolean;
  onOpenLocation?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onToggleMobileSidebar,
  isMobileSidebarOpen = false,
  onOpenLocation
}) => {
  const { lang, setLanguage, currentUser, activeSection, setActiveSection, totalBalance } = useApp();
  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  const handleLocationClick = () => {
    if (onOpenLocation) {
      onOpenLocation();
    } else {
      setActiveSection('location');
    }
  };

  const navLinks = isOwner ? [
    { id: 'dashboard', label: isAr ? 'الرئيسية' : 'Accueil', icon: LayoutDashboard },
    { id: 'apartments', label: isAr ? 'شقتي' : 'Mon Appt', icon: KeyRound },
    { id: 'payments', label: isAr ? 'وصلاتي' : 'Reçus', icon: HandCoins },
    { id: 'expenses', label: isAr ? 'المصاريف' : 'Dépenses', icon: ReceiptText },
    { id: 'two-years-report', label: isAr ? 'حصيلة سنتين' : 'Bilan 2 Ans', icon: Landmark, featured: true },
  ] : [
    { id: 'dashboard', label: isAr ? 'الرئيسية' : 'Accueil', icon: LayoutDashboard },
    { id: 'payments', label: isAr ? 'المداخيل والوصولات' : 'Recettes', icon: HandCoins },
    { id: 'expenses', label: isAr ? 'المصاريف' : 'Dépenses', icon: ReceiptText },
    { id: 'apartments', label: isAr ? 'الشقق والملاك' : 'Copropriétaires', icon: Building2 },
    { id: 'two-years-report', label: isAr ? 'حصيلة 2025-2026' : 'Bilan 2 Ans', icon: Landmark, featured: true },
    { id: 'operations', label: isAr ? 'الخدمات' : 'Services', icon: Wrench },
  ];

  return (
    <header className="bg-white/95 backdrop-blur-xl text-slate-900 sticky top-0 z-40 border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Brand & Mobile Hamburger */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              id="btn-toggle-sidebar"
              onClick={onToggleMobileSidebar}
              className={`
                lg:hidden flex items-center justify-center w-9 h-9 rounded-xl transition-all cursor-pointer shrink-0 border
                ${isMobileSidebarOpen 
                  ? 'bg-emerald-900 text-white border-emerald-950 shadow-xs' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                }
              `}
              aria-label={isMobileSidebarOpen ? 'إغلاق القائمة' : 'فتح القائمة'}
            >
              <Menu className={`w-5 h-5 ${isMobileSidebarOpen ? 'rotate-90' : ''} transition-transform duration-200`} />
            </button>

            {/* Residence Crest / Identity */}
            <div 
              onClick={() => setActiveSection('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer group min-w-0 select-none"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl gradient-flow text-white flex items-center justify-center font-black text-sm sm:text-base shadow-md shadow-emerald-500/30 shrink-0 group-hover:rotate-6 transition-transform">
                <Building2 className="w-5 h-5 anim-bob" />
              </div>
              <div className="min-w-0">
                <div className="font-extrabold text-sm sm:text-base tracking-tight leading-none text-slate-950 flex items-center gap-1.5">
                  <span className="truncate">إقامة المرجان</span>
                  <span className="hidden md:inline-block text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-50 text-amber-900 border border-amber-200/80 shrink-0">
                    أبواب مراكش 10
                  </span>
                </div>
                <div className="text-[10px] sm:text-[11px] text-slate-500 font-medium mt-0.5 truncate">
                  {isAr ? 'نظام التسيير والحصيلة المالية للملكية المشتركة' : 'Gestion & Bilan de Copropriété'}
                </div>
              </div>
            </div>
          </div>

          {/* Center: Desktop Quick Journey Bar */}
          <nav className="hidden xl:flex items-center gap-1 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/70">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeSection === link.id || 
                (link.id === 'operations' && ['operations', 'maintenance', 'notices', 'employees', 'archive'].includes(activeSection));

              if (link.featured) {
                return (
                  <button
                    key={link.id}
                    onClick={() => setActiveSection(link.id)}
                    className={`
                      flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer
                      ${isActive 
                        ? 'bg-amber-500 text-slate-950 shadow-xs border border-amber-400' 
                        : 'bg-amber-100/70 hover:bg-amber-200/80 text-amber-950 border border-amber-300/60'
                      }
                    `}
                  >
                    <Icon className="icon-wiggle w-4 h-4 text-slate-950" />
                    <span>{link.label}</span>
                  </button>
                );
              }

              return (
                <button
                  key={link.id}
                  onClick={() => setActiveSection(link.id)}
                  className={`
                    flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer
                    ${isActive 
                      ? 'bg-white text-emerald-900 shadow-xs border border-slate-200/80' 
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                    }
                  `}
                >
                  <Icon className={`icon-wiggle w-4 h-4 ${isActive ? 'text-emerald-700' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Widgets */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Live Treasury Balance Chip */}
            <div 
              onClick={() => setActiveSection('two-years-report')}
              title={isAr ? 'اضغط لعرض التقرير المالي لسنتي 2025 و 2026' : 'Voir le bilan financier'}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-950 text-xs font-bold transition-all cursor-pointer shadow-2xs"
            >
              <Wallet className="w-3.5 h-3.5 text-emerald-700 shrink-0 anim-bob" />
              <div className="text-start leading-tight">
                <span className="text-[10px] text-emerald-700 block font-normal">
                  {isAr ? 'الرصيد الصافي' : 'Solde Net'}
                </span>
                <span className="font-black font-mono">
                  {totalBalance.toLocaleString()} <span className="text-[10px]">DH</span>
                </span>
              </div>
            </div>

            {/* Quick Two-Years Report Button (Visible on medium screens) */}
            <button
              id="btn-navbar-two-years-report"
              type="button"
              onClick={() => setActiveSection('two-years-report')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black transition-all shadow-xs cursor-pointer border border-amber-300 xl:hidden"
              title={isAr ? 'صفحة التقرير المالي الشامل لسنتي 2025 و 2026' : 'Rapport Financier 2025-2026'}
            >
              <Landmark className="w-3.5 h-3.5 text-slate-950" />
              <span className="hidden sm:inline text-xs">
                {isAr ? 'حصيلة 2025-2026' : 'Bilan 2 Ans'}
              </span>
            </button>

            {/* Language Switcher */}
            <button
              type="button"
              onClick={() => setLanguage(lang === 'ar' ? 'fr' : 'ar')}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200/80 cursor-pointer transition-colors"
              title={isAr ? 'Passer en Français' : 'التحويل للعربية'}
            >
              {lang === 'ar' ? 'FR' : 'عربي'}
            </button>

            {/* Location / GPS Shortcut */}
            <button
              type="button"
              onClick={handleLocationClick}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200/80 cursor-pointer transition-colors"
              title={isAr ? 'موقع الإقامة - أبواب مراكش' : 'Localisation Marrakech'}
            >
              <MapPin className="w-4 h-4 text-emerald-800" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
