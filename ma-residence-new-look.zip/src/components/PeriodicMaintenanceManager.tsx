import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PeriodicMaintenance, PeriodicFrequency, MaintenanceCategory, MaintenanceAlert } from '../types';
import { 
  Plus, Search, Filter, Calendar, Clock, Wrench, 
  ShieldAlert, Droplets, Sparkles, Lightbulb, CheckCircle2, 
  PlayCircle, MessageSquare, Phone, Edit3, Trash2, 
  History, ArrowRight, X, AlertTriangle, ChevronRight, Check
} from 'lucide-react';

interface PeriodicMaintenanceManagerProps {
  onStartOperation: (schedule: PeriodicMaintenance) => void;
  onOpenCompleteModal: (schedule: PeriodicMaintenance) => void;
}

export const PeriodicMaintenanceManager: React.FC<PeriodicMaintenanceManagerProps> = ({
  onStartOperation,
  onOpenCompleteModal
}) => {
  const { 
    t, lang, currentUser, buildings, 
    periodicMaintenances, addPeriodicMaintenance, 
    updatePeriodicMaintenance, deletePeriodicMaintenance,
    maintenanceAlerts
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBuilding, setFilterBuilding] = useState('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterFrequency, setFilterFrequency] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'alerts_only' | 'active_only'>('ALL');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PeriodicMaintenance | null>(null);
  const [historyItem, setHistoryItem] = useState<PeriodicMaintenance | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    buildingCode: string;
    apartmentOrArea: string;
    category: MaintenanceCategory;
    frequency: PeriodicFrequency;
    customIntervalDays: number;
    lastCompletedDate: string;
    nextDueDate: string;
    remindDaysBefore: number;
    providerOrTechnician: string;
    providerPhone: string;
    estimatedCost: number;
    isActive: boolean;
    notes: string;
  }>({
    title: '',
    buildingCode: 'ALL',
    apartmentOrArea: 'جميع المرافق',
    category: 'lighting',
    frequency: 'monthly',
    customIntervalDays: 30,
    lastCompletedDate: new Date().toISOString().slice(0, 10),
    nextDueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    remindDaysBefore: 7,
    providerOrTechnician: '',
    providerPhone: '',
    estimatedCost: 0,
    isActive: true,
    notes: ''
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleOpenAdd = () => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const nextDate = new Date();
    nextDate.setDate(nextDate.getDate() + 30);
    const nextDueStr = nextDate.toISOString().slice(0, 10);

    setEditingItem(null);
    setFormData({
      title: '',
      buildingCode: 'ALL',
      apartmentOrArea: lang === 'ar' ? 'المرافق المشتركة' : 'Espaces communs',
      category: 'lighting',
      frequency: 'monthly',
      customIntervalDays: 30,
      lastCompletedDate: todayStr,
      nextDueDate: nextDueStr,
      remindDaysBefore: 7,
      providerOrTechnician: '',
      providerPhone: '',
      estimatedCost: 0,
      isActive: true,
      notes: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: PeriodicMaintenance) => {
    setEditingItem(item);
    setFormData({
      title: item.title,
      buildingCode: item.buildingCode,
      apartmentOrArea: item.apartmentOrArea,
      category: item.category,
      frequency: item.frequency,
      customIntervalDays: item.customIntervalDays || 30,
      lastCompletedDate: item.lastCompletedDate,
      nextDueDate: item.nextDueDate,
      remindDaysBefore: item.remindDaysBefore || 7,
      providerOrTechnician: item.providerOrTechnician,
      providerPhone: item.providerPhone || '',
      estimatedCost: item.estimatedCost || 0,
      isActive: item.isActive,
      notes: item.notes || ''
    });
    setIsModalOpen(true);
  };

  const handleFrequencyChange = (freq: PeriodicFrequency) => {
    const base = new Date(formData.lastCompletedDate || new Date());
    const next = new Date(base);

    switch (freq) {
      case 'weekly': next.setDate(next.getDate() + 7); break;
      case 'monthly': next.setMonth(next.getMonth() + 1); break;
      case 'quarterly': next.setMonth(next.getMonth() + 3); break;
      case 'biannual': next.setMonth(next.getMonth() + 6); break;
      case 'annual': next.setFullYear(next.getFullYear() + 1); break;
      case 'custom': next.setDate(next.getDate() + (formData.customIntervalDays || 30)); break;
    }

    setFormData({
      ...formData,
      frequency: freq,
      nextDueDate: next.toISOString().slice(0, 10)
    });
  };

  const handlePresetSelect = (presetType: string) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const presets: Record<string, Partial<typeof formData>> = {
      lighting: {
        title: lang === 'ar' ? 'فحص وصيانة اللوحات والإنارة المشتركة' : 'Contrat maintenance éclairage & tableaux',
        category: 'lighting',
        frequency: 'monthly',
        remindDaysBefore: 7,
        providerOrTechnician: 'Société Électro-Technique',
        estimatedCost: 800,
        apartmentOrArea: lang === 'ar' ? 'اللوحات الكهربائية وممرات العمارات' : 'Tableaux et couloirs',
        notes: lang === 'ar' ? 'فحص دوري شهري للإنارة وقواطع الحماية ومؤقتات الدرج' : 'Contrôle mensuel éclairage et disjoncteurs'
      },
      pumps: {
        title: lang === 'ar' ? 'صيانة مضخات المياه والخزانات' : 'Entretien des surpresseurs et bâches d\'eau',
        category: 'plumbing',
        frequency: 'quarterly',
        remindDaysBefore: 7,
        providerOrTechnician: 'Société Hydro-Technique',
        estimatedCost: 800,
        apartmentOrArea: lang === 'ar' ? 'قبو المضخات والخزان الأرضي' : 'Sous-sol et bâche à eau',
        notes: lang === 'ar' ? 'فحص ضغط المضخات والصمامات وعوامات الخزان' : 'Contrôle pression pompes et flotteurs'
      },
      fire: {
        title: lang === 'ar' ? 'فحص وإعادة تعبئة طفايات الحريق' : 'Contrôle et recharge des extincteurs',
        category: 'security',
        frequency: 'annual',
        remindDaysBefore: 15,
        providerOrTechnician: 'Maroc Protection Incendie',
        estimatedCost: 1500,
        apartmentOrArea: lang === 'ar' ? 'جميع الممرات والسلالم والمواقف' : 'Couloirs, cages d\'escalier et parking',
        notes: lang === 'ar' ? 'فحص الصلاحية وشهادة الفحص السنوية' : 'Inspection annuelle et certification'
      },
      cleaning_tanks: {
        title: lang === 'ar' ? 'تنظيف وتعقيم خزان الماء الصالح للشرب' : 'Nettoyage et désinfection de la bâche à eau',
        category: 'cleaning',
        frequency: 'biannual',
        remindDaysBefore: 10,
        providerOrTechnician: 'Société Bio-Désinfection',
        estimatedCost: 600,
        apartmentOrArea: lang === 'ar' ? 'الخزان المائي الرئيسي' : 'Bâche principale',
        notes: lang === 'ar' ? 'تفريغ وتطهير الخزان بمواد معقمة معتمدة' : 'Vidange, brossage et désinfection certifiée'
      },
      intercom: {
        title: lang === 'ar' ? 'صيانة كاميرات المراقبة والإنترفون' : 'Maintenance vidéophonie et caméras de surveillance',
        category: 'security',
        frequency: 'quarterly',
        remindDaysBefore: 5,
        providerOrTechnician: 'Sécurité & Domotique SARL',
        estimatedCost: 450,
        apartmentOrArea: lang === 'ar' ? 'المداخل والمحيط الخارجي' : 'Portails et accès',
        notes: lang === 'ar' ? 'فحص جودة التسجيل وتغذية الكاميرات' : 'Test enregistreur NVR et caméras'
      }
    };

    if (presets[presetType]) {
      const p = presets[presetType];
      const base = new Date(todayStr);
      const next = new Date(base);
      if (p.frequency === 'monthly') next.setMonth(next.getMonth() + 1);
      else if (p.frequency === 'quarterly') next.setMonth(next.getMonth() + 3);
      else if (p.frequency === 'biannual') next.setMonth(next.getMonth() + 6);
      else if (p.frequency === 'annual') next.setFullYear(next.getFullYear() + 1);

      setFormData(prev => ({
        ...prev,
        ...p,
        lastCompletedDate: todayStr,
        nextDueDate: next.toISOString().slice(0, 10)
      }));
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast(lang === 'ar' ? 'يرجى إدخال عنوان الصيانة' : 'Veuillez saisir un titre');
      return;
    }

    if (editingItem) {
      updatePeriodicMaintenance(editingItem.id, {
        title: formData.title.trim(),
        buildingCode: formData.buildingCode,
        apartmentOrArea: formData.apartmentOrArea.trim(),
        category: formData.category,
        frequency: formData.frequency,
        customIntervalDays: Number(formData.customIntervalDays),
        lastCompletedDate: formData.lastCompletedDate,
        nextDueDate: formData.nextDueDate,
        remindDaysBefore: Number(formData.remindDaysBefore),
        providerOrTechnician: formData.providerOrTechnician.trim(),
        providerPhone: formData.providerPhone.trim(),
        estimatedCost: Number(formData.estimatedCost) || 0,
        isActive: formData.isActive,
        notes: formData.notes.trim()
      });
      showToast(lang === 'ar' ? 'تم تحديث برنامج الصيانة بنجاح' : 'Programme mis à jour avec succès');
    } else {
      addPeriodicMaintenance({
        title: formData.title.trim(),
        buildingCode: formData.buildingCode,
        apartmentOrArea: formData.apartmentOrArea.trim() || (lang === 'ar' ? 'المرافق المشتركة' : 'Espaces communs'),
        category: formData.category,
        frequency: formData.frequency,
        customIntervalDays: Number(formData.customIntervalDays),
        lastCompletedDate: formData.lastCompletedDate,
        nextDueDate: formData.nextDueDate,
        remindDaysBefore: Number(formData.remindDaysBefore),
        providerOrTechnician: formData.providerOrTechnician.trim() || (lang === 'ar' ? 'شركة الصيانة المعتمدة' : 'Prestataire'),
        providerPhone: formData.providerPhone.trim(),
        estimatedCost: Number(formData.estimatedCost) || 0,
        isActive: formData.isActive,
        notes: formData.notes.trim()
      });
      showToast(t.maintenance.periodicAddedSuccess);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا العقد والبرنامج الدوري؟' : 'Êtes-vous sûr de supprimer ce programme ?')) {
      deletePeriodicMaintenance(id);
      showToast(lang === 'ar' ? 'تم حذف برنامج الصيانة' : 'Programme supprimé');
    }
  };

  const handleWhatsApp = (item: PeriodicMaintenance) => {
    const phoneClean = item.providerPhone ? item.providerPhone.replace(/[^0-9]/g, '') : '';
    const textAr = `السلام عليكم،\n\nتذكير بموعد الصيانة الدورية:\n📌 الموضوع: ${item.title}\n🏢 الموقع: ${item.buildingCode} (${item.apartmentOrArea})\n📅 موعد الاستحقاق: ${item.nextDueDate}\n\nنرجو تأكيد موعد التدخل مع السانديك. شكراً.`;
    const textFr = `Bonjour,\n\nRappel d'échéance de maintenance périodique :\n📌 Objet : ${item.title}\n🏢 Emplacement : ${item.buildingCode} (${item.apartmentOrArea})\n📅 Date : ${item.nextDueDate}\n\nMerci de confirmer votre intervention. Cordialement.`;
    
    const message = lang === 'ar' ? textAr : textFr;
    const url = phoneClean 
      ? `https://wa.me/${phoneClean}?text=${encodeURIComponent(message)}`
      : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Helper for alert status calculation
  const getItemAlert = (item: PeriodicMaintenance): MaintenanceAlert | undefined => {
    return maintenanceAlerts.find(a => a.scheduleId === item.id);
  };

  // Filter items
  const filteredItems = periodicMaintenances.filter(pm => {
    const matchesSearch = searchTerm === '' || 
      pm.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pm.providerOrTechnician.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pm.apartmentOrArea.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesBuilding = filterBuilding === 'ALL' || pm.buildingCode === filterBuilding || pm.buildingCode === 'ALL';
    const matchesCategory = filterCategory === 'ALL' || pm.category === filterCategory;
    const matchesFrequency = filterFrequency === 'ALL' || pm.frequency === filterFrequency;

    const alert = getItemAlert(pm);
    const matchesStatus = 
      filterStatus === 'ALL' ? true :
      filterStatus === 'alerts_only' ? (alert !== undefined) :
      filterStatus === 'active_only' ? pm.isActive : true;

    return matchesSearch && matchesBuilding && matchesCategory && matchesFrequency && matchesStatus;
  });

  const getCategoryIcon = (cat: MaintenanceCategory) => {
    switch (cat) {
      case 'lighting': return <Lightbulb className="w-4 h-4 text-amber-500" />;
      case 'plumbing': return <Droplets className="w-4 h-4 text-blue-600" />;
      case 'security': return <ShieldAlert className="w-4 h-4 text-red-600" />;
      case 'cleaning': return <Sparkles className="w-4 h-4 text-emerald-600" />;
      default: return <Wrench className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-900 text-white text-xs font-semibold shadow-xl animate-in fade-in duration-200">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Control Bar: Search, Filters, Add Button */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-600" />
              <span>{t.maintenance.periodicTab}</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {lang === 'ar' 
                ? 'إدارة عقود الصيانة الدورية وتتبع مواعيد الفحوصات والتدخلات الوقائية' 
                : 'Gestion des contrats de maintenance préventive et suivi des échéances'}
            </p>
          </div>

          {!isOwner && (
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-xs self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.maintenance.addNewPeriodic}</span>
            </button>
          )}
        </div>

        {/* Search & Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-3 border-t border-slate-100">
          {/* Search Box */}
          <div className="relative sm:col-span-2 lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={lang === 'ar' ? 'بحث باسم العقد، الفني، أو المكان...' : 'Rechercher un contrat, technicien...'}
              className="w-full h-9 pl-9 pr-9 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
            />
          </div>

          {/* Building Filter */}
          <div>
            <select
              value={filterBuilding}
              onChange={(e) => setFilterBuilding(e.target.value)}
              className="w-full h-9 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden text-slate-700"
            >
              <option value="ALL">{t.maintenance.allBuildings}</option>
              <option value="ALL">{lang === 'ar' ? 'كامل الإقامة (ALL)' : 'Toute la résidence'}</option>
              {buildings.map(b => (
                <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full h-9 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden text-slate-700"
            >
              <option value="ALL">{t.maintenance.allCategories}</option>
              <option value="lighting">{t.maintenance.categories.lighting}</option>
              <option value="plumbing">{t.maintenance.categories.plumbing}</option>
              <option value="security">{t.maintenance.categories.security}</option>
              <option value="cleaning">{t.maintenance.categories.cleaning}</option>
              <option value="other">{t.maintenance.categories.other}</option>
            </select>
          </div>

          {/* Status / Alert Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'ALL' | 'alerts_only' | 'active_only')}
              className="w-full h-9 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden text-slate-700"
            >
              <option value="ALL">{lang === 'ar' ? 'جميع الحالات' : 'Tous les états'}</option>
              <option value="alerts_only">{lang === 'ar' ? '🚨 التنبيهات المستحقة فقط' : '🚨 Alertes uniquement'}</option>
              <option value="active_only">{lang === 'ar' ? 'البرامج النشطة فقط' : 'Actifs uniquement'}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Periodic Schedules */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3">
          <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
          <p className="text-sm font-semibold text-slate-700">
            {lang === 'ar' ? 'لم يتم العثور على برامج صيانة مطابقة للبحث' : 'Aucun programme de maintenance trouvé'}
          </p>
          {!isOwner && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 text-white text-xs font-bold hover:bg-amber-500 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.maintenance.addNewPeriodic}</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map(item => {
            const alert = getItemAlert(item);
            const isOverdue = alert?.type === 'overdue';
            const isToday = alert?.type === 'today';
            const isImminent = alert?.type === 'imminent';

            const cardBorder = isOverdue
              ? 'border-rose-300 ring-1 ring-rose-300 bg-linear-to-b from-white to-rose-50/20'
              : isToday
              ? 'border-amber-400 ring-1 ring-amber-400 bg-linear-to-b from-white to-amber-50/20'
              : isImminent
              ? 'border-orange-300 bg-white'
              : 'border-slate-200 bg-white';

            return (
              <div 
                key={item.id}
                className={`rounded-2xl border ${cardBorder} p-4 sm:p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4`}
              >
                {/* Header of card */}
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                      {getCategoryIcon(item.category)}
                      <span>{t.maintenance.categories[item.category] || item.category}</span>
                    </span>

                    {/* Alert badge if any */}
                    {alert ? (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                        isOverdue 
                          ? 'bg-rose-100 text-rose-800 border border-rose-200' 
                          : isToday 
                          ? 'bg-amber-500 text-white' 
                          : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}>
                        {isOverdue && <AlertTriangle className="w-3 h-3 text-rose-600" />}
                        {isToday && <Clock className="w-3 h-3 text-white" />}
                        <span>
                          {isOverdue 
                            ? (lang === 'ar' ? `متأخر بـ ${Math.abs(alert.daysRemaining)} يوم` : `Retard de ${Math.abs(alert.daysRemaining)} j`)
                            : isToday
                            ? t.maintenance.dueToday
                            : (lang === 'ar' ? `متبقي ${alert.daysRemaining} أيام` : `Dans ${alert.daysRemaining} j`)}
                        </span>
                      </span>
                    ) : (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {item.isActive ? (lang === 'ar' ? 'ساري' : 'Actif') : (lang === 'ar' ? 'معطل' : 'Inactif')}
                      </span>
                    )}
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {item.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                    <span className="font-semibold text-slate-700">
                      {item.buildingCode === 'ALL' ? (lang === 'ar' ? 'جميع العمارات' : 'Toute la résidence') : item.buildingCode}
                    </span>
                    <span>•</span>
                    <span>{item.apartmentOrArea}</span>
                  </div>
                </div>

                {/* Key metadata box */}
                <div className="p-3 rounded-xl bg-slate-50/80 border border-slate-100 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{t.maintenance.frequency}:</span>
                    <span className="font-semibold text-slate-800">
                      {t.maintenance.frequencies[item.frequency] || item.frequency}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{t.maintenance.nextDueDate}:</span>
                    <span className={`font-bold ${isOverdue ? 'text-rose-700' : isToday ? 'text-amber-700' : 'text-slate-900'}`}>
                      {item.nextDueDate}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">{t.maintenance.provider}:</span>
                    <span className="font-semibold text-slate-800 truncate max-w-[140px]">
                      {item.providerOrTechnician}
                    </span>
                  </div>

                  {item.estimatedCost > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">{t.maintenance.cost}:</span>
                      <span className="font-bold text-emerald-700">
                        {item.estimatedCost} DH
                      </span>
                    </div>
                  )}
                </div>

                {/* Card Action Buttons */}
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  {!isOwner && (
                    <div className="grid grid-cols-2 gap-2">
                      {/* Button: Start Operation */}
                      <button
                        type="button"
                        onClick={() => onStartOperation(item)}
                        className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer"
                      >
                        <PlayCircle className="w-3.5 h-3.5" />
                        <span>{t.maintenance.startOperation}</span>
                      </button>

                      {/* Button: Complete and Reschedule */}
                      <button
                        type="button"
                        onClick={() => onOpenCompleteModal(item)}
                        className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'تأكيد الإنجاز' : 'Terminer'}</span>
                      </button>
                    </div>
                  )}

                  {/* Secondary shortcuts */}
                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-1">
                      {/* WhatsApp shortcut */}
                      <button
                        type="button"
                        onClick={() => handleWhatsApp(item)}
                        title={t.maintenance.sendWhatsAppReminder}
                        className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                      </button>

                      {/* Phone call */}
                      {item.providerPhone && (
                        <a
                          href={`tel:${item.providerPhone}`}
                          title={item.providerPhone}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition-all"
                        >
                          <Phone className="w-3.5 h-3.5 text-slate-600" />
                        </a>
                      )}

                      {/* History button */}
                      <button
                        type="button"
                        onClick={() => setHistoryItem(item)}
                        title={t.maintenance.historyTitle}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 transition-all flex items-center gap-1 text-[11px] font-medium cursor-pointer"
                      >
                        <History className="w-3.5 h-3.5 text-slate-500" />
                        <span>({item.history?.length || 0})</span>
                      </button>
                    </div>

                    {!isOwner && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-amber-700 transition-all cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal: Add/Edit Periodic Schedule */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-8">
            <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {editingItem ? t.common.edit : t.maintenance.addNewPeriodic}
                </h3>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-4">
              {/* Presets Selector for Fast Auto-fill */}
              {!editingItem && (
                <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                  <div className="text-[11px] font-bold text-amber-900 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>{lang === 'ar' ? 'نماذج جاهزة للاختيار السريع (قوالب العقود المعتادة):' : 'Modèles prédéfinis rapides :'}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => handlePresetSelect('lighting')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white hover:bg-amber-100 text-amber-900 border border-amber-200 shadow-2xs transition-all cursor-pointer"
                    >
                      💡 {lang === 'ar' ? 'الإنارة والكهرباء' : 'Éclairage'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePresetSelect('pumps')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white hover:bg-blue-50 text-blue-900 border border-blue-200 shadow-2xs transition-all cursor-pointer"
                    >
                      💧 {lang === 'ar' ? 'مضخات الماء' : 'Surpresseurs'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePresetSelect('fire')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white hover:bg-rose-50 text-rose-900 border border-rose-200 shadow-2xs transition-all cursor-pointer"
                    >
                      🧯 {lang === 'ar' ? 'طفايات الحريق' : 'Extincteurs'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePresetSelect('cleaning_tanks')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-200 shadow-2xs transition-all cursor-pointer"
                    >
                      🧼 {lang === 'ar' ? 'تنظيف الخزانات' : 'Bâche à eau'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePresetSelect('intercom')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-white hover:bg-purple-50 text-purple-900 border border-purple-200 shadow-2xs transition-all cursor-pointer"
                    >
                      📹 {lang === 'ar' ? 'كاميرات وإنترفون' : 'Caméras & Interphone'}
                    </button>
                  </div>
                </div>
              )}

              {/* Title & Building */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.formTitle} *</label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    placeholder={lang === 'ar' ? 'مثال: الفحص الوقائي لمضخات وضغط المياه' : 'Ex: Maintenance surpresseurs'}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.building} *</label>
                  <select
                    value={formData.buildingCode}
                    onChange={e => setFormData({ ...formData, buildingCode: e.target.value })}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value="ALL">{lang === 'ar' ? 'كامل المجمع (ALL)' : 'Toute la résidence'}</option>
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Category & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.category} *</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as MaintenanceCategory })}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value="lighting">{t.maintenance.categories.lighting}</option>
                    <option value="plumbing">{t.maintenance.categories.plumbing}</option>
                    <option value="security">{t.maintenance.categories.security}</option>
                    <option value="cleaning">{t.maintenance.categories.cleaning}</option>
                    <option value="other">{t.maintenance.categories.other}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.apartmentOrArea}</label>
                  <input
                    type="text"
                    value={formData.apartmentOrArea}
                    onChange={e => setFormData({ ...formData, apartmentOrArea: e.target.value })}
                    placeholder={lang === 'ar' ? 'غرفة المضخات، السطح، بهو المدخل...' : 'Cage d\'escalier, machinerie...'}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Frequency & Dates */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.frequency} *</label>
                  <select
                    value={formData.frequency}
                    onChange={e => handleFrequencyChange(e.target.value as PeriodicFrequency)}
                    className="w-full h-9 px-2 text-xs rounded-lg bg-white border border-slate-300 focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value="weekly">{t.maintenance.frequencies.weekly}</option>
                    <option value="monthly">{t.maintenance.frequencies.monthly}</option>
                    <option value="quarterly">{t.maintenance.frequencies.quarterly}</option>
                    <option value="biannual">{t.maintenance.frequencies.biannual}</option>
                    <option value="annual">{t.maintenance.frequencies.annual}</option>
                    <option value="custom">{t.maintenance.frequencies.custom}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.lastCompletedDate}</label>
                  <input
                    type="date"
                    value={formData.lastCompletedDate}
                    onChange={e => setFormData({ ...formData, lastCompletedDate: e.target.value })}
                    className="w-full h-9 px-2 text-xs rounded-lg bg-white border border-slate-300 focus:border-amber-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700 text-amber-900">{t.maintenance.nextDueDate} *</label>
                  <input
                    type="date"
                    required
                    value={formData.nextDueDate}
                    onChange={e => setFormData({ ...formData, nextDueDate: e.target.value })}
                    className="w-full h-9 px-2 text-xs rounded-lg bg-white border border-amber-400 font-bold text-amber-900 focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Reminder Threshold & Cost */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.remindDaysBefore}</label>
                  <select
                    value={formData.remindDaysBefore}
                    onChange={e => setFormData({ ...formData, remindDaysBefore: Number(e.target.value) })}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value={3}>{lang === 'ar' ? 'قبل 3 أيام من الموعد' : '3 jours avant'}</option>
                    <option value={7}>{lang === 'ar' ? 'قبل 7 أيام من الموعد (مستحسن)' : '7 jours avant (Recommandé)'}</option>
                    <option value={15}>{lang === 'ar' ? 'قبل 15 يوماً من الموعد' : '15 jours avant'}</option>
                    <option value={30}>{lang === 'ar' ? 'قبل شهر (30 يوماً)' : '30 jours avant'}</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.estimatedCost} (DH)</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.estimatedCost || ''}
                    onChange={e => setFormData({ ...formData, estimatedCost: parseFloat(e.target.value) || 0 })}
                    placeholder="0.00"
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Provider / Company & Contact Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.provider} *</label>
                  <input
                    type="text"
                    required
                    value={formData.providerOrTechnician}
                    onChange={e => setFormData({ ...formData, providerOrTechnician: e.target.value })}
                    placeholder={lang === 'ar' ? 'اسم الشركة أو الفني المكلف' : 'Nom de la société / technicien'}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">{t.maintenance.providerPhone}</label>
                  <input
                    type="tel"
                    value={formData.providerPhone}
                    onChange={e => setFormData({ ...formData, providerPhone: e.target.value })}
                    placeholder="06XX XX XX XX"
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">{t.maintenance.notes}</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={lang === 'ar' ? 'تفاصيل بنود العقد، رقم البوليصة، تعليمات الفحص...' : 'Détails du contrat, consignes de révision...'}
                  className="w-full p-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              {/* Active Switch */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={e => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-amber-600 rounded-sm border-slate-300 focus:ring-amber-500"
                />
                <label htmlFor="isActive" className="text-xs font-bold text-slate-800 cursor-pointer">
                  {lang === 'ar' ? 'تفعيل العقد ونظام التنبيهات التلقائية' : 'Activer le contrat et les rappels automatiques'}
                </label>
              </div>

              {/* Form Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold transition-all cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  {editingItem ? t.common.save : t.common.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white w-full max-w-xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in duration-150">
            <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">{t.maintenance.historyTitle}</h3>
                  <p className="text-xs text-slate-500">{historyItem.title} ({historyItem.buildingCode})</p>
                </div>
              </div>
              <button 
                onClick={() => setHistoryItem(null)}
                className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 max-h-96 overflow-y-auto space-y-3">
              {(!historyItem.history || historyItem.history.length === 0) ? (
                <div className="p-6 text-center text-xs text-slate-500 font-medium">
                  {lang === 'ar' ? 'لا يوجد سجل تدخلات سابقة مسجل لهذا العقد حتى الآن.' : 'Aucun historique d\'intervention pour ce contrat.'}
                </div>
              ) : (
                historyItem.history.map((hist, idx) => (
                  <div key={hist.id || idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{hist.completedDate}</span>
                      </span>
                      <span className="font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        {hist.actualCost || 0} DH
                      </span>
                    </div>
                    <p className="text-slate-600">{hist.notes || 'تم إنجاز الصيانة'}</p>
                    <div className="text-[10px] text-slate-400">
                      {lang === 'ar' ? 'المشرف:' : 'Supervisé par:'} {hist.completedBy || 'السانديك'}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setHistoryItem(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-700 cursor-pointer"
              >
                {t.common.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
