import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MaintenanceAlert, MaintenanceCategory } from '../types';
import { 
  AlertTriangle, Clock, PlayCircle, CheckCircle2, 
  Phone, MessageSquare, BellRing, BellOff, X, 
  Volume2, ChevronDown, ChevronUp, Wrench, ShieldAlert,
  Droplets, Sparkles, Lightbulb, Check
} from 'lucide-react';

interface MaintenanceAlertsBannerProps {
  onStartOperation: (alert: MaintenanceAlert) => void;
  onCompleteOperation: (alert: MaintenanceAlert) => void;
  onNavigateToSchedule?: (scheduleId: string) => void;
}

export const MaintenanceAlertsBanner: React.FC<MaintenanceAlertsBannerProps> = ({
  onStartOperation,
  onCompleteOperation,
  onNavigateToSchedule
}) => {
  const { 
    t, lang, currentUser, maintenanceAlerts, 
    dismissedAlertIds, dismissAlert, resetDismissedAlerts,
    overdueAlertsCount, imminentAlertsCount 
  } = useApp();

  const [isExpanded, setIsExpanded] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const isOwner = currentUser?.role === 'resident';

  // Filter out dismissed alerts for the main view unless user chooses to see them
  const visibleAlerts = maintenanceAlerts.filter(a => !dismissedAlertIds.includes(a.scheduleId));
  const dismissedCount = maintenanceAlerts.filter(a => dismissedAlertIds.includes(a.scheduleId)).length;

  if (maintenanceAlerts.length === 0 && dismissedCount === 0) {
    return null;
  }

  // Web Audio subtle chime for reminders
  const playAlertChime = () => {
    try {
      const AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof window.AudioContext }).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.12); // A5
      
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } catch {
      // Audio not supported or blocked by browser policy
    }
  };

  const handleWhatsAppReminder = (alert: MaintenanceAlert) => {
    const { schedule } = alert;
    const phoneClean = schedule.providerPhone ? schedule.providerPhone.replace(/[^0-9]/g, '') : '';
    
    const textAr = `السلام عليكم ورحمة الله،\n\nنذكركم بموعد الصيانة الدورية المجدولة:\n📌 المهمة: ${schedule.title}\n🏢 الموقع: ${schedule.buildingCode} (${schedule.apartmentOrArea})\n📅 موعد الاستحقاق: ${schedule.nextDueDate}\n\nنرجو منكم التنسيق مع إدارة السانديك لبدء العمليات في أقرب وقت.\nوشكراً جزيلاً.`;
    const textFr = `Bonjour,\n\nNous vous rappelons l'échéance de maintenance périodique programmée :\n📌 Objet : ${schedule.title}\n🏢 Emplacement : ${schedule.buildingCode} (${schedule.apartmentOrArea})\n📅 Date d'échéance : ${schedule.nextDueDate}\n\nMerci de coordonner avec le bureau du syndic pour démarrer l'intervention.\nCordialement.`;
    
    const message = lang === 'ar' ? textAr : textFr;
    const encoded = encodeURIComponent(message);
    
    const url = phoneClean 
      ? `https://wa.me/${phoneClean}?text=${encoded}`
      : `https://wa.me/?text=${encoded}`;
      
    window.open(url, '_blank');
  };

  const getCategoryIcon = (cat: MaintenanceCategory) => {
    switch (cat) {
      case 'lighting': return <Lightbulb className="w-3.5 h-3.5 text-amber-500" />;
      case 'plumbing': return <Droplets className="w-3.5 h-3.5 text-blue-600" />;
      case 'security': return <ShieldAlert className="w-3.5 h-3.5 text-red-600" />;
      case 'cleaning': return <Sparkles className="w-3.5 h-3.5 text-emerald-600" />;
      default: return <Wrench className="w-3.5 h-3.5 text-slate-600" />;
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="rounded-2xl border border-amber-200 bg-linear-to-b from-amber-50/90 via-orange-50/50 to-amber-50/30 p-4 sm:p-5 shadow-xs transition-all relative overflow-hidden">
      {/* Toast popup */}
      {toastMessage && (
        <div className="absolute top-3 inset-x-3 sm:inset-x-auto sm:right-4 z-20 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-semibold shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-800 flex items-center justify-center border border-amber-300">
              <BellRing className="w-5 h-5 text-amber-700 animate-bounce" />
            </div>
            {overdueAlertsCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-rose-600 text-white text-[9px] font-bold items-center justify-center">
                  {overdueAlertsCount}
                </span>
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-slate-900">
                {t.maintenance.alertsBannerTitle}
              </h2>
              <div className="flex items-center gap-1.5">
                {overdueAlertsCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                    {overdueAlertsCount} {t.maintenance.overdueCount}
                  </span>
                )}
                {imminentAlertsCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                    {imminentAlertsCount} {t.maintenance.imminentCount}
                  </span>
                )}
              </div>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              {t.maintenance.alertsBannerDesc}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound trigger button */}
          <button
            type="button"
            onClick={() => {
              playAlertChime();
              setSoundEnabled(!soundEnabled);
              showToast(lang === 'ar' ? 'تم تشغيل نغمة التنبيه التجريبية' : 'Sonnerie de test jouée');
            }}
            title={lang === 'ar' ? 'تشغيل نغمة تنبيه صوتية' : 'Tester le son d\'alerte'}
            className="p-2 rounded-xl bg-white hover:bg-slate-100 border border-amber-200 text-amber-800 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          {/* Reset dismissed button if any are dismissed */}
          {dismissedCount > 0 && (
            <button
              type="button"
              onClick={() => {
                resetDismissedAlerts();
                showToast(lang === 'ar' ? 'تمت استعادة التنبيهات المكتومة' : 'Alertes ignorées restaurées');
              }}
              className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-slate-100 border border-amber-200 text-slate-700 text-xs font-semibold transition-all cursor-pointer"
            >
              {lang === 'ar' ? `استعادة ${dismissedCount} تنبيه مكتوم` : `Restaurer ${dismissedCount} masquées`}
            </button>
          )}

          {/* Toggle expand */}
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-xl bg-white hover:bg-slate-100 border border-amber-200 text-slate-700 text-xs font-semibold transition-all cursor-pointer"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Alerts Cards List */}
      {isExpanded && (
        <div className="mt-4 space-y-2.5">
          {visibleAlerts.length === 0 ? (
            <div className="p-4 rounded-xl bg-white/80 border border-emerald-200 text-center text-xs text-emerald-800 font-medium">
              {lang === 'ar' 
                ? '✅ جميع مواعيد الصيانة الدورية في وضع منتظم ولا توجد تنبيهات عاجلة حالياً.'
                : '✅ Toutes les opérations de maintenance périodique sont à jour.'}
            </div>
          ) : (
            visibleAlerts.map((alert) => {
              const { schedule, type, daysRemaining } = alert;
              const isOverdue = type === 'overdue';
              const isToday = type === 'today';

              const cardBorderColor = isOverdue
                ? 'border-rose-300 bg-white/95'
                : isToday
                ? 'border-amber-400 bg-amber-50/90'
                : 'border-orange-200 bg-white/90';

              const badgeColor = isOverdue
                ? 'bg-rose-100 text-rose-800 border-rose-200'
                : isToday
                ? 'bg-amber-500 text-white animate-pulse'
                : 'bg-amber-100 text-amber-900 border-amber-200';

              return (
                <div
                  key={alert.scheduleId}
                  className={`p-3.5 sm:p-4 rounded-xl border ${cardBorderColor} shadow-2xs hover:shadow-xs transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-3`}
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 border ${badgeColor}`}>
                        {isOverdue && <AlertTriangle className="w-3 h-3 text-rose-600" />}
                        {isToday && <Clock className="w-3 h-3 text-white" />}
                        {!isOverdue && !isToday && <Clock className="w-3 h-3 text-amber-700" />}
                        <span>
                          {isOverdue 
                            ? (lang === 'ar' ? `متأخرة بـ ${Math.abs(daysRemaining)} يوم` : `En retard de ${Math.abs(daysRemaining)} j`)
                            : isToday 
                            ? t.maintenance.dueToday 
                            : (lang === 'ar' ? `متبقي ${daysRemaining} أيام` : `Dans ${daysRemaining} jours`)}
                        </span>
                      </span>

                      <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                        {getCategoryIcon(schedule.category)}
                        <span>{schedule.buildingCode === 'ALL' ? (lang === 'ar' ? 'كامل المجمع' : 'Toute la résidence') : schedule.buildingCode}</span>
                      </span>

                      <span className="text-[11px] text-slate-500">
                        {schedule.apartmentOrArea}
                      </span>
                    </div>

                    <h3 
                      onClick={() => onNavigateToSchedule && onNavigateToSchedule(schedule.id)}
                      className="text-xs sm:text-sm font-bold text-slate-900 hover:text-amber-700 cursor-pointer"
                    >
                      {schedule.title}
                    </h3>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-600">
                      <div>
                        <span className="text-slate-400">{t.maintenance.nextDueDate}: </span>
                        <span className="font-semibold text-slate-800">{schedule.nextDueDate}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">{t.maintenance.provider}: </span>
                        <span className="font-semibold text-slate-800">{schedule.providerOrTechnician}</span>
                      </div>
                      {schedule.estimatedCost > 0 && (
                        <div>
                          <span className="text-slate-400">{t.maintenance.cost}: </span>
                          <span className="font-semibold text-emerald-800">{schedule.estimatedCost} DH</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions buttons */}
                  {!isOwner && (
                    <div className="flex flex-wrap items-center gap-2 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100">
                      {/* Button: Start Operation */}
                      <button
                        type="button"
                        onClick={() => {
                          onStartOperation(alert);
                          showToast(t.maintenance.operationStartedSuccess);
                        }}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer"
                      >
                        <PlayCircle className="w-4 h-4" />
                        <span>{t.maintenance.startOperation}</span>
                      </button>

                      {/* Button: Complete and Reschedule */}
                      <button
                        type="button"
                        onClick={() => onCompleteOperation(alert)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t.maintenance.markCompletedAndReschedule}</span>
                      </button>

                      {/* Button: WhatsApp reminder */}
                      <button
                        type="button"
                        onClick={() => handleWhatsAppReminder(alert)}
                        title={t.maintenance.sendWhatsAppReminder}
                        className="flex items-center gap-1 px-2.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-semibold transition-all cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-700" />
                        <span className="hidden sm:inline">{lang === 'ar' ? 'واتساب الفني' : 'WhatsApp'}</span>
                      </button>

                      {/* Phone call shortcut if phone exists */}
                      {schedule.providerPhone && (
                        <a
                          href={`tel:${schedule.providerPhone}`}
                          title={schedule.providerPhone}
                          className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs transition-all flex items-center justify-center"
                        >
                          <Phone className="w-3.5 h-3.5 text-slate-600" />
                        </a>
                      )}

                      {/* Dismiss / Snooze */}
                      <button
                        type="button"
                        onClick={() => {
                          dismissAlert(schedule.id);
                          showToast(lang === 'ar' ? 'تم كتم هذا التنبيه' : 'Alerte masquée');
                        }}
                        title={lang === 'ar' ? 'كتم هذا التنبيه' : 'Masquer cette alerte'}
                        className="p-2 rounded-xl hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-all cursor-pointer"
                      >
                        <BellOff className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
