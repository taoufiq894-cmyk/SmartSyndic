import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, Printer, Download, Calendar, Building2, 
  Users, CheckCircle2, AlertCircle, Search, Filter, 
  FileSpreadsheet, ShieldCheck, CreditCard, Receipt, 
  Wallet, TrendingUp, Sparkles, Check, Info, FileText,
  Clock, ArrowUpDown
} from 'lucide-react';
import { exportMonthlyResidentsReportToPdf, exportResidentsReportToCSV } from '../utils/monthlyPdfReportUtils';
import { getApartmentDebtStatus } from '../utils/debtUtils';
import { ARABIC_MONTH_NAMES, FRENCH_MONTH_NAMES } from '../utils/monthlyFinanceUtils';

export interface MonthlyResidentsReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMonth?: string; // YYYY-MM
  initialBuilding?: string; // ALL or specific building code
}

export const MonthlyResidentsReportModal: React.FC<MonthlyResidentsReportModalProps> = ({
  isOpen,
  onClose,
  initialMonth,
  initialBuilding = 'ALL'
}) => {
  const { 
    lang, 
    apartments, 
    buildings, 
    payments, 
    expenses, 
    residents,
    showToast 
  } = useApp();

  const isAr = lang === 'ar';
  const today = new Date();

  // Current or initial period default
  const defaultPeriod = useMemo(() => {
    if (initialMonth) return initialMonth;
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    return `${y}-${m}`;
  }, [initialMonth]);

  const [selectedPeriod, setSelectedPeriod] = useState<string>(defaultPeriod);
  const [selectedBuilding, setSelectedBuilding] = useState<string>(initialBuilding);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PAID' | 'UNPAID'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [exportSuccessMsg, setExportSuccessMsg] = useState<string | null>(null);

  // Parse Year and Month
  const [periodYear, periodMonth] = useMemo(() => {
    const parts = selectedPeriod.split('-');
    return [parts[0] || '2026', parts[1] || '08'];
  }, [selectedPeriod]);

  // Month Display Name
  const periodMonthName = useMemo(() => {
    const mNum = parseInt(periodMonth, 10);
    if (isAr) {
      return ARABIC_MONTH_NAMES[mNum] || `شهر ${periodMonth}`;
    }
    return FRENCH_MONTH_NAMES[mNum] || `Mois ${periodMonth}`;
  }, [periodMonth, isAr]);

  const periodTitle = useMemo(() => {
    return isAr ? `${periodMonthName} ${periodYear}` : `${periodMonthName} ${periodYear}`;
  }, [periodMonthName, periodYear, isAr]);

  // List of available months (last 12 months + next 2)
  const availablePeriods = useMemo(() => {
    const list: Array<{ value: string; label: string }> = [];
    const baseYear = today.getFullYear();
    for (let y = baseYear; y >= baseYear - 1; y--) {
      for (let m = 12; m >= 1; m--) {
        const mStr = String(m).padStart(2, '0');
        const val = `${y}-${mStr}`;
        const name = isAr ? ARABIC_MONTH_NAMES[m] : FRENCH_MONTH_NAMES[m];
        list.push({ value: val, label: `${name} ${y}` });
      }
    }
    return list;
  }, [isAr]);

  // Filtered Apartments list
  const filteredApartments = useMemo(() => {
    return apartments.filter(apt => {
      // Building filter
      if (selectedBuilding !== 'ALL' && apt.buildingCode !== selectedBuilding) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const aptNum = (apt.number || '').toLowerCase();
        const bld = (apt.buildingCode || '').toLowerCase();
        const res = residents.find(r => r.buildingCode === apt.buildingCode && r.apartmentNumber === apt.number);
        const ownerName = (res?.fullName || apt.residentName || '').toLowerCase();

        if (!aptNum.includes(q) && !bld.includes(q) && !ownerName.includes(q)) {
          return false;
        }
      }
      return true;
    });
  }, [apartments, selectedBuilding, searchQuery, residents]);

  // Calculate detailed payment status for each apartment for this specific month
  const reportRows = useMemo(() => {
    return filteredApartments.map(apt => {
      const res = residents.find(r => r.buildingCode === apt.buildingCode && r.apartmentNumber === apt.number);
      const ownerName = res?.fullName || apt.residentName || (isAr ? 'مالك الشقة' : 'Copropriétaire');
      const monthlyFee = apt.monthlyFee || 100;

      // Find if payment exists for this specific period
      const paidPayment = payments.find(p => 
        p.buildingCode === apt.buildingCode &&
        p.apartmentNumber === apt.number &&
        (p.periodMonth === selectedPeriod || (p.notes && p.notes.includes(selectedPeriod)))
      );
      const isPaid = !!paidPayment;
      const amountPaid = paidPayment ? (Number(paidPayment.amount) || monthlyFee) : 0;
      
      // Calculate overall debt status
      const debtStatus = getApartmentDebtStatus(apt, payments);
      const accumulatedDebt = debtStatus.totalBalanceDue;

      return {
        apt,
        apartmentNumber: apt.number,
        buildingCode: apt.buildingCode,
        ownerName,
        phone: res?.phone || '',
        monthlyFee,
        isPaid,
        amountPaid,
        receiptNumber: paidPayment?.receiptNumber || '',
        paymentDate: paidPayment?.paymentDate || '',
        paymentMethod: paidPayment?.paymentMethod || '',
        accumulatedDebt,
        monthsLate: debtStatus.unpaidMonths,
      };
    });
  }, [filteredApartments, residents, payments, selectedPeriod, isAr]);

  // Apply Status Filter
  const displayedRows = useMemo(() => {
    if (statusFilter === 'PAID') {
      return reportRows.filter(r => r.isPaid);
    }
    if (statusFilter === 'UNPAID') {
      return reportRows.filter(r => !r.isPaid);
    }
    return reportRows;
  }, [reportRows, statusFilter]);

  // Aggregated Report Metrics
  const metrics = useMemo(() => {
    const totalApartments = reportRows.length;
    const paidCount = reportRows.filter(r => r.isPaid).length;
    const unpaidCount = totalApartments - paidCount;
    const collectionRate = totalApartments > 0 ? Math.round((paidCount / totalApartments) * 100) : 0;
    const totalCollected = reportRows.reduce((sum, r) => sum + r.amountPaid, 0);
    const expectedIncome = reportRows.reduce((sum, r) => sum + r.monthlyFee, 0);

    // Expenses during this selected period
    const periodExpenses = expenses.filter(e => {
      const eDate = e.date || '';
      const inPeriod = eDate.startsWith(selectedPeriod);
      if (selectedBuilding === 'ALL') return inPeriod;
      return inPeriod && (e.buildingCode === selectedBuilding || !e.buildingCode || e.buildingCode === 'ALL');
    });

    const totalPeriodExpenses = periodExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const netReserve = totalCollected - totalPeriodExpenses;

    return {
      totalApartments,
      paidCount,
      unpaidCount,
      collectionRate,
      totalCollected,
      expectedIncome,
      totalPeriodExpenses,
      netReserve,
      periodExpenses
    };
  }, [reportRows, expenses, selectedPeriod, selectedBuilding]);

  // PDF Export Action
  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    setExportSuccessMsg(null);
    try {
      const success = await exportMonthlyResidentsReportToPdf(
        'residents-report-print-container',
        selectedPeriod,
        selectedBuilding
      );
      if (success) {
        setExportSuccessMsg(isAr ? 'تم تصدير تقرير السكان إلى ملف PDF بنجاح!' : 'Rapport des résidents exporté en PDF avec succès !');
        showToast(isAr ? 'تم إنشاء وتحميل ملف PDF للتقرير الشهري للسكان' : 'PDF du rapport mensuel généré', { type: 'success' });
        setTimeout(() => setExportSuccessMsg(null), 4000);
      } else {
        showToast(isAr ? 'حدث خطأ أثناء تصدير ملف PDF' : 'Erreur lors de la génération PDF', { type: 'error' });
      }
    } catch (err) {
      console.error('PDF export error:', err);
      showToast(isAr ? 'حدث خطأ أثناء تصدير ملف PDF' : 'Erreur lors de la génération PDF', { type: 'error' });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // CSV / Excel Export Action
  const handleDownloadCSV = () => {
    exportResidentsReportToCSV({
      residenceName: 'إقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10',
      period: periodTitle,
      buildingFilter: selectedBuilding,
      totalApartments: metrics.totalApartments,
      paidCount: metrics.paidCount,
      unpaidCount: metrics.unpaidCount,
      collectionRate: metrics.collectionRate,
      totalCollected: metrics.totalCollected,
      totalExpenses: metrics.totalPeriodExpenses,
      netReserve: metrics.netReserve,
      apartmentsData: displayedRows.map(r => ({
        apartmentNumber: r.apartmentNumber,
        buildingCode: r.buildingCode,
        ownerName: r.ownerName,
        status: r.isPaid ? (isAr ? 'مؤدى' : 'Payé') : (isAr ? 'غير مؤدى' : 'Impayé'),
        amountPaid: r.amountPaid,
        monthlyFee: r.monthlyFee,
        accumulatedDebt: r.accumulatedDebt,
        notes: r.isPaid 
          ? (isAr ? `وصل رقم ${r.receiptNumber} (${r.paymentDate})` : `Reçu N° ${r.receiptNumber}`) 
          : (r.monthsLate > 1 ? (isAr ? `متأخر بـ ${r.monthsLate} أشهر` : `Retard de ${r.monthsLate} mois`) : (isAr ? 'في انتظار الأداء' : 'En attente'))
      }))
    });
    setExportSuccessMsg(isAr ? 'تم تصدير جدول الإكسيل (CSV) بنجاح!' : 'Fichier Excel (CSV) exporté avec succès !');
    setTimeout(() => setExportSuccessMsg(null), 4000);
  };

  // Native Browser Print
  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh]">
        
        {/* ========================================================
            TOP ACTION & FILTER BAR (Hidden During Native Print)
            ======================================================== */}
        <div className="no-print p-4 sm:p-5 bg-gradient-to-r from-[#0f172a] via-[#0a8591] to-[#1e3a8a] text-white flex flex-wrap items-center justify-between gap-3 border-b border-[#0d5262]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center text-white shadow-inner shrink-0">
              <Users className="w-5 h-5 text-rose-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  {isAr ? 'التقرير الشهري للسكان والملاك المشتركين' : 'Rapport Mensuel des Copropriétaires'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-950 border border-amber-300 uppercase">
                  PDF & Print
                </span>
              </div>
              <p className="text-xs text-rose-200 font-medium">
                {isAr 
                  ? 'كشف رسمي لاستخلاص واجبات السانديك، مصاريف الشهر، والوضعية العامة للإقامة'
                  : 'État officiel des cotisations, dépenses et situation de la résidence'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Close Button */}
            <button
              type="button"
              id="btn-close-residents-report-modal"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title={isAr ? 'إغلاق' : 'Fermer'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Toolbar (No Print) */}
        <div className="no-print p-4 bg-[#e9fbf8] border-b border-[#92e8dd] flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 flex-1">
            {/* Month / Period Picker */}
            <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-xs shadow-2xs">
              <Calendar className="w-4 h-4 text-[#0a8591]" />
              <label htmlFor="select-residents-report-period" className="font-bold text-slate-700">
                {isAr ? 'الشهر:' : 'Période:'}
              </label>
              <select
                id="select-residents-report-period"
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="bg-transparent font-bold text-slate-900 border-none outline-hidden cursor-pointer"
              >
                {availablePeriods.map(p => (
                  <option key={p.value} value={p.value}>{p.label}</option>
                ))}
              </select>
            </div>

            {/* Building Picker */}
            <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-xs shadow-2xs">
              <Building2 className="w-4 h-4 text-[#0a8591]" />
              <label htmlFor="select-residents-report-building" className="font-bold text-slate-700">
                {isAr ? 'العمارة:' : 'Immeuble:'}
              </label>
              <select
                id="select-residents-report-building"
                value={selectedBuilding}
                onChange={(e) => setSelectedBuilding(e.target.value)}
                className="bg-transparent font-bold text-slate-900 border-none outline-hidden cursor-pointer"
              >
                <option value="ALL">{isAr ? 'كافة العمارات (20 عمارة)' : 'Tous les immeubles (20)'}</option>
                {buildings.map(b => (
                  <option key={b.code} value={b.code}>
                    {isAr ? `عمارة ${b.code}` : `Immeuble ${b.code}`}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center p-0.5 bg-slate-200/80 rounded-xl border border-slate-300 text-xs">
              <button
                type="button"
                onClick={() => setStatusFilter('ALL')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  statusFilter === 'ALL' ? 'bg-white text-slate-950 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isAr ? `الكل (${reportRows.length})` : `Tous (${reportRows.length})`}
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('PAID')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  statusFilter === 'PAID' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isAr ? `المؤدون (${metrics.paidCount})` : `Payés (${metrics.paidCount})`}
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('UNPAID')}
                className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  statusFilter === 'UNPAID' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isAr ? `المتأخرون (${metrics.unpaidCount})` : `Impayés (${metrics.unpaidCount})`}
              </button>
            </div>

            {/* Search Box */}
            <div className="relative min-w-[150px] sm:min-w-[180px]">
              <Search className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isAr ? 'بحث برقم الشقة أو الاسم...' : 'Recherche apt ou nom...'}
                className="w-full pl-3 pr-8 py-1.5 bg-white rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-[#0a8591] outline-hidden shadow-2xs"
              />
            </div>
          </div>

          {/* Action Buttons: PDF, Print, CSV */}
          <div className="flex items-center gap-2">
            {/* Download PDF Button */}
            <button
              type="button"
              id="btn-export-residents-report-pdf"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#0b6a78] via-[#0a8591] to-[#1e3a8a] hover:from-[#0f172a] hover:to-[#0a8591] text-white text-xs font-bold transition-all shadow-sm cursor-pointer border border-[#0d5262] disabled:opacity-60"
              title={isAr ? 'تحميل تقرير السكان بصيغة PDF عالية الجودة' : 'Télécharger le rapport PDF des résidents'}
            >
              <Download className={`w-3.5 h-3.5 ${isGeneratingPdf ? 'animate-bounce' : ''}`} />
              <span>{isGeneratingPdf ? (isAr ? 'جارٍ الإنشاء...' : 'Génération...') : (isAr ? 'تصدير PDF' : 'Export PDF')}</span>
            </button>

            {/* Native Browser Print Button */}
            <button
              type="button"
              id="btn-print-residents-report-native"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title={isAr ? 'طباعة مباشرة للمستند عبر الطابعة (A4)' : 'Imprimer directement le rapport'}
            >
              <Printer className="w-3.5 h-3.5 text-[#0a8591]" />
              <span>{isAr ? 'طباعة' : 'Imprimer'}</span>
            </button>

            {/* CSV / Excel Button */}
            <button
              type="button"
              id="btn-export-residents-report-csv"
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title={isAr ? 'تصدير كشف إكسيل (CSV)' : 'Exporter Excel (CSV)'}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Excel</span>
            </button>
          </div>
        </div>

        {/* Success feedback toast inside modal */}
        {exportSuccessMsg && (
          <div className="no-print mx-4 mt-3 p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{exportSuccessMsg}</span>
            </div>
            <button type="button" onClick={() => setExportSuccessMsg(null)} className="text-emerald-700 hover:text-emerald-950">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* ========================================================
            PRINTABLE REPORT CONTAINER (Captured by PDF & Window.print)
            ======================================================== */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-slate-50 print:bg-white print:p-0 print:overflow-visible">
          <div 
            id="residents-report-print-container"
            className="bg-white p-6 sm:p-10 rounded-2xl border-2 border-slate-200 shadow-sm max-w-4xl mx-auto space-y-6 text-slate-900 font-sans print:p-0 print:border-none print:shadow-none"
          >
            
            {/* 1. OFFICIAL ADMINISTRATIVE HEADER (Bordeaux & Moroccan Standards) */}
            <div className="border-b-2 border-[#0a8591] pb-5">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-start">
                <div className="space-y-1.5">
                  <div className="text-[11px] font-extrabold text-slate-600 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                    <span>المملكة المغربية</span>
                    <span>•</span>
                    <span>عمالة مراكش</span>
                    <span>•</span>
                    <span>إتحاد الملاك المشتركين</span>
                  </div>
                  
                  {/* Exact Residence Name */}
                  <h1 className="text-xl sm:text-2xl font-black text-[#0a8591] tracking-tight leading-tight">
                    إقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10
                  </h1>
                  
                  <div className="text-xs font-bold text-slate-700 flex items-center justify-center sm:justify-start gap-1.5">
                    <span>Résidence Al Morjane - Moyen Standing - Abwab Marrakech Zone 10</span>
                  </div>
                  <div className="text-[11px] text-slate-600 font-semibold">
                    {isAr ? '20 عمارة (GH 34 A إلى GH 38 D) • 320 شقة ومحل تجاري' : '20 Immeubles (GH 34 à GH 38) • 320 Appartements'}
                  </div>
                </div>

                {/* Report Badge */}
                <div className="p-3.5 sm:p-4 rounded-2xl bg-[#e9fbf8] border-2 border-[#0d5262] text-center sm:text-end shrink-0 shadow-xs">
                  <div className="text-[10px] font-extrabold text-[#0a8591] uppercase tracking-wider">
                    {isAr ? 'التقرير الشهري للسكان والملاك المشتركين' : 'Rapport Mensuel des Copropriétaires'}
                  </div>
                  <div className="text-base sm:text-lg font-black text-[#0f172a] mt-0.5 font-mono">
                    {periodTitle}
                  </div>
                  <div className="text-[10px] text-slate-600 mt-1 font-semibold">
                    {isAr ? `تاريخ الاستخراج: ${today.toISOString().slice(0, 10)}` : `Émis le: ${today.toISOString().slice(0, 10)}`}
                  </div>
                </div>
              </div>

              {/* Perimeter notice if building filtered */}
              <div className="mt-3 flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-slate-200">
                <div className="px-3 py-1 rounded-xl bg-slate-100 text-xs font-bold text-slate-800 inline-flex items-center gap-1.5 border border-slate-200">
                  <Building2 className="w-3.5 h-3.5 text-[#0a8591]" />
                  <span>
                    {selectedBuilding === 'ALL' 
                      ? (isAr ? 'النطاق الشامل: كافة عمارات الإقامة الـ 20' : 'Périmètre : Ensemble des 20 Immeubles')
                      : (isAr ? `النطاق المحدد: عمارة ${selectedBuilding}` : `Périmètre : Immeuble ${selectedBuilding}`)}
                  </span>
                </div>

                <div className="text-[11px] font-bold text-slate-500">
                  {isAr ? `عدد الشقق المعروضة: ${displayedRows.length} من أصل ${reportRows.length}` : `Appartements listés: ${displayedRows.length}/${reportRows.length}`}
                </div>
              </div>
            </div>

            {/* 2. EXECUTIVE SUMMARY KPIS FOR RESIDENTS */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 print-avoid-break">
              {/* Collection Rate */}
              <div className="p-4 rounded-2xl bg-[#e9fbf8] border border-[#92e8dd] space-y-1">
                <div className="flex items-center justify-between text-[#0a8591] text-[11px] font-bold">
                  <span>{isAr ? 'نسبة الاستخلاص للشهر' : 'Taux de recouvrement'}</span>
                  <TrendingUp className="w-4 h-4 text-[#0a8591]" />
                </div>
                <div className="text-2xl font-black font-mono text-[#0f172a]">
                  {metrics.collectionRate}%
                </div>
                <div className="text-[10px] text-slate-600 font-semibold">
                  {metrics.paidCount} {isAr ? 'شقة مستوفية' : 'payés'} / {metrics.totalApartments}
                </div>
              </div>

              {/* Total Contributions Collected */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <div className="flex items-center justify-between text-emerald-800 text-[11px] font-bold">
                  <span>{isAr ? 'مداخيل الشهر المحصلة' : 'Recettes perçues'}</span>
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-black font-mono text-emerald-950">
                  {metrics.totalCollected.toLocaleString()} <span className="text-xs font-sans font-bold">DH</span>
                </div>
                <div className="text-[10px] text-emerald-700 font-semibold">
                  {isAr ? `المتوقع: ${metrics.expectedIncome.toLocaleString()} DH` : `Attendu: ${metrics.expectedIncome} DH`}
                </div>
              </div>

              {/* Month Expenses for the Residence */}
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-1">
                <div className="flex items-center justify-between text-rose-800 text-[11px] font-bold">
                  <span>{isAr ? 'مصاريف وخدمات الإقامة' : 'Dépenses & travaux'}</span>
                  <Receipt className="w-4 h-4 text-rose-600" />
                </div>
                <div className="text-2xl font-black font-mono text-rose-950">
                  {metrics.totalPeriodExpenses.toLocaleString()} <span className="text-xs font-sans font-bold">DH</span>
                </div>
                <div className="text-[10px] text-rose-700 font-semibold">
                  {metrics.periodExpenses.length} {isAr ? 'فواتير وخدمات منجزة' : 'factures'}
                </div>
              </div>

              {/* Net Reserve Fund Balance */}
              <div className={`p-4 rounded-2xl border space-y-1 ${
                metrics.netReserve >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-amber-50 border-amber-200'
              }`}>
                <div className="flex items-center justify-between text-slate-700 text-[11px] font-bold">
                  <span>{isAr ? 'الرصيد الصافي المتاح' : 'Solde disponible'}</span>
                  <Wallet className={`w-4 h-4 ${metrics.netReserve >= 0 ? 'text-blue-600' : 'text-amber-600'}`} />
                </div>
                <div className={`text-2xl font-black font-mono ${metrics.netReserve >= 0 ? 'text-blue-950' : 'text-amber-950'}`}>
                  {metrics.netReserve >= 0 ? `+${metrics.netReserve.toLocaleString()}` : metrics.netReserve.toLocaleString()} <span className="text-xs font-sans font-bold">DH</span>
                </div>
                <div className="text-[10px] font-bold text-slate-600">
                  {metrics.netReserve >= 0 ? (isAr ? '🟢 فائض لصندوق الصيانة' : '🟢 Excédent') : (isAr ? '⚠️ عجز في الفترة' : '⚠️ Déficit')}
                </div>
              </div>
            </div>

            {/* 3. RESIDENCE SERVICES & WORKS ACCOMPLISHED THIS MONTH */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5 print-avoid-break">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-black text-slate-900">
                  <Sparkles className="w-4 h-4 text-[#0a8591]" />
                  <span>{isAr ? 'ملخص الخدمات والأشغال المنجزة لصالح سكان الإقامة خلال الشهر:' : 'Services et travaux réalisés pour les résidents ce mois :'}</span>
                </div>
                <span className="text-[10px] font-bold text-slate-500">
                  {isAr ? 'تسيير وصيانة مستمرة' : 'Gestion continue'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>{isAr ? 'النظافة والحراسة' : 'Nettoyage & Sécurité'}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {isAr 
                      ? 'مواصلة خدمات كنس وغسل المداخل والسلالم وحراسة البوابات ومحيط العمارات بانتظام.'
                      : 'Nettoyage régulier des halls et escaliers, gardiennage permanent.'}
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    <span>{isAr ? 'الإنارة والمصاعد والمضخات' : 'Éclairage & Ascenseurs'}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {isAr 
                      ? 'الصيانة الوقائية للمصاعد، ضبط مضخات ضغط الماء، واستبدال المصابيح التالفة بالممرات.'
                      : 'Entretien préventif des ascenseurs, surpresseurs d\'eau et éclairage.'}
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-1">
                  <div className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>{isAr ? 'السباكة والمساحات المشتركة' : 'Plomberie & Espaces'}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {isAr 
                      ? 'مراقبة شبكة الصرف الصحي والأسطح المشتركة والعناية بالمحيط الخارجي للإقامة.'
                      : 'Contrôle des canalisations, étanchéité des toits et espaces extérieurs.'}
                  </p>
                </div>
              </div>
            </div>

            {/* 4. MAIN APARTMENTS CONTRIBUTIONS TABLE */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#0a8591]" />
                  <span>{isAr ? 'جدول استخلاص واجبات السانديك حسب الشقق والملاك المشتركين:' : 'État nominatif des cotisations par appartement :'}</span>
                </h3>
                <span className="text-[11px] text-slate-500 font-bold">
                  {isAr ? `شهر ${periodTitle}` : periodTitle}
                </span>
              </div>

              <div className="overflow-x-auto border-2 border-slate-300 rounded-xl">
                <table className="w-full text-xs text-start border-collapse">
                  <thead>
                    <tr className="bg-[#0f172a] text-white font-bold border-b border-[#0a8591]">
                      <th className="py-2 px-2.5 text-center w-14">{isAr ? 'الشقة' : 'Apt'}</th>
                      <th className="py-2 px-2.5 text-center w-20">{isAr ? 'العمارة' : 'Immeuble'}</th>
                      <th className="py-2 px-3 text-start">{isAr ? 'المالك / الساكن' : 'Copropriétaire'}</th>
                      <th className="py-2 px-2.5 text-center w-24">{isAr ? 'الواجب الشهري' : 'Cotisation'}</th>
                      <th className="py-2 px-3 text-center w-28">{isAr ? `حالة ${periodMonthName}` : 'Statut'}</th>
                      <th className="py-2 px-2.5 text-center w-24">{isAr ? 'المدفوع' : 'Payé'}</th>
                      <th className="py-2 px-2.5 text-center w-28">{isAr ? 'المتأخرات السابقة' : 'Arriérés'}</th>
                      <th className="py-2 px-3 text-start">{isAr ? 'بيانات الوصل والملاحظات' : 'Reçu & Notes'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {displayedRows.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-500 font-bold">
                          {isAr ? 'لا توجد شقق مطابقة للمعايير المحددة' : 'Aucun enregistrement trouvé'}
                        </td>
                      </tr>
                    ) : (
                      displayedRows.map((row, idx) => (
                        <tr 
                          key={row.apt.id} 
                          className={`hover:bg-slate-50 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}`}
                        >
                          <td className="py-2 px-2.5 text-center font-mono font-black text-slate-900">
                            {row.apartmentNumber}
                          </td>
                          <td className="py-2 px-2.5 text-center font-bold text-slate-700">
                            {row.buildingCode}
                          </td>
                          <td className="py-2 px-3 font-semibold text-slate-900">
                            {row.ownerName}
                          </td>
                          <td className="py-2 px-2.5 text-center font-mono font-bold text-slate-800">
                            {row.monthlyFee} DH
                          </td>
                          <td className="py-2 px-3 text-center">
                            {row.isPaid ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-extrabold text-[11px] border border-emerald-300">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>{isAr ? 'مؤدى ✅' : 'Payé ✅'}</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-extrabold text-[11px] border border-rose-300">
                                <Clock className="w-3 h-3 text-rose-600" />
                                <span>{isAr ? 'غير مؤدى ⏳' : 'Impayé ⏳'}</span>
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-2.5 text-center font-mono font-black text-emerald-700">
                            {row.amountPaid > 0 ? `${row.amountPaid} DH` : '-'}
                          </td>
                          <td className="py-2 px-2.5 text-center font-mono font-bold">
                            {row.accumulatedDebt > 0 ? (
                              <span className="text-rose-700 font-black">
                                {row.accumulatedDebt} DH
                              </span>
                            ) : (
                              <span className="text-emerald-700">0 DH</span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-[11px] text-slate-600">
                            {row.isPaid ? (
                              <span className="font-mono text-slate-700">
                                {isAr ? `وصل: ${row.receiptNumber || 'نظامي'} (${row.paymentDate})` : `Reçu ${row.receiptNumber}`}
                              </span>
                            ) : (
                              <span className="text-slate-500 italic">
                                {row.monthsLate > 1 
                                  ? (isAr ? `متأخر (${row.monthsLate} أشهر)` : `Retard (${row.monthsLate}m)`)
                                  : (isAr ? 'واجب الشهر مستحق' : 'À régler')}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  {/* Table Footer Totals */}
                  <tfoot>
                    <tr className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-900">
                      <td colSpan={3} className="py-2.5 px-3 text-start font-black">
                        {isAr ? 'المجموع الإجمالي للشقق المعروضة:' : 'Total pour les enregistrements affichés :'}
                      </td>
                      <td className="py-2.5 px-2.5 text-center font-mono font-black">
                        {displayedRows.reduce((s, r) => s + r.monthlyFee, 0).toLocaleString()} DH
                      </td>
                      <td className="py-2.5 px-3 text-center text-xs font-extrabold">
                        {displayedRows.filter(r => r.isPaid).length} {isAr ? 'مؤدون' : 'payés'} / {displayedRows.filter(r => !r.isPaid).length} {isAr ? 'متأخرون' : 'impayés'}
                      </td>
                      <td className="py-2.5 px-2.5 text-center font-mono font-black text-emerald-800">
                        {displayedRows.reduce((s, r) => s + r.amountPaid, 0).toLocaleString()} DH
                      </td>
                      <td className="py-2.5 px-2.5 text-center font-mono font-black text-rose-800">
                        {displayedRows.reduce((s, r) => s + r.accumulatedDebt, 0).toLocaleString()} DH
                      </td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-600 font-semibold">
                        {isAr ? `تاريخ الحصر: ${today.toISOString().slice(0, 10)}` : ''}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* 5. LEGAL NOTICE & REMINDER TO CO-OWNERS */}
            <div className="p-4 rounded-2xl bg-amber-50/80 border-2 border-amber-300/80 text-xs space-y-2 print-avoid-break">
              <div className="flex items-center gap-2 font-black text-amber-950">
                <Info className="w-4 h-4 text-amber-700 shrink-0" />
                <span>{isAr ? 'تنبيه وتذكير قانوني هام لجميع الملاك المشتركين (القانون رقم 18.00):' : 'Rappel juridique important (Loi 18.00 sur la copropriété) :'}</span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                {isAr 
                  ? 'يُذكّر مكتب السانديك جميع الملاك المشتركين بأن أداء واجبات الاشتراك الشهري هو التزام قانوني وأخلاقي أساسي يفرضه نظام الملكية المشتركة. استمرار خدمات النظافة، الحراسة، إنارة السلالم، صيانة مضخات المياه والمصاعد رهين بمساهمة كل شقة في وقتها المحدد. نلتمس من الملاك المتأخرين المبادرة لتسوية وضعيتهم حفاظاً على المصلحة العامة للإقامة وقيمتها العقارية.'
                  : 'Le syndic rappelle à l\'ensemble des copropriétaires que le règlement des charges mensuelles est une obligation légale régie par la loi 18.00. La continuité des services de gardiennage, nettoyage et entretien des ascenseurs dépend de la contribution de chacun. Merci de régulariser vos cotisations sans délai.'}
              </p>
            </div>

            {/* 6. OFFICIAL SIGNATURES & SEAL SECTION */}
            <div className="pt-4 border-t-2 border-slate-800 grid grid-cols-3 gap-4 text-center print-avoid-break">
              <div className="space-y-12">
                <div className="text-xs font-black text-slate-800">
                  {isAr ? 'وكيل الإتحاد (السانديك)' : 'Le Syndic de Copropriété'}
                </div>
                <div className="text-[10px] text-slate-400 italic">
                  {isAr ? '[ التوقيع والخاتم الرسمي ]' : '[ Signature & Cachet ]'}
                </div>
              </div>

              <div className="space-y-12">
                <div className="text-xs font-black text-slate-800">
                  {isAr ? 'نائب وكيل السانديك' : 'Le Vice-Syndic'}
                </div>
                <div className="text-[10px] text-slate-400 italic">
                  {isAr ? '[ التأشير والتوقيع ]' : '[ Visa ]'}
                </div>
              </div>

              <div className="space-y-12">
                <div className="text-xs font-black text-slate-800">
                  {isAr ? 'مجلس الملاك المشتركين' : 'Conseil Syndical'}
                </div>
                <div className="text-[10px] text-slate-400 italic">
                  {isAr ? '[ المصادقة والمراجعة ]' : '[ Validation ]'}
                </div>
              </div>
            </div>

            {/* Document Footer Note */}
            <div className="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-200">
              {isAr 
                ? 'وثيقة رسمية صادرة عن منظومة التسيير الرقمي لإقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10 • صالحة للإشهار الإداري والتعليق'
                : 'Document officiel généré par le système de gestion de la Résidence Al Morjane Abwab Marrakech Zone 10'}
            </div>

          </div>
        </div>

        {/* Modal Bottom Footer (No Print) */}
        <div className="no-print p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>{isAr ? 'تنسيق الطباعة A4 متوافق مع كافة الطابعات' : 'Format A4 prêt pour impression'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-white hover:bg-slate-200 border border-slate-300 font-bold text-slate-700 transition-colors cursor-pointer"
            >
              {isAr ? 'إغلاق' : 'Fermer'}
            </button>

            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white font-bold transition-all shadow-xs cursor-pointer disabled:opacity-60"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isAr ? 'تصدير PDF' : 'Télécharger PDF'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
