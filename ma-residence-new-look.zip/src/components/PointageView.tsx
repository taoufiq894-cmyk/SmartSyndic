import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Employee, PointageStatus } from '../types';
import { 
  Calendar, Check, X, Coffee, FileText, Download, Printer, 
  Sparkles, RefreshCw, AlertCircle, DollarSign, CreditCard, 
  UserCheck, Shield, Eye, Flower2, Wrench, Briefcase, Wallet, Brush,
  Search, ChevronLeft, ChevronRight, Clock, Plus, HelpCircle,
  Pencil, Trash2, Eraser, UserX, Save
} from 'lucide-react';
import { 
  getMonthDays, getPointageKey, calculateEmployeeSalary, 
  exportPointageToExcel, STANDARD_WORK_DAYS, STANDARD_REST_DAYS,
  getEmployeeEffectiveStartDate, isEmployeeActiveInMonth,
  generateDefaultMonthPointage
} from '../utils/pointageUtils';
import { ARABIC_MONTH_NAMES, FRENCH_MONTH_NAMES } from '../utils/monthlyFinanceUtils';

interface PointageViewProps {
  initialMonth?: string;
  onPaySalary?: (emp: Employee, netAmount: number, notes: string) => void;
}

export const PointageView: React.FC<PointageViewProps> = ({ initialMonth, onPaySalary }) => {
  const { 
    lang, currentUser, employees, buildings, expenses, addExpense,
    updateEmployee, deleteEmployee,
    pointageRecords, pointageAdvances, pointageBonuses,
    setPointageStatus, batchSetPointageStatus, applyMonthDefaultPointage,
    clearMonthPointage, setPointageAdvance, setPointageBonus, savePointageData
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  // Current selected month: e.g. "2026-08" or "2026-09"
  const [selectedMonth, setSelectedMonth] = useState<string>(initialMonth || '2026-05');
  const [filterRole, setFilterRole] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Selected worker for Fiche de Paie (بطاقة الأجر)
  const [selectedEmployeeForPayslip, setSelectedEmployeeForPayslip] = useState<Employee | null>(null);

  // Edit Employee State
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [editName, setEditName] = useState<string>('');
  const [editRole, setEditRole] = useState<Employee['role']>('security');
  const [editSalary, setEditSalary] = useState<number | string>('');
  const [editPhone, setEditPhone] = useState<string>('');
  const [editCin, setEditCin] = useState<string>('');
  const [editShift, setEditShift] = useState<string>('');
  const [editAssignedBuilding, setEditAssignedBuilding] = useState<string>('');
  const [editStatus, setEditStatus] = useState<'active' | 'leave'>('active');
  const [editStartDate, setEditStartDate] = useState<string>('');

  // Delete / Clear Pointage State
  const [deletingOrClearingEmployee, setDeletingOrClearingEmployee] = useState<Employee | null>(null);
  const [confirmPermanentDelete, setConfirmPermanentDelete] = useState<boolean>(false);

  // Quick picker popover state for a single cell: { employeeId, date, x, y }
  const [activeCellPicker, setActiveCellPicker] = useState<{
    employeeId: string;
    date: string;
    currentStatus?: PointageStatus;
  } | null>(null);

  // Track last saved timestamp for feedback
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);

  // Success notifications
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4000);
  };

  // Main Save action at bottom of page
  const handleSaveAllPointage = () => {
    if (isOwner) return;
    savePointageData();
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLastSavedTime(timeStr);

    showNotification(lang === 'ar'
      ? `💾 تم الحفظ بنجاح! (${timeStr})`
      : `💾 Enregistré avec succès! (${timeStr})`
    );
  };

  // Handlers for Worker Editing
  const handleOpenEdit = (emp: Employee) => {
    if (isOwner) return;
    setEditingEmployee(emp);
    setEditName(emp.name);
    setEditRole(emp.role);
    setEditSalary(emp.salary);
    setEditPhone(emp.phone);
    setEditCin(emp.cin || '');
    setEditShift(emp.shift || '08:00 - 16:00');
    setEditAssignedBuilding(emp.assignedBuilding || '');
    setEditStatus(emp.status || 'active');
    setEditStartDate(emp.startDate || '');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner || !editingEmployee) return;
    if (!editName.trim()) {
      alert(lang === 'ar' ? 'يرجى إدخال اسم العامل' : 'Veuillez saisir le nom');
      return;
    }
    const sal = parseFloat(String(editSalary)) || 0;
    updateEmployee(editingEmployee.id, {
      name: editName.trim(),
      role: editRole,
      salary: sal,
      phone: editPhone.trim(),
      cin: editCin.trim(),
      shift: editShift.trim(),
      assignedBuilding: editAssignedBuilding.trim(),
      status: editStatus,
      startDate: editStartDate.trim() || undefined,
    });
    showNotification(lang === 'ar' 
      ? `✅ تم تعديل بيانات العامل (${editName.trim()}) بنجاح!` 
      : `✅ Agent (${editName.trim()}) modifié avec succès!`
    );
    setEditingEmployee(null);
  };

  // Days in current selected month
  const monthDays = useMemo(() => getMonthDays(selectedMonth), [selectedMonth]);

  // Available worker employees for the selected month:
  // ONLY workers who have started/registered on or before selectedMonth are included!
  const workerEmployees = useMemo(() => {
    return employees.filter(emp => {
      const isWorker = emp.role !== 'syndic' && emp.role !== 'deputy_syndic';
      const matchesRole = filterRole === 'ALL' || emp.role === filterRole;
      const matchesSearch = 
        emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (emp.cin && emp.cin.toLowerCase().includes(searchTerm.toLowerCase()));
      
      if (!isWorker || !matchesRole || !matchesSearch) return false;

      // Filter: Worker must be active in this month (registration / start date <= selectedMonth)
      return isEmployeeActiveInMonth(emp, selectedMonth);
    });
  }, [employees, filterRole, searchTerm, selectedMonth]);

  // Previous & Next month handlers
  const handlePrevMonth = () => {
    const [y, m] = selectedMonth.split('-').map(Number);
    let prevY = y;
    let prevM = m - 1;
    if (prevM < 1) {
      prevM = 12;
      prevY -= 1;
    }
    const nextKey = `${prevY}-${String(prevM).padStart(2, '0')}`;
    setSelectedMonth(nextKey);
  };

  const handleNextMonth = () => {
    const [y, m] = selectedMonth.split('-').map(Number);
    let nextY = y;
    let nextM = m + 1;
    if (nextM > 12) {
      nextM = 1;
      nextY += 1;
    }
    const nextKey = `${nextY}-${String(nextM).padStart(2, '0')}`;
    setSelectedMonth(nextKey);
  };

  const monthLabel = useMemo(() => {
    const [year, month] = selectedMonth.split('-');
    const mIndex = parseInt(month, 10) - 1;
    if (lang === 'ar') {
      return `${ARABIC_MONTH_NAMES[mIndex] || month} ${year}`;
    }
    return `${FRENCH_MONTH_NAMES[mIndex] || month} ${year}`;
  }, [selectedMonth, lang]);

  // Ensure every active worker in selectedMonth has attendance records generated so they never appear blank
  useEffect(() => {
    if (workerEmployees.length === 0) return;
    const days = getMonthDays(selectedMonth);
    const missingWorkers = workerEmployees.filter(emp => {
      const empStart = getEmployeeEffectiveStartDate(emp);
      const eligibleDays = days.filter(d => d.date >= empStart);
      if (eligibleDays.length === 0) return false;
      const hasRecord = eligibleDays.some(d => pointageRecords[`${emp.id}_${d.date}`] !== undefined);
      return !hasRecord;
    });

    if (missingWorkers.length > 0) {
      const generated = generateDefaultMonthPointage(selectedMonth, missingWorkers, pointageRecords);
      const entries: Array<{ employeeId: string; date: string; status: PointageStatus }> = [];
      missingWorkers.forEach(emp => {
        days.forEach(d => {
          const key = `${emp.id}_${d.date}`;
          if (generated[key]) {
            entries.push({ employeeId: emp.id, date: d.date, status: generated[key] });
          }
        });
      });
      if (entries.length > 0) {
        batchSetPointageStatus(entries);
      }
    }
  }, [selectedMonth, workerEmployees, pointageRecords, batchSetPointageStatus]);

  // Handlers for Worker Delete or Clear Month Pointage
  const handleOpenDeleteOrClear = (emp: Employee) => {
    if (isOwner) return;
    setDeletingOrClearingEmployee(emp);
    setConfirmPermanentDelete(false);
  };

  const handleClearThisWorkerMonth = () => {
    if (!deletingOrClearingEmployee) return;
    const empName = deletingOrClearingEmployee.name;
    clearMonthPointage(selectedMonth, deletingOrClearingEmployee.id);
    showNotification(lang === 'ar'
      ? `🧹 تم مسح وتصفير تنقيط شهر (${monthLabel}) للعامل (${empName}) بنجاح!`
      : `🧹 Pointage du mois (${monthLabel}) effacé pour (${empName})!`
    );
    setDeletingOrClearingEmployee(null);
  };

  const handleDeleteWorkerPermanently = () => {
    if (!deletingOrClearingEmployee) return;
    const empName = deletingOrClearingEmployee.name;
    deleteEmployee(deletingOrClearingEmployee.id);
    showNotification(lang === 'ar'
      ? `🗑️ تم حذف العامل (${empName}) نهائياً من قائمة موظفي الإقامة!`
      : `🗑️ Agent (${empName}) supprimé définitivement!`
    );
    setDeletingOrClearingEmployee(null);
  };

  // Quick Action: Pointage for Today (تسجيل الحضور اليوم لكافة العمال)
  const handlePointageToday = () => {
    if (isOwner) return;
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    
    // Check if today belongs to selectedMonth
    const targetDate = todayStr.startsWith(selectedMonth) ? todayStr : `${selectedMonth}-01`;

    const entries: Array<{ employeeId: string; date: string; status: PointageStatus }> = [];
    workerEmployees.forEach(emp => {
      entries.push({
        employeeId: emp.id,
        date: targetDate,
        status: 'present',
      });
    });

    batchSetPointageStatus(entries);
    showNotification(lang === 'ar' 
      ? `✅ تم بنجاح تسجيل حضور كافة العمال ليوم (${targetDate})!`
      : `✅ Présence enregistrée pour tous les agents le (${targetDate})!`
    );
  };

  // Quick Action: Auto-prefill 26 work days + 4 rest days for this month
  const handleAutoFillMonth = () => {
    if (isOwner) return;
    applyMonthDefaultPointage(selectedMonth);
    showNotification(lang === 'ar'
      ? `⚡ تم ملء الشهر بنظام (26 يوم عمل + 4 أيام راحة أسبوعية) لكافة العمال!`
      : `⚡ Remplissage automatique (26j travail + 4j repos) appliqué avec succès!`
    );
  };

  // Quick Action: Reset/Clear month
  const handleClearMonth = () => {
    if (isOwner) return;
    if (!window.confirm(lang === 'ar' ? 'هل أنت متأكد من مسح تنقيط هذا الشهر؟' : 'Voulez-vous réinitialiser le pointage de ce mois?')) {
      return;
    }
    clearMonthPointage(selectedMonth);
    showNotification(lang === 'ar' ? '🧹 تم مسح تنقيط هذا الشهر.' : 'Pointage réinitialisé.');
  };

  // Quick toggle on a cell click
  const handleCellClick = (employeeId: string, date: string, currentStatus?: PointageStatus) => {
    if (isOwner) return;
    const targetWorker = employees.find(e => e.id === employeeId);
    if (targetWorker) {
      const targetStart = getEmployeeEffectiveStartDate(targetWorker);
      if (date < targetStart) {
        showNotification(lang === 'ar'
          ? `⚠️ لا يمكن تنقيط هذا اليوم لأن تاريخ بدء عمل العامل هو: ${targetStart}`
          : `⚠️ Ce jour est antérieur à la date de début de travail (${targetStart})`
        );
        return;
      }
    }

    // Cycle order: undefined -> present -> absent -> rest -> leave_paid -> undefined
    let nextStatus: PointageStatus = 'present';
    if (!currentStatus) nextStatus = 'present';
    else if (currentStatus === 'present') nextStatus = 'absent';
    else if (currentStatus === 'absent') nextStatus = 'rest';
    else if (currentStatus === 'rest') nextStatus = 'leave_paid';
    else if (currentStatus === 'leave_paid') nextStatus = 'present';

    setPointageStatus(employeeId, date, nextStatus);
  };

  // Check if salary for this employee in this month is already paid into expenses
  const getSalaryPaidExpense = (emp: Employee) => {
    return expenses.find(e => {
      const matchesCat = e.category === 'worker_salaries' || e.category === 'syndic_fees';
      if (!matchesCat) return false;
      const dateMatches = (e.date && e.date.startsWith(selectedMonth)) || 
                          (e.invoiceRef && e.invoiceRef.includes(selectedMonth)) ||
                          (e.title && e.title.includes(selectedMonth));
      const empMatches = e.supplier.includes(emp.name) || e.title.includes(emp.name);
      return dateMatches && empMatches;
    });
  };

  // Handle Paying Salary directly into Expenses with detailed calculations
  const handleDirectPaySalary = (emp: Employee) => {
    if (isOwner) return;
    const advance = pointageAdvances[`${emp.id}_${selectedMonth}`] || 0;
    const bonus = pointageBonuses[`${emp.id}_${selectedMonth}`] || 0;
    const calc = calculateEmployeeSalary(emp, selectedMonth, pointageRecords, advance, bonus);

    const [y, m] = selectedMonth.split('-');
    const mName = lang === 'ar' ? (ARABIC_MONTH_NAMES[parseInt(m, 10) - 1] || m) : (FRENCH_MONTH_NAMES[parseInt(m, 10) - 1] || m);

    // Build explanatory title & notes
    const title = lang === 'ar'
      ? `أجرة العامل: ${emp.name} (${getRoleLabel(emp.role)}) عن شهر ${mName} ${y}`
      : `Salaire agent: ${emp.name} (${getRoleLabel(emp.role)}) mois ${mName} ${y}`;

    const notes = lang === 'ar'
      ? `حساب الأجرة حسب التنقيط: حضور ${calc.presentDays} يوم من أصل 26، راحة ${calc.restDays} أيام، غياب ${calc.absentDays} يوم (خصم: ${calc.totalAbsenceDeduction} درهم، الأجر اليومي: ${calc.dailyRate} درهم). صافي الأجر المؤدى: ${calc.netSalary} درهم.`
      : `Calcul d'assiduité: ${calc.presentDays}j présence sur 26, ${calc.restDays}j repos, ${calc.absentDays}j absence (déduction: ${calc.totalAbsenceDeduction} DH, taux: ${calc.dailyRate} DH/j). Net payé: ${calc.netSalary} DH.`;

    const invoiceRef = `SAL-PTG-${y}-${m}-${emp.id.slice(-4)}`;

    addExpense({
      category: 'worker_salaries',
      title,
      amount: calc.netSalary,
      buildingCode: 'ALL',
      date: `${selectedMonth}-28`,
      supplier: emp.name,
      invoiceRef,
      paidBy: lang === 'ar' ? 'مكتب السانديك (أمين المال)' : 'Bureau du Syndic (Trésorier)',
      paymentMethod: 'cash',
      notes,
    });

    showNotification(lang === 'ar'
      ? `💰 تم بنجاح صرف وتسجيل أجرة (${emp.name}) بمبلغ ${calc.netSalary.toLocaleString()} درهم في مصاريف الإقامة!`
      : `💰 Salaire de (${emp.name}) enregistré (${calc.netSalary.toLocaleString()} DH) dans les dépenses!`
    );
  };

  // Calculations for all workers in this month
  const calculations = useMemo(() => {
    return workerEmployees.map(emp => {
      const adv = pointageAdvances[`${emp.id}_${selectedMonth}`] || 0;
      const bon = pointageBonuses[`${emp.id}_${selectedMonth}`] || 0;
      const calc = calculateEmployeeSalary(emp, selectedMonth, pointageRecords, adv, bon);
      const existingExp = getSalaryPaidExpense(emp);
      return {
        emp,
        calc,
        existingExp,
      };
    });
  }, [workerEmployees, selectedMonth, pointageRecords, pointageAdvances, pointageBonuses, expenses]);

  // Global totals for banner
  const totalBaseSalaries = calculations.reduce((sum, item) => sum + item.calc.baseSalary, 0);
  const totalAbsences = calculations.reduce((sum, item) => sum + item.calc.absentDays, 0);
  const totalDeductions = calculations.reduce((sum, item) => sum + item.calc.totalAbsenceDeduction, 0);
  const totalNetPayable = calculations.reduce((sum, item) => sum + item.calc.netSalary, 0);
  const totalPresentDays = calculations.reduce((sum, item) => sum + item.calc.presentDays, 0);

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'security': return lang === 'ar' ? 'حارس أمن' : 'Sécurité';
      case 'cleaning': return lang === 'ar' ? 'عامل نظافة' : 'Nettoyage';
      case 'sweeper': return lang === 'ar' ? 'كناس' : 'Balayeur';
      case 'gardener': return lang === 'ar' ? 'بستاني وصيانة' : 'Jardinier';
      case 'technician': return lang === 'ar' ? 'تقني صيانة' : 'Technicien';
      case 'supervisor': return lang === 'ar' ? 'مشرف ميداني' : 'Superviseur';
      default: return role;
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'security': return <Shield className="w-3.5 h-3.5 text-indigo-600" />;
      case 'cleaning': return <Sparkles className="w-3.5 h-3.5 text-emerald-600" />;
      case 'sweeper': return <Brush className="w-3.5 h-3.5 text-lime-600" />;
      case 'gardener': return <Flower2 className="w-3.5 h-3.5 text-teal-600" />;
      case 'technician': return <Wrench className="w-3.5 h-3.5 text-amber-600" />;
      case 'supervisor': return <Eye className="w-3.5 h-3.5 text-cyan-600" />;
      default: return <UserCheck className="w-3.5 h-3.5 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 start-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-xs sm:text-sm font-bold">{notification}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-gradient-to-r from-white via-[#e9fbf8]/70 to-[#faf6f7] p-5 rounded-2xl border-2 border-[#92e8dd] shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd]">
              <Calendar className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              {lang === 'ar' ? 'جدول التنقيط اليومي للعمال وحساب الأجور (Pointage)' : 'Pointage Journalier & Calcul des Salaires'}
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            {lang === 'ar'
              ? 'مدة العمل المعتمدة 26 يوماً + 4 أيام راحة في الشهر = شهر كامل (مثلاً 2200 درهم). وينقص من الأجرة عند الغياب بمقدار (الراتب ÷ 26) عن كل يوم غياب.'
              : 'Base de calcul: 26 jours de travail + 4 jours de repos = Mois plein (ex: 2200 DH). Déduction automatique de (salaire ÷ 26) par jour d\'absence.'}
          </p>
        </div>

        {/* Month Selector & Main Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Month Selectors */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-[#92e8dd] shadow-2xs">
            <button
              type="button"
              onClick={() => setSelectedMonth('2026-05')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedMonth === '2026-05'                  ? 'bg-[#0a8591] text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {lang === 'ar' ? 'ماي 2026' : 'Mai 2026'}
            </button>
            <button
              type="button"
              onClick={() => setSelectedMonth('2026-09')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                selectedMonth === '2026-09'
                  ? 'bg-[#0a8591] text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {lang === 'ar' ? 'شتنبر 2026' : 'Sept 2026'}
            </button>
          </div>

          {/* Month Stepper */}
          <div className="flex items-center bg-white rounded-xl border border-[#92e8dd] shadow-2xs p-1">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg hover:bg-[#e9fbf8] text-slate-600 hover:text-[#0a8591] cursor-pointer"
              title={lang === 'ar' ? 'الشهر السابق' : 'Mois précédent'}
            >
              <ChevronRight className="w-4 h-4 rtl:rotate-0 rotate-180" />
            </button>
            <span className="px-3 text-xs sm:text-sm font-black text-slate-900 min-w-[130px] text-center font-mono">
              📅 {monthLabel}
            </span>
            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg hover:bg-[#e9fbf8] text-slate-600 hover:text-[#0a8591] cursor-pointer"
              title={lang === 'ar' ? 'الشهر التالي' : 'Mois suivant'}
            >
              <ChevronLeft className="w-4 h-4 rtl:rotate-0 rotate-180" />
            </button>
          </div>

          {!isOwner && (
            <>
              {/* Pointage Today */}
              <button
                type="button"
                id="btn-pointage-today"
                onClick={handlePointageToday}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black transition-all shadow-sm cursor-pointer"
                title={lang === 'ar' ? 'تسجيل حضور كافة العمال ليوم العمل الحالي' : 'Pointer la présence de tous les agents pour aujourd\'hui'}
              >
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'تنقيط اليوم ✔️' : 'Pointer Aujourd\'hui'}</span>
              </button>

              {/* Auto Fill Standard Month (26 Work + 4 Rest) */}
              <button
                type="button"
                id="btn-pointage-autofill"
                onClick={handleAutoFillMonth}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-black transition-all shadow-sm cursor-pointer"
                title={lang === 'ar' ? 'تعبئة الشهر كاملاً بنظام 26 يوم عمل و 4 أيام عطلة، وتعديل الغياب بسهولة' : 'Remplir automatiquement 26 jours de travail + 4 jours de repos'}
              >
                <Sparkles className="w-4 h-4 text-rose-200" />
                <span>{lang === 'ar' ? 'ملء آلي (26 عمل + 4 راحة) ⚡' : 'Auto (26j + 4j)'}</span>
              </button>
            </>
          )}

          {/* Export to Excel */}
          <button
            type="button"
            id="btn-pointage-excel"
            onClick={() => exportPointageToExcel(selectedMonth, workerEmployees, pointageRecords, lang, pointageAdvances, pointageBonuses)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-xs font-bold transition-all shadow-2xs cursor-pointer"
            title={lang === 'ar' ? 'تصدير جدول التنقيط وحساب الأجور كاملاً إلى Excel' : 'Exporter la feuille de pointage vers Excel'}
          >
            <Download className="w-4 h-4 text-emerald-700" />
            <span>{lang === 'ar' ? 'تصدير Excel 📗' : 'Excel'}</span>
          </button>

          {/* Print Sheet */}
          <button
            type="button"
            id="btn-pointage-print"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-xs font-bold transition-all shadow-2xs cursor-pointer"
            title={lang === 'ar' ? 'طباعة جدول التنقيط الشهري للتوقيع والمصادقة' : 'Imprimer la feuille de pointage'}
          >
            <Printer className="w-4 h-4 text-sky-700" />
            <span>{lang === 'ar' ? 'طباعة 🖨️' : 'Imprimer'}</span>
          </button>

          {!isOwner && (
            <button
              type="button"
              onClick={handleClearMonth}
              className="p-2 rounded-xl hover:bg-rose-50 text-slate-400 hover:text-rose-600 border border-transparent hover:border-rose-200 cursor-pointer"
              title={lang === 'ar' ? 'تفريغ ومسح تنقيط هذا الشهر' : 'Réinitialiser le pointage du mois'}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Legal & Calculation Rule Notice */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white p-4 sm:p-5 rounded-2xl border border-sky-800 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[11px] font-black border border-emerald-500/30">
                {lang === 'ar' ? 'نظام العمل والأجور المعتمد' : 'Règle de paie'}
              </span>
              <span className="text-xs text-sky-200 font-semibold">
                {lang === 'ar' ? '26 يوم عمل + 4 أيام راحة = 30 يوم (شهر كامل)' : '26j travail + 4j repos = 30j (Mois plein)'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {lang === 'ar' 
                ? 'العامل الذي يتقاضى مثلاً 2,200 درهم يكون أجره اليومي هو (2,200 ÷ 26 = 84.62 درهم). عند تسجيل غياب (A) يُخصم 84.62 درهم عن كل يوم غياب تلقائياً من راتب الشهر، وتُحسب أيام الراحة الأربعة (R) كأيام مؤداة قانونياً.'
                : 'Un ouvrier à 2,200 DH perçoit un taux de (2,200 ÷ 26 = 84.62 DH/j). Toute absence (A) déduit automatiquement 84.62 DH par jour, et les 4 jours de repos (R) sont rémunérés.'}
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs shrink-0 flex-wrap">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-200 border border-emerald-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span>{lang === 'ar' ? 'P = حاضر (يوم عمل)' : 'P = Présent'}</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-sky-500/20 text-sky-200 border border-sky-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
              <span>{lang === 'ar' ? 'R = راحة (4 أيام)' : 'R = Repos'}</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-rose-500/20 text-rose-200 border border-rose-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
              <span>{lang === 'ar' ? 'A = غياب (خصم الأجرة)' : 'A = Absence'}</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/20 text-amber-200 border border-amber-500/30">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span>{lang === 'ar' ? 'J = إجازة مبررة' : 'J = Justifié'}</span>
            </div>
          </div>
        </div>

        {/* Metric Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-white/10">
          <div className="bg-white/5 p-3 rounded-xl border border-white/10">
            <span className="text-[11px] text-sky-300 font-bold block mb-0.5">
              {lang === 'ar' ? '👷 العمال الخاضعون للتنقيط' : 'Effectif Ouvriers'}
            </span>
            <div className="text-lg sm:text-xl font-black text-white font-mono">
              {workerEmployees.length} <span className="text-xs font-normal">{lang === 'ar' ? 'عمال' : 'agents'}</span>
            </div>
          </div>

          <div className="bg-white/5 p-3 rounded-xl border border-white/10">
            <span className="text-[11px] text-emerald-300 font-bold block mb-0.5">
              {lang === 'ar' ? '✔️ مجموع أيام الحضور' : 'Total Présences'}
            </span>
            <div className="text-lg sm:text-xl font-black text-emerald-300 font-mono">
              {totalPresentDays} <span className="text-xs font-normal">{lang === 'ar' ? 'يوم' : 'j'}</span>
            </div>
          </div>

          <div className="bg-white/5 p-3 rounded-xl border border-white/10">
            <span className="text-[11px] text-rose-300 font-bold block mb-0.5">
              {lang === 'ar' ? '❌ أيام الغياب واقتطاعها' : 'Absences & Déductions'}
            </span>
            <div className="text-lg sm:text-xl font-black text-rose-300 font-mono">
              {totalAbsences} <span className="text-xs font-normal">{lang === 'ar' ? 'يوم' : 'j'}</span>
              <span className="text-xs font-semibold text-rose-200 ms-1">
                (-{totalDeductions.toLocaleString()} DH)
              </span>
            </div>
          </div>

          <div className="bg-emerald-600/30 p-3 rounded-xl border border-emerald-500/40">
            <span className="text-[11px] text-emerald-200 font-bold block mb-0.5">
              {lang === 'ar' ? '💰 صافي الأجور المستحقة للصرف' : 'Net des Salaires à Payer'}
            </span>
            <div className="text-lg sm:text-xl font-black text-emerald-200 font-mono">
              {totalNetPayable.toLocaleString()} <span className="text-xs">DH</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={lang === 'ar' ? 'بحث باسم العامل، رقم الهاتف، أو بطاقة التعريف الوطنية...' : 'Recherche agent, CIN, téléphone...'}
            className="w-full ps-9 pe-4 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
        </div>

        <div>
          <select
            value={filterRole}
            onChange={e => setFilterRole(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-cyan-500 font-medium"
          >
            <option value="ALL">{lang === 'ar' ? 'جميع مهام العمال (حراسة، نظافة، بستنة...)' : 'Tous les corps de métier'}</option>
            <option value="security">👮 {lang === 'ar' ? 'حراس الأمن' : 'Gardiens & Sécurité'}</option>
            <option value="cleaning">🧹 {lang === 'ar' ? 'عمال النظافة' : 'Agents de propreté'}</option>
            <option value="sweeper">🗑️ {lang === 'ar' ? 'الكناسون' : 'Balayeurs'}</option>
            <option value="gardener">🌿 {lang === 'ar' ? 'البستانيون' : 'Jardiniers'}</option>
            <option value="technician">🛠️ {lang === 'ar' ? 'التقنيون' : 'Techniciens'}</option>
          </select>
        </div>
      </div>

      {/* Interactive Pointage Table */}
      <div className="bg-white rounded-2xl border-2 border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 animate-pulse" />
            <h2 className="text-sm font-black text-slate-900">
              {lang === 'ar' ? `شبكة التنقيط اليومي لشهر: ${monthLabel}` : `Grille de pointage - ${monthLabel}`}
            </h2>
            <span className="text-xs text-slate-500 font-medium">
              ({monthDays.length} {lang === 'ar' ? 'يوماً في هذا الشهر' : 'jours'})
            </span>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center gap-2">
            <span>💡 {lang === 'ar' ? 'انقر على أي خانة لتبديل الحالة:' : 'Cliquez sur une case pour changer l\'état:'}</span>
            <span className="font-semibold text-emerald-700">P (حاضر)</span>
            <span>➜</span>
            <span className="font-semibold text-rose-700">A (غياب)</span>
            <span>➜</span>
            <span className="font-semibold text-sky-700">R (راحة)</span>
            <span>➜</span>
            <span className="font-semibold text-amber-700">J (مرخص)</span>
          </div>
        </div>

        {/* Scrollable Matrix Container */}
        <div className="overflow-x-auto max-w-full">
          <table className="w-full whitespace-nowrap text-start border-collapse text-xs select-none">
            <thead>
              <tr className="bg-slate-100 text-slate-700 border-b border-slate-300">
                {/* Fixed columns for Worker Info */}
                <th className="sticky start-0 z-20 bg-slate-100 px-3 py-2.5 text-start font-black text-slate-900 border-e border-slate-300 min-w-[180px] shadow-xs">
                  {lang === 'ar' ? 'العامل والوظيفة' : 'Agent & Fonction'}
                </th>
                {/* Actions column right in front of each worker */}
                <th className="px-2 py-2.5 text-center font-black text-slate-900 bg-slate-100 border-e border-slate-300 min-w-[135px]">
                  {lang === 'ar' ? 'تغيير / مسح' : 'Modifier / Effacer'}
                </th>
                <th className="px-2 py-2.5 text-center font-bold text-slate-800 border-e border-slate-200 min-w-[85px]">
                  {lang === 'ar' ? 'الراتب (DH)' : 'Salaire (DH)'}
                </th>
                <th className="px-2 py-2.5 text-center font-bold text-slate-800 border-e border-slate-300 min-w-[75px]">
                  {lang === 'ar' ? 'اليوم (DH)' : 'Tarif/j'}
                </th>

                {/* Day Columns (1 .. 28/29/30/31) */}
                {monthDays.map(day => {
                  const isWeekend = day.isSunday || day.isFriday;
                  return (
                    <th 
                      key={day.date}
                      className={`px-1 py-1 text-center font-mono border-e border-slate-200 min-w-[34px] ${
                        isWeekend ? 'bg-sky-50/80 text-sky-900 font-black' : 'text-slate-700'
                      }`}
                    >
                      <div className="text-[11px] leading-tight font-bold">{day.dayNum}</div>
                      <div className={`text-[9px] ${day.isSunday ? 'text-rose-600 font-black' : day.isFriday ? 'text-teal-700 font-bold' : 'text-slate-600'}`}>
                        {lang === 'ar' ? day.dayNameAr : day.dayNameFr}
                      </div>
                    </th>
                  );
                })}

                {/* Summary Headers */}
                <th className="px-2.5 py-2 text-center font-bold text-emerald-800 bg-emerald-50/80 border-e border-slate-200 min-w-[65px]">
                  {lang === 'ar' ? 'حضور (26)' : 'Prés. (26)'}
                </th>
                <th className="px-2.5 py-2 text-center font-bold text-sky-800 bg-sky-50/80 border-e border-slate-200 min-w-[60px]">
                  {lang === 'ar' ? 'راحة (4)' : 'Repos (4)'}
                </th>
                <th className="px-2.5 py-2 text-center font-bold text-rose-800 bg-rose-50/80 border-e border-slate-200 min-w-[60px]">
                  {lang === 'ar' ? 'غياب' : 'Absence'}
                </th>
                <th className="px-2.5 py-2 text-center font-bold text-rose-900 bg-rose-100/60 border-e border-slate-300 min-w-[85px]">
                  {lang === 'ar' ? 'خصم الغياب' : 'Déduction'}
                </th>
                <th className="px-3 py-2 text-center font-black text-slate-900 bg-emerald-100/80 border-e border-slate-300 min-w-[95px]">
                  {lang === 'ar' ? 'صافي الأجرة' : 'Net à Payer'}
                </th>
                <th className="px-3 py-2 text-center font-bold text-slate-800 bg-slate-100 min-w-[140px]">
                  {lang === 'ar' ? 'صرف الأجر وبطاقة الأداء' : 'Règlement & Fiche'}
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {calculations.length === 0 ? (
                <tr>
                  <td colSpan={monthDays.length + 10} className="py-12 text-center text-slate-500">
                    <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="font-bold">{lang === 'ar' ? 'لا يوجد عمال يطابقون شروط البحث الحالية' : 'Aucun ouvrier trouvé'}</p>
                  </td>
                </tr>
              ) : (
                calculations.map(({ emp, calc, existingExp }) => {
                  return (
                    <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Fixed Worker Info Column (Clean with no duplicate buttons) */}
                      <td className="sticky start-0 z-10 bg-white hover:bg-slate-50 px-3 py-2 border-e border-slate-300 shadow-2xs">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                            {getRoleIcon(emp.role)}
                          </div>
                          <div className="min-w-0">
                            <div className="font-black text-slate-900 truncate" title={emp.name}>
                              {emp.name}
                            </div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-1">
                              <span>{getRoleLabel(emp.role)}</span>
                              {emp.cin && <span className="font-mono text-slate-400">• {emp.cin}</span>}
                            </div>
                            {getEmployeeEffectiveStartDate(emp) && (
                              <div className="text-[9px] font-mono text-emerald-800 flex items-center gap-1 mt-0.5" title={lang === 'ar' ? 'تاريخ بدء العمل' : 'Date de début'}>
                                <Calendar className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                                <span>{lang === 'ar' ? 'بدء العمل:' : 'Début:'} {getEmployeeEffectiveStartDate(emp)}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Actions Column: Change & Delete / Clear (تغيير ومسح الوحيدة والرئيسية) */}
                      <td className="px-2 py-1.5 text-center border-e border-slate-300 bg-slate-50/60">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            disabled={isOwner}
                            onClick={() => handleOpenEdit(emp)}
                            className="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 active:bg-amber-200 text-amber-900 border border-amber-300 text-[11px] font-bold flex items-center gap-1 transition-all shadow-2xs hover:scale-105 active:scale-95 disabled:opacity-40 cursor-pointer"
                            title={lang === 'ar' ? `تغيير بيانات وراتب العامل: ${emp.name}` : `Modifier l'agent: ${emp.name}`}
                          >
                            <Pencil className="w-3 h-3 text-amber-700" />
                            <span>{lang === 'ar' ? 'تغيير' : 'Modifier'}</span>
                          </button>

                          <button
                            type="button"
                            disabled={isOwner}
                            onClick={() => handleOpenDeleteOrClear(emp)}
                            className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 active:bg-rose-200 text-rose-900 border border-rose-300 text-[11px] font-bold flex items-center gap-1 transition-all shadow-2xs hover:scale-105 active:scale-95 disabled:opacity-40 cursor-pointer"
                            title={lang === 'ar' ? `مسح تنقيط أو حذف العامل: ${emp.name}` : `Effacer pointage ou supprimer: ${emp.name}`}
                          >
                            <Trash2 className="w-3 h-3 text-rose-700" />
                            <span>{lang === 'ar' ? 'مسح' : 'Effacer'}</span>
                          </button>
                        </div>
                      </td>

                      {/* Base Salary */}
                      <td className="px-2 py-2 text-center font-mono font-bold text-slate-800 border-e border-slate-200 bg-slate-50/50">
                        {calc.baseSalary.toLocaleString()}
                      </td>

                      {/* Daily Rate */}
                      <td className="px-2 py-2 text-center font-mono text-[11px] font-semibold text-slate-600 border-e border-slate-300 bg-slate-50/50">
                        {calc.dailyRate}
                      </td>

                      {/* Days Matrix */}
                      {monthDays.map(day => {
                        const effectiveStart = getEmployeeEffectiveStartDate(emp);
                        const isBeforeStart = day.date < effectiveStart;

                        if (isBeforeStart) {
                          return (
                            <td 
                              key={day.date}
                              className="p-0.5 text-center border-e border-slate-200 bg-slate-100/60"
                            >
                              <button
                                type="button"
                                disabled={isOwner}
                                onClick={() => {
                                  showNotification(lang === 'ar'
                                    ? `⚠️ لا يمكن تنقيط هذا اليوم لأن تاريخ بدء عمل العامل هو: ${effectiveStart}`
                                    : `⚠️ Ce jour est antérieur à la date de début de travail (${effectiveStart})`
                                  );
                                }}
                                className="w-7 h-7 rounded-lg text-[10px] font-mono mx-auto flex items-center justify-center bg-slate-200/50 text-slate-400 cursor-not-allowed hover:bg-slate-300/50 transition-colors"
                                title={`${emp.name} - ${day.date}: ${
                                  lang === 'ar' 
                                    ? `العامل لم يبدأ العمل بعد (تاريخ بدء العمل: ${effectiveStart})` 
                                    : `Non encore embauché (Début: ${effectiveStart})`
                                }`}
                              >
                                —
                              </button>
                            </td>
                          );
                        }

                        const key = getPointageKey(emp.id, day.date);
                        const status = pointageRecords[key];
                        const isWeekend = day.isSunday || day.isFriday;

                        let badgeBg = 'bg-slate-100 text-slate-400 hover:bg-slate-200';
                        let label = '-';

                        if (status === 'present') {
                          badgeBg = 'bg-emerald-500 text-white font-black shadow-2xs hover:bg-emerald-600';
                          label = 'P';
                        } else if (status === 'rest') {
                          badgeBg = 'bg-sky-500 text-white font-black shadow-2xs hover:bg-sky-600';
                          label = 'R';
                        } else if (status === 'absent') {
                          badgeBg = 'bg-rose-600 text-white font-black shadow-2xs hover:bg-rose-700 animate-pulse';
                          label = 'A';
                        } else if (status === 'leave_paid') {
                          badgeBg = 'bg-amber-500 text-white font-black shadow-2xs hover:bg-amber-600';
                          label = 'J';
                        }

                        return (
                          <td 
                            key={day.date}
                            className={`p-0.5 text-center border-e border-slate-200 ${
                              isWeekend ? 'bg-sky-50/40' : ''
                            }`}
                          >
                            <button
                              type="button"
                              disabled={isOwner}
                              onClick={() => handleCellClick(emp.id, day.date, status)}
                              className={`w-7 h-7 rounded-lg text-[11px] font-mono transition-all flex items-center justify-center mx-auto cursor-pointer ${badgeBg} ${
                                isOwner ? 'cursor-default' : ''
                              }`}
                              title={`${emp.name} - ${day.date}: ${
                                status === 'present' ? 'حاضر (Présent)' :
                                status === 'rest' ? 'راحة أسبوعية (Repos)' :
                                status === 'absent' ? 'غياب غير مبرر (Absence)' :
                                status === 'leave_paid' ? 'رخصة مبررة (Congé)' : 'غير محدد (-)'
                              }`}
                            >
                              {label}
                            </button>
                          </td>
                        );
                      })}

                      {/* Summary: Present Days */}
                      <td className="px-2 py-2 text-center font-mono font-bold text-emerald-800 bg-emerald-50/40 border-e border-slate-200">
                        {calc.presentDays} <span className="text-[10px] text-slate-400">/26</span>
                      </td>

                      {/* Summary: Rest Days */}
                      <td className="px-2 py-2 text-center font-mono font-bold text-sky-800 bg-sky-50/40 border-e border-slate-200">
                        {calc.restDays}
                      </td>

                      {/* Summary: Absent Days */}
                      <td className={`px-2 py-2 text-center font-mono font-bold border-e border-slate-200 ${
                        calc.absentDays > 0 ? 'bg-rose-100 text-rose-800' : 'text-slate-500'
                      }`}>
                        {calc.absentDays}
                      </td>

                      {/* Summary: Absence Deduction */}
                      <td className={`px-2 py-2 text-center font-mono font-bold border-e border-slate-300 ${
                        calc.totalAbsenceDeduction > 0 ? 'text-rose-700 bg-rose-50/80 font-black' : 'text-slate-400'
                      }`}>
                        {calc.totalAbsenceDeduction > 0 ? `-${calc.totalAbsenceDeduction.toLocaleString()} DH` : '0 DH'}
                      </td>

                      {/* Summary: Net Salary */}
                      <td className="px-3 py-2 text-center font-mono font-black text-emerald-900 bg-emerald-50 text-sm border-e border-slate-300">
                        {calc.netSalary.toLocaleString()} <span className="text-[10px] font-normal">DH</span>
                      </td>

                      {/* Actions */}
                      <td className="px-2 py-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {existingExp ? (
                            <div 
                              className="px-2 py-1 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center gap-1 border border-emerald-300"
                              title={`${lang === 'ar' ? 'تم صرف هذا الأجر في مصاريف الإقامة بتاريخ' : 'Payé le'}: ${existingExp.date}`}
                            >
                              <Check className="w-3 h-3 text-emerald-700" />
                              <span>{lang === 'ar' ? 'خالص بالمصاريف' : 'Payé'}</span>
                            </div>
                          ) : !isOwner ? (
                            <button
                              type="button"
                              onClick={() => handleDirectPaySalary(emp)}
                              className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-[10px] flex items-center gap-1 transition-all shadow-2xs cursor-pointer"
                              title={lang === 'ar' ? 'صرف وتسجيل صافي الأجر المحتسب فوراً في المصاريف' : 'Imputer le salaire calculé dans les dépenses'}
                            >
                              <CreditCard className="w-3 h-3 text-emerald-400" />
                              <span>{lang === 'ar' ? 'صرف الأجر' : 'Payer'}</span>
                            </button>
                          ) : null}

                          {/* Print/View Payslip button */}
                          <button
                            type="button"
                            onClick={() => setSelectedEmployeeForPayslip(emp)}
                            className="p-1 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-sky-700 border border-slate-200 cursor-pointer"
                            title={lang === 'ar' ? 'معاينة وطباعة بطاقة الأجر الفردية وكشف الحضور' : 'Bulletin de paie'}
                          >
                            <FileText className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Notes & Legend */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="font-bold text-slate-900">{lang === 'ar' ? 'دليل الرموز:' : 'Légende:'}</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-500 inline-block text-center text-white text-[9px] leading-3 font-mono font-bold">P</span> = {lang === 'ar' ? 'حاضر (يوم عمل)' : 'Présent'}</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-sky-500 inline-block text-center text-white text-[9px] leading-3 font-mono font-bold">R</span> = {lang === 'ar' ? 'راحة أسبوعية (4 أيام مؤداة)' : 'Repos hebdomadaire payé'}</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-rose-600 inline-block text-center text-white text-[9px] leading-3 font-mono font-bold">A</span> = {lang === 'ar' ? 'غياب غير مبرر (يُخصم من الأجر)' : 'Absence (Déduite du salaire)'}</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-amber-500 inline-block text-center text-white text-[9px] leading-3 font-mono font-bold">J</span> = {lang === 'ar' ? 'رخصة مبررة' : 'Congé justifié'}</span>

            {lastSavedTime && (
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300 ms-auto">
                <Check className="w-3 h-3 text-emerald-600" />
                <span>{lang === 'ar' ? `آخر حفظ للخانات: ${lastSavedTime}` : `Dernier enregistrement: ${lastSavedTime}`}</span>
              </span>
            )}
          </div>

          <div className="font-mono text-slate-500">
            {lang === 'ar' ? 'نظام الحساب: الأجر = (الراتب ÷ 26) × الحضور' : 'Calcul: Salaire = (Base ÷ 26) × Présence'}
          </div>
        </div>
      </div>

      {/* Bottom Save Action Box (خانة واحدة أسفل الصفحة عليها كلمة حفظ فقط) */}
      {!isOwner && (
        <div className="flex flex-col items-center justify-center pt-2 pb-8">
          <button
            type="button"
            id="btn-save-pointage-bottom"
            onClick={handleSaveAllPointage}
            className="px-14 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black text-lg shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center cursor-pointer border-2 border-emerald-500 min-w-[200px]"
          >
            <span>{lang === 'ar' ? 'حفظ' : 'Enregistrer'}</span>
          </button>
          {lastSavedTime && (
            <p className="text-xs text-emerald-700 font-bold mt-2 flex items-center gap-1">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? `تم الحفظ بنجاح (الساعة ${lastSavedTime})` : `Enregistré avec succès (${lastSavedTime})`}</span>
            </p>
          )}
        </div>
      )}

      {/* Payslip Modal (بطاقة الأجر الفردية وكشف الحضور) */}
      {selectedEmployeeForPayslip && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border-2 border-slate-300 overflow-hidden my-6">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-400" />
                <h3 className="font-black text-base">
                  {lang === 'ar' ? 'بيان الحضور وبطاقة الأداء الشهري (Bulletin de Paie)' : 'Bulletin de Paie & Relevé d\'Assiduité'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedEmployeeForPayslip(null)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Payslip Body */}
            <div className="p-6 space-y-6" id="printable-worker-payslip">
              {/* Residence Header */}
              <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
                <div>
                  <h4 className="text-lg font-black text-slate-900">
                    {lang === 'ar' ? 'اتحاد الملاك المشتركين - إقامة المرجان' : 'Syndicat des Copropriétaires - Résidence Al Morjane'}
                  </h4>
                  <p className="text-xs text-slate-600">
                    {lang === 'ar' ? 'مكتب السانديك وإدارة المرافق والأعوان' : 'Bureau du Syndic & Gestion du Personnel'}
                  </p>
                  <p className="text-xs text-slate-500 font-mono">
                    {lang === 'ar' ? 'أبواب مراكش، مراكش، المملكة المغربية' : 'Abouab Marrakech, Marrakech, Royaume du Maroc'}
                  </p>
                </div>
                <div className="text-end font-mono">
                  <div className="text-xs font-bold text-slate-500">{lang === 'ar' ? 'فترة العمل' : 'Période'}</div>
                  <div className="text-sm font-black text-slate-900">{monthLabel}</div>
                </div>
              </div>

              {(() => {
                const emp = selectedEmployeeForPayslip;
                const adv = pointageAdvances[`${emp.id}_${selectedMonth}`] || 0;
                const bon = pointageBonuses[`${emp.id}_${selectedMonth}`] || 0;
                const calc = calculateEmployeeSalary(emp, selectedMonth, pointageRecords, adv, bon);

                return (
                  <>
                    {/* Worker Info Card */}
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                      <div>
                        <span className="text-slate-500 block">{lang === 'ar' ? 'اسم العامل:' : 'Nom:'}</span>
                        <span className="font-bold text-slate-900 text-sm">{emp.name}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">{lang === 'ar' ? 'المهمة / الوظيفة:' : 'Fonction:'}</span>
                        <span className="font-bold text-emerald-800">{getRoleLabel(emp.role)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">{lang === 'ar' ? 'تاريخ بدء العمل:' : 'Début de travail:'}</span>
                        <span className="font-bold text-slate-900 font-mono">{emp.startDate || '-'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">{lang === 'ar' ? 'رقم ب.ت.و (CIN):' : 'CIN:'}</span>
                        <span className="font-bold text-slate-900 font-mono">{emp.cin || '-'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">{lang === 'ar' ? 'الهاتف:' : 'Téléphone:'}</span>
                        <span className="font-bold text-slate-900 font-mono">{emp.phone}</span>
                      </div>
                    </div>

                    {/* Breakdown Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full whitespace-nowrap text-xs border border-slate-300 divide-y divide-slate-300">
                        <thead className="bg-slate-100 font-bold text-slate-800">
                        <tr>
                          <th className="p-2.5 text-start">{lang === 'ar' ? 'البيان / عنصر الاحتساب' : 'Rubrique'}</th>
                          <th className="p-2.5 text-center">{lang === 'ar' ? 'المدة / العدد' : 'Nombre / Taux'}</th>
                          <th className="p-2.5 text-end">{lang === 'ar' ? 'المبلغ المستحق (DH)' : 'Montant (DH)'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="p-2.5">
                            <span className="font-bold text-slate-900">{lang === 'ar' ? 'الراتب الأساسي المعتمد' : 'Salaire contractuel de base'}</span>
                            <span className="block text-[11px] text-slate-500">{lang === 'ar' ? '26 يوم عمل + 4 أيام راحة أسبوعية' : 'Base de 26j travail + 4j repos'}</span>
                          </td>
                          <td className="p-2.5 text-center font-mono">30 {lang === 'ar' ? 'يوم' : 'j'}</td>
                          <td className="p-2.5 text-end font-mono font-bold">{calc.baseSalary.toFixed(2)}</td>
                        </tr>

                        <tr>
                          <td className="p-2.5">
                            <span className="font-semibold text-slate-800">{lang === 'ar' ? 'سعر اليوم الواحد' : 'Taux journalier'}</span>
                            <span className="block text-[11px] text-slate-500">{calc.baseSalary} ÷ {STANDARD_WORK_DAYS} {lang === 'ar' ? 'يوم عمل' : 'jours'}</span>
                          </td>
                          <td className="p-2.5 text-center font-mono">1 {lang === 'ar' ? 'يوم' : 'j'}</td>
                          <td className="p-2.5 text-end font-mono text-slate-600">{calc.dailyRate.toFixed(2)}</td>
                        </tr>

                        <tr>
                          <td className="p-2.5">
                            <span className="font-semibold text-emerald-800">{lang === 'ar' ? 'أيام الحضور الفعلية' : 'Jours de présence effective'}</span>
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold text-emerald-700">{calc.presentDays} {lang === 'ar' ? 'يوم' : 'j'}</td>
                          <td className="p-2.5 text-end font-mono text-emerald-700">✔️</td>
                        </tr>

                        <tr>
                          <td className="p-2.5">
                            <span className="font-semibold text-sky-800">{lang === 'ar' ? 'أيام الراحة الأسبوعية المؤداة' : 'Jours de repos légal rémunérés'}</span>
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold text-sky-700">{calc.restDays} {lang === 'ar' ? 'أيام' : 'j'}</td>
                          <td className="p-2.5 text-end font-mono text-sky-700">✔️</td>
                        </tr>

                        {calc.absentDays > 0 && (
                          <tr className="bg-rose-50/70">
                            <td className="p-2.5">
                              <span className="font-bold text-rose-900">{lang === 'ar' ? 'خصم أيام الغياب غير المبرر' : 'Déduction pour absence injustifiée'}</span>
                              <span className="block text-[11px] text-rose-700">{calc.absentDays} × {calc.dailyRate} {lang === 'ar' ? 'درهم' : 'DH'}</span>
                            </td>
                            <td className="p-2.5 text-center font-mono font-bold text-rose-700">{calc.absentDays} {lang === 'ar' ? 'يوم' : 'j'}</td>
                            <td className="p-2.5 text-end font-mono font-bold text-rose-700">-{calc.totalAbsenceDeduction.toFixed(2)}</td>
                          </tr>
                        )}
                      </tbody>
                      <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-400">
                        <tr>
                          <td colSpan={2} className="p-3 text-sm font-black text-slate-900">
                            {lang === 'ar' ? 'صافي الأجرة المستحقة للأداء (Net à Payer):' : 'Net à payer:'}
                          </td>
                          <td className="p-3 text-end font-mono text-base font-black text-emerald-800">
                            {calc.netSalary.toLocaleString()} DH
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                    </div>

                    {/* Signature Blocks */}
                    <div className="grid grid-cols-2 gap-8 pt-8 text-center text-xs">
                      <div className="border-t border-slate-300 pt-2">
                        <span className="font-bold text-slate-700 block">{lang === 'ar' ? 'تأكيد واستلام العامل:' : 'Signature de l\'agent:'}</span>
                        <p className="text-[10px] text-slate-400 mt-1">{lang === 'ar' ? 'أشهد أنني استلمت المبلغ المذكور أعلاه' : 'Reçu conforme'}</p>
                        <div className="h-12" />
                        <span className="text-slate-400 font-mono">({emp.name})</span>
                      </div>

                      <div className="border-t border-slate-300 pt-2">
                        <span className="font-bold text-slate-700 block">{lang === 'ar' ? 'تأشيرة وخاتم السانديك / أمين المال:' : 'Cachet du Syndic / Trésorier:'}</span>
                        <p className="text-[10px] text-slate-400 mt-1">{lang === 'ar' ? 'تمت المصادقة وصرف المستحقات' : 'Validé pour paiement'}</p>
                        <div className="h-12" />
                        <span className="text-slate-400 font-mono">(Bureau Syndic)</span>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedEmployeeForPayslip(null)}
                className="px-4 py-2 rounded-xl bg-white hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all border border-slate-300 cursor-pointer"
              >
                {lang === 'ar' ? 'إغلاق' : 'Fermer'}
              </button>

              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>{lang === 'ar' ? 'طباعة بيان الأجر 🖨️' : 'Imprimer'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Worker Modal (نافذة تغيير وتعديل بيانات وراتب العامل) */}
      {editingEmployee && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border-2 border-slate-300 overflow-hidden my-6">
            {/* Modal Header */}
            <div className="bg-amber-600 text-white p-4 flex items-center justify-between border-b border-amber-700">
              <div className="flex items-center gap-2">
                <Pencil className="w-5 h-5 text-amber-100" />
                <h3 className="font-black text-base">
                  {lang === 'ar' ? `تغيير وتعديل بيانات العامل: ${editingEmployee.name}` : `Modifier l'agent: ${editingEmployee.name}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1 rounded-lg hover:bg-amber-700 text-amber-100 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Edit Form */}
            <form onSubmit={handleSaveEdit} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Full Name */}
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'الاسم الكامل للعامل *' : 'Nom complet de l\'agent *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>

                {/* Role / Job */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'الوظيفة / المهمة *' : 'Fonction / Métier *'}
                  </label>
                  <select
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value as Employee['role'])}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  >
                    <option value="security">👮 {lang === 'ar' ? 'حارس أمن' : 'Gardien & Sécurité'}</option>
                    <option value="cleaning">🧹 {lang === 'ar' ? 'عامل نظافة' : 'Agent de propreté'}</option>
                    <option value="sweeper">🗑️ {lang === 'ar' ? 'كناس' : 'Balayeur'}</option>
                    <option value="gardener">🌿 {lang === 'ar' ? 'بستاني' : 'Jardinier'}</option>
                    <option value="technician">🛠️ {lang === 'ar' ? 'تقني صيانة' : 'Technicien'}</option>
                    <option value="supervisor">👔 {lang === 'ar' ? 'مشرف ميداني' : 'Superviseur'}</option>
                  </select>
                </div>

                {/* Base Salary */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'الراتب الشهري الأساسي (DH) *' : 'Salaire mensuel de base (DH) *'}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      required
                      min="0"
                      step="50"
                      value={editSalary}
                      onChange={(e) => setEditSalary(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                    <span className="absolute end-3 top-2 text-slate-400 font-bold text-[11px]">DH</span>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {lang === 'ar' ? 'يُقسّم على 26 لحساب سعر اليوم اليومي تلقائياً' : 'Divisé par 26 pour le taux journalier'}
                  </span>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'رقم الهاتف' : 'Téléphone'}
                  </label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="06XXXXXXXX"
                  />
                </div>

                {/* CIN */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'رقم ب.ت.و (CIN)' : 'N° CIN'}
                  </label>
                  <input
                    type="text"
                    value={editCin}
                    onChange={(e) => setEditCin(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono uppercase text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="AXXXXXX"
                  />
                </div>

                {/* Start Date */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'تاريخ بدء العمل *' : 'Date de début de travail *'}
                  </label>
                  <input
                    type="date"
                    value={editStartDate}
                    onChange={(e) => setEditStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    {lang === 'ar' ? 'يُحتسب تنقيط وأيام العمل ابتداءً من هذا التاريخ' : 'Pointage calculé à partir de cette date'}
                  </span>
                </div>

                {/* Shift */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'الوردية / أوقات العمل' : 'Horaire / Shift'}
                  </label>
                  <input
                    type="text"
                    value={editShift}
                    onChange={(e) => setEditShift(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="08:00 - 16:00"
                  />
                </div>

                {/* Assigned Building */}
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'العمارة / مكان العمل' : 'Bâtiment assigné'}
                  </label>
                  <select
                    value={editAssignedBuilding}
                    onChange={(e) => setEditAssignedBuilding(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                  >
                    <option value="">{lang === 'ar' ? 'كامل الإقامة' : 'Toute la résidence'}</option>
                    <option value="البوابة الرئيسية">{lang === 'ar' ? 'البوابة الرئيسية' : 'Porte principale'}</option>
                    {buildings.map(b => (
                      <option key={b.code} value={b.name}>{b.name} ({b.code})</option>
                    ))}
                  </select>
                </div>

                {/* Status */}
                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-bold mb-1">
                    {lang === 'ar' ? 'حالة العامل' : 'Statut de l\'agent'}
                  </label>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="editStatus"
                        value="active"
                        checked={editStatus === 'active'}
                        onChange={() => setEditStatus('active')}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className="font-bold text-emerald-800">{lang === 'ar' ? 'نشط ومستمر في العمل' : 'Actif en poste'}</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="editStatus"
                        value="leave"
                        checked={editStatus === 'leave'}
                        onChange={() => setEditStatus('leave')}
                        className="text-amber-600 focus:ring-amber-500"
                      />
                      <span className="font-bold text-amber-800">{lang === 'ar' ? 'في عطلة / متوقف مؤقتاً' : 'En congé / Inactif'}</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Form Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingEmployee(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-black text-xs flex items-center gap-1.5 shadow-sm hover:scale-105 active:scale-95 transition-all cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ التغييرات' : 'Enregistrer'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete / Clear Pointage Modal (نافذة مسح تنقيط الشهر أو حذف العامل) */}
      {deletingOrClearingEmployee && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border-2 border-rose-300 overflow-hidden my-6">
            {/* Modal Header */}
            <div className="bg-rose-700 text-white p-4 flex items-center justify-between border-b border-rose-800">
              <div className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-100" />
                <h3 className="font-black text-base">
                  {lang === 'ar' ? `خيارات المسح للعامل: ${deletingOrClearingEmployee.name}` : `Options d'effacement: ${deletingOrClearingEmployee.name}`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setDeletingOrClearingEmployee(null)}
                className="p-1 rounded-lg hover:bg-rose-800 text-rose-100 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-lg shrink-0">
                  {getRoleIcon(deletingOrClearingEmployee.role)}
                </div>
                <div>
                  <h4 className="font-black text-slate-900 text-sm">{deletingOrClearingEmployee.name}</h4>
                  <p className="text-slate-500">{getRoleLabel(deletingOrClearingEmployee.role)} • {deletingOrClearingEmployee.salary.toLocaleString()} DH</p>
                </div>
              </div>

              <p className="text-slate-600 leading-relaxed font-semibold">
                {lang === 'ar' 
                  ? 'اختر نوع العملية التي ترغب بالقيام بها لهذا العامل:' 
                  : 'Choisissez le type d\'opération à effectuer pour cet agent :'}
              </p>

              {/* Option 1: Clear month pointage only */}
              <div className="p-4 rounded-xl border-2 border-amber-200 bg-amber-50/50 hover:bg-amber-50 transition-all space-y-2">
                <div className="flex items-center gap-2 text-amber-900 font-black text-sm">
                  <Eraser className="w-4 h-4 text-amber-600" />
                  <span>{lang === 'ar' ? `1. مسح تنقيط شهر (${monthLabel}) فقط` : `1. Effacer le pointage de (${monthLabel})`}</span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {lang === 'ar'
                    ? `يقوم بتصفير كافة أيام الحضور والغياب المسجلة لهذا العامل في شهر ${monthLabel} للبدء من جديد، مع الإبقاء على العامل في النظام.`
                    : `Réinitialise toutes les cases de présence/absence du mois en cours pour cet agent, sans le supprimer.`}
                </p>
                <button
                  type="button"
                  onClick={handleClearThisWorkerMonth}
                  className="w-full mt-2 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                >
                  <Eraser className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'مسح وتصفير تنقيط هذا الشهر فقط 🧹' : 'Effacer le pointage du mois'}</span>
                </button>
              </div>

              {/* Option 2: Delete worker permanently */}
              <div className="p-4 rounded-xl border-2 border-rose-200 bg-rose-50/50 hover:bg-rose-50 transition-all space-y-2">
                <div className="flex items-center gap-2 text-rose-900 font-black text-sm">
                  <UserX className="w-4 h-4 text-rose-600" />
                  <span>{lang === 'ar' ? '2. مسح وحذف العامل نهائياً من الإقامة' : '2. Supprimer définitivement l\'agent'}</span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {lang === 'ar'
                    ? 'يقوم بحذف العامل وبياناته بالكامل من قاعدة بيانات عمال وموظفي الإقامة.'
                    : 'Supprime complètement l\'agent de la base de données des employés de la résidence.'}
                </p>
                
                {!confirmPermanentDelete ? (
                  <button
                    type="button"
                    onClick={() => setConfirmPermanentDelete(true)}
                    className="w-full mt-2 py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'حذف العامل نهائياً من النظام 🗑️' : 'Supprimer définitivement l\'agent'}</span>
                  </button>
                ) : (
                  <div className="p-3 bg-white rounded-lg border border-rose-300 space-y-2 animate-in fade-in">
                    <p className="text-rose-700 font-bold text-[11px] text-center">
                      {lang === 'ar' ? '⚠️ هل أنت متأكد تماماً من حذف هذا العامل؟' : '⚠️ Êtes-vous sûr de vouloir supprimer cet agent ?'}
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setConfirmPermanentDelete(false)}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] cursor-pointer"
                      >
                        {lang === 'ar' ? 'تراجع' : 'Annuler'}
                      </button>
                      <button
                        type="button"
                        onClick={handleDeleteWorkerPermanently}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-rose-700 hover:bg-rose-800 text-white font-black text-[11px] flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>{lang === 'ar' ? 'نعم، تأكيد الحذف' : 'Confirmer la suppression'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Close Dialog */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setDeletingOrClearingEmployee(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  {lang === 'ar' ? 'إغلاق' : 'Fermer'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
