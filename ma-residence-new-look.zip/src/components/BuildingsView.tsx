import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Building } from '../types';
import { Building2, Plus, Search, Phone, User, Home, Trash2, Edit2, Check, X, Lock } from 'lucide-react';
import { Building2 as HeaderIcon } from 'lucide-react';

export const BuildingsView: React.FC = () => {
  const { t, lang, currentUser, buildings, apartments, addBuilding, updateBuilding, deleteBuilding, setActiveSection } = useApp();
  
  const isOwner = currentUser?.role === 'resident';

  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form fields
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [floors, setFloors] = useState(3);
  const [apartmentsCount, setApartmentsCount] = useState(16);
  const [managerName, setManagerName] = useState('');
  const [managerPhone, setManagerPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [selectedComplex, setSelectedComplex] = useState<string>('ALL');

  const handleOpenNew = () => {
    if (isOwner) return;
    setEditingId(null);
    setCode(`GH 44 A`);
    setName(`عمارة GH 44 A`);
    setFloors(3);
    setApartmentsCount(16);
    setManagerName('');
    setManagerPhone('');
    setNotes('المدخل A');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (b: Building) => {
    if (isOwner) return;
    setEditingId(b.id);
    setCode(b.code);
    setName(b.name);
    setFloors(b.floors);
    setApartmentsCount(b.apartmentsCount);
    setManagerName(b.managerName);
    setManagerPhone(b.managerPhone);
    setNotes(b.notes || '');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!code.trim() || !name.trim()) return;

    if (editingId) {
      updateBuilding(editingId, {
        code,
        name,
        floors: Number(floors),
        apartmentsCount: Number(apartmentsCount),
        managerName,
        managerPhone,
        notes,
      });
    } else {
      addBuilding({
        code,
        name,
        floors: Number(floors),
        apartmentsCount: Number(apartmentsCount),
        managerName,
        managerPhone,
        notes,
      });
    }
    setIsFormOpen(false);
  };

  const complexesList = ['GH 34', 'GH 35', 'GH 36', 'GH 37', 'GH 38', 'GH 39', 'GH 40', 'GH 41', 'GH 42', 'GH 43'];

  const filteredBuildings = buildings.filter(b => {
    const matchesSearch = 
      b.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.managerName.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedComplex === 'ALL') return true;
    if (selectedComplex === 'A_ONLY') return b.code.endsWith('A');
    if (selectedComplex === 'B_ONLY') return b.code.endsWith('B');
    return b.code.startsWith(selectedComplex);
  });

  return (
    <div className="space-y-6">
      {/* Architecture Info Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#0f172a] via-[#0a8591] to-[#1e3a8a] text-white shadow-sm border border-[#0d5262]/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/15 text-amber-300 font-black flex items-center justify-center text-base shrink-0 border border-white/25">
            20
          </div>
          <div>
            <div className="font-extrabold text-sm flex items-center gap-2">
              <span>{lang === 'ar' ? 'الهيكلة المعمارية لإقامة المرجان:' : 'Structure Architecturale :'}</span>
              <span className="text-amber-300 font-mono text-xs px-2 py-0.5 rounded bg-black/35 border border-white/20">
                10 كتل × 2 عمارات (A و B) = 20 عمارة
              </span>
            </div>
            <p className="text-xs text-rose-100/90 mt-0.5">
              {lang === 'ar' 
                ? 'كل كتلة تضم عمارتين توأمين (عمارة GH A وعمارة GH B)، كل عمارة تحتوي على 3 طوابق و 16 شقة (المجموع: 319 شقة سكنية + 1 مكتب السانديك).'
                : '10 blocs comprenant chacun 2 immeubles (A et B) de 3 étages et 16 appartements (Total : 20 immeubles, 319 logements + 1 bureau syndic).'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold shrink-0">
          <span className="px-3 py-1.5 rounded-xl bg-white/15 border border-white/25 text-white">
            {buildings.length} {lang === 'ar' ? 'عمارة مسجلة' : 'immeubles'}
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold">
            {apartments.length} {lang === 'ar' ? 'شقة' : 'lots'}
          </span>
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-3"><span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-400 to-indigo-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span><h1 className="text-xl sm:text-2xl font-bold text-slate-900">{t.buildings.title}</h1></div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">{t.buildings.subtitle}</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
          <button
            id="btn-goto-financial-control"
            type="button"
            onClick={() => setActiveSection('financial-control')}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-[#e9fbf8] hover:bg-[#92e8dd] text-[#0a8591] border border-[#92e8dd] text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            <span>📊</span>
            <span>{lang === 'ar' ? 'جدول المتابعة المالية في لوحة التحكم' : 'Suivi Financier (Tableau de Bord)'}</span>
          </button>

          {!isOwner ? (
            <button
              onClick={handleOpenNew}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.buildings.addBtn}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>{lang === 'ar' ? 'وضع الاطلاع فقط' : 'Mode Consultation'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Form Modal / Box */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-[#0a8591] shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-[#0a8591] flex items-center gap-2">
              <Building2 className="w-5 h-5 text-[#0a8591]" />
              <span>{editingId ? t.common.edit : t.buildings.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.code} *</label>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={e => setCode(e.target.value)}
                  placeholder="GH34"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.name} *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="عمارة 34 / Immeuble 34"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.floors}</label>
                <input
                  type="number"
                  min="1"
                  value={floors}
                  onChange={e => setFloors(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.apartments}</label>
                <input
                  type="number"
                  min="1"
                  value={apartmentsCount}
                  onChange={e => setApartmentsCount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.manager}</label>
                <input
                  type="text"
                  value={managerName}
                  onChange={e => setManagerName(e.target.value)}
                  placeholder={lang === 'ar' ? 'مسؤول العمارة أو السانديك' : 'Responsable d’immeuble ou Syndic'}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.buildings.phone}</label>
                <input
                  type="tel"
                  value={managerPhone}
                  onChange={e => setManagerPhone(e.target.value)}
                  placeholder="+212 661-123456"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات وموقع العمارة</label>
              <input
                type="text"
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="المدخل الرئيسي الشمالي، قرب الحديقة..."
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search & Complex Filter Pills */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute start-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={t.buildings.searchPlaceholder}
            className="w-full ps-10 pe-4 py-2.5 text-xs sm:text-sm bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#0a8591] shadow-xs"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-bold scrollbar-thin">
          <button
            onClick={() => setSelectedComplex('ALL')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              selectedComplex === 'ALL'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {lang === 'ar' ? '🏢 جميع العمارات (20 عمارة)' : 'Tous les 20'}
          </button>

          <button
            onClick={() => setSelectedComplex('A_ONLY')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              selectedComplex === 'A_ONLY'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-[#0a8591] border border-[#92e8dd] hover:bg-[#e9fbf8]'
            }`}
          >
            {lang === 'ar' ? 'المجموعة A: من GH 34 A إلى GH 43 A (10 عمارات)' : 'Groupe A (GH 34 A à GH 43 A)'}
          </button>

          <button
            onClick={() => setSelectedComplex('B_ONLY')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              selectedComplex === 'B_ONLY'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-[#0a8591] border border-[#92e8dd] hover:bg-[#e9fbf8]'
            }`}
          >
            {lang === 'ar' ? 'المجموعة B: من GH 34 B إلى GH 43 B (10 عمارات)' : 'Groupe B (GH 34 B à GH 43 B)'}
          </button>

          <div className="w-px h-5 bg-slate-300 mx-1 shrink-0" />

          {complexesList.map(comp => (
            <button
              key={comp}
              onClick={() => setSelectedComplex(comp)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                selectedComplex === comp
                  ? 'bg-[#0a8591] text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {comp} (A & B)
            </button>
          ))}
        </div>
      </div>

      {/* Buildings Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBuildings.map((b) => {
          const buildingApts = apartments.filter(a => a.buildingCode === b.code);
          const occupied = buildingApts.filter(a => a.status === 'occupied').length;

          return (
            <div 
              key={b.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-[#0a8591]/50 hover:shadow-md transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-[#e9fbf8] text-[#0a8591] font-bold flex items-center justify-center text-sm border border-[#92e8dd] shadow-inner">
                      {b.code}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{b.name}</h3>
                      <span className="text-[11px] text-slate-500 font-medium">{b.notes || 'مجمع سكني'}</span>
                    </div>
                  </div>

                  {!isOwner && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(b)}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-[#0a8591] cursor-pointer"
                        title={t.common.edit}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(t.buildings.deleteConfirm)) deleteBuilding(b.id);
                        }}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                        title={t.common.delete}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-2 my-3 p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">{t.buildings.floors}:</span>
                    <span className="font-bold text-slate-800">{b.floors} طوابق</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">{t.buildings.apartments}:</span>
                    <span className="font-bold text-slate-800">{b.apartmentsCount} شقة</span>
                  </div>
                  <div className="flex items-center justify-between col-span-2 pt-2 border-t border-slate-200/60">
                    <span className="text-slate-500">{t.buildings.occupiedCount}:</span>
                    <span className="font-bold text-[#0a8591]">{occupied} / {b.apartmentsCount}</span>
                  </div>
                  <div className="flex items-center justify-between col-span-2 pt-1.5 border-t border-slate-200/40">
                    <span className="text-slate-500">{lang === 'ar' ? 'المستحق الشهري (150 DH / شقة):' : 'Cotisation Mensuelle :'}</span>
                    <span className="font-mono font-bold text-slate-900">
                      {buildingApts.reduce((sum, a) => sum + (Number(a.monthlyFee) || 0), 0).toLocaleString()} DH
                    </span>
                  </div>
                </div>

                {/* Manager info */}
                <div className="space-y-1 text-xs text-slate-600 pt-1">
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-medium text-slate-800">{b.managerName || 'غير محدد'}</span>
                  </div>
                  {b.managerPhone && (
                    <div className="flex items-center gap-2 text-slate-500">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <a href={`tel:${b.managerPhone}`} dir="ltr" className="font-mono text-[11px] text-[#0a8591] font-bold hover:underline">
                        {b.managerPhone}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* View Apartments button */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  onClick={() => setActiveSection('apartments')}
                  className="w-full py-2 px-3 rounded-xl bg-[#e9fbf8] hover:bg-[#92e8dd] text-[#0a8591] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Home className="w-3.5 h-3.5 text-[#0a8591]" />
                  <span>{t.buildings.apartmentsList} ({b.code})</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
};
