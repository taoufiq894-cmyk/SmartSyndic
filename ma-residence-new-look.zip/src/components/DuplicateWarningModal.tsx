import React from 'react';
import { AlertTriangle, X, Check, ArrowRight, ShieldAlert } from 'lucide-react';
import { Payment, Expense } from '../types';

interface DuplicateWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  lang: 'ar' | 'fr';
  type: 'payment' | 'expense';
  existingPayment?: Payment;
  candidatePayment?: {
    buildingCode: string;
    apartmentNumber: string;
    periodMonth: string;
    amount: number;
    paymentDate: string;
    residentName: string;
  };
  existingExpense?: Expense;
  candidateExpense?: {
    title: string;
    category?: string;
    amount: number;
    date: string;
    supplier?: string;
    invoiceRef?: string;
  };
  customMessage?: string;
}

export const DuplicateWarningModal: React.FC<DuplicateWarningModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  lang,
  type,
  existingPayment,
  candidatePayment,
  existingExpense,
  candidateExpense,
  customMessage
}) => {
  if (!isOpen) return null;

  const isAr = lang === 'ar';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        role="dialog"
        aria-modal="true"
        className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl border-2 border-amber-400 overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <ShieldAlert className="w-6 h-6 text-white animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base">
                {type === 'payment'
                  ? (isAr ? 'تنبيه: أداء مسجل مسبقاً لنفس الشقة والشهر!' : 'Attention : Paiement déjà enregistré pour ce lot et ce mois !')
                  : (isAr ? 'تنبيه: مصروف مالي مشابه مسجل مسبقاً!' : 'Attention : Dépense similaire déjà enregistrée !')}
              </h3>
              <p className="text-xs text-amber-100 font-medium">
                {isAr ? 'نظام التحقق الذكي لمنع التكرار والأخطاء المحاسبية' : 'Système anti-doublon pour fiabiliser la comptabilité'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/20 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Main warning text */}
          <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs leading-relaxed flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block mb-1">
                {isAr ? 'تم رصد تطابق مع سجل مسجل سابقاً في النظام:' : 'Une correspondance a été détectée dans les registres :'}
              </span>
              <span>
                {customMessage || (type === 'payment'
                  ? (isAr 
                      ? 'الشقة المحددة مسجل لها بالفعل أداء مالي عن نفس الشهر. تجنباً لتكرار احتساب المبالغ أو إصدار وصولات مضاعفة عن طريق الخطأ، يرجى مراجعة التفاصيل أدناه.'
                      : 'Un paiement est déjà enregistré pour cet appartement sur ce même mois. Veuillez vérifier les détails ci-dessous afin d\'éviter tout doublon comptable.')
                  : (isAr
                      ? 'تم العثور على مصروف بنفس رقم الفاتورة أو بنفس العنوان والمبلغ خلال نفس الفترة المحاسبية. يرجى التأكد لتفادي ازدواجية المصاريف.'
                      : 'Une dépense identique ou similaire a déjà été saisie sur cette même période ou avec cette même référence.'))}
              </span>
            </div>
          </div>

          {/* Comparative Cards */}
          {type === 'payment' && existingPayment && (
            <div className="space-y-3">
              {/* Existing Record */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-800 pb-2 mb-2 border-b border-slate-200">
                  <span className="flex items-center gap-1.5 text-rose-700">
                    <span className="w-2 h-2 rounded-full bg-rose-600 inline-block" />
                    {isAr ? 'السجل المسجل مسبقاً في النظام' : 'Paiement existant dans le système'}
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 font-mono text-[11px]">
                    {existingPayment.receiptNumber || 'REC'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-600">
                  <div>
                    <span className="font-semibold">{isAr ? 'العمارة والشقة:' : 'Lot / Appartement:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingPayment.buildingCode} - {existingPayment.apartmentNumber}</span>
                  </div>
                  <div>
                    <span className="font-semibold">{isAr ? 'شهر الأداء:' : 'Mois réglé:'}</span>{' '}
                    <span className="font-bold text-emerald-800 font-mono">{existingPayment.periodMonth}</span>
                  </div>
                  <div>
                    <span className="font-semibold">{isAr ? 'المبلغ المؤدى:' : 'Montant réglé:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingPayment.amount} DH</span>
                  </div>
                  <div>
                    <span className="font-semibold">{isAr ? 'تاريخ الأداء:' : 'Date paiement:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingPayment.paymentDate}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="font-semibold">{isAr ? 'اسم المؤدي / المالك:' : 'Résident / Payeur:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingPayment.residentName}</span>
                  </div>
                </div>
              </div>

              {/* Candidate Record */}
              {candidatePayment && (
                <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs">
                  <div className="flex items-center justify-between font-bold text-amber-900 pb-2 mb-2 border-b border-amber-200">
                    <span className="flex items-center gap-1.5 text-amber-800">
                      <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
                      {isAr ? 'الأداء الجديد المراد إدخاله الآن' : 'Nouveau paiement en cours de saisie'}
                    </span>
                    <span className="text-[11px] font-mono text-amber-700">
                      {isAr ? 'قيد الإدخال' : 'En attente'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-700">
                    <div>
                      <span className="font-semibold">{isAr ? 'العمارة والشقة:' : 'Lot / Appartement:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidatePayment.buildingCode} - {candidatePayment.apartmentNumber}</span>
                    </div>
                    <div>
                      <span className="font-semibold">{isAr ? 'شهر الأداء:' : 'Mois réglé:'}</span>{' '}
                      <span className="font-bold text-amber-900 font-mono">{candidatePayment.periodMonth}</span>
                    </div>
                    <div>
                      <span className="font-semibold">{isAr ? 'المبلغ:' : 'Montant:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidatePayment.amount} DH</span>
                    </div>
                    <div>
                      <span className="font-semibold">{isAr ? 'التاريخ:' : 'Date:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidatePayment.paymentDate}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Comparative Cards for Expense */}
          {type === 'expense' && existingExpense && (
            <div className="space-y-3">
              {/* Existing Expense */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div className="flex items-center justify-between font-bold text-slate-800 pb-2 mb-2 border-b border-slate-200">
                  <span className="flex items-center gap-1.5 text-rose-700">
                    <span className="w-2 h-2 rounded-full bg-rose-600 inline-block" />
                    {isAr ? 'المصروف المسجل مسبقاً في النظام' : 'Dépense existante dans le système'}
                  </span>
                  {existingExpense.invoiceRef && (
                    <span className="px-2 py-0.5 rounded-md bg-slate-200 text-slate-800 font-mono text-[11px]">
                      {isAr ? 'فاتورة:' : 'Facture:'} {existingExpense.invoiceRef}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-600">
                  <div className="col-span-2">
                    <span className="font-semibold">{isAr ? 'عنوان النفقة:' : 'Intitulé:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingExpense.title}</span>
                  </div>
                  <div>
                    <span className="font-semibold">{isAr ? 'المبلغ:' : 'Montant:'}</span>{' '}
                    <span className="font-bold text-rose-700 font-mono">{existingExpense.amount} DH</span>
                  </div>
                  <div>
                    <span className="font-semibold">{isAr ? 'تاريخ المصروف:' : 'Date:'}</span>{' '}
                    <span className="font-bold text-slate-900">{existingExpense.date}</span>
                  </div>
                  {existingExpense.supplier && (
                    <div className="col-span-2">
                      <span className="font-semibold">{isAr ? 'المورد / الشركة:' : 'Fournisseur:'}</span>{' '}
                      <span className="font-bold text-slate-900">{existingExpense.supplier}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Candidate Expense */}
              {candidateExpense && (
                <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs">
                  <div className="flex items-center justify-between font-bold text-amber-900 pb-2 mb-2 border-b border-amber-200">
                    <span className="flex items-center gap-1.5 text-amber-800">
                      <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
                      {isAr ? 'المصروف الجديد المراد إدخاله' : 'Nouvelle dépense en cours de saisie'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-700">
                    <div className="col-span-2">
                      <span className="font-semibold">{isAr ? 'عنوان النفقة:' : 'Intitulé:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidateExpense.title}</span>
                    </div>
                    <div>
                      <span className="font-semibold">{isAr ? 'المبلغ:' : 'Montant:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidateExpense.amount} DH</span>
                    </div>
                    <div>
                      <span className="font-semibold">{isAr ? 'التاريخ:' : 'Date:'}</span>{' '}
                      <span className="font-bold text-slate-900">{candidateExpense.date}</span>
                    </div>
                    {candidateExpense.invoiceRef && (
                      <div className="col-span-2">
                        <span className="font-semibold">{isAr ? 'رقم الفاتورة:' : 'N° Facture:'}</span>{' '}
                        <span className="font-bold text-slate-900 font-mono">{candidateExpense.invoiceRef}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-300 transition-all cursor-pointer shadow-2xs flex items-center justify-center gap-1.5"
          >
            <X className="w-4 h-4 text-slate-500" />
            <span>{isAr ? 'إلغاء العملية لتفادي التكرار (مستحسن)' : 'Annuler pour éviter le doublon'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>
              {type === 'payment'
                ? (isAr ? 'تأكيد التسجيل رغم التنبيه (دفعة إضافية مكملة)' : 'Confirmer malgré tout (Versement complémentaire)')
                : (isAr ? 'تأكيد تسجيل المصروف (نفقة منفصلة)' : 'Confirmer la dépense (Dépense distincte)')}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
