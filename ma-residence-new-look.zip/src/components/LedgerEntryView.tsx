import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ManualMonthlyRecord } from '../types';
import {
  filterPaymentsByMonth,
  getPreviousMonthKey,
  ARABIC_MONTH_NAMES,
  FRENCH_MONTH_NAMES
} from '../utils/monthlyFinanceUtils';
import {
  Wallet, Lock, Unlock, Save, CalendarCheck, TrendingUp, TrendingDown,
  Gavel, FileSignature, Users, Briefcase, Hammer, Zap, Sprout, Droplets,
  Lightbulb, FlaskConical, Package, RefreshCw, ArrowLeft, CheckCircle2, AlertCircle
} from 'lucide-react';

type ExpenseKey =
  | 'syndicAndDeputyFees' | 'lawyerFees' | 'bailiffFees' | 'workerSalaries'
  | 'hardwareDroguerie' | 'buildingMaterials' | 'electricalMaterials' | 'irrigationTools' | 'otherExpenses'
  | 'stairsElectricity' | 'wellElectricity';

interface FieldDef {
  key: ExpenseKey;
  ar: string;
  fr: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: string;
}

const GROUPS: { id: string; ar: string; fr: string; fields: FieldDef[] }[] = [
  {
    id: 'fees',
    ar: 'الأجور والأتعاب',
    fr: 'Salaires & Honoraires',
    fields: [
      { key: 'syndicAndDeputyFees', ar: 'أجرة السانديك', fr: 'Indemnité du syndic', icon: Briefcase, tone: 'from-indigo-400 to-indigo-600' },
      { key: 'lawyerFees', ar: 'أتعاب المحامي', fr: 'Honoraires avocat', icon: Gavel, tone: 'from-violet-400 to-violet-600' },
      { key: 'bailiffFees', ar: 'أتعاب المفوض القضائي', fr: 'Frais d\'huissier', icon: FileSignature, tone: 'from-fuchsia-400 to-fuchsia-600' },
      { key: 'workerSalaries', ar: 'أجور العمال', fr: 'Salaires des ouvriers', icon: Users, tone: 'from-amber-400 to-amber-600' }
    ]
  },
  {
    id: 'misc',
    ar: 'مصاريف مختلفة (الاستعمال اليومي)',
    fr: 'Dépenses diverses (usage quotidien)',
    fields: [
      { key: 'hardwareDroguerie', ar: 'العقاقير', fr: 'Droguerie', icon: FlaskConical, tone: 'from-emerald-400 to-emerald-600' },
      { key: 'buildingMaterials', ar: 'مواد البناء', fr: 'Matériaux de construction', icon: Hammer, tone: 'from-orange-400 to-orange-600' },
      { key: 'electricalMaterials', ar: 'مواد كهربائية', fr: 'Matériel électrique', icon: Zap, tone: 'from-yellow-400 to-yellow-600' },
      { key: 'irrigationTools', ar: 'أدوات السقي', fr: 'Matériel d\'arrosage', icon: Sprout, tone: 'from-lime-400 to-lime-600' },
      { key: 'otherExpenses', ar: 'أخرى (استعمال يومي)', fr: 'Autres (usage quotidien)', icon: Package, tone: 'from-slate-400 to-slate-600' }
    ]
  },
  {
    id: 'electricity',
    ar: 'فواتير الكهرباء',
    fr: 'Factures d\'électricité',
    fields: [
      { key: 'stairsElectricity', ar: 'كهرباء الدرج', fr: 'Électricité des escaliers', icon: Lightbulb, tone: 'from-amber-400 to-orange-500' },
      { key: 'wellElectricity', ar: 'كهرباء البئر', fr: 'Électricité du puits', icon: Droplets, tone: 'from-sky-400 to-sky-600' }
    ]
  }
];

const ALL_KEYS: ExpenseKey[] = GROUPS.flatMap(g => g.fields.map(f => f.key));
// حقول قديمة تُحفظ كما هي وتدخل في المجموع حتى لا يضيع أي إدخال سابق
const LEGACY_KEYS = ['salaries', 'utilities', 'maintenance', 'supplies'] as const;

const money = (n: number) =>
  new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n || 0);

const toNum = (v: string) => {
  const n = parseFloat(String(v).replace(',', '.'));
  return isNaN(n) || n < 0 ? 0 : n;
};

const currentMonthKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

export const LedgerEntryView: React.FC = () => {
  const {
    lang, currentUser, manualMonthlyRecords, payments,
    upsertManualMonthlyRecord, closeManualMonth, reopenManualMonth
  } = useApp();
  const isAr = lang === 'ar';
  const canEdit = currentUser?.role !== 'resident';

  // الأشهر المتاحة: من 04/2025 إلى الشهر الموالي للشهر الحالي
  const monthKeys = useMemo(() => {
    const list: string[] = [];
    const now = new Date();
    const endY = now.getFullYear() + (now.getMonth() === 11 ? 1 : 0);
    const endM = (now.getMonth() + 2 > 12) ? 1 : now.getMonth() + 2;
    let y = 2025, m = 4;
    while (y < endY || (y === endY && m <= endM)) {
      list.push(`${y}-${String(m).padStart(2, '0')}`);
      m += 1;
      if (m > 12) { m = 1; y += 1; }
    }
    return list;
  }, []);

  const monthLabel = (key: string) => {
    const [y, m] = key.split('-');
    return `${(isAr ? ARABIC_MONTH_NAMES : FRENCH_MONTH_NAMES)[m] || m} ${y}`;
  };

  const [monthKey, setMonthKey] = useState<string>(() => {
    const cur = currentMonthKey();
    return cur;
  });
  const [income, setIncome] = useState('');
  const [fields, setFields] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const record: ManualMonthlyRecord | undefined = useMemo(
    () => manualMonthlyRecords.find(r => r.monthKey === monthKey),
    [manualMonthlyRecords, monthKey]
  );
  const isClosed = !!record?.isClosed;
  const locked = isClosed || !canEdit;

  // تحميل بيانات الشهر المحدد في النموذج
  useEffect(() => {
    setIncome(record && record.totalIncome ? String(record.totalIncome) : '');
    const next: Record<string, string> = {};
    ALL_KEYS.forEach(k => {
      const v = record?.breakdownExpenses?.[k];
      next[k] = v ? String(v) : '';
    });
    setFields(next);
    setNotes(record?.notes || '');
  }, [record?.id, record?.updatedAt, monthKey]);

  const legacyTotal = useMemo(() => {
    const b = record?.breakdownExpenses as Record<string, number | undefined> | undefined;
    if (!b) return 0;
    return LEGACY_KEYS.reduce((s, k) => s + (Number(b[k]) || 0), 0);
  }, [record]);

  const expensesTotal = useMemo(
    () => ALL_KEYS.reduce((s, k) => s + toNum(fields[k] || ''), 0) + legacyTotal,
    [fields, legacyTotal]
  );
  const incomeTotal = toNum(income);

  // الرصيد المرحل من الشهر السابق (تلقائي)
  const openingBalance = useMemo(() => {
    const prevKey = getPreviousMonthKey(monthKey);
    const prev = manualMonthlyRecords.find(r => r.monthKey === prevKey);
    if (prev) {
      return prev.closingBalance !== undefined
        ? prev.closingBalance
        : (prev.openingBalance || 0) + prev.totalIncome - prev.totalExpenses;
    }
    return typeof record?.openingBalance === 'number' ? record.openingBalance : 0;
  }, [manualMonthlyRecords, monthKey, record]);

  const closingBalance = openingBalance + incomeTotal - expensesTotal;

  const buildRecord = () => {
    const prevBreak = (record?.breakdownExpenses || {}) as Record<string, number | undefined>;
    const breakdownExpenses: Record<string, number> = {};
    LEGACY_KEYS.forEach(k => { if (prevBreak[k]) breakdownExpenses[k] = Number(prevBreak[k]); });
    ALL_KEYS.forEach(k => { const v = toNum(fields[k] || ''); if (v > 0) breakdownExpenses[k] = v; });

    let breakdownIncome = record?.breakdownIncome;
    if (breakdownIncome) {
      const sum = Object.values(breakdownIncome).reduce((s, v) => s + (Number(v) || 0), 0);
      if (Math.abs(sum - incomeTotal) > 0.009) breakdownIncome = undefined;
    }

    return {
      id: record?.id,
      monthKey,
      totalIncome: incomeTotal,
      totalExpenses: expensesTotal,
      openingBalance: record?.openingBalance,
      breakdownIncome,
      breakdownExpenses,
      notes: notes.trim() || undefined
    } as Omit<ManualMonthlyRecord, 'id' | 'updatedAt'> & { id?: string };
  };

  const handleSave = () => {
    if (locked) return;
    upsertManualMonthlyRecord(buildRecord());
    setMessage({
      type: 'ok',
      text: isAr ? `تم حفظ مداخيل ومصاريف ${monthLabel(monthKey)}` : `Recettes et dépenses de ${monthLabel(monthKey)} enregistrées`
    });
  };

  const handleClose = () => {
    if (locked) return;
    const ok = window.confirm(
      isAr
        ? `إغلاق شهر ${monthLabel(monthKey)}؟\nسيُرحَّل الرصيد (${money(closingBalance)} د.م) تلقائياً إلى بداية الشهر الموالي.`
        : `Clôturer ${monthLabel(monthKey)} ?\nLe solde (${money(closingBalance)} DH) sera reporté automatiquement au mois suivant.`
    );
    if (!ok) return;
    upsertManualMonthlyRecord(buildRecord());
    const res = closeManualMonth(monthKey);
    if (res.success) {
      setMessage({
        type: 'ok',
        text: isAr
          ? `تم إغلاق ${monthLabel(monthKey)} وترحيل ${money(res.closingBalance || 0)} د.م إلى ${monthLabel(res.nextMonthKey || '')}`
          : `${monthLabel(monthKey)} clôturé : ${money(res.closingBalance || 0)} DH reportés sur ${monthLabel(res.nextMonthKey || '')}`
      });
      if (res.nextMonthKey) setMonthKey(res.nextMonthKey);
    } else {
      setMessage({ type: 'err', text: isAr ? 'تعذّر إغلاق الشهر' : 'Impossible de clôturer le mois' });
    }
  };

  const handleReopen = () => {
    if (!canEdit || !isClosed) return;
    const res = reopenManualMonth(monthKey);
    setMessage(res.success
      ? { type: 'ok', text: isAr ? 'تمت إعادة فتح الشهر للتعديل' : 'Mois rouvert pour modification' }
      : { type: 'err', text: isAr ? 'لا يمكن إعادة فتح شهر لاحقه مغلق، أعد فتح الشهر اللاحق أولاً' : 'Rouvrez d\'abord le mois suivant (il est clôturé)' });
  };

  const fillIncomeFromReceipts = () => {
    if (locked) return;
    const sum = filterPaymentsByMonth(payments, monthKey).reduce((s, p) => s + (Number(p.amount) || 0), 0);
    setIncome(sum ? String(sum) : '');
  };

  // لوحة الأشهر المدونة
  const rows = useMemo(
    () => [...manualMonthlyRecords].sort((a, b) => b.monthKey.localeCompare(a.monthKey)),
    [manualMonthlyRecords]
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden bg-white p-5 rounded-2xl border border-slate-200 border-t-4 border-t-emerald-500 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="icon-wiggle anim-bob w-11 h-11 rounded-2xl gradient-flow text-white flex items-center justify-center shadow-md shrink-0">
              <Wallet className="w-6 h-6" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                {isAr ? 'المداخيل والمصاريف الشهرية' : 'Recettes & Dépenses du mois'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 font-medium mt-0.5">
                {isAr
                  ? 'أدخل مجموع المداخيل والمصاريف، وعند إغلاق الشهر يُرحَّل الرصيد تلقائياً للشهر القادم'
                  : 'Saisissez les totaux ; à la clôture, le solde est reporté automatiquement au mois suivant'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <select
              value={monthKey}
              onChange={e => { setMonthKey(e.target.value); setMessage(null); }}
              className="px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {monthKeys.map(k => (
                <option key={k} value={k}>
                  {monthLabel(k)}{manualMonthlyRecords.find(r => r.monthKey === k)?.isClosed ? ' 🔒' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {message && (
        <div className={`flex items-start gap-2 p-3.5 rounded-xl text-sm font-bold border ${
          message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          {message.type === 'ok' ? <CheckCircle2 className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
          <span>{message.text}</span>
        </div>
      )}

      {isClosed && (
        <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm font-bold">
          <span className="flex items-center gap-2"><Lock className="w-4 h-4 shrink-0" />
            {isAr ? 'هذا الشهر مغلق، وقد رُحِّل رصيده إلى الشهر التالي.' : 'Ce mois est clôturé ; son solde est reporté au mois suivant.'}
          </span>
          {canEdit && (
            <button type="button" onClick={handleReopen}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-xs font-black cursor-pointer hover:bg-amber-100">
              <Unlock className="w-3.5 h-3.5" /> {isAr ? 'إعادة الفتح' : 'Rouvrir'}
            </button>
          )}
        </div>
      )}

      {/* Summary: carried → income → expenses → closing */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><ArrowLeft className="w-3.5 h-3.5" />{isAr ? 'الرصيد المرحل' : 'Solde reporté'}</div>
          <div className={`mt-1 text-lg font-black ${openingBalance >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>{money(openingBalance)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><TrendingUp className="w-3.5 h-3.5 text-emerald-600" />{isAr ? 'مداخيل الشهر' : 'Recettes'}</div>
          <div className="mt-1 text-lg font-black text-emerald-700">{money(incomeTotal)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><TrendingDown className="w-3.5 h-3.5 text-rose-600" />{isAr ? 'مصاريف الشهر' : 'Dépenses'}</div>
          <div className="mt-1 text-lg font-black text-rose-600">{money(expensesTotal)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-white shadow-md">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-100"><Wallet className="w-3.5 h-3.5" />{isAr ? 'الرصيد الختامي (المرحل للشهر القادم)' : 'Solde final (reporté)'}</div>
          <div className={`mt-1 text-lg font-black ${closingBalance >= 0 ? 'text-white' : 'text-rose-200'}`}>{money(closingBalance)} <span className="text-xs">DH</span></div>
        </div>
      </div>

      {/* Income */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="flex items-center gap-2 text-base font-black text-slate-900">
            <span className="icon-wiggle w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-white flex items-center justify-center shadow-sm"><TrendingUp className="w-[18px] h-[18px]" /></span>
            {isAr ? 'مجموع مداخيل الشهر' : 'Total des recettes du mois'}
          </h2>
          {!locked && (
            <button type="button" onClick={fillIncomeFromReceipts}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold cursor-pointer hover:bg-emerald-100">
              <RefreshCw className="w-3.5 h-3.5" /> {isAr ? 'جلب من الوصولات' : 'Depuis les reçus'}
            </button>
          )}
        </div>
        <div className="relative">
          <input
            type="number" inputMode="decimal" min="0" step="0.01"
            value={income} disabled={locked}
            onChange={e => setIncome(e.target.value)}
            placeholder="0.00"
            className="w-full px-4 py-3 rounded-xl border border-slate-300 text-lg font-black text-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
          />
          <span className="absolute top-1/2 -translate-y-1/2 end-4 text-xs font-bold text-slate-500">DH</span>
        </div>
      </div>

      {/* Expense groups */}
      {GROUPS.map(g => {
        const groupTotal = g.fields.reduce((s, f) => s + toNum(fields[f.key] || ''), 0);
        return (
          <div key={g.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-black text-slate-900">{isAr ? g.ar : g.fr}</h2>
              <span className="text-xs font-black text-rose-600">{money(groupTotal)} DH</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {g.fields.map(f => {
                const Icon = f.icon;
                return (
                  <label key={f.key} className="group flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:border-emerald-300 transition-colors">
                    <span className={`icon-wiggle w-10 h-10 rounded-xl bg-gradient-to-br ${f.tone} text-white flex items-center justify-center shadow-sm shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-xs font-bold text-slate-700 mb-1">{isAr ? f.ar : f.fr}</span>
                      <input
                        type="number" inputMode="decimal" min="0" step="0.01"
                        value={fields[f.key] || ''} disabled={locked}
                        onChange={e => setFields(prev => ({ ...prev, [f.key]: e.target.value }))}
                        placeholder="0.00"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
                      />
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        );
      })}

      {legacyTotal > 0 && (
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-600">
          {isAr
            ? `مبلغ ${money(legacyTotal)} د.م من مصاريف مدونة سابقاً (حراسة، ماء وكهرباء مشترك، صيانة، تنظيف) محتسب ضمن المجموع.`
            : `${money(legacyTotal)} DH de dépenses saisies précédemment (gardiennage, eau/électricité, entretien, nettoyage) sont inclus dans le total.`}
        </div>
      )}

      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <label className="block text-xs font-bold text-slate-700 mb-1.5">{isAr ? 'ملاحظات' : 'Remarques'}</label>
        <textarea
          rows={2} value={notes} disabled={locked}
          onChange={e => setNotes(e.target.value)}
          className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
        />
      </div>

      {/* Actions */}
      {!locked && (
        <div className="flex flex-col sm:flex-row gap-3">
          <button type="button" onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-white border-2 border-emerald-600 text-emerald-800 font-black text-sm cursor-pointer hover:bg-emerald-50">
            <Save className="w-4 h-4" /> {isAr ? 'حفظ' : 'Enregistrer'}
          </button>
          <button type="button" onClick={handleClose}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-gradient-to-l from-emerald-700 to-emerald-500 text-white font-black text-sm shadow-md cursor-pointer hover:shadow-lg">
            <Lock className="w-4 h-4" /> {isAr ? 'إغلاق الشهر وترحيل الرصيد' : 'Clôturer et reporter le solde'}
          </button>
        </div>
      )}

      {/* History */}
      {rows.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 font-black text-slate-900 text-sm">
            {isAr ? 'سجل الأشهر والأرصدة المرحلة' : 'Historique des mois et soldes reportés'}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-50 text-slate-600">
                  <th className="px-3 py-2 text-start font-bold">{isAr ? 'الشهر' : 'Mois'}</th>
                  <th className="px-3 py-2 text-end font-bold">{isAr ? 'المرحل' : 'Reporté'}</th>
                  <th className="px-3 py-2 text-end font-bold">{isAr ? 'مداخيل' : 'Recettes'}</th>
                  <th className="px-3 py-2 text-end font-bold">{isAr ? 'مصاريف' : 'Dépenses'}</th>
                  <th className="px-3 py-2 text-end font-bold">{isAr ? 'الرصيد' : 'Solde'}</th>
                  <th className="px-3 py-2 text-center font-bold">{isAr ? 'الحالة' : 'État'}</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(r => {
                  const closing = r.closingBalance ?? ((r.openingBalance || 0) + r.totalIncome - r.totalExpenses);
                  return (
                    <tr key={r.id} onClick={() => { setMonthKey(r.monthKey); setMessage(null); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                      className={`border-t border-slate-100 cursor-pointer hover:bg-emerald-50/50 ${r.monthKey === monthKey ? 'bg-emerald-50' : ''}`}>
                      <td className="px-3 py-2 font-bold text-slate-800">{monthLabel(r.monthKey)}</td>
                      <td className="px-3 py-2 text-end text-slate-600">{money(r.openingBalance || 0)}</td>
                      <td className="px-3 py-2 text-end text-emerald-700 font-bold">{money(r.totalIncome)}</td>
                      <td className="px-3 py-2 text-end text-rose-600 font-bold">{money(r.totalExpenses)}</td>
                      <td className={`px-3 py-2 text-end font-black ${closing >= 0 ? 'text-emerald-800' : 'text-rose-600'}`}>{money(closing)}</td>
                      <td className="px-3 py-2 text-center">
                        {r.isClosed
                          ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-black"><Lock className="w-3 h-3" />{isAr ? 'مغلق' : 'Clôturé'}</span>
                          : <span className="inline-flex px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[11px] font-bold">{isAr ? 'مفتوح' : 'Ouvert'}</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
