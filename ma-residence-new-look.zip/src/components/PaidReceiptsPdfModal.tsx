import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Payment } from '../types';
import { 
  X, FileText, CheckCircle2, MessageSquare, Mail, Printer, 
  Download, Search, Building2, Calendar, Send, FileDown,
  ShieldCheck, Share2, Sparkles, Filter
} from 'lucide-react';
import { formatPeriodDisplay } from '../utils/debtUtils';
import { buildReceiptWhatsAppUrl, buildReceiptEmailUrl, downloadReceiptAsPdf } from '../utils/pdfReceiptUtils';
import { isGenericPlaceholderName, isOldMockResidentName, getMoroccanApartmentData } from '../data/moroccanResidentsData';

interface PaidReceiptsPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaidReceiptsPdfModal: React.FC<PaidReceiptsPdfModalProps> = ({
  isOpen,
  onClose
}) => {
  const { payments, buildings, apartments, residents, setSelectedReceipt, lang } = useApp();

  const [selectedBuilding, setSelectedBuilding] = useState('ALL');
  const [selectedPeriod, setSelectedPeriod] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  // Extract all unique period months from payments
  const uniquePeriods = Array.from(new Set<string>(payments.map(p => p.periodMonth))).sort().reverse();

  const resolveRealOwnerName = (payment: Payment): string => {
    const cleanB = (payment.buildingCode || '').replace(/\s+/g, ' ').trim().toUpperCase();
    const cleanA = String(payment.apartmentNumber || '01').trim().padStart(2, '0');
    const res = residents.find(
      r => r.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
           String(r.apartmentNumber).trim().padStart(2, '0') === cleanA
    );
    if (res?.fullName && !isGenericPlaceholderName(res.fullName) && !isOldMockResidentName(res.fullName)) {
      return res.fullName.trim();
    }
    if (cleanB === 'GH 34 A' && cleanA === '01') {
      return 'مكتب إدارة وسانديك إقامة المرجان';
    }
    if (cleanB === 'GH 38 B' && cleanA === '03') {
      return 'السيد محمد أيت بلعربي';
    }
    const apt = apartments.find(
      a => a.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
           String(a.number).trim().padStart(2, '0') === cleanA
    );
    if (apt?.ownerName && !isGenericPlaceholderName(apt.ownerName) && !isOldMockResidentName(apt.ownerName)) {
      return apt.ownerName.trim();
    }
    if (apt?.residentName && !isGenericPlaceholderName(apt.residentName) && !isOldMockResidentName(apt.residentName)) {
      return apt.residentName.trim();
    }
    if (!isGenericPlaceholderName(payment.residentName) && !isOldMockResidentName(payment.residentName)) {
      return payment.residentName;
    }
    const mData = getMoroccanApartmentData(cleanB, cleanA);
    if (mData?.fullName && !isGenericPlaceholderName(mData.fullName) && !isOldMockResidentName(mData.fullName)) {
      return mData.fullName;
    }
    return `شقة ${cleanA}`;
  };

  // Find contact info for an apartment/resident
  const getResidentContact = (payment: Payment) => {
    const cleanB = (payment.buildingCode || '').replace(/\s+/g, ' ').trim().toUpperCase();
    const cleanA = String(payment.apartmentNumber || '01').trim().padStart(2, '0');
    const res = residents.find(
      r => r.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
           String(r.apartmentNumber).trim().padStart(2, '0') === cleanA
    );
    const apt = apartments.find(
      a => a.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
           String(a.number).trim().padStart(2, '0') === cleanA
    );

    const phone = res?.phone || apt?.ownerPhone || apt?.residentPhone || '';
    const email = res?.email || apt?.ownerEmail || apt?.residentEmail || '';

    return { phone, email };
  };

  const filteredPayments = payments.filter(p => {
    const matchesBuilding = selectedBuilding === 'ALL' || p.buildingCode === selectedBuilding;
    const matchesPeriod = selectedPeriod === 'ALL' || p.periodMonth === selectedPeriod;
    const matchesSearch = 
      p.residentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.buildingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.apartmentNumber.includes(searchTerm);

    return matchesBuilding && matchesPeriod && matchesSearch;
  });

  const totalPaidAmount = filteredPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700/80 border border-emerald-500/40 flex items-center justify-center text-emerald-200">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-base sm:text-lg">
                  {lang === 'ar' ? 'إرسال وصولات الأداء للملاك (صيغة PDF)' : 'Envoi des Reçus de Cotisation (Format PDF)'}
                </h2>
                <span className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-black uppercase font-mono tracking-wider">
                  PDF
                </span>
              </div>
              <p className="text-xs text-emerald-200 mt-0.5">
                {lang === 'ar' 
                  ? 'إرسال وتنزيل وصولات الأداء للملاك الذين أدوا واجبات السانديك عبر واتساب أو البريد الإلكتروني' 
                  : 'Envoyer ou télécharger les reçus officiels PDF pour les copropriétaires à jour'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-emerald-800 text-emerald-200 hover:text-white transition-colors cursor-pointer"
            title={lang === 'ar' ? 'إغلاق' : 'Fermer'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters & Stats Bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 shrink-0">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder={lang === 'ar' ? 'بحث بالاسم، الشقة أو رقم الوصل...' : 'Recherche par nom, appt...'}
              className="w-full ps-9 pe-3 py-2 text-xs bg-white rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
          </div>

          {/* Building Filter */}
          <div>
            <select
              value={selectedBuilding}
              onChange={e => setSelectedBuilding(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 font-semibold"
            >
              <option value="ALL">{lang === 'ar' ? '🏢 كل العمارات (GH34-GH43)' : 'Tous les immeubles'}</option>
              {buildings.map(b => (
                <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
              ))}
            </select>
          </div>

          {/* Period Filter */}
          <div>
            <select
              value={selectedPeriod}
              onChange={e => setSelectedPeriod(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 font-semibold"
            >
              <option value="ALL">{lang === 'ar' ? '📅 جميع الشهور والفترات' : 'Toutes les périodes'}</option>
              {uniquePeriods.map(p => (
                <option key={p} value={p}>{formatPeriodDisplay(p, lang)} ({p})</option>
              ))}
            </select>
          </div>

          {/* Total Counter Summary */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-100/70 border border-emerald-300 text-xs sm:col-span-3 lg:col-span-1">
            <span className="text-emerald-950 font-bold">
              {lang === 'ar' ? 'الوصولات المؤداة:' : 'Reçus réglés:'}
            </span>
            <span className="font-mono font-black text-emerald-900">
              {filteredPayments.length} ({totalPaidAmount.toLocaleString()} DH)
            </span>
          </div>
        </div>

        {/* Paid Owners List with Direct PDF & Sending Actions */}
        <div className="flex-1 p-4 overflow-y-auto min-h-0 divide-y divide-slate-100">
          {filteredPayments.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              <CheckCircle2 className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p>{lang === 'ar' ? 'لا توجد وصولات مطابقة للبحث أو الفلتر المختار' : 'Aucun reçu correspondant'}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredPayments.map(payment => {
                const { phone, email } = getResidentContact(payment);
                const formattedPeriod = formatPeriodDisplay(payment.periodMonth, lang);
                const realOwnerName = resolveRealOwnerName(payment);
                const paymentWithRealOwner: Payment = { ...payment, residentName: realOwnerName };
                const whatsappUrl = buildReceiptWhatsAppUrl(paymentWithRealOwner, formattedPeriod, phone);
                const emailUrl = buildReceiptEmailUrl(paymentWithRealOwner, formattedPeriod, email);

                return (
                  <div 
                    key={payment.id}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-emerald-300 bg-white hover:bg-slate-50/70 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-2xs"
                  >
                    {/* Left: Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-mono font-black text-xs border border-emerald-300">
                          {payment.receiptNumber}
                        </span>
                        <span className="font-bold text-sm text-slate-900 truncate">
                          {realOwnerName}
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {payment.buildingCode} - {lang === 'ar' ? 'شقة' : 'Appt'} {payment.apartmentNumber}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-600 flex-wrap">
                        <div>
                          <span className="text-slate-400">{lang === 'ar' ? 'الفترة:' : 'Période:'}</span>{' '}
                          <span className="font-bold text-slate-800">{formattedPeriod}</span>
                        </div>
                        <div>
                          <span className="text-slate-400">{lang === 'ar' ? 'المبلغ:' : 'Montant:'}</span>{' '}
                          <span className="font-black text-emerald-700 font-mono">{payment.amount} DH</span>
                        </div>
                        <div>
                          <span className="text-slate-400">{lang === 'ar' ? 'تاريخ الأداء:' : 'Date:'}</span>{' '}
                          <span className="font-mono text-slate-700">{payment.paymentDate}</span>
                        </div>
                      </div>

                      {/* Contact Preview */}
                      <div className="mt-1.5 flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                        <span>📱 {phone || (lang === 'ar' ? 'بدون هاتف' : 'Sans tél')}</span>
                        {email && (
                          <>
                            <span>•</span>
                            <span>✉️ {email}</span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Right: PDF and Sending Actions */}
                    <div className="flex items-center gap-2 flex-wrap md:justify-end shrink-0">
                      {/* WhatsApp Button */}
                      <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noreferrer"
                        className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                          phone
                            ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white'
                            : 'bg-slate-100 hover:bg-emerald-50 text-emerald-800 border border-emerald-300'
                        }`}
                        title={lang === 'ar' ? 'إرسال بيانات الوصل عبر واتساب للمالك' : 'Envoyer par WhatsApp'}
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'واتساب' : 'WhatsApp'}</span>
                      </a>

                      {/* Email Button */}
                      <a
                        href={emailUrl}
                        className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                          email
                            ? 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white'
                            : 'bg-slate-100 hover:bg-blue-50 text-blue-800 border border-blue-300'
                        }`}
                        title={lang === 'ar' ? 'إرسال الوصل عبر البريد الإلكتروني للمالك' : 'Envoyer par Email'}
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'إيميل' : 'Email'}</span>
                      </a>

                      {/* View / Download PDF Modal */}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedReceipt(paymentWithRealOwner);
                        }}
                        className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                        title={lang === 'ar' ? 'معاينة واستخراج وصل PDF' : 'Aperçu et extraction PDF'}
                      >
                        <FileDown className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{lang === 'ar' ? 'معاينة وPDF' : 'Reçu PDF'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500 font-semibold hidden sm:block">
            {lang === 'ar' ? 'جميع الوصولات مستخرجة ومعتمدة وفق قانون الملكية المشتركة 18.00' : 'Reçus conformes à la loi 18.00'}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer ms-auto"
          >
            {lang === 'ar' ? 'إغلاق النافذة' : 'Fermer'}
          </button>
        </div>

      </div>
    </div>
  );
};
