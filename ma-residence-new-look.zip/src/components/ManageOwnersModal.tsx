import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Apartment, Resident } from '../types';
import { 
  Users, UserPlus, UserMinus, Search, Filter, CheckCircle2, 
  AlertTriangle, X, Edit3, Trash2, Home, Building2, Phone, 
  CreditCard, Shield, Save, ArrowRight, ArrowLeft, RefreshCw,
  Plus, Check, UserCheck, AlertCircle, Info, Sparkles
} from 'lucide-react';

interface ManageOwnersModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialBuildingCode?: string;
  initialApartmentNumber?: string;
  defaultTab?: 'add' | 'remove' | 'list';
}

export const ManageOwnersModal: React.FC<ManageOwnersModalProps> = ({
  isOpen,
  onClose,
  initialBuildingCode,
  initialApartmentNumber,
  defaultTab = 'add'
}) => {
  const { 
    lang, t, buildings, apartments, residents,
    addApartment, updateApartment, deleteApartment,
    addResident, updateResident, deleteResident,
    syncAllPaymentsWithResidents
  } = useApp();

  const [activeTab, setActiveTab] = useState<'add' | 'remove' | 'list'>(defaultTab);

  // Form states for "زيادة مالك" (Add Owner)
  const [selectedBuilding, setSelectedBuilding] = useState(initialBuildingCode || buildings[0]?.code || 'GH 34 A');
  const [apartmentNumber, setApartmentNumber] = useState(initialApartmentNumber || '01');
  const [ownerFullName, setOwnerFullName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerCin, setOwnerCin] = useState('');
  const [floor, setFloor] = useState<number>(0);
  const [monthlyFee, setMonthlyFee] = useState<number>(150);
  const [occupancyType, setOccupancyType] = useState<'owner_resident' | 'owner_landlord'>('owner_resident');
  const [isCustomAptNumber, setIsCustomAptNumber] = useState(false);
  const [customAptNumber, setCustomAptNumber] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Filter & Search states for "نقص مالك" & "قائمة الملاك"
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBuilding, setFilterBuilding] = useState('ALL');

  // Confirmation state for deleting or clearing an owner
  const [ownerToClear, setOwnerToClear] = useState<{ apt: Apartment; action: 'clear_owner' | 'delete_apartment' } | null>(null);

  // Quick edit state
  const [editingAptId, setEditingAptId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editCin, setEditCin] = useState('');
  const [editFee, setEditFee] = useState<number>(150);

  // Synchronize initial values when modal opens or props change
  useEffect(() => {
    if (isOpen) {
      if (initialBuildingCode) setSelectedBuilding(initialBuildingCode);
      if (initialApartmentNumber) setApartmentNumber(initialApartmentNumber);
      if (defaultTab) setActiveTab(defaultTab);
      setFeedbackMessage(null);
    }
  }, [isOpen, initialBuildingCode, initialApartmentNumber, defaultTab]);

  // Existing apartment in selected building
  const existingApt = useMemo(() => {
    const targetNumber = isCustomAptNumber ? customAptNumber.trim() : apartmentNumber.trim();
    return apartments.find(
      a => a.buildingCode.trim().toUpperCase() === selectedBuilding.trim().toUpperCase() &&
           String(a.number).trim().padStart(2, '0') === String(targetNumber).padStart(2, '0')
    );
  }, [apartments, selectedBuilding, apartmentNumber, isCustomAptNumber, customAptNumber]);

  // If apartment exists, prefill floor and fee, and show existing owner
  useEffect(() => {
    if (existingApt) {
      setFloor(existingApt.floor ?? 0);
      setMonthlyFee(existingApt.monthlyFee || 150);
    }
  }, [existingApt]);

  // Helper: Get building display list (Group A & Group B)
  const parseBuildingCode = (code: string) => {
    const match = (code || '').match(/GH\s*(\d+)\s*([AB])/i);
    if (match) {
      return { num: parseInt(match[1], 10), letter: match[2].toUpperCase() };
    }
    return { num: 999, letter: '' };
  };

  const buildingsGroupA = useMemo(() => {
    return buildings
      .filter(b => parseBuildingCode(b.code).letter === 'A')
      .sort((a, b) => parseBuildingCode(a.code).num - parseBuildingCode(b.code).num);
  }, [buildings]);

  const buildingsGroupB = useMemo(() => {
    return buildings
      .filter(b => parseBuildingCode(b.code).letter === 'B')
      .sort((a, b) => parseBuildingCode(a.code).num - parseBuildingCode(b.code).num);
  }, [buildings]);

  // Available apartments in the currently selected building
  const availableAptsInSelectedBuilding = useMemo(() => {
    return apartments
      .filter(a => a.buildingCode.trim().toUpperCase() === selectedBuilding.trim().toUpperCase())
      .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));
  }, [apartments, selectedBuilding]);

  // Filtered owners list for Remove / List tabs
  const filteredApartments = useMemo(() => {
    return apartments.filter(apt => {
      // Building filter
      if (filterBuilding !== 'ALL' && apt.buildingCode.trim().toUpperCase() !== filterBuilding.trim().toUpperCase()) {
        return false;
      }
      // Search term
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const aptNum = String(apt.number).toLowerCase();
        const bCode = apt.buildingCode.toLowerCase();
        const oName = (apt.ownerName || '').toLowerCase();
        const rName = (apt.residentName || '').toLowerCase();
        const phone = (apt.ownerPhone || apt.residentPhone || '').toLowerCase();
        const cin = (apt.ownerCin || '').toLowerCase();
        return (
          aptNum.includes(term) ||
          bCode.includes(term) ||
          oName.includes(term) ||
          rName.includes(term) ||
          phone.includes(term) ||
          cin.includes(term)
        );
      }
      return true;
    }).sort((a, b) => {
      if (a.buildingCode !== b.buildingCode) {
        return a.buildingCode.localeCompare(b.buildingCode);
      }
      return a.number.localeCompare(b.number, undefined, { numeric: true });
    });
  }, [apartments, filterBuilding, searchTerm]);

  // Total stats
  const totalOwnersCount = useMemo(() => {
    return apartments.filter(a => (a.ownerName && a.ownerName.trim().length > 0) || (a.residentName && a.residentName.trim().length > 0)).length;
  }, [apartments]);

  const vacantAptsCount = useMemo(() => {
    return apartments.filter(a => !a.ownerName?.trim() && !a.residentName?.trim()).length;
  }, [apartments]);

  // Handle Add/Increase Owner (زيادة مالك)
  const handleAddOwnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalNumber = (isCustomAptNumber ? customAptNumber.trim() : apartmentNumber.trim()).padStart(2, '0');
    const finalName = ownerFullName.trim();

    if (!finalName) {
      setFeedbackMessage({
        type: 'error',
        text: lang === 'ar' ? 'يرجى إدخال الاسم الكامل للمالك' : 'Veuillez saisir le nom complet du propriétaire'
      });
      return;
    }

    if (!finalNumber) {
      setFeedbackMessage({
        type: 'error',
        text: lang === 'ar' ? 'يرجى تحديد رقم الشقة' : 'Veuillez spécifier le numéro d\'appartement'
      });
      return;
    }

    // 1. Update or create apartment
    if (existingApt) {
      updateApartment(existingApt.id, {
        ownerName: finalName,
        residentName: occupancyType === 'owner_resident' ? finalName : (existingApt.residentName || finalName),
        ownerPhone: ownerPhone.trim() || existingApt.ownerPhone,
        residentPhone: ownerPhone.trim() || existingApt.residentPhone,
        ownerCin: ownerCin.trim().toUpperCase() || existingApt.ownerCin,
        floor: Number(floor) || 0,
        monthlyFee: Number(monthlyFee) || 150,
        isRented: occupancyType === 'owner_landlord',
        status: 'occupied'
      });
    } else {
      addApartment({
        number: finalNumber,
        buildingCode: selectedBuilding,
        floor: Number(floor) || 0,
        ownerName: finalName,
        residentName: finalName,
        ownerPhone: ownerPhone.trim(),
        residentPhone: ownerPhone.trim(),
        ownerCin: ownerCin.trim().toUpperCase(),
        isRented: occupancyType === 'owner_landlord',
        status: 'occupied',
        monthlyFee: Number(monthlyFee) || 150,
        balanceDue: 0
      });
    }

    // 2. Sync / Add to residents list
    const existingRes = residents.find(
      r => r.buildingCode.trim().toUpperCase() === selectedBuilding.trim().toUpperCase() &&
           String(r.apartmentNumber).trim().padStart(2, '0') === finalNumber
    );

    if (existingRes) {
      updateResident(existingRes.id, {
        fullName: finalName,
        phone: ownerPhone.trim() || existingRes.phone,
        cin: ownerCin.trim().toUpperCase() || existingRes.cin,
        type: 'owner'
      });
    } else {
      addResident({
        fullName: finalName,
        type: 'owner',
        buildingCode: selectedBuilding,
        apartmentNumber: finalNumber,
        phone: ownerPhone.trim(),
        email: '',
        cin: ownerCin.trim().toUpperCase(),
        familyMembersCount: 1,
        entryDate: new Date().toISOString().slice(0, 10)
      });
    }

    // Sync payments with new resident names
    syncAllPaymentsWithResidents();

    setFeedbackMessage({
      type: 'success',
      text: lang === 'ar'
        ? `✅ تم بنجاح إضافة وتثبيت المالك "${finalName}" بالشقة ${finalNumber} بالعمارة ${selectedBuilding}. البيانات أصبحت فورية في كافة الوصولات والمستحقات.`
        : `✅ Le propriétaire "${finalName}" a été enregistré avec succès pour l'appartement ${finalNumber} (${selectedBuilding}).`
    });

    // Reset fields for convenient next entry
    setOwnerFullName('');
    setOwnerPhone('');
    setOwnerCin('');
  };

  // Handle Remove/Decrease Owner (نقص مالك)
  const handleConfirmClearOwner = () => {
    if (!ownerToClear) return;
    const { apt, action } = ownerToClear;

    const bCode = apt.buildingCode.trim().toUpperCase();
    const aNum = String(apt.number).trim().padStart(2, '0');
    const oldOwnerName = apt.ownerName || apt.residentName || '';

    if (action === 'delete_apartment') {
      // Complete removal of apartment from records
      deleteApartment(apt.id);

      // Also remove resident if exists
      const res = residents.find(
        r => r.buildingCode.trim().toUpperCase() === bCode &&
             String(r.apartmentNumber).trim().padStart(2, '0') === aNum
      );
      if (res) {
        deleteResident(res.id);
      }

      setFeedbackMessage({
        type: 'info',
        text: lang === 'ar'
          ? `🗑️ تم حذف الشقة ${apt.number} بالعمارة ${apt.buildingCode} والمالك "${oldOwnerName}" نهائياً من النظام.`
          : `🗑️ L'appartement ${apt.number} et le propriétaire "${oldOwnerName}" ont été supprimés définitivement.`
      });
    } else {
      // Clear owner details (make apartment vacant / without owner)
      updateApartment(apt.id, {
        ownerName: '',
        residentName: '',
        ownerPhone: '',
        residentPhone: '',
        ownerCin: '',
        status: 'vacant'
      });

      // Remove from residents table
      const res = residents.find(
        r => r.buildingCode.trim().toUpperCase() === bCode &&
             String(r.apartmentNumber).trim().padStart(2, '0') === aNum
      );
      if (res) {
        deleteResident(res.id);
      }

      setFeedbackMessage({
        type: 'info',
        text: lang === 'ar'
          ? `👤 تم بنجاح نقص وإزالة المالك "${oldOwnerName}" من الشقة ${apt.number} بالعمارة ${apt.buildingCode} وأصبحت الشقة شاغرة بدون مالك.`
          : `👤 Le propriétaire "${oldOwnerName}" a été retiré de l'appartement ${apt.number}. L'appartement est désormais vacant.`
      });
    }

    syncAllPaymentsWithResidents();
    setOwnerToClear(null);
  };

  // Quick edit save
  const handleSaveQuickEdit = (apt: Apartment) => {
    if (!editName.trim()) return;

    updateApartment(apt.id, {
      ownerName: editName.trim(),
      residentName: editName.trim(),
      ownerPhone: editPhone.trim(),
      residentPhone: editPhone.trim(),
      ownerCin: editCin.trim().toUpperCase(),
      monthlyFee: Number(editFee) || 150,
      status: 'occupied'
    });

    // Sync resident
    const bCode = apt.buildingCode.trim().toUpperCase();
    const aNum = String(apt.number).trim().padStart(2, '0');
    const existingRes = residents.find(
      r => r.buildingCode.trim().toUpperCase() === bCode &&
           String(r.apartmentNumber).trim().padStart(2, '0') === aNum
    );

    if (existingRes) {
      updateResident(existingRes.id, {
        fullName: editName.trim(),
        phone: editPhone.trim(),
        cin: editCin.trim().toUpperCase(),
        type: 'owner'
      });
    }

    syncAllPaymentsWithResidents();
    setEditingAptId(null);

    setFeedbackMessage({
      type: 'success',
      text: lang === 'ar'
        ? `✅ تم تحديث بيانات المالك "${editName.trim()}" بنجاح.`
        : `✅ Données du copropriétaire mises à jour avec succès.`
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden my-auto">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between gap-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/30 shrink-0">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black tracking-tight">
                  {lang === 'ar' ? 'إدارة الملاك (زيادة أو نقصان الملاك)' : 'Gestion des Copropriétaires (+ / -)'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-[10px] font-bold">
                  {lang === 'ar' ? 'استلام الواجبات' : 'Paiements'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 font-medium">
                {lang === 'ar'
                  ? 'إضافة ملاك جدد لتعيينهم بالشقق أو نقص وحذف ملاك مع ضبط فوري لوصولات ومستحقات السانديك'
                  : 'Ajouter de nouveaux propriétaires ou retirer/supprimer des copropriétaires'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-colors cursor-pointer shrink-0"
            title={t.common.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats Ribbon */}
        <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? 'الملاك المسجلين:' : 'Propriétaires:'}</span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 font-mono font-black">
                {totalOwnersCount}
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <Home className="w-4 h-4 text-amber-600" />
              <span>{lang === 'ar' ? 'شقق شاغرة / بدون مالك:' : 'Logements vacants:'}</span>
              <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono font-black">
                {vacantAptsCount}
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-bold text-slate-700">
              <Building2 className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ar' ? 'العمارات:' : 'Immeubles:'}</span>
              <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 font-mono font-black">
                {buildings.length} (20 عمارة)
              </span>
            </div>
          </div>

          {/* Tab Navigation Buttons */}
          <div className="flex items-center gap-1 bg-slate-200/80 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => { setActiveTab('add'); setFeedbackMessage(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === 'add'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? '➕ زيادة مالك (إضافة)' : '➕ Ajouter copropriétaire'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('remove'); setFeedbackMessage(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === 'remove'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
              }`}
            >
              <UserMinus className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? '➖ نقص مالك (إزالة/حذف)' : '➖ Retirer copropriétaire'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setActiveTab('list'); setFeedbackMessage(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeTab === 'list'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? '📋 قائمة الملاك والبحث' : '📋 Liste complète'}</span>
            </button>
          </div>
        </div>

        {/* Feedback Message Banner */}
        {feedbackMessage && (
          <div className={`mx-6 mt-4 p-3.5 rounded-xl border flex items-center justify-between text-xs font-bold animate-in fade-in ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : feedbackMessage.type === 'error'
              ? 'bg-rose-50 border-rose-300 text-rose-950'
              : 'bg-blue-50 border-blue-300 text-blue-950'
          }`}>
            <div className="flex items-center gap-2">
              {feedbackMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : feedbackMessage.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span>{feedbackMessage.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setFeedbackMessage(null)}
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: زيادة مالك (ADD OWNER) */}
          {activeTab === 'add' && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-blue-50/80 via-indigo-50/50 to-blue-50/80 p-4 rounded-2xl border border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-blue-600 text-white shrink-0 mt-0.5">
                    <UserPlus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-blue-950">
                      {lang === 'ar' ? 'زيادة وتسجيل مالك جديد في السجل' : 'Ajouter un nouveau copropriétaire'}
                    </h3>
                    <p className="text-xs text-blue-800/80 mt-0.5">
                      {lang === 'ar'
                        ? 'اختر العمارة ورقم الشقة لإسنادها لمالك جديد، أو كتابة رقم شقة إضافية. سيتم تحديث الوصولات والمستحقات فوراً.'
                        : 'Sélectionnez l\'immeuble et le numéro d\'appartement pour attribuer un nouveau propriétaire.'}
                    </p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleAddOwnerSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  
                  {/* Building Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'العمارة السكنية *' : 'Immeuble *'}
                    </label>
                    <select
                      value={selectedBuilding}
                      onChange={e => {
                        setSelectedBuilding(e.target.value);
                        setFeedbackMessage(null);
                      }}
                      className="w-full px-3 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-bold text-slate-900 bg-white"
                    >
                      <optgroup label="المجموعة الأولى (10 عمارات A: من GH 34 A إلى GH 43 A)">
                        {buildingsGroupA.map(b => (
                          <option key={b.id} value={b.code}>
                            {b.code} ({b.name})
                          </option>
                        ))}
                      </optgroup>
                      <optgroup label="المجموعة الثانية (10 عمارات B: من GH 34 B إلى GH 43 B)">
                        {buildingsGroupB.map(b => (
                          <option key={b.id} value={b.code}>
                            {b.code} ({b.name})
                          </option>
                        ))}
                      </optgroup>
                    </select>
                  </div>

                  {/* Apartment Number Selection or Custom */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-bold text-slate-700">
                        {lang === 'ar' ? 'رقم الشقة *' : 'Appartement *'}
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsCustomAptNumber(!isCustomAptNumber)}
                        className="text-[10px] text-blue-700 hover:text-blue-900 font-bold underline cursor-pointer"
                      >
                        {isCustomAptNumber
                          ? (lang === 'ar' ? 'اختيار من القائمة' : 'Choisir de la liste')
                          : (lang === 'ar' ? '+ رقم شقة مخصص' : '+ Numéro personnalisé')}
                      </button>
                    </div>

                    {isCustomAptNumber ? (
                      <input
                        type="text"
                        required
                        value={customAptNumber}
                        onChange={e => setCustomAptNumber(e.target.value)}
                        placeholder="مثال: 17 أو 01 bis"
                        className="w-full px-3 py-2.5 text-xs rounded-xl border border-blue-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-bold text-slate-900 bg-blue-50/30"
                      />
                    ) : (
                      <select
                        value={apartmentNumber}
                        onChange={e => {
                          setApartmentNumber(e.target.value);
                          setFeedbackMessage(null);
                        }}
                        className="w-full px-3 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-bold text-slate-900 bg-white"
                      >
                        {availableAptsInSelectedBuilding.length > 0 ? (
                          availableAptsInSelectedBuilding.map(a => {
                            const hasOwner = !!a.ownerName?.trim();
                            return (
                              <option key={a.id} value={a.number}>
                                {lang === 'ar' ? 'شقة' : 'Appt'} {a.number} {hasOwner ? `• ${a.ownerName}` : '• (شاغرة / بدون مالك)'}
                              </option>
                            );
                          })
                        ) : (
                          Array.from({ length: 16 }, (_, i) => {
                            const num = String(i + 1).padStart(2, '0');
                            return (
                              <option key={num} value={num}>
                                {lang === 'ar' ? 'شقة' : 'Appt'} {num}
                              </option>
                            );
                          })
                        )}
                      </select>
                    )}
                  </div>

                  {/* Floor */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'الطابق' : 'Étage'}
                    </label>
                    <select
                      value={floor}
                      onChange={e => setFloor(Number(e.target.value))}
                      className="w-full px-3 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-semibold text-slate-900 bg-white"
                    >
                      <option value={0}>{lang === 'ar' ? 'الطابق الأرضي (السفلي RDC)' : 'Rez-de-chaussée (RDC)'}</option>
                      <option value={1}>{lang === 'ar' ? 'الطابق الأول (1er)' : '1er Étage'}</option>
                      <option value={2}>{lang === 'ar' ? 'الطابق الثاني (2ème)' : '2ème Étage'}</option>
                      <option value={3}>{lang === 'ar' ? 'الطابق الثالث (3ème)' : '3ème Étage'}</option>
                      <option value={4}>{lang === 'ar' ? 'الطابق الرابع (4ème)' : '4ème Étage'}</option>
                    </select>
                  </div>
                </div>

                {/* Info about current owner if apartment is occupied */}
                {existingApt && existingApt.ownerName && (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        {lang === 'ar' 
                          ? `هذه الشقة مسجل بها حالياً المالك: "${existingApt.ownerName}" (${existingApt.ownerPhone || 'بدون هاتف'}). تسجيل مالك جديد سيقوم بنقل الملكية وتحديث البيانات.`
                          : `Actuellement attribué à: "${existingApt.ownerName}". L'enregistrement remplacera ce copropriétaire.`}
                      </span>
                    </div>
                  </div>
                )}

                {/* Owner details inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                  
                  {/* Owner Full Name */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'اسم المالك الكامل *' : 'Nom complet du copropriétaire *'}
                    </label>
                    <input
                      type="text"
                      required
                      value={ownerFullName}
                      onChange={e => setOwnerFullName(e.target.value)}
                      placeholder={lang === 'ar' ? 'مثال: السيد محمد العلمي أو السيدة مريم التازي' : 'Ex: M. Mohammed Alami'}
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-bold text-slate-900 bg-white"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'رقم الهاتف' : 'Téléphone'}
                    </label>
                    <input
                      type="tel"
                      value={ownerPhone}
                      onChange={e => setOwnerPhone(e.target.value)}
                      placeholder="06 XX XX XX XX"
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-semibold text-slate-900 bg-white"
                    />
                  </div>

                  {/* National ID / CIN */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'رقم البطاقة الوطنية (CIN)' : 'N° CIN'}
                    </label>
                    <input
                      type="text"
                      value={ownerCin}
                      onChange={e => setOwnerCin(e.target.value)}
                      placeholder="مثال: AB123456"
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-semibold uppercase text-slate-900 bg-white"
                    />
                  </div>

                  {/* Monthly Fee */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'الواجب الشهري المتفق عليه (درهم)' : 'Cotisation mensuelle (DH)'}
                    </label>
                    <input
                      type="number"
                      min={0}
                      value={monthlyFee}
                      onChange={e => setMonthlyFee(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-bold text-slate-900 bg-white"
                    />
                  </div>

                  {/* Occupancy Type */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {lang === 'ar' ? 'صفة السكن' : 'Type d\'occupation'}
                    </label>
                    <select
                      value={occupancyType}
                      onChange={e => setOccupancyType(e.target.value as any)}
                      className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-600 focus:outline-hidden font-semibold text-slate-900 bg-white"
                    >
                      <option value="owner_resident">{lang === 'ar' ? 'مالك مقيم بالشقة' : 'Copropriétaire occupant'}</option>
                      <option value="owner_landlord">{lang === 'ar' ? 'مالك غير مقيم (شقة مكرية/مؤجرة)' : 'Bailleur (Appt loué)'}</option>
                    </select>
                  </div>
                </div>

                {/* Submit Action */}
                <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors cursor-pointer"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white text-xs font-black shadow-md shadow-blue-500/20 transition-all cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'تأكيد وحفظ زيادة المالك ➕' : 'Enregistrer le copropriétaire'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: نقص مالك (REMOVE / DECREASE OWNER) */}
          {activeTab === 'remove' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-rose-50/90 via-orange-50/50 to-rose-50/90 p-4 rounded-2xl border border-rose-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-rose-600 text-white shrink-0 mt-0.5">
                    <UserMinus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-rose-950">
                      {lang === 'ar' ? 'نقص مالك (إزالة المالك أو تفريغ الشقة)' : 'Retirer un copropriétaire (Logement vacant / Suppression)'}
                    </h3>
                    <p className="text-xs text-rose-800/80 mt-0.5">
                      {lang === 'ar'
                        ? 'يمكنك نقص المالك عبر تفريغ الشقة وجعلها شاغرة (دون مالك مسجل)، أو حذف سجل الشقة بالكامل إذا كانت زائدة عن الحاجة.'
                        : 'Permet de retirer un propriétaire de son logement (rendre vacant) ou de supprimer complètement l\'appartement.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Search and Filters */}
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <div className="relative flex-1 w-full">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 rtl:right-3.5 rtl:left-auto ltr:left-3.5 ltr:right-auto" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder={lang === 'ar' ? 'بحث باسم المالك، رقم الشقة، العمارة، أو الهاتف...' : 'Recherche par nom, appartement, immeuble...'}
                    className="w-full h-10 pr-10 pl-10 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden font-medium text-slate-900"
                  />
                </div>
                <div className="w-full sm:w-64">
                  <select
                    value={filterBuilding}
                    onChange={e => setFilterBuilding(e.target.value)}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 font-bold text-slate-800"
                  >
                    <option value="ALL">{lang === 'ar' ? '🏢 جميع العمارات (20 عمارة)' : 'Tous les immeubles'}</option>
                    <optgroup label="المجموعة الأولى (10 عمارات A)">
                      {buildingsGroupA.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                    <optgroup label="المجموعة الثانية (10 عمارات B)">
                      {buildingsGroupB.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>

              {/* Owners Table for Removal */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                <div className="max-h-[380px] overflow-y-auto">
                  <table className="w-full text-right rtl:text-right ltr:text-left border-collapse text-xs">
                    <thead className="bg-slate-100/80 sticky top-0 z-10 text-slate-700 font-black border-b border-slate-200">
                      <tr>
                        <th className="p-3">{lang === 'ar' ? 'العمارة والشقة' : 'Immeuble & Appt'}</th>
                        <th className="p-3">{lang === 'ar' ? 'اسم المالك الحالي' : 'Propriétaire actuel'}</th>
                        <th className="p-3">{lang === 'ar' ? 'الهاتف و CIN' : 'Contact'}</th>
                        <th className="p-3">{lang === 'ar' ? 'الواجب الشهري' : 'Cotisation'}</th>
                        <th className="p-3 text-center">{lang === 'ar' ? 'إجراءات نقص المالك' : 'Actions'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredApartments.length > 0 ? (
                        filteredApartments.map(apt => {
                          const ownerName = apt.ownerName || apt.residentName || '';
                          const isOccupied = !!ownerName.trim();
                          return (
                            <tr key={apt.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="p-3 font-bold text-slate-900">
                                <div className="flex items-center gap-2">
                                  <span className="px-2 py-1 rounded-md bg-blue-50 text-blue-900 font-mono font-black border border-blue-200">
                                    {apt.buildingCode}
                                  </span>
                                  <span className="px-2 py-1 rounded-md bg-slate-100 text-slate-800 font-mono font-bold">
                                    {lang === 'ar' ? 'شقة' : 'Appt'} {apt.number}
                                  </span>
                                </div>
                              </td>

                              <td className="p-3">
                                {isOccupied ? (
                                  <div className="font-black text-slate-900">
                                    {ownerName}
                                  </div>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 font-medium text-[11px]">
                                    {lang === 'ar' ? 'شاغرة (بدون مالك)' : 'Vacant'}
                                  </span>
                                )}
                              </td>

                              <td className="p-3 text-slate-600">
                                <div>{apt.ownerPhone || apt.residentPhone || '-'}</div>
                                {apt.ownerCin && (
                                  <div className="text-[10px] font-mono text-slate-400">CIN: {apt.ownerCin}</div>
                                )}
                              </td>

                              <td className="p-3 font-mono font-bold text-slate-800">
                                {apt.monthlyFee || 150} DH
                              </td>

                              <td className="p-3 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  {isOccupied && (
                                    <button
                                      type="button"
                                      onClick={() => setOwnerToClear({ apt, action: 'clear_owner' })}
                                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-orange-50 hover:bg-orange-100 text-orange-800 font-bold text-[11px] border border-orange-200 transition-colors cursor-pointer"
                                      title={lang === 'ar' ? 'نقص المالك وجعل الشقة شاغرة' : 'Retirer le propriétaire (Rendre vacant)'}
                                    >
                                      <UserMinus className="w-3.5 h-3.5 text-orange-600" />
                                      <span>{lang === 'ar' ? 'نقص المالك' : 'Retirer'}</span>
                                    </button>
                                  )}

                                  <button
                                    type="button"
                                    onClick={() => setOwnerToClear({ apt, action: 'delete_apartment' })}
                                    className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-900 border border-rose-200 transition-colors cursor-pointer"
                                    title={lang === 'ar' ? 'حذف الشقة بالكامل من السجل' : 'Supprimer l\'appartement'}
                                  >
                                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={5} className="p-8 text-center text-slate-400 font-bold">
                            {lang === 'ar' ? 'لا توجد شقق أو ملاك متطابقين مع البحث' : 'Aucun résultat trouvé'}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: قائمة الملاك الشاملة والتعديل السريع (FULL LIST & EDIT) */}
          {activeTab === 'list' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <div className="relative flex-1 w-full">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 rtl:right-3.5 rtl:left-auto ltr:left-3.5 ltr:right-auto" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder={lang === 'ar' ? 'بحث سريع بالملاك والشقق...' : 'Recherche rapide...'}
                    className="w-full h-10 pr-10 pl-10 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 font-medium text-slate-900"
                  />
                </div>
                <div className="w-full sm:w-64">
                  <select
                    value={filterBuilding}
                    onChange={e => setFilterBuilding(e.target.value)}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 font-bold text-slate-800"
                  >
                    <option value="ALL">{lang === 'ar' ? 'جميع العمارات (20 عمارة)' : 'Tous les immeubles'}</option>
                    <optgroup label="المجموعة الأولى (عمارات A)">
                      {buildingsGroupA.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                    <optgroup label="المجموعة الثانية (عمارات B)">
                      {buildingsGroupB.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                  </select>
                </div>
              </div>

              {/* Editable Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                <div className="max-h-[400px] overflow-y-auto">
                  <table className="w-full text-right rtl:text-right ltr:text-left border-collapse text-xs">
                    <thead className="bg-slate-100/90 sticky top-0 z-10 text-slate-700 font-black border-b border-slate-200">
                      <tr>
                        <th className="p-3">{lang === 'ar' ? 'العمارة - الشقة' : 'Immeuble - Appt'}</th>
                        <th className="p-3">{lang === 'ar' ? 'اسم المالك' : 'Nom du copropriétaire'}</th>
                        <th className="p-3">{lang === 'ar' ? 'الهاتف' : 'Téléphone'}</th>
                        <th className="p-3">{lang === 'ar' ? 'CIN' : 'CIN'}</th>
                        <th className="p-3">{lang === 'ar' ? 'الواجب الشهري' : 'Cotisation'}</th>
                        <th className="p-3 text-center">{lang === 'ar' ? 'تعديل' : 'Modifier'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredApartments.map(apt => {
                        const isEditing = editingAptId === apt.id;
                        return (
                          <tr key={apt.id} className={isEditing ? 'bg-blue-50/60' : 'hover:bg-slate-50 transition-colors'}>
                            <td className="p-3 font-mono font-bold text-slate-900">
                              <span className="text-blue-900">{apt.buildingCode}</span> - {lang === 'ar' ? 'شقة' : 'Appt'} {apt.number}
                            </td>

                            <td className="p-3">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editName}
                                  onChange={e => setEditName(e.target.value)}
                                  className="w-full px-2 py-1 text-xs rounded-lg border border-blue-300 font-bold bg-white"
                                />
                              ) : (
                                <span className="font-bold text-slate-900">
                                  {apt.ownerName || apt.residentName || <span className="text-slate-400 italic">بدون مالك</span>}
                                </span>
                              )}
                            </td>

                            <td className="p-3 text-slate-700">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editPhone}
                                  onChange={e => setEditPhone(e.target.value)}
                                  className="w-full px-2 py-1 text-xs rounded-lg border border-blue-300 bg-white"
                                />
                              ) : (
                                apt.ownerPhone || apt.residentPhone || '-'
                              )}
                            </td>

                            <td className="p-3 font-mono text-slate-700 uppercase">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editCin}
                                  onChange={e => setEditCin(e.target.value)}
                                  className="w-full px-2 py-1 text-xs rounded-lg border border-blue-300 uppercase bg-white"
                                />
                              ) : (
                                apt.ownerCin || '-'
                              )}
                            </td>

                            <td className="p-3 font-mono font-bold text-slate-900">
                              {isEditing ? (
                                <input
                                  type="number"
                                  value={editFee}
                                  onChange={e => setEditFee(Number(e.target.value))}
                                  className="w-20 px-2 py-1 text-xs rounded-lg border border-blue-300 font-mono bg-white"
                                />
                              ) : (
                                `${apt.monthlyFee || 150} DH`
                              )}
                            </td>

                            <td className="p-3 text-center">
                              {isEditing ? (
                                <div className="flex items-center justify-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleSaveQuickEdit(apt)}
                                    className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors cursor-pointer"
                                    title={t.common.save}
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingAptId(null)}
                                    className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 transition-colors cursor-pointer"
                                    title={t.common.cancel}
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingAptId(apt.id);
                                    setEditName(apt.ownerName || apt.residentName || '');
                                    setEditPhone(apt.ownerPhone || apt.residentPhone || '');
                                    setEditCin(apt.ownerCin || '');
                                    setEditFee(apt.monthlyFee || 150);
                                  }}
                                  className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 transition-colors cursor-pointer"
                                  title={lang === 'ar' ? 'تعديل بيانات المالك' : 'Modifier'}
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Confirmation Modal for Clearing / Deleting Owner */}
        {ownerToClear && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-rose-200 space-y-4">
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-rose-100 text-rose-700 shrink-0">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {ownerToClear.action === 'delete_apartment'
                      ? (lang === 'ar' ? 'تأكيد حذف الشقة بالكامل' : 'Confirmer la suppression du logement')
                      : (lang === 'ar' ? 'تأكيد نقص وإزالة المالك' : 'Confirmer le retrait du copropriétaire')}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    {ownerToClear.action === 'delete_apartment' ? (
                      lang === 'ar' ? (
                        <>هل أنت متأكد من رغبتك في حذف الشقة <strong>{ownerToClear.apt.number}</strong> بالعمارة <strong>{ownerToClear.apt.buildingCode}</strong> نهائياً من قاعدة البيانات؟</>
                      ) : (
                        <>Voulez-vous supprimer définitivement le logement <strong>{ownerToClear.apt.number}</strong> ({ownerToClear.apt.buildingCode}) ?</>
                      )
                    ) : (
                      lang === 'ar' ? (
                        <>هل أنت متأكد من نقص وإزالة المالك <strong>"{ownerToClear.apt.ownerName || ownerToClear.apt.residentName}"</strong> من الشقة <strong>{ownerToClear.apt.number}</strong> بالعمارة <strong>{ownerToClear.apt.buildingCode}</strong> وجعلها شاغرة بدون مالك؟</>
                      ) : (
                        <>Voulez-vous retirer le propriétaire <strong>"{ownerToClear.apt.ownerName}"</strong> de l'appartement <strong>{ownerToClear.apt.number}</strong> ?</>
                      )
                    )}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setOwnerToClear(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-colors cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmClearOwner}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-md transition-colors cursor-pointer"
                >
                  {ownerToClear.action === 'delete_apartment'
                    ? (lang === 'ar' ? 'نعم، حذف الشقة نهائياً' : 'Oui, supprimer')
                    : (lang === 'ar' ? 'نعم، تأكيد نقص المالك' : 'Oui, retirer')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-600" />
            <span className="font-semibold">
              {lang === 'ar' ? 'المزامنة الفورية لمستحقات ووصولات السانديك مفعلة' : 'Synchronisation temps réel activée'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
          >
            {t.common.close}
          </button>
        </div>

      </div>
    </div>
  );
};
