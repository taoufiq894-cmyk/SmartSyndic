import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  FileSpreadsheet, Upload, Download, CheckCircle2, AlertCircle, 
  HelpCircle, ArrowRight, ArrowLeft, RefreshCw, Eye, X, Filter,
  FileCheck, Shield, Phone, Mail, Building, Home, MapPin, Hash, Sparkles,
  Users, UserCheck, AlertTriangle, Database
} from 'lucide-react';
import { 
  generateResidentsExcelTemplate,
  readExcelFile, 
  autoDetectResidentFieldMapping, 
  processResidentImportData,
  ResidentImportFieldMapping,
  ResidentImportSummary,
  ParsedResidentRow
} from '../utils/excelImportUtils';

interface ResidentsExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = 'upload' | 'mapping' | 'preview' | 'success';

export const ResidentsExcelImportModal: React.FC<ResidentsExcelImportModalProps> = ({ isOpen, onClose }) => {
  const { 
    lang, t, apartments, buildings, residents, importResidentsFromExcelData 
  } = useApp();
  const isAr = lang === 'ar';

  const [step, setStep] = useState<Step>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sheets data
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [sheetsRawData, setSheetsRawData] = useState<Record<string, { headers: string[]; rows: any[][] }>>({});

  // Column mapping
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ResidentImportFieldMapping>({
    fullName: '',
    type: '',
    buildingCode: '',
    apartmentNumber: '',
    phone: '',
    cin: '',
    email: '',
    vehiclePlate: '',
    familyMembersCount: '',
    entryDate: ''
  });

  // Processed Import Data
  const [summary, setSummary] = useState<ResidentImportSummary | null>(null);
  const [previewFilter, setPreviewFilter] = useState<'ALL' | 'existing' | 'new' | 'invalid'>('ALL');
  const [previewSearch, setPreviewSearch] = useState('');

  // Initial Setup & Import options
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [syncApartments, setSyncApartments] = useState(true);
  const [overwriteExistingDetails, setOverwriteExistingDetails] = useState(true);

  // Success stats
  const [resultStats, setResultStats] = useState<{
    residentsAdded: number;
    residentsUpdated: number;
    apartmentsSynced: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleReset = () => {
    setStep('upload');
    setFile(null);
    setErrorMessage(null);
    setSummary(null);
    setResultStats(null);
    setPreviewSearch('');
  };

  const handleFileProcess = async (selectedFile: File) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const parsed = await readExcelFile(selectedFile);
      if (parsed.sheetNames.length === 0) {
        throw new Error(isAr ? 'الملف فارغ أو غير مدعوم' : 'Le fichier est vide ou non pris en charge');
      }

      setFile(selectedFile);
      setSheetNames(parsed.sheetNames);
      setSheetsRawData(parsed.sheetsData);

      const firstSheet = parsed.sheetNames[0];
      setSelectedSheet(firstSheet);

      const sheetData = parsed.sheetsData[firstSheet];
      setHeaders(sheetData.headers);

      const autoMap = autoDetectResidentFieldMapping(sheetData.headers);
      setMapping(autoMap);

      // Auto-check if basic required columns are found
      const hasReq = autoMap.fullName && autoMap.buildingCode && autoMap.apartmentNumber;
      if (hasReq) {
        const resSummary = processResidentImportData(
          sheetData.headers, 
          sheetData.rows, 
          autoMap, 
          residents, 
          apartments, 
          buildings
        );
        setSummary(resSummary);
        setStep('preview');
      } else {
        setStep('mapping');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || (isAr ? 'حدث خطأ أثناء قراءة ملف Excel' : 'Erreur lors de la lecture du fichier Excel'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSheetChange = (sheetName: string) => {
    setSelectedSheet(sheetName);
    const sheetData = sheetsRawData[sheetName];
    if (sheetData) {
      setHeaders(sheetData.headers);
      const autoMap = autoDetectResidentFieldMapping(sheetData.headers);
      setMapping(autoMap);
    }
  };

  const handleProceedToPreview = () => {
    if (!mapping.fullName || !mapping.buildingCode || !mapping.apartmentNumber) {
      setErrorMessage(
        isAr 
          ? 'يرجى تحديد الأعمدة الإلزامية: اسم الساكن، رمز العمارة، ورقم الشقة.' 
          : 'Veuillez mapper les colonnes obligatoires : Nom du résident, Code Bâtiment et N° Appartement.'
      );
      return;
    }
    setErrorMessage(null);
    const sheetData = sheetsRawData[selectedSheet];
    if (!sheetData) return;

    const resSummary = processResidentImportData(
      sheetData.headers,
      sheetData.rows,
      mapping,
      residents,
      apartments,
      buildings
    );
    setSummary(resSummary);
    setStep('preview');
  };

  const handleExecuteImport = () => {
    if (!summary || summary.validRows === 0) {
      setErrorMessage(isAr ? 'لا توجد بيانات صالحة للاستيراد' : 'Aucune donnée valide à importer');
      return;
    }

    setIsLoading(true);
    try {
      const validRowsToImport = summary.parsedData
        .filter(r => r.matchType === 'existing' || r.matchType === 'new')
        .map(r => ({
          fullName: r.fullName,
          type: r.type,
          buildingCode: r.buildingCode,
          apartmentNumber: r.apartmentNumber,
          phone: r.phone,
          email: r.email,
          cin: r.cin,
          vehiclePlate: r.vehiclePlate,
          familyMembersCount: r.familyMembersCount,
          entryDate: r.entryDate
        }));

      const results = importResidentsFromExcelData(validRowsToImport, {
        mode: importMode,
        syncApartments,
        overwriteExistingDetails
      });

      setResultStats(results);
      setStep('success');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || (isAr ? 'فشل تنفيذ استيراد السكان' : 'Échec de l\'importation'));
    } finally {
      setIsLoading(false);
    }
  };

  const filteredPreviewData = summary?.parsedData.filter(r => {
    const matchesFilter = 
      previewFilter === 'ALL' || 
      r.matchType === previewFilter;

    const searchLower = previewSearch.toLowerCase();
    const matchesSearch = !previewSearch || 
      r.fullName.toLowerCase().includes(searchLower) ||
      r.buildingCode.toLowerCase().includes(searchLower) ||
      r.apartmentNumber.includes(searchLower) ||
      r.phone.includes(searchLower) ||
      (r.cin && r.cin.toLowerCase().includes(searchLower)) ||
      (r.vehiclePlate && r.vehiclePlate.toLowerCase().includes(searchLower));

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0a8591] via-[#0b6a78] to-[#0f172a] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/20">
              <FileSpreadsheet className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">
                  {isAr ? 'استيراد وتحديث قائمة السكان من ملف Excel' : 'Importation de la Liste des Résidents via Excel'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 uppercase">
                  {isAr ? 'إدخال أولي سهل' : 'Initialisation'}
                </span>
              </div>
              <p className="text-xs text-rose-100 font-medium mt-0.5">
                {isAr 
                  ? 'تسجيل الملاك والمكترين دفعة واحدة ومزامنة بطاقات الشقق وتسهيل الإدخال الأولي للنظام'
                  : 'Saisie initiale rapide de tous les résidents et synchronisation automatique avec les appartements'}
              </p>
            </div>
          </div>
          <button 
            type="button"
            id="btn-close-residents-excel-modal"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between overflow-x-auto text-xs font-bold text-slate-600 shrink-0">
          <div className={`flex items-center gap-2 shrink-0 ${step === 'upload' ? 'text-[#0a8591] font-black' : ''}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'upload' ? 'bg-[#0a8591] text-white' : 'bg-slate-200 text-slate-600'}`}>1</span>
            <span>{isAr ? 'رفع الملف أو النموذج' : 'Fichier / Modèle'}</span>
          </div>
          <div className="w-8 h-0.5 bg-slate-200 shrink-0" />
          <div className={`flex items-center gap-2 shrink-0 ${step === 'mapping' ? 'text-[#0a8591] font-black' : ''}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'mapping' ? 'bg-[#0a8591] text-white' : 'bg-slate-200 text-slate-600'}`}>2</span>
            <span>{isAr ? 'مطابقة الأعمدة' : 'Colonnes'}</span>
          </div>
          <div className="w-8 h-0.5 bg-slate-200 shrink-0" />
          <div className={`flex items-center gap-2 shrink-0 ${step === 'preview' ? 'text-[#0a8591] font-black' : ''}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'preview' ? 'bg-[#0a8591] text-white' : 'bg-slate-200 text-slate-600'}`}>3</span>
            <span>{isAr ? 'المعاينة وخيارات الإدخال' : 'Aperçu & Options'}</span>
          </div>
          <div className="w-8 h-0.5 bg-slate-200 shrink-0" />
          <div className={`flex items-center gap-2 shrink-0 ${step === 'success' ? 'text-emerald-700 font-black' : ''}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${step === 'success' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'}`}>4</span>
            <span>{isAr ? 'تم الاستيراد' : 'Succès'}</span>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="m-4 p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2.5 animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span className="font-semibold">{errorMessage}</span>
          </div>
        )}

        {/* Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">

          {/* ================= STEP 1: UPLOAD & TEMPLATE ================= */}
          {step === 'upload' && (
            <div className="space-y-6">
              {/* Guidance Box */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-500 text-slate-950 shrink-0 shadow-2xs">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div className="text-xs text-amber-950 leading-relaxed">
                  <span className="font-black block text-sm mb-0.5">
                    {isAr ? 'طريقة ميسرة وسريعة للإدخال الأولي لبيانات السكان 📋' : 'Initialisation rapide des données de la résidence 📋'}
                  </span>
                  {isAr ? (
                    <p>
                      لتفادي إدخال بيانات السكان يدوياً شقة بشقة، يمكنك تحميل نموذج Excel أدناه الجاهز والمسبق التعبئة بعمارات وشقق الإقامة (320 شقة)، تعبئة أسماء الملاك أو المكترين وهواتفهم، ثم إعادة رفع الملف هنا ليقوم النظام تلقائياً بتسجيل السكان وتحديث بطاقات الشقق!
                    </p>
                  ) : (
                    <p>
                      Pour éviter la saisie manuelle appartement par appartement, téléchargez notre modèle Excel pré-rempli avec les 320 appartements de la résidence, remplissez les noms et coordonnées des résidents, puis importez le fichier ici.
                    </p>
                  )}
                </div>
              </div>

              {/* Download Pre-filled vs Blank Template Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Template 1: Pre-filled with 320 apartments */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 via-white to-teal-50/40 border-2 border-emerald-200/90 shadow-2xs hover:border-emerald-500 transition-all flex flex-col justify-between space-y-3 group">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-emerald-600 text-white shadow-2xs group-hover:scale-105 transition-transform">
                        <Download className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          {isAr ? 'نموذج مسبق التعبئة (320 شقة)' : 'Modèle Pré-rempli (320 appartements)'}
                        </h4>
                        <span className="text-[10px] text-emerald-800 font-bold">
                          {isAr ? 'شامل لجميع العمارات من GH 34 A إلى GH 35 J' : 'Contient tous les lots existants'}
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-normal">
                      {isAr 
                        ? 'مجهز سلفاً بكافة أرقام الشقق والعمارات والبيانات الحالية، لتقوم فقط بتعديل الأسماء أو إكمال الهواتف وبطاقات CIN.'
                        : 'Pré-rempli avec tous les numéros d\'appartements pour une saisie rapide et sans fautes de frappe.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    id="btn-download-prefilled-residents-template"
                    onClick={() => generateResidentsExcelTemplate(apartments, buildings, residents, lang, true)}
                    className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                    <span>{isAr ? 'تحميل النموذج المسبق (Excel) 📥' : 'Télécharger modèle complet'}</span>
                  </button>
                </div>

                {/* Template 2: Blank formatted template */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-50 via-white to-slate-50/50 border-2 border-slate-200 hover:border-slate-400 transition-all flex flex-col justify-between space-y-3 group">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-slate-800 text-white shadow-2xs group-hover:scale-105 transition-transform">
                        <FileCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-extrabold text-slate-900">
                          {isAr ? 'نموذج فارغ مع أمثلة إرشادية' : 'Modèle Vierge avec Exemples'}
                        </h4>
                        <span className="text-[10px] text-slate-500 font-bold">
                          {isAr ? 'تعبئة حرة مخصصة' : 'Saisie personnalisée'}
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 leading-normal">
                      {isAr 
                        ? 'ملف Excel فارغ يتضمن الأعمدة المطلوبة مع 4 أسطر تجريبية توضيحية ودليل الاستخدام.'
                        : 'Format type avec colonnes standardisées et guide de conformité pour vos données.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    id="btn-download-blank-residents-template"
                    onClick={() => generateResidentsExcelTemplate(apartments, buildings, residents, lang, false)}
                    className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 active:bg-slate-950 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-slate-300" />
                    <span>{isAr ? 'تحميل نموذج فارغ (Excel) 📄' : 'Télécharger modèle vierge'}</span>
                  </button>
                </div>
              </div>

              {/* Dropzone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    handleFileProcess(e.dataTransfer.files[0]);
                  }
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`p-8 sm:p-10 rounded-2xl border-2 border-dashed transition-all text-center cursor-pointer flex flex-col items-center justify-center gap-3 ${
                  isDragging 
                    ? 'border-[#0a8591] bg-rose-50/50 scale-[0.99]' 
                    : 'border-slate-300 hover:border-[#0a8591] bg-slate-50/60 hover:bg-white'
                }`}
              >
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileProcess(e.target.files[0]);
                    }
                  }} 
                  accept=".xlsx, .xls, .csv" 
                  className="hidden" 
                />

                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0a8591] to-[#3b82f6] text-white shadow-md shadow-[#0a8591]/20">
                  <Upload className="w-8 h-8" />
                </div>

                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-slate-800">
                    {isAr ? 'انقر لاختيار ملف Excel أو قم بإفلاته هنا' : 'Glissez-déposez votre fichier Excel ou cliquez pour parcourir'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium mt-1">
                    {isAr ? 'يدعم ملفات .xlsx و .xls و .csv (حتى 15 ميغابايت)' : 'Prend en charge .xlsx, .xls, .csv (jusqu\'à 15 Mo)'}
                  </p>
                </div>

                {isLoading && (
                  <div className="flex items-center gap-2 text-xs text-[#0a8591] font-bold mt-2 animate-pulse">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isAr ? 'جارٍ قراءة وفحص ملف Excel...' : 'Lecture et analyse du fichier...'}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= STEP 2: COLUMN MAPPING ================= */}
          {step === 'mapping' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 flex items-start gap-3">
                <HelpCircle className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div className="text-xs text-blue-900 leading-relaxed">
                  <span className="font-extrabold block mb-0.5">
                    {isAr ? 'تأكيد مطابقة أعمدة ملفك مع حقول النظام' : 'Vérifiez la correspondance des colonnes'}
                  </span>
                  {isAr 
                    ? 'تعرف النظام تلقائياً على الأعمدة. يرجى التأكد من مطابقة الحقول الإلزامية الثلاثة (الاسم الكامل، رمز العمارة، رقم الشقة).'
                    : 'Les colonnes ont été détectées automatiquement. Assurez-vous que les champs obligatoires (Nom, Bâtiment, Appartement) sont bien assignés.'}
                </div>
              </div>

              {/* Sheet selector if multiple sheets */}
              {sheetNames.length > 1 && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-4">
                  <label className="text-xs font-bold text-slate-700">
                    {isAr ? 'ورقة العمل المحددة في الملف:' : 'Feuille de calcul :'}
                  </label>
                  <select
                    value={selectedSheet}
                    onChange={(e) => handleSheetChange(e.target.value)}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-bold bg-white text-slate-800"
                  >
                    {sheetNames.map(name => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Mapping Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Full Name (Required) */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#0a8591]" />
                      <span>{isAr ? 'اسم الساكن الكامل' : 'Nom Complet du Résident'}</span>
                      <span className="text-red-500 font-bold">*</span>
                    </span>
                    {mapping.fullName && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.fullName}
                    onChange={(e) => setMapping(prev => ({ ...prev, fullName: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir colonne --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 2. Resident Type (Optional / Auto) */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                      <span>{isAr ? 'صفة الساكن (مالك / مكتري)' : 'Qualité (Propriétaire / Locataire)'}</span>
                    </span>
                    {mapping.type && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.type}
                    onChange={(e) => setMapping(prev => ({ ...prev, type: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- افتراضي (مالك) إن لم يحدد --' : '-- Par défaut (Propriétaire) --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 3. Building Code (Required) */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-amber-600" />
                      <span>{isAr ? 'رمز العمارة' : 'Code Bâtiment'}</span>
                      <span className="text-red-500 font-bold">*</span>
                    </span>
                    {mapping.buildingCode && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.buildingCode}
                    onChange={(e) => setMapping(prev => ({ ...prev, buildingCode: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir colonne --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 4. Apartment Number (Required) */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Home className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{isAr ? 'رقم الشقة' : 'N° Appartement'}</span>
                      <span className="text-red-500 font-bold">*</span>
                    </span>
                    {mapping.apartmentNumber && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.apartmentNumber}
                    onChange={(e) => setMapping(prev => ({ ...prev, apartmentNumber: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختر العمود --' : '-- Choisir colonne --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 5. Phone */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-600" />
                      <span>{isAr ? 'رقم الهاتف' : 'Téléphone'}</span>
                    </span>
                    {mapping.phone && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.phone}
                    onChange={(e) => setMapping(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 6. CIN */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-slate-600" />
                      <span>{isAr ? 'بطاقة التعريف (CIN)' : 'N° CIN'}</span>
                    </span>
                    {mapping.cin && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.cin}
                    onChange={(e) => setMapping(prev => ({ ...prev, cin: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 7. Email */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-600" />
                      <span>{isAr ? 'البريد الإلكتروني' : 'Email'}</span>
                    </span>
                    {mapping.email && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.email}
                    onChange={(e) => setMapping(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>

                {/* 8. Vehicle Plate */}
                <div className="p-3 rounded-xl border-2 border-slate-200 bg-white space-y-1.5">
                  <label className="flex items-center justify-between text-xs font-bold text-slate-900">
                    <span className="flex items-center gap-1.5">
                      <Hash className="w-3.5 h-3.5 text-slate-600" />
                      <span>{isAr ? 'رقم لوحة ترقيم السيارة' : 'Matricule Véhicule'}</span>
                    </span>
                    {mapping.vehiclePlate && <span className="text-[10px] text-emerald-600 font-black">✓ تم الربط</span>}
                  </label>
                  <select
                    value={mapping.vehiclePlate}
                    onChange={(e) => setMapping(prev => ({ ...prev, vehiclePlate: e.target.value }))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium text-slate-800 bg-slate-50 focus:bg-white"
                  >
                    <option value="">{isAr ? '-- اختياري --' : '-- Optionnel --'}</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* ================= STEP 3: PREVIEW & OPTIONS ================= */}
          {step === 'preview' && summary && (
            <div className="space-y-5">
              
              {/* Stats Summary Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 block">{isAr ? 'إجمالي السطور' : 'Total Lignes'}</span>
                  <span className="text-base font-black text-slate-900">{summary.totalRows}</span>
                </div>
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[10px] font-bold text-emerald-700 block">{isAr ? 'سكان جدد للإضافة' : 'Nouveaux Résidents'}</span>
                  <span className="text-base font-black text-emerald-800">+{summary.newResidents}</span>
                </div>
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <span className="text-[10px] font-bold text-blue-700 block">{isAr ? 'سكان للتحديث' : 'Mises à jour'}</span>
                  <span className="text-base font-black text-blue-800">{summary.existingResidents}</span>
                </div>
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-[10px] font-bold text-amber-700 block">{isAr ? 'سطور بها تنبيهات' : 'Lignes Invalides'}</span>
                  <span className="text-base font-black text-amber-800">{summary.invalidRows}</span>
                </div>
              </div>

              {/* Initial Data Entry Setup Options */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-50 via-white to-rose-50/20 border-2 border-slate-200 space-y-3">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#0a8591]" />
                  <h4 className="text-xs sm:text-sm font-black text-slate-900">
                    {isAr ? 'خيارات تهيئة وإدخال البيانات الأولية للنظام:' : 'Options d\'initialisation des données :'}
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {/* Mode Selector */}
                  <div className="space-y-2 p-3 rounded-xl bg-white border border-slate-200">
                    <span className="text-xs font-bold text-slate-800 block">
                      {isAr ? 'وضع الاستيراد والإدخال:' : 'Mode d\'importation :'}
                    </span>
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="importMode"
                        checked={importMode === 'merge'}
                        onChange={() => setImportMode('merge')}
                        className="text-[#0a8591] focus:ring-[#0a8591]"
                      />
                      <span>{isAr ? 'دمج وتحديث (مستحسن)' : 'Fusionner et mettre à jour (Recommandé)'}</span>
                    </label>
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="radio"
                        name="importMode"
                        checked={importMode === 'replace'}
                        onChange={() => setImportMode('replace')}
                        className="text-[#0a8591] focus:ring-[#0a8591]"
                      />
                      <span>{isAr ? 'إدخال أولي كامل / استبدال القائمة السابقة' : 'Initialisation complète (Remplacer la liste)'}</span>
                    </label>
                  </div>

                  {/* Sync Checkboxes */}
                  <div className="space-y-2 p-3 rounded-xl bg-white border border-slate-200">
                    <span className="text-xs font-bold text-slate-800 block">
                      {isAr ? 'المزامنة والتحديث التلقائي:' : 'Synchronisations automatiques :'}
                    </span>
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={syncApartments}
                        onChange={(e) => setSyncApartments(e.target.checked)}
                        className="rounded text-[#0a8591] focus:ring-[#0a8591]"
                      />
                      <span>{isAr ? 'مزامنة بطاقات الشقق وتحديث الساكن المقابل' : 'Mettre à jour les fiches appartements'}</span>
                    </label>
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={overwriteExistingDetails}
                        onChange={(e) => setOverwriteExistingDetails(e.target.checked)}
                        className="rounded text-[#0a8591] focus:ring-[#0a8591]"
                      />
                      <span>{isAr ? 'تحديث أرقام الهاتف والـ CIN القائمة بالجديدة' : 'Écraser téléphones et CIN si modifiés'}</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Table Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('ALL')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      previewFilter === 'ALL' ? 'bg-[#0a8591] text-white shadow-2xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {isAr ? 'الكل' : 'Tous'} ({summary.totalRows})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('new')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      previewFilter === 'new' ? 'bg-emerald-600 text-white shadow-2xs' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                    }`}
                  >
                    {isAr ? 'جديد' : 'Nouveau'} ({summary.newResidents})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('existing')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      previewFilter === 'existing' ? 'bg-blue-600 text-white shadow-2xs' : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                    }`}
                  >
                    {isAr ? 'تحديث' : 'Mise à jour'} ({summary.existingResidents})
                  </button>
                  {summary.invalidRows > 0 && (
                    <button
                      type="button"
                      onClick={() => setPreviewFilter('invalid')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        previewFilter === 'invalid' ? 'bg-red-600 text-white shadow-2xs' : 'bg-red-50 text-red-700 hover:bg-red-100'
                      }`}
                    >
                      {isAr ? 'أخطاء' : 'Erreurs'} ({summary.invalidRows})
                    </button>
                  )}
                </div>

                <div className="relative">
                  <input
                    type="text"
                    value={previewSearch}
                    onChange={(e) => setPreviewSearch(e.target.value)}
                    placeholder={isAr ? 'بحث في البيانات المستوردة...' : 'Rechercher...'}
                    className="w-full sm:w-56 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-300 bg-white"
                  />
                </div>
              </div>

              {/* Preview Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="max-h-64 overflow-y-auto">
                  <table className="w-full text-start text-xs border-collapse">
                    <thead className="bg-slate-100 sticky top-0 z-10 text-slate-700 font-extrabold border-b border-slate-200 text-start">
                      <tr>
                        <th className="p-2.5 text-center w-12">#</th>
                        <th className="p-2.5 text-start">{isAr ? 'الساكن الكامل' : 'Résident'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'الصفة' : 'Qualité'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'العمارة' : 'Bâtiment'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'الشقة' : 'Appt'}</th>
                        <th className="p-2.5 text-start">{isAr ? 'الهاتف' : 'Téléphone'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'CIN' : 'CIN'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'لوحة السيارة' : 'Matricule'}</th>
                        <th className="p-2.5 text-center">{isAr ? 'الحالة' : 'Statut'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 text-slate-700">
                      {filteredPreviewData && filteredPreviewData.length > 0 ? (
                        filteredPreviewData.map((row) => (
                          <tr key={row.rowNumber} className={row.matchType === 'invalid' ? 'bg-red-50/50' : 'hover:bg-slate-50'}>
                            <td className="p-2 text-center text-[10px] text-slate-400 font-mono">{row.rowNumber}</td>
                            <td className="p-2 font-bold text-slate-900">{row.fullName || '-'}</td>
                            <td className="p-2 text-center">
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                row.type === 'tenant' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-900'
                              }`}>
                                {row.type === 'tenant' ? (isAr ? 'مكتري' : 'Locataire') : (isAr ? 'مالك' : 'Propriétaire')}
                              </span>
                            </td>
                            <td className="p-2 text-center font-bold text-[#0a8591]">{row.buildingCode}</td>
                            <td className="p-2 text-center font-mono font-bold text-slate-800">{row.apartmentNumber}</td>
                            <td className="p-2 font-mono text-slate-600">{row.phone || '-'}</td>
                            <td className="p-2 text-center font-mono text-slate-600">{row.cin || '-'}</td>
                            <td className="p-2 text-center font-mono text-slate-600">{row.vehiclePlate || '-'}</td>
                            <td className="p-2 text-center">
                              {row.matchType === 'new' && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                  {isAr ? 'ساكن جديد' : 'Nouveau'}
                                </span>
                              )}
                              {row.matchType === 'existing' && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-800">
                                  {isAr ? 'تحديث قائم' : 'Mise à jour'}
                                </span>
                              )}
                              {row.matchType === 'invalid' && (
                                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-red-100 text-red-800" title={row.validationErrors.join(', ')}>
                                  {isAr ? 'خطأ بالسطر' : 'Erreur'}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={9} className="p-6 text-center text-slate-400 text-xs">
                            {isAr ? 'لا توجد بيانات مطابقة لخيارات البحث' : 'Aucune donnée correspondante'}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* ================= STEP 4: SUCCESS ================= */}
          {step === 'success' && resultStats && (
            <div className="py-6 text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-lg font-black text-slate-900">
                  {isAr ? 'اكتمل استيراد وتحديث قائمة السكان بنجاح! 🎉' : 'Importation des résidents réussie ! 🎉'}
                </h3>
                <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
                  {isAr 
                    ? 'تم تسجيل السكان ومزامنة بطاقات الشقق المقابلة بنجاح. أصبحت البيانات الأولية جاهزة في النظام.'
                    : 'Les résidents ont été enregistrés et les fiches d\'appartements ont été synchronisées avec succès.'}
                </p>
              </div>

              {/* Results Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-lg mx-auto">
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-xs font-bold text-emerald-800 block">{isAr ? 'سكان جدد أضيفوا' : 'Résidents Ajoutés'}</span>
                  <span className="text-xl font-black text-emerald-900">+{resultStats.residentsAdded}</span>
                </div>
                <div className="p-4 rounded-xl bg-blue-50 border border-blue-200">
                  <span className="text-xs font-bold text-blue-800 block">{isAr ? 'سجلات تم تحديثها' : 'Résidents Mis à jour'}</span>
                  <span className="text-xl font-black text-blue-900">{resultStats.residentsUpdated}</span>
                </div>
                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-xs font-bold text-amber-800 block">{isAr ? 'شقق تمت مزامنتها' : 'Appts Synchronisés'}</span>
                  <span className="text-xl font-black text-amber-900">{resultStats.apartmentsSynced}</span>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div>
            {step !== 'upload' && step !== 'success' && (
              <button
                type="button"
                onClick={() => setStep(step === 'preview' ? 'mapping' : 'upload')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-0 rotate-180" />
                <span>{isAr ? 'السابق' : 'Retour'}</span>
              </button>
            )}
            {step === 'upload' && (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Annuler'}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {step === 'mapping' && (
              <button
                type="button"
                id="btn-proceed-to-residents-preview"
                onClick={handleProceedToPreview}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-sm shadow-[#0a8591]/20 cursor-pointer"
              >
                <span>{isAr ? 'متابعة إلى المعاينة ←' : 'Continuer vers l\'aperçu'}</span>
                <ArrowLeft className="w-3.5 h-3.5 rtl:rotate-0 rotate-180" />
              </button>
            )}

            {step === 'preview' && (
              <button
                type="button"
                id="btn-execute-residents-import"
                onClick={handleExecuteImport}
                disabled={isLoading || !summary || summary.validRows === 0}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 disabled:opacity-50 text-white text-xs font-black transition-all shadow-sm shadow-emerald-600/30 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isAr ? 'جارٍ تسجيل البيانات...' : 'Enregistrement en cours...'}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>{isAr ? 'تأكيد واستيراد قائمة السكان 🚀' : 'Confirmer et Importer'}</span>
                  </>
                )}
              </button>
            )}

            {step === 'success' && (
              <button
                type="button"
                id="btn-finish-residents-import"
                onClick={onClose}
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <span>{isAr ? 'إغلاق وعرض قائمة السكان' : 'Fermer et consulter'}</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
