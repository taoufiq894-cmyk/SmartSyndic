import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Payment, PaymentMethod } from '../types';
import { 
  CreditCard, Plus, Search, Printer, Trash2, Edit2, Check, X, Lock, 
  Archive, RotateCcw, Ban, AlertTriangle, Calendar, FileText, 
  Send, MessageSquare, FileDown, Share2, Mail, Bell, Building2, ArrowUpDown,
  FileSpreadsheet, RefreshCw, CheckCircle2, Zap, Users, UserPlus, UserMinus, Clock, Home, UserCheck
} from 'lucide-react';
import { 
  getApartmentDebtStatus, 
  getLastPaidMonthDisplay, 
  getEarliestUnpaidMonthKey, 
  getUnpaidMonthsList, 
  formatPeriodDisplay, 
  calculateMonthsLateFromPeriod,
  CURRENT_REFERENCE_YEAR 
} from '../utils/debtUtils';
import { buildReceiptWhatsAppUrl } from '../utils/pdfReceiptUtils';
import { PaidReceiptsPdfModal } from './PaidReceiptsPdfModal';
import { PaymentDueAlertModal } from './PaymentDueAlertModal';
import { OwnersDuesExcelModal } from './OwnersDuesExcelModal';
import { ManageOwnersModal } from './ManageOwnersModal';
import { 
  getAvailableMonthsList, 
  filterPaymentsByMonth, 
  filterExpensesByMonth, 
  ARABIC_MONTH_NAMES, 
  FRENCH_MONTH_NAMES 
} from '../utils/monthlyFinanceUtils';
import { isGenericPlaceholderName, isOldMockResidentName, getMoroccanApartmentData } from '../data/moroccanResidentsData';
import { checkDuplicatePayment } from '../utils/duplicateCheckUtils';
import { DuplicateWarningModal } from './DuplicateWarningModal';
import { HandCoins as HeaderIcon } from 'lucide-react';

export const PaymentsView: React.FC = () => {
  const { 
    t, lang, currentUser, payments, expenses, buildings, apartments, residents,
    addPayment, updatePayment, deletePayment, clearAllPayments, syncAllPaymentsWithResidents,
    addApartment, deleteApartment, updateApartment, addResident, updateResident, setSelectedReceipt, setActiveSection,
    archivedPayments
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  const [searchTerm, setSearchTerm] = useState('');
  const [filterBuilding, setFilterBuilding] = useState(isOwner && currentUser?.building ? currentUser.building : 'ALL');
  const [filterBuildingTab, setFilterBuildingTab] = useState<'ALL' | 'INTERLEAVED' | 'GROUP_A' | 'GROUP_B'>('ALL');
  const [filterMethod, setFilterMethod] = useState('ALL');
  const [filterPeriod, setFilterPeriod] = useState('2026-05');
  const [sortMode, setSortMode] = useState<'date' | 'interleaved' | 'groupA_then_B'>('date');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isPaidReceiptsModalOpen, setIsPaidReceiptsModalOpen] = useState(false);
  const [isDueAlertModalOpen, setIsDueAlertModalOpen] = useState(false);
  const [isOwnersDuesModalOpen, setIsOwnersDuesModalOpen] = useState(false);
  const [ownersDuesTab, setOwnersDuesTab] = useState<'export' | 'import'>('export');
  
  // Manage Owners Modal State (خاصية تغيير الملاك: زيادة أو نقصان)
  const [isManageOwnersModalOpen, setIsManageOwnersModalOpen] = useState(false);
  const [manageOwnersBuilding, setManageOwnersBuilding] = useState(buildings[0]?.code || 'GH 34 A');
  const [manageOwnersApartment, setManageOwnersApartment] = useState('01');
  const [manageOwnersDefaultTab, setManageOwnersDefaultTab] = useState<'add' | 'remove' | 'list'>('add');

  // Quick Edit Owner Name Modal State (تعديل وحفظ اسم المالك في قائمة الملاك الرسمية)
  const [isEditOwnerNameModalOpen, setIsEditOwnerNameModalOpen] = useState(false);
  const [editOwnerBuilding, setEditOwnerBuilding] = useState(buildings[0]?.code || 'GH 34 A');
  const [editOwnerApartment, setEditOwnerApartment] = useState('01');
  const [editOwnerFullName, setEditOwnerFullName] = useState('');
  const [editOwnerPhone, setEditOwnerPhone] = useState('');
  const [editOwnerCin, setEditOwnerCin] = useState('');

  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [paymentSuccessToast, setPaymentSuccessToast] = useState<string | null>(null);
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);

  // Quick Add State
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [quickBuildingCode, setQuickBuildingCode] = useState(buildings[0]?.code || 'GH 34 A');
  const [quickApartmentNumber, setQuickApartmentNumber] = useState('01');
  const [quickAmount, setQuickAmount] = useState('150');
  const [quickPeriodMonth, setQuickPeriodMonth] = useState('2026-05');

  // Quick Apartment Management Dialog from Payments Form (إضافة أو حذف شقة مباشرة)
  const [isAptManagePopupOpen, setIsAptManagePopupOpen] = useState(false);
  const [newAptInputNumber, setNewAptInputNumber] = useState('03 مكرر (3 bis)');
  const [newAptOwnerName, setNewAptOwnerName] = useState('');
  const [newAptFloor, setNewAptFloor] = useState<number>(1);
  const [newAptFee, setNewAptFee] = useState<number>(150);
  const [aptToDeleteNumber, setAptToDeleteNumber] = useState('16');
  const [aptActionFeedback, setAptActionFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form State & Building Mode (all 20 buildings: 10 Group A then 10 Group B, or individual groups)
  const [formBuildingMode, setFormBuildingMode] = useState<'all' | 'groupA' | 'groupB' | 'interleaved'>('all');
  const [isShowBuildingAptsDirectory, setIsShowBuildingAptsDirectory] = useState(false);
  const [buildingCode, setBuildingCode] = useState(buildings[0]?.code || 'GH 34 A');
  const [apartmentNumber, setApartmentNumber] = useState('01');
  const [residentName, setResidentName] = useState('');
  const [periodMonth, setPeriodMonth] = useState('2026-05');
  const [monthsCount, setMonthsCount] = useState<number>(1);
  const [amount, setAmount] = useState<number>(150);
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().slice(0, 10));
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [notes, setNotes] = useState('أداء واجب السانديك المتفق عليه بالجمع العام');
  const [receivedBy, setReceivedBy] = useState('مكتب السانديك');

  // State to reduce / collapse monthly reconciliation banner (تقليص وتصغير خانة المحاسبة الشهرية)
  const [isMonthlyBannerReduced, setIsMonthlyBannerReduced] = useState(true);

  // Duplicate Payment Warning Modal State
  const [duplicatePaymentModal, setDuplicatePaymentModal] = useState<{
    isOpen: boolean;
    existingPayment?: Payment;
    candidatePayment?: {
      buildingCode: string;
      apartmentNumber: string;
      periodMonth: string;
      amount: number;
      paymentDate: string;
      residentName: string;
    };
    customMessage?: string;
    onConfirm: () => void;
  } | null>(null);

  // Live duplicate check for main form
  const duplicatePaymentCheck = useMemo(() => {
    if (!isFormOpen || !buildingCode || !apartmentNumber || !periodMonth) {
      return { isDuplicate: false, messageAr: '', messageFr: '' };
    }
    return checkDuplicatePayment(payments, {
      buildingCode,
      apartmentNumber,
      periodMonth,
      residentName,
      amount: Number(amount) || 150
    });
  }, [isFormOpen, payments, buildingCode, apartmentNumber, periodMonth, residentName, amount]);

  // Live duplicate check for quick add modal
  const quickDuplicateCheck = useMemo(() => {
    if (!isQuickAddOpen || !quickBuildingCode || !quickApartmentNumber || !quickPeriodMonth) {
      return { isDuplicate: false, messageAr: '', messageFr: '' };
    }
    return checkDuplicatePayment(payments, {
      buildingCode: quickBuildingCode,
      apartmentNumber: quickApartmentNumber,
      periodMonth: quickPeriodMonth,
      amount: Number(quickAmount) || 150
    });
  }, [isQuickAddOpen, payments, quickBuildingCode, quickApartmentNumber, quickPeriodMonth, quickAmount]);

  // Helper to extract building number (34..43) and letter (A or B)
  const parseBuildingCode = (code: string) => {
    const match = (code || '').match(/GH\s*(\d+)\s*([AB])/i);
    if (match) {
      return { num: parseInt(match[1], 10), letter: match[2].toUpperCase() };
    }
    return { num: 999, letter: '' };
  };

  // 1. عمارات حرف A (العشرة الأولى: 10 عمارات من GH 34 A إلى GH 43 A)
  const buildingsGroupA = useMemo(() => {
    return buildings
      .filter(b => parseBuildingCode(b.code).letter === 'A')
      .sort((a, b) => parseBuildingCode(a.code).num - parseBuildingCode(b.code).num);
  }, [buildings]);

  // 2. عمارات حرف B (العشرة الثانية: 10 عمارات من GH 34 B إلى GH 43 B)
  const buildingsGroupB = useMemo(() => {
    return buildings
      .filter(b => parseBuildingCode(b.code).letter === 'B')
      .sort((a, b) => parseBuildingCode(a.code).num - parseBuildingCode(b.code).num);
  }, [buildings]);

  // 3. مجموع الـ 20 عمارة بالترتيب القانوني: العشرة الأولى (A) ثم تليها العشرة الثانية (B)
  const all20Buildings = useMemo(() => {
    return [...buildingsGroupA, ...buildingsGroupB];
  }, [buildingsGroupA, buildingsGroupB]);

  // 4. ترتيب متتالي: كل عمارة A تليها عمارة B (GH 34 A تليها GH 34 B، GH 35 A تليها GH 35 B...)
  const buildingsInterleaved = useMemo(() => {
    return [...buildings].sort((a, b) => {
      const pA = parseBuildingCode(a.code);
      const pB = parseBuildingCode(b.code);
      if (pA.num !== pB.num) return pA.num - pB.num;
      return pA.letter.localeCompare(pB.letter);
    });
  }, [buildings]);

  // عمارات النموذج تبعا للوضع المختار
  const displayedFormBuildings = useMemo(() => {
    if (formBuildingMode === 'groupA') return buildingsGroupA;
    if (formBuildingMode === 'groupB') return buildingsGroupB;
    if (formBuildingMode === 'interleaved') return buildingsInterleaved;
    return all20Buildings;
  }, [formBuildingMode, buildingsGroupA, buildingsGroupB, buildingsInterleaved, all20Buildings]);

  // Helper to normalize building codes and apartment numbers reliably
  const normBld = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
  const normApt = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';
  const matchesLot = (b1: string, a1: string, b2: string, a2: string) =>
    normBld(b1) === normBld(b2) && (normApt(a1) === normApt(a2) || String(a1).trim() === String(a2).trim());

  // شقق العمارة المحددة حاليا المطابقة للائحة الرسمية
  const currentBuildingApts = useMemo(() => {
    return apartments
      .filter(a => normBld(a.buildingCode) === normBld(buildingCode))
      .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));
  }, [apartments, buildingCode]);

  // Confirmation state for deleting/canceling a payment
  const [paymentToDelete, setPaymentToDelete] = useState<Payment | null>(null);

  // Edit payment recorded by mistake (تعديل وتصحيح وصل مسجل بالخطأ)
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [editPayAmount, setEditPayAmount] = useState<number>(150);
  const [editPayDate, setEditPayDate] = useState<string>('');
  const [editPayMethod, setEditPayMethod] = useState<PaymentMethod>('cash');
  const [editPayPeriodMonth, setEditPayPeriodMonth] = useState<string>('');
  const [editPayNotes, setEditPayNotes] = useState<string>('');

  const handleOpenEditPayment = (p: Payment) => {
    if (isOwner) return;
    setEditingPayment(p);
    setEditPayAmount(p.amount);
    setEditPayDate(p.paymentDate);
    setEditPayMethod(p.paymentMethod);
    setEditPayPeriodMonth(p.periodMonth);
    setEditPayNotes(p.notes || '');
  };

  const handleSaveEditPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment || isOwner) return;

    const dupCheck = checkDuplicatePayment(payments, {
      buildingCode: editingPayment.buildingCode,
      apartmentNumber: editingPayment.apartmentNumber,
      periodMonth: editPayPeriodMonth,
      excludeId: editingPayment.id,
      amount: Number(editPayAmount)
    });

    if (dupCheck.isDuplicate) {
      setDuplicatePaymentModal({
        isOpen: true,
        existingPayment: dupCheck.existingPayment,
        candidatePayment: {
          buildingCode: editingPayment.buildingCode,
          apartmentNumber: editingPayment.apartmentNumber,
          periodMonth: editPayPeriodMonth,
          amount: Number(editPayAmount),
          paymentDate: editPayDate,
          residentName: editingPayment.residentName,
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          updatePayment(editingPayment.id, {
            amount: Number(editPayAmount),
            paymentDate: editPayDate,
            paymentMethod: editPayMethod,
            periodMonth: editPayPeriodMonth,
            notes: editPayNotes,
          });
          setEditingPayment(null);
        }
      });
      return;
    }

    updatePayment(editingPayment.id, {
      amount: Number(editPayAmount),
      paymentDate: editPayDate,
      paymentMethod: editPayMethod,
      periodMonth: editPayPeriodMonth,
      notes: editPayNotes,
    });
    setEditingPayment(null);
  };

  const selectedApt = useMemo(() => {
    return apartments.find(a => matchesLot(a.buildingCode, a.number, buildingCode, apartmentNumber));
  }, [apartments, buildingCode, apartmentNumber]);
  const selectedAptDebt = getApartmentDebtStatus(selectedApt, payments);
  const selectedAptUnpaidList = getUnpaidMonthsList(selectedAptDebt.unpaidMonths);

  // جلب اسم المالك الرسمي المطابق بدقة للائحة الرسمية للملاك
  const resolveOwnerName = (bCode: string, aptNum: string): string => {
    if (!bCode || !aptNum) return '';

    // 1. الوحدة المخصصة: مكتب إدارة وسانديك إقامة المرجان
    if (normBld(bCode) === 'GH34A' && normApt(aptNum) === '1') {
      return 'مكتب إدارة وسانديك إقامة المرجان';
    }
    // 2. الوحدة المخصصة: السيد محمد أيت بلعربي
    if (normBld(bCode) === 'GH38B' && normApt(aptNum) === '3') {
      return 'السيد محمد أيت بلعربي';
    }

    // 3. الأولوية الأولى: مالك مسجل في سجل السكان والملاك المعتمد (اللائحة الرسمية للملاك - type === 'owner')
    const resOwner = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, bCode, aptNum) && r.type === 'owner');
    const resOwnerName = resOwner?.fullName?.trim();
    if (resOwnerName && !isGenericPlaceholderName(resOwnerName) && !isOldMockResidentName(resOwnerName)) {
      return resOwnerName;
    }

    // 4. الأولوية الثانية: اسم المالك في سجل الشقق والملاك (Master Apartments)
    const apt = apartments.find(a => matchesLot(a.buildingCode, a.number, bCode, aptNum));
    const aptOwner = apt?.ownerName?.trim();
    if (aptOwner && !isGenericPlaceholderName(aptOwner) && !isOldMockResidentName(aptOwner)) {
      return aptOwner;
    }

    // 5. الأولوية الثالثة: أي ساكن مسجل بالسجل الرسمي للسكان
    const res = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, bCode, aptNum));
    const resName = res?.fullName?.trim();
    if (resName && !isGenericPlaceholderName(resName) && !isOldMockResidentName(resName)) {
      return resName;
    }

    // 6. الأولوية الرابعة: حقل residentName في سجل الشقة
    const aptRes = apt?.residentName?.trim();
    if (aptRes && !isGenericPlaceholderName(aptRes) && !isOldMockResidentName(aptRes)) {
      return aptRes;
    }

    // 7. الأولوية الخامسة: اللائحة الرسمية المعتمدة تلقائياً (الـ 320 مالك مغربي حقيقي)
    const mData = getMoroccanApartmentData(bCode, aptNum);
    if (mData?.fullName && !isGenericPlaceholderName(mData.fullName) && !isOldMockResidentName(mData.fullName)) {
      return mData.fullName;
    }

    return '';
  };

  const handleBuildingOrAptChange = (bCode: string, aptNum: string) => {
    const cleanB = bCode.replace(/\s+/g, ' ').trim().toUpperCase();
    const cleanA = String(aptNum || '01').trim();
    setBuildingCode(cleanB);
    setApartmentNumber(cleanA);
    const apt = apartments.find(a => matchesLot(a.buildingCode, a.number, cleanB, cleanA));

    const resolvedOwner = resolveOwnerName(cleanB, cleanA);
    setResidentName(resolvedOwner || '');

    if (apt) {
      const debt = getApartmentDebtStatus(apt, payments);
      const dueMonthKey = getEarliestUnpaidMonthKey(debt.unpaidMonths);
      setMonthsCount(1);
      setAmount(apt.monthlyFee ?? ((normBld(cleanB) === 'GH34A' && normApt(cleanA) === '1') ? 0 : 150));
      setPeriodMonth(dueMonthKey);
      setNotes(
        debt.unpaidMonths > 1
          ? (lang === 'ar' ? `أداء واجب السانديك لشهر ${formatPeriodDisplay(dueMonthKey, 'ar')} (متأخر بـ ${debt.unpaidMonths} أشهر)` : `Cotisation ${formatPeriodDisplay(dueMonthKey, 'fr')} (retard ${debt.unpaidMonths} mois)`)
          : (lang === 'ar' ? `أداء واجب السانديك لشهر ${formatPeriodDisplay(dueMonthKey, 'ar')}` : `Cotisation ${formatPeriodDisplay(dueMonthKey, 'fr')}`)
      );
    } else {
      setAmount((normBld(cleanB) === 'GH34A' && normApt(cleanA) === '1') ? 0 : 150);
    }
  };

  useEffect(() => {
    if (isFormOpen) {
      const currentName = resolveOwnerName(buildingCode, apartmentNumber);
      if (currentName) {
        setResidentName(currentName);
      }
    }
  }, [isFormOpen, buildingCode, apartmentNumber]);

  useEffect(() => {
    const handleCheckOpen = () => {
      if (sessionStorage.getItem('open_payment_modal_on_load') === 'true') {
        sessionStorage.removeItem('open_payment_modal_on_load');
        setIsFormOpen(true);
      }
    };
    handleCheckOpen();
    window.addEventListener('open-payment-modal', handleCheckOpen);
    return () => window.removeEventListener('open-payment-modal', handleCheckOpen);
  }, []);

  // Open modal to edit co-owner name (تعديل اسم المالك في القائمة الرسمية)
  const handleOpenEditOwnerNameModal = (targetB?: string, targetA?: string) => {
    if (isOwner) return;
    const b = (targetB || buildingCode || buildings[0]?.code || 'GH 34 A').trim();
    const a = String(targetA || apartmentNumber || '01').trim();
    setEditOwnerBuilding(b);
    setEditOwnerApartment(a);
    const resolved = resolveOwnerName(b, a);
    setEditOwnerFullName(resolved || '');

    const res = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, b, a));
    const apt = apartments.find(ap => matchesLot(ap.buildingCode, ap.number, b, a));
    setEditOwnerPhone(apt?.ownerPhone || res?.phone || apt?.residentPhone || '');
    setEditOwnerCin(apt?.ownerCin || res?.cin || '');
    setIsEditOwnerNameModalOpen(true);
  };

  // Save modified owner name to both apartments and master residents list
  const handleSaveOwnerNameModalSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isOwner) return;
    const cleanB = (editOwnerBuilding || buildingCode || 'GH 34 A').trim();
    const cleanA = String(editOwnerApartment || apartmentNumber || '01').trim();
    const newName = editOwnerFullName.trim();
    if (!newName) return;

    // 1. Update apartment record in official apartments list
    const targetApt = apartments.find(a => matchesLot(a.buildingCode, a.number, cleanB, cleanA));
    if (targetApt) {
      updateApartment(targetApt.id, {
        ownerName: newName,
        residentName: newName,
        ...(editOwnerPhone ? { ownerPhone: editOwnerPhone, residentPhone: editOwnerPhone } : {}),
        ...(editOwnerCin ? { ownerCin: editOwnerCin.toUpperCase() } : {}),
      });
    }

    // 2. Update or create resident in master residents list
    const existingRes = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, cleanB, cleanA));
    if (existingRes) {
      updateResident(existingRes.id, {
        fullName: newName,
        ...(editOwnerPhone ? { phone: editOwnerPhone } : {}),
        ...(editOwnerCin ? { cin: editOwnerCin.toUpperCase() } : {}),
      });
    } else {
      addResident({
        fullName: newName,
        buildingCode: cleanB,
        apartmentNumber: cleanA,
        type: 'owner',
        phone: editOwnerPhone || '',
        email: '',
        cin: editOwnerCin ? editOwnerCin.toUpperCase() : '',
        entryDate: new Date().toISOString().slice(0, 10),
      });
    }

    // 3. Update existing payments for this apartment to keep receipts matching the official owner
    payments.forEach(p => {
      if (matchesLot(p.buildingCode, p.apartmentNumber, cleanB, cleanA) && p.residentName !== newName) {
        updatePayment(p.id, { residentName: newName });
      }
    });

    // 4. Update current form if active for this apartment
    if (matchesLot(buildingCode, apartmentNumber, cleanB, cleanA)) {
      setResidentName(newName);
    }

    setPaymentSuccessToast(
      lang === 'ar'
        ? `✅ تم تعديل وحفظ اسم المالك "${newName}" للشقة (${cleanB} - شقة ${cleanA}) في قائمة الملاك الرسمية بنجاح!`
        : `✅ Nom du copropriétaire "${newName}" (${cleanB} Appt ${cleanA}) enregistré dans la liste officielle avec succès !`
    );
    setTimeout(() => setPaymentSuccessToast(null), 6000);
    setIsEditOwnerNameModalOpen(false);
  };

  // Quick save from the payment form inline input
  const handleSaveOwnerNameToMasterList = () => {
    if (isOwner) return;
    const cleanB = (buildingCode || 'GH 34 A').trim();
    const cleanA = String(apartmentNumber || '01').trim();
    const newName = residentName.trim();
    if (!newName) return;

    setEditOwnerBuilding(cleanB);
    setEditOwnerApartment(cleanA);
    setEditOwnerFullName(newName);

    const targetApt = apartments.find(a => matchesLot(a.buildingCode, a.number, cleanB, cleanA));
    if (targetApt) {
      updateApartment(targetApt.id, {
        ownerName: newName,
        residentName: newName,
      });
    }

    const existingRes = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, cleanB, cleanA));
    if (existingRes) {
      updateResident(existingRes.id, { fullName: newName });
    } else {
      addResident({
        fullName: newName,
        buildingCode: cleanB,
        apartmentNumber: cleanA,
        type: 'owner',
        phone: targetApt?.ownerPhone || '',
        email: targetApt?.ownerEmail || '',
        cin: targetApt?.ownerCin || '',
        entryDate: new Date().toISOString().slice(0, 10),
      });
    }

    // Update existing receipts to reflect official name
    payments.forEach(p => {
      if (matchesLot(p.buildingCode, p.apartmentNumber, cleanB, cleanA) && p.residentName !== newName) {
        updatePayment(p.id, { residentName: newName });
      }
    });

    setPaymentSuccessToast(
      lang === 'ar'
        ? `✅ تم حفظ الاسم "${newName}" للشقة (${cleanB} - شقة ${cleanA}) في قائمة الملاك الرسمية بنجاح!`
        : `✅ Nom "${newName}" enregistré dans la liste des copropriétaires avec succès !`
    );
    setTimeout(() => setPaymentSuccessToast(null), 5000);
  };

  const handleClearForm = () => {
    setResidentName('');
    setMonthsCount(1);
    setAmount(150);
    setNotes('');
    setPaymentDate(new Date().toISOString().slice(0, 10));
    setPaymentMethod('cash');
    setReceivedBy('مكتب السانديك');
  };

  const handleSelectBuildingInForm = (newBCode: string) => {
    const cleanB = newBCode.trim();
    setBuildingCode(cleanB);
    const bApts = apartments.filter(a => normBld(a.buildingCode) === normBld(cleanB));
    const existing = bApts.find(a => matchesLot(a.buildingCode, a.number, cleanB, apartmentNumber));
    const targetAptNum = existing ? existing.number : (bApts[0]?.number || '01');
    handleBuildingOrAptChange(cleanB, targetAptNum);
  };

  const handleSwitchFormBuildingMode = (mode: 'all' | 'groupA' | 'groupB' | 'interleaved') => {
    setFormBuildingMode(mode);
    let targetList = all20Buildings;
    if (mode === 'groupA') targetList = buildingsGroupA;
    if (mode === 'groupB') targetList = buildingsGroupB;
    if (mode === 'interleaved') targetList = buildingsInterleaved;
    if (targetList.length > 0 && !targetList.some(b => normBld(b.code) === normBld(buildingCode))) {
      handleSelectBuildingInForm(targetList[0].code);
    }
  };

  const handleOpenNew = () => {
    if (isOwner) return;
    // Preselect current filter building if specific, otherwise default to first building GH 34 A
    let targetBCode = buildingsGroupA[0]?.code || 'GH 34 A';
    if (filterBuilding !== 'ALL' && filterBuilding !== 'GROUP_A' && filterBuilding !== 'GROUP_B') {
      targetBCode = filterBuilding;
    } else if (filterBuilding === 'GROUP_B') {
      targetBCode = buildingsGroupB[0]?.code || 'GH 34 B';
      setFormBuildingMode('groupB');
    } else if (filterBuilding === 'GROUP_A') {
      targetBCode = buildingsGroupA[0]?.code || 'GH 34 A';
      setFormBuildingMode('groupA');
    } else {
      setFormBuildingMode('all');
    }

    const cleanB = targetBCode.trim();
    const bApts = apartments.filter(a => normBld(a.buildingCode) === normBld(cleanB));
    const targetApt = bApts[0] || apartments[0];
    const targetAptNum = targetApt ? targetApt.number : '01';
    handleBuildingOrAptChange(cleanB, targetAptNum);
    setPaymentDate(new Date().toISOString().slice(0, 10));
    setPaymentMethod('cash');
    setReceivedBy('مكتب السانديك');
    setIsFormOpen(true);
  };

  const handleOpenNewForBuilding = (bCode: string) => {
    if (isOwner) return;
    const cleanB = bCode.trim();
    const bApts = apartments.filter(a => normBld(a.buildingCode) === normBld(cleanB));
    const targetApt = bApts[0];
    const targetAptNum = targetApt ? targetApt.number : '01';
    handleBuildingOrAptChange(cleanB, targetAptNum);
    const bLetter = parseBuildingCode(cleanB).letter;
    if (bLetter === 'A') setFormBuildingMode('groupA');
    else if (bLetter === 'B') setFormBuildingMode('groupB');
    else setFormBuildingMode('interleaved');
    setPaymentDate(new Date().toISOString().slice(0, 10));
    setPaymentMethod('cash');
    setReceivedBy('مكتب السانديك');
    setIsFormOpen(true);
  };

  const handleCancelForm = () => {
    handleClearForm();
    setIsFormOpen(false);
  };

  const executeSavePayment = (paymentData: {
    residentName: string;
    buildingCode: string;
    apartmentNumber: string;
    periodMonth: string;
    monthsCount: number;
    amount: number;
    paymentDate: string;
    paymentMethod: PaymentMethod;
    notes?: string;
    receivedBy: string;
  }) => {
    const receipt = addPayment(paymentData);

    const targetApt = apartments.find(a => 
      a.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === paymentData.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() && 
      String(a.number).padStart(2, '0') === String(paymentData.apartmentNumber).padStart(2, '0')
    );
    if (targetApt && !isGenericPlaceholderName(paymentData.residentName.trim()) && (targetApt.residentName !== paymentData.residentName.trim() || targetApt.ownerName !== paymentData.residentName.trim())) {
      updateApartment(targetApt.id, {
        residentName: paymentData.residentName.trim(),
        ownerName: paymentData.residentName.trim()
      });
    }

    // Set filterPeriod so the newly added payment is immediately visible in the table and not hidden
    const payMonthPrefix = paymentData.paymentDate ? paymentData.paymentDate.slice(0, 7) : (paymentData.periodMonth ? paymentData.periodMonth.slice(0, 7) : 'ALL');
    setFilterPeriod(payMonthPrefix);
    if (filterBuilding !== 'ALL' && filterBuilding !== paymentData.buildingCode) {
      setFilterBuilding('ALL');
    }
    setSearchTerm('');

    setPaymentSuccessToast(
      lang === 'ar'
        ? `✅ تم تسجيل وحفظ وصل الأداء (${receipt.receiptNumber}) للشقة ${paymentData.buildingCode} - شقة ${paymentData.apartmentNumber} بمبلغ ${receipt.amount} درهم فوراً بنجاح!`
        : `✅ Reçu (${receipt.receiptNumber}) pour ${paymentData.buildingCode} Appt ${paymentData.apartmentNumber} (${receipt.amount} DH) enregistré avec succès !`
    );
    setTimeout(() => setPaymentSuccessToast(null), 7000);

    setIsFormOpen(false);
    setSelectedReceipt(receipt);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!residentName.trim() || !amount) return;

    const paymentData = {
      residentName: residentName.trim(),
      buildingCode,
      apartmentNumber,
      periodMonth,
      monthsCount: Number(monthsCount) || 1,
      amount: Number(amount),
      paymentDate,
      paymentMethod,
      notes,
      receivedBy,
    };

    // Check for duplicate payment for this apartment and month
    const dupCheck = checkDuplicatePayment(payments, paymentData);
    if (dupCheck.isDuplicate) {
      setDuplicatePaymentModal({
        isOpen: true,
        existingPayment: dupCheck.existingPayment,
        candidatePayment: {
          buildingCode,
          apartmentNumber,
          periodMonth,
          amount: Number(amount),
          paymentDate,
          residentName: residentName.trim(),
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          executeSavePayment(paymentData);
        }
      });
      return;
    }

    executeSavePayment(paymentData);
  };

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!quickAmount) return;

    const currentName = resolveOwnerName(quickBuildingCode, quickApartmentNumber);

    const paymentData = {
      residentName: currentName || 'صاحب الشقة',
      buildingCode: quickBuildingCode,
      apartmentNumber: quickApartmentNumber,
      periodMonth: quickPeriodMonth,
      monthsCount: 1,
      amount: Number(quickAmount) || 150,
      paymentDate: new Date().toISOString().slice(0, 10),
      paymentMethod: 'cash' as PaymentMethod,
      notes: 'أداء واجب السانديك (إدخال سريع)',
      receivedBy: 'مكتب السانديك',
    };

    // Check for duplicate payment
    const dupCheck = checkDuplicatePayment(payments, paymentData);
    if (dupCheck.isDuplicate) {
      setDuplicatePaymentModal({
        isOpen: true,
        existingPayment: dupCheck.existingPayment,
        candidatePayment: {
          buildingCode: quickBuildingCode,
          apartmentNumber: quickApartmentNumber,
          periodMonth: quickPeriodMonth,
          amount: Number(quickAmount) || 150,
          paymentDate: paymentData.paymentDate,
          residentName: paymentData.residentName,
        },
        customMessage: lang === 'ar' ? dupCheck.messageAr : dupCheck.messageFr,
        onConfirm: () => {
          const receipt = addPayment(paymentData);
          const payMonthPrefix = paymentData.paymentDate ? paymentData.paymentDate.slice(0, 7) : 'ALL';
          setFilterPeriod(payMonthPrefix);
          if (filterBuilding !== 'ALL' && filterBuilding !== paymentData.buildingCode) {
            setFilterBuilding('ALL');
          }
          setSearchTerm('');
          setPaymentSuccessToast(
            lang === 'ar'
              ? `✅ تم تسجيل وحفظ الوصل السريع (${receipt.receiptNumber}) بمبلغ ${receipt.amount} درهم فوراً بنجاح!`
              : `✅ Reçu express (${receipt.receiptNumber}) de ${receipt.amount} DH enregistré avec succès !`
          );
          setTimeout(() => setPaymentSuccessToast(null), 7000);
          setIsQuickAddOpen(false);
          setSelectedReceipt(receipt);
        }
      });
      return;
    }

    const receipt = addPayment(paymentData);
    const payMonthPrefix = paymentData.paymentDate ? paymentData.paymentDate.slice(0, 7) : 'ALL';
    setFilterPeriod(payMonthPrefix);
    if (filterBuilding !== 'ALL' && filterBuilding !== paymentData.buildingCode) {
      setFilterBuilding('ALL');
    }
    setSearchTerm('');
    setPaymentSuccessToast(
      lang === 'ar'
        ? `✅ تم تسجيل وحفظ الوصل السريع (${receipt.receiptNumber}) بمبلغ ${receipt.amount} درهم فوراً بنجاح!`
        : `✅ Reçu express (${receipt.receiptNumber}) de ${receipt.amount} DH enregistré avec succès !`
    );
    setTimeout(() => setPaymentSuccessToast(null), 7000);
    setIsQuickAddOpen(false);
    setSelectedReceipt(receipt);
  };

  const confirmDeletePayment = () => {
    if (paymentToDelete) {
      deletePayment(paymentToDelete.id);
      setPaymentToDelete(null);
    }
  };

  const handleSyncPaymentNames = () => {
    setIsSyncing(true);
    const updatedCount = syncAllPaymentsWithResidents();
    setIsSyncing(false);
    setSyncMessage(
      lang === 'ar'
        ? `✅ تم بنجاح جلب ومزامنة أسماء الملاك من صفحة السكان الحقيقية (تم تحديث ${updatedCount} وصل)`
        : `✅ Noms synchronisés avec succès depuis la page Résidents (${updatedCount} reçus mis à jour)`
    );
    setTimeout(() => setSyncMessage(null), 6000);
  };

  const handleConfirmClearAllPayments = () => {
    clearAllPayments();
    setIsClearConfirmOpen(false);
    setSyncMessage(
      lang === 'ar'
        ? '🗑️ تم بنجاح مسح جميع الوصولات التجريبية السابقة من سجل استلام واجبات السانديك.'
        : '🗑️ Tous les reçus de test ont été supprimés avec succès.'
    );
    setTimeout(() => setSyncMessage(null), 5000);
  };

  const availableMonths = useMemo(() => getAvailableMonthsList(payments, expenses), [payments, expenses]);

  const filteredPayments = payments.filter(p => {
    // If owner, strictly restrict to only their building and apartment
    if (isOwner && currentUser?.building && currentUser?.apartment) {
      const matchBuilding = p.buildingCode.replace(/\s+/g, '').toUpperCase() === currentUser.building.replace(/\s+/g, '').toUpperCase();
      const matchApt = p.apartmentNumber.replace(/\D/g, '') === currentUser.apartment.replace(/\D/g, '');
      if (!matchBuilding || !matchApt) return false;
    }

    const matchesSearch = 
      (p.receiptNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.residentName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.buildingCode || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.apartmentNumber || '').toLowerCase().includes(searchTerm.toLowerCase());

    const bLetter = parseBuildingCode(p.buildingCode).letter;
    const matchesBuilding = 
      filterBuilding === 'ALL' ||
      (filterBuilding === 'GROUP_A' && bLetter === 'A') ||
      (filterBuilding === 'GROUP_B' && bLetter === 'B') ||
      p.buildingCode === filterBuilding;

    const matchesMethod = filterMethod === 'ALL' || p.paymentMethod === filterMethod;
    const matchesPeriod = filterPeriod === 'ALL' || 
      (p.paymentDate ? p.paymentDate.startsWith(filterPeriod) : (p.periodMonth && p.periodMonth.startsWith(filterPeriod)));

    return matchesSearch && matchesBuilding && matchesMethod && matchesPeriod;
  });

  // فرز الأداءات حسب الوضع المطلوب (تاريخياً أو حسب تسلسل العمارات)
  const sortedPayments = useMemo(() => {
    return [...filteredPayments].sort((a, b) => {
      if (sortMode === 'interleaved') {
        const pA = parseBuildingCode(a.buildingCode);
        const pB = parseBuildingCode(b.buildingCode);
        if (pA.num !== pB.num) return pA.num - pB.num;
        if (pA.letter !== pB.letter) return pA.letter.localeCompare(pB.letter);
        const aptA = parseInt(a.apartmentNumber.replace(/\D/g, '') || '0', 10);
        const aptB = parseInt(b.apartmentNumber.replace(/\D/g, '') || '0', 10);
        return aptA - aptB;
      }
      if (sortMode === 'groupA_then_B') {
        const pA = parseBuildingCode(a.buildingCode);
        const pB = parseBuildingCode(b.buildingCode);
        if (pA.letter !== pB.letter) return pA.letter.localeCompare(pB.letter);
        if (pA.num !== pB.num) return pA.num - pB.num;
        const aptA = parseInt(a.apartmentNumber.replace(/\D/g, '') || '0', 10);
        const aptB = parseInt(b.apartmentNumber.replace(/\D/g, '') || '0', 10);
        return aptA - aptB;
      }
      // default: newest date first, then receipt number
      return (b.paymentDate || '').localeCompare(a.paymentDate || '') || (b.receiptNumber || '').localeCompare(a.receiptNumber || '');
    });
  }, [filteredPayments, sortMode]);

  const totalFilteredIncome = filteredPayments.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  // Monthly income & expense calculations for the active period
  const monthPayments = useMemo(() => filterPaymentsByMonth(payments, filterPeriod), [payments, filterPeriod]);
  const monthExpenses = useMemo(() => filterExpensesByMonth(expenses, filterPeriod), [expenses, filterPeriod]);
  const monthIncomeTotal = useMemo(() => monthPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0), [monthPayments]);
  const monthExpenseTotal = useMemo(() => monthExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0), [monthExpenses]);
  const monthNetBalance = monthIncomeTotal - monthExpenseTotal;

  const monthLabel = useMemo(() => {
    if (filterPeriod === 'ALL') return lang === 'ar' ? 'جميع الشهور (الإجمالي الشامل)' : 'Tous les mois (Cumul)';
    const [y, m] = filterPeriod.split('-');
    return lang === 'ar' ? `${ARABIC_MONTH_NAMES[m] || m} ${y}` : `${FRENCH_MONTH_NAMES[m] || m} ${y}`;
  }, [filterPeriod, lang]);

  const getMethodLabel = (m: PaymentMethod) => {
    switch (m) {
      case 'cash': return t.payments.methodCash;
      case 'bank_transfer': return t.payments.methodTransfer;
      case 'check': return t.payments.methodCheck;
      default: return t.payments.methodOnline;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative overflow-hidden bg-white p-5 rounded-2xl border border-slate-200 border-t-4 border-t-amber-500 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.payments.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">{t.payments.subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* 1. Main Action: Modifier les noms des copropriétaires (تعديل أسماء الملاك) */}
          {!isOwner && (
            <button
              id="btn-edit-owners-names-cotisation"
              type="button"
              onClick={() => handleOpenEditOwnerNameModal(buildingCode, apartmentNumber)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-700 via-blue-700 to-indigo-800 hover:from-indigo-600 hover:to-blue-600 text-white text-xs font-black transition-all shadow-sm cursor-pointer border border-indigo-400/40"
              title={lang === 'ar' ? 'تعديل أسماء الملاك وحفظها مباشرة في قائمة الملاك الرسمية' : 'Modifier les noms des copropriétaires et enregistrer dans la liste officielle'}
            >
              <UserCheck className="w-4 h-4 text-indigo-200" />
              <span>{lang === 'ar' ? 'تعديل أسماء الملاك 👥' : 'Modifier Noms Copropriétaires'}</span>
            </button>
          )}

          {/* 2. Main Action: Add New Payment (تسجيل أداء جديد) */}
          {!isOwner ? (
            <button
              id="btn-add-payment-main"
              type="button"
              onClick={handleOpenNew}
              className="flex items-center gap-2 px-4.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-black transition-all shadow-sm shadow-emerald-700/20 cursor-pointer border border-emerald-500/30"
              title={lang === 'ar' ? 'تسجيل وصل أداء جديد' : 'Enregistrer une cotisation'}
            >
              <Plus className="w-4 h-4" />
              <span>{t.payments.addBtn}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>{lang === 'ar' ? 'سجل الأداءات (اطلاع وتحميل الوصولات)' : 'Consultation & Téléchargement'}</span>
            </div>
          )}

          {/* 3. Utility Tools: Excel Arriérés */}
          <button
            id="btn-open-payments-dues-excel-modal"
            type="button"
            onClick={() => {
              setOwnersDuesTab('export');
              setIsOwnersDuesModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-300 shadow-2xs cursor-pointer"
            title={lang === 'ar' ? 'خانة استيراد وتصدير مستحقات الملاك على صيغة Excel' : 'Gestion des arriérés des copropriétaires (Excel)'}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'ar' ? 'مستحقات Excel' : 'Arriérés Excel'}</span>
          </button>

          {/* 4. Utility Tools: Reçus PDF */}
          <button
            id="btn-open-paid-receipts-pdf-modal"
            type="button"
            onClick={() => setIsPaidReceiptsModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-300 shadow-2xs cursor-pointer"
            title={lang === 'ar' ? 'إرسال وتصدير وصولات الأداء للملاك المؤدين بصيغة PDF' : 'Envoyer les reçus PDF aux propriétaires à jour'}
          >
            <FileText className="w-3.5 h-3.5 text-blue-600" />
            <span>{lang === 'ar' ? 'وصولات PDF' : 'Reçus PDF'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-800 text-[10px] font-mono">
              {payments.length}
            </span>
          </button>

          {/* 5. Utility Tools: Alertes Échéance */}
          {!isOwner && (
            <button
              id="btn-open-payment-due-alerts-payments"
              type="button"
              onClick={() => setIsDueAlertModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-300 shadow-2xs cursor-pointer"
              title={lang === 'ar' ? 'نظام تنبيهات وإشعارات اقتراب موعد سداد السانديك' : 'Alertes d\'échéance de cotisation'}
            >
              <Bell className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'ar' ? 'التنبيهات ⏰' : 'Alertes'}</span>
            </button>
          )}

          {/* 6. Utility Tools: Sync Names */}
          {!isOwner && (
            <button
              id="btn-sync-payment-names-residents"
              type="button"
              onClick={handleSyncPaymentNames}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-300 shadow-2xs cursor-pointer"
              title={lang === 'ar' ? 'جلب ومزامنة أسماء الملاك الحقيقيين من صفحة السكان لجميع الوصولات ومسح أي أسماء قديمة' : 'Synchroniser les noms réels des copropriétaires depuis la page Résidents'}
            >
              <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{lang === 'ar' ? 'مزامنة الأسماء' : 'Sync Noms'}</span>
            </button>
          )}

          {/* 7. Utility Tools: Archive */}
          <button
            type="button"
            onClick={() => setActiveSection('archive')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition-all border border-slate-300 shadow-2xs cursor-pointer"
          >
            <Archive className="w-3.5 h-3.5 text-slate-500" />
            <span>{t.nav.archive}</span>
            {archivedPayments.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-800 text-[10px]">
                {archivedPayments.length}
              </span>
            )}
          </button>

          {/* 8. Clear Test Payments */}
          {!isOwner && payments.length > 0 && (
            <button
              id="btn-clear-test-payments"
              type="button"
              onClick={() => setIsClearConfirmOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all border border-rose-200 shadow-2xs cursor-pointer"
              title={lang === 'ar' ? 'مسح جميع وصولات الأداء التجريبية والبدء بسجل نظيف' : 'Effacer tous les reçus de test'}
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span>{lang === 'ar' ? 'تنظيف الوصولات' : 'Purger'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Instant Payment Success Notification Banner */}
      {paymentSuccessToast && (
        <div className="flex items-center justify-between p-4 rounded-2xl bg-emerald-700 text-white text-xs sm:text-sm font-black shadow-lg border-2 border-emerald-500 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-xl bg-white/20 text-white font-bold">
              <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
            </span>
            <span>{paymentSuccessToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setPaymentSuccessToast(null)}
            className="p-1 rounded-lg hover:bg-white/20 text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sync / Action Notification Banner */}
      {syncMessage && (
        <div className="flex items-center justify-between p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{syncMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSyncMessage(null)}
            className="text-emerald-700 hover:text-emerald-950 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Form Modal / Box (Syndic only) */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600 shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-emerald-900 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-emerald-700" />
              <span>{t.payments.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.building} *</label>
                <select
                  value={buildingCode}
                  onChange={e => handleSelectBuildingInForm(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold text-slate-900"
                >
                  <optgroup label="المجموعة الأولى: عمارات GH A (من GH 34 A إلى GH 43 A)">
                    {buildingsGroupA.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </optgroup>
                  <optgroup label="المجموعة الثانية: عمارات GH B (من GH 34 B إلى GH 43 B)">
                    {buildingsGroupB.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">{t.payments.apartment} *</label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsShowBuildingAptsDirectory(!isShowBuildingAptsDirectory)}
                      className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded border transition-colors cursor-pointer ${
                        isShowBuildingAptsDirectory
                          ? 'bg-blue-700 text-white border-blue-800'
                          : 'text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 border-blue-200'
                      }`}
                      title={lang === 'ar' ? 'عرض جدول شقق وملاك هذه العمارة الرسمي للاختيار السريع' : 'Afficher le répertoire officiel'}
                    >
                      <Users className="w-3 h-3" />
                      <span>{lang === 'ar' ? (isShowBuildingAptsDirectory ? 'إخفاء الدليل' : '📋 دليل الملاك') : 'Répertoire'}</span>
                    </button>
                    {!isOwner && (
                      <button
                        id="btn-quick-manage-apts-in-payment"
                        type="button"
                        onClick={() => {
                          setAptActionFeedback(null);
                          setIsAptManagePopupOpen(true);
                        }}
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded border border-indigo-200 transition-colors cursor-pointer"
                        title={lang === 'ar' ? 'إضافة شقة (مثل 3 مكرر) أو حذف شقة (مثل 16) من هذه العمارة' : 'Ajouter ou supprimer un appartement'}
                      >
                        <Plus className="w-3 h-3" />
                        <span>{lang === 'ar' ? 'زيادة / مسح' : '+/-'}</span>
                      </button>
                    )}
                  </div>
                </div>
                <select
                  value={apartmentNumber}
                  onChange={e => handleBuildingOrAptChange(buildingCode, e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold text-slate-900"
                >
                  {currentBuildingApts.length > 0 ? (
                    currentBuildingApts.map(a => {
                      const debt = getApartmentDebtStatus(a, payments);
                      const isOffice = a.isSyndicOffice || (normBld(buildingCode) === 'GH34A' && normApt(a.number) === '1');
                      const ownerName = resolveOwnerName(buildingCode, a.number);
                      return (
                        <option key={a.id} value={a.number}>
                          {lang === 'ar' ? 'شقة' : 'Appt'} {a.number} {ownerName ? `• 👤 ${ownerName}` : (lang === 'ar' ? '• (الاسم غير مسجل)' : '• (Non renseigné)')} {isOffice ? '(مكتب السانديك)' : debt.isPaid ? '• 🟢 خالص' : `• 🔴 متأخر (${debt.unpaidMonths} أشهر)`}
                        </option>
                      );
                    })
                  ) : (
                    Array.from({ length: 16 }, (_, i) => {
                      const num = String(i + 1).padStart(2, '0');
                      const ownerName = resolveOwnerName(buildingCode, num);
                      return (
                        <option key={num} value={num}>
                          {lang === 'ar' ? 'شقة' : 'Appt'} {num} {ownerName ? `• 👤 ${ownerName}` : ''}
                        </option>
                      );
                    })
                  )}
                </select>
              </div>

              {isShowBuildingAptsDirectory && (
                <div className="col-span-1 sm:col-span-2 lg:col-span-4 p-3 rounded-xl bg-blue-50/70 border-2 border-blue-200 shadow-sm animate-in fade-in duration-150">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-blue-700" />
                      <h4 className="text-xs font-black text-slate-900">
                        {lang === 'ar' ? `📋 الدليل الرسمي لشقق وملاك العمارة (${buildingCode})` : `Répertoire officiel des copropriétaires (${buildingCode})`}
                      </h4>
                      <span className="text-[10px] text-blue-800 font-bold bg-blue-100 px-2 py-0.5 rounded-full border border-blue-200">
                        {currentBuildingApts.length} {lang === 'ar' ? 'شقة' : 'lots'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsShowBuildingAptsDirectory(false)}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      {lang === 'ar' ? '✕ إغلاق الدليل' : '✕ Fermer'}
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 max-h-64 overflow-y-auto p-1">
                    {currentBuildingApts.map(a => {
                      const debt = getApartmentDebtStatus(a, payments);
                      const isOffice = a.isSyndicOffice || (normBld(buildingCode) === 'GH34A' && normApt(a.number) === '1');
                      const owner = resolveOwnerName(buildingCode, a.number);
                      const isSelected = matchesLot(buildingCode, a.number, buildingCode, apartmentNumber);
                      return (
                        <button
                          key={a.id}
                          type="button"
                          onClick={() => {
                            handleBuildingOrAptChange(buildingCode, a.number);
                            setIsShowBuildingAptsDirectory(false);
                          }}
                          className={`p-2.5 rounded-xl text-start transition-all border cursor-pointer ${
                            isSelected
                              ? 'bg-blue-700 text-white border-blue-800 shadow-sm ring-2 ring-blue-400'
                              : 'bg-white hover:bg-blue-100/70 border-slate-200 hover:border-blue-300 shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className={`text-xs font-black font-mono ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                              {lang === 'ar' ? 'شقة' : 'Appt'} {a.number}
                            </span>
                            <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : isOffice
                                ? 'bg-purple-100 text-purple-900 border border-purple-200'
                                : debt.isPaid
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                                : 'bg-rose-100 text-rose-900 border border-rose-200'
                            }`}>
                              {isOffice ? '🏢 مكتب' : debt.isPaid ? 'خالص 🟢' : `متأخر (${debt.unpaidMonths}) 🔴`}
                            </span>
                          </div>
                          <div className={`text-xs font-bold truncate ${isSelected ? 'text-blue-50' : 'text-slate-900'}`}>
                            👤 {owner || (lang === 'ar' ? 'غير مسجل' : 'Non renseigné')}
                          </div>
                          {(a.ownerPhone || a.residentPhone) && (
                            <div className={`text-[10px] font-mono mt-0.5 truncate ${isSelected ? 'text-blue-200' : 'text-slate-500'}`}>
                              📞 {a.ownerPhone || a.residentPhone}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="sm:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">{t.payments.resident} *</label>
                  <div className="flex items-center gap-1.5">
                    {!isOwner && (
                      <button
                        type="button"
                        id="btn-edit-owner-name-form"
                        onClick={() => handleOpenEditOwnerNameModal(buildingCode, apartmentNumber)}
                        className="inline-flex items-center gap-1 text-[11px] font-extrabold text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg border border-blue-200 transition-colors cursor-pointer shadow-2xs"
                        title={lang === 'ar' ? 'تعديل اسم مالك هذه الشقة وحفظه فوراً في قائمة الملاك الرسمية' : 'Modifier le nom du copropriétaire et enregistrer dans la liste'}
                      >
                        <Edit2 className="w-3.5 h-3.5 text-blue-600" />
                        <span>{lang === 'ar' ? 'تعديل اسم المالك في القائمة ✏️' : 'Modifier nom copropriétaire'}</span>
                      </button>
                    )}
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {lang === 'ar' ? 'جلب تلقائي للمالك' : 'Auto-détecté'}
                    </span>
                  </div>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={residentName}
                    onChange={e => setResidentName(e.target.value)}
                    placeholder={lang === 'ar' ? 'الاسم الكامل للساكن / المالك' : 'Nom complet du résident'}
                    className="w-full ps-3.5 pe-48 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none font-bold text-slate-900 bg-white placeholder:text-slate-400 placeholder:font-normal shadow-xs"
                    dir="auto"
                  />
                  <div className="absolute end-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    {residentName.trim() && residentName.trim() !== resolveOwnerName(buildingCode, apartmentNumber) && (
                      <button
                        type="button"
                        onClick={() => handleSaveOwnerNameToMasterList()}
                        title={lang === 'ar' ? 'حفظ هذا الاسم الجديد في قائمة الملاك الرسمية' : 'Enregistrer ce nom dans la liste des copropriétaires'}
                        className="text-[11px] text-white font-extrabold px-2.5 py-1 bg-blue-700 hover:bg-blue-800 rounded-lg shadow-2xs transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'حفظ في القائمة' : 'Enregistrer'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setResidentName(resolveOwnerName(buildingCode, apartmentNumber))}
                      title={lang === 'ar' ? 'إعادة جلب الاسم المسجل' : 'Actualiser le nom'}
                      className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold px-2 py-1 bg-emerald-100/90 rounded-lg border border-emerald-300 hover:bg-emerald-200 transition-colors cursor-pointer"
                    >
                      {lang === 'ar' ? '🔄 تحديث' : '🔄 Actualiser'}
                    </button>
                  </div>
                </div>
                {/* Live Resident Details Badge */}
                {(() => {
                  const resolved = resolveOwnerName(buildingCode, apartmentNumber);
                  const currentRes = residents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, buildingCode, apartmentNumber));
                  const currentApt = apartments.find(a => matchesLot(a.buildingCode, a.number, buildingCode, apartmentNumber));
                  const phone = currentApt?.ownerPhone || currentRes?.phone || currentApt?.residentPhone || '';
                  const cin = currentApt?.ownerCin || currentRes?.cin || '';
                  return (
                    <div className="mt-1.5 flex flex-wrap items-center justify-between gap-1 text-[11px] px-2.5 py-1.5 rounded-lg bg-emerald-50/90 border border-emerald-200/90 text-emerald-950">
                      <div className="flex items-center gap-1.5 font-bold">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-emerald-700">{lang === 'ar' ? 'الاسم باللائحة الرسمية:' : 'Nom dans la liste :'}</span>
                        <span className="font-extrabold text-emerald-950">{resolved || (lang === 'ar' ? '(لم يُسجل بعد باللائحة)' : '(Non renseigné)')}</span>
                      </div>
                      <div className="flex items-center gap-2 text-emerald-800 font-mono text-[10px]">
                        {phone && <span>📞 {phone}</span>}
                        {cin && <span>🪪 {cin}</span>}
                        {resolved && residentName !== resolved && (
                          <button
                            type="button"
                            onClick={() => setResidentName(resolved)}
                            className="text-[10px] font-sans font-bold text-white bg-emerald-700 hover:bg-emerald-800 px-1.5 py-0.5 rounded cursor-pointer"
                          >
                            {lang === 'ar' ? 'استرجاع الاسم الرسمي' : 'Restaurer'}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">{t.payments.period} *</label>
                  {periodMonth && (
                    <span className="text-[11px] text-emerald-800 font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                      {formatPeriodDisplay(periodMonth, lang)}
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  required
                  value={periodMonth}
                  onChange={e => setPeriodMonth(e.target.value)}
                  placeholder="2026-07 أو 2026-07 إلى 2026-08"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none font-bold text-slate-900 bg-white placeholder:text-slate-400 placeholder:font-normal shadow-xs"
                  dir="auto"
                />
              </div>

              {/* عدد الأشهر الخالص بالأرقام (تحت خانة الفترة / الشهر) */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    {t.payments.paidMonthsCount} *
                  </label>
                  <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    {monthsCount > 1 
                      ? (lang === 'ar' ? `${monthsCount} أشهر` : `${monthsCount} mois`) 
                      : (lang === 'ar' ? 'شهر واحد' : '1 mois')}
                  </span>
                </div>
                <div className="space-y-1.5">
                  <input
                    type="number"
                    min="1"
                    max="60"
                    step="1"
                    required
                    value={monthsCount || ''}
                    onChange={e => {
                      const val = parseInt(e.target.value, 10);
                      const count = isNaN(val) ? 1 : Math.max(1, val);
                      setMonthsCount(count);
                      const unitFee = selectedApt?.monthlyFee || 150;
                      setAmount(count * unitFee);
                    }}
                    placeholder="1"
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none font-bold text-slate-900 bg-white shadow-xs"
                  />
                  {/* أزرار سريعة لاختيار عدد الأشهر */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                    {[
                      { num: 1, label: lang === 'ar' ? '1 شهر' : '1 m' },
                      { num: 2, label: lang === 'ar' ? '2 أشهر' : '2 m' },
                      { num: 3, label: lang === 'ar' ? '3 أشهر' : '3 m' },
                      { num: 6, label: lang === 'ar' ? '6 أشهر' : '6 m' },
                      { num: 12, label: lang === 'ar' ? '12 شهر (سنة)' : '12 m (1 an)' }
                    ].map(preset => (
                      <button
                        key={preset.num}
                        type="button"
                        onClick={() => {
                          setMonthsCount(preset.num);
                          const unitFee = selectedApt?.monthlyFee || 150;
                          setAmount(preset.num * unitFee);
                        }}
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                          monthsCount === preset.num 
                            ? 'bg-emerald-800 text-white shadow-2xs' 
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">{t.payments.amount} (DH) *</label>
                  {amount > 0 && (
                    <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                      {amount} DH
                    </span>
                  )}
                </div>
                <input
                  type="number"
                  min="1"
                  step="1"
                  required
                  value={amount}
                  onChange={e => setAmount(Number(e.target.value))}
                  placeholder="المبلغ المؤدى بالدرهم..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none font-bold text-slate-900 bg-white placeholder:text-slate-400 shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.date}</label>
                <input
                  type="date"
                  value={paymentDate}
                  onChange={e => setPaymentDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none bg-white text-slate-900 font-bold shadow-xs"
                />
                <p className="text-[10px] text-emerald-800 mt-1 font-semibold">
                  {lang === 'ar' ? '💡 يُحتسب المبلغ في مداخيل شهر تاريخ الأداء.' : '💡 Comptabilisé aux recettes du mois de versement.'}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.method}</label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none bg-white text-slate-900 font-bold shadow-xs"
                >
                  <option value="cash">{t.payments.methodCash}</option>
                  <option value="bank_transfer">{t.payments.methodTransfer}</option>
                  <option value="check">{t.payments.methodCheck}</option>
                  <option value="online">{t.payments.methodOnline}</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.receivedBy}</label>
              <input
                type="text"
                value={receivedBy}
                onChange={e => setReceivedBy(e.target.value)}
                placeholder="مكتب السانديك"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 focus:outline-none bg-white text-slate-900 font-bold placeholder:text-slate-400 placeholder:font-normal shadow-xs"
                dir="auto"
              />
            </div>

            {/* Live Duplicate Warning Banner */}
            {duplicatePaymentCheck.isDuplicate && (
              <div className="p-3.5 rounded-xl bg-amber-50 border-2 border-amber-300 text-amber-950 flex items-start gap-3 my-2 animate-in fade-in">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1 text-xs w-full">
                  <div className="font-bold flex items-center justify-between text-amber-900">
                    <span className="flex items-center gap-1.5">
                      ⚠️ {lang === 'ar' ? 'تنبيه تكرار الأداء: مسجل مسبقاً لهذا الشهر!' : 'Attention : Cotisation déjà enregistrée pour ce mois !'}
                    </span>
                    <span className="text-[10px] bg-amber-200/80 text-amber-900 font-bold px-2 py-0.5 rounded-md">
                      {lang === 'ar' ? 'نظام التحقق الذكي' : 'Détection doublon'}
                    </span>
                  </div>
                  <p className="text-amber-800 leading-relaxed">
                    {lang === 'ar' ? duplicatePaymentCheck.messageAr : duplicatePaymentCheck.messageFr}
                  </p>
                  {duplicatePaymentCheck.existingPayment && (
                    <div className="mt-1.5 p-2 bg-white/90 rounded-lg border border-amber-200 text-[11px] font-mono flex flex-wrap items-center gap-x-4 gap-y-1">
                      <span>{lang === 'ar' ? 'رقم الوصل:' : 'N° Reçu :'} <strong>{duplicatePaymentCheck.existingPayment.receiptNumber}</strong></span>
                      <span>{lang === 'ar' ? 'المبلغ:' : 'Montant :'} <strong>{duplicatePaymentCheck.existingPayment.amount} DH</strong></span>
                      <span>{lang === 'ar' ? 'التاريخ:' : 'Date :'} <strong>{duplicatePaymentCheck.existingPayment.paymentDate}</strong></span>
                      <span>{lang === 'ar' ? 'المستلم:' : 'Reçu par :'} <strong>{duplicatePaymentCheck.existingPayment.receivedBy}</strong></span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2 pt-4 justify-between border-t border-slate-100">
              <button
                id="btn-clear-payment-form"
                type="button"
                onClick={handleClearForm}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer border border-slate-200"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                <span>{lang === 'ar' ? 'مسح الحقول (إعادة الضبط)' : 'Effacer les champs'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  id="btn-cancel-payment-form"
                  type="button"
                  onClick={handleCancelForm}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer shadow-2xs"
                >
                  <Ban className="w-3.5 h-3.5 text-slate-500" />
                  <span>{lang === 'ar' ? 'إلغاء العملية' : t.common.cancel}</span>
                </button>
                <button
                  id="btn-submit-payment-form"
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 active:bg-emerald-900 text-white text-xs font-black transition-all shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ المعاملة وتوليد الوصل' : 'Enregistrer et générer le reçu'}</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Monthly Financial Reconciliation Banner (حساب كل شهر على حدة - مخفض ومنسق بأناقة) */}
      <div className="bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#0d5262] text-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-blue-900/40">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Left Title & Month Indicator */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-200">
              <Calendar className="w-4 h-4" />
            </span>
            <div className="flex items-center gap-2">
              <h2 className="text-xs sm:text-sm font-black">
                {lang === 'ar' ? 'المحاسبة الشهرية' : 'Comptabilité Mensuelle'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-600/40 text-blue-100 text-[11px] font-bold border border-blue-400/30">
                {monthLabel}
              </span>
            </div>

            {/* Quick Month Select Dropdown */}
            <select
              id="select-pay-month-dropdown"
              value={filterPeriod}
              onChange={(e) => setFilterPeriod(e.target.value)}
              className="px-2.5 py-1 text-[11px] font-bold rounded-lg border border-white/20 bg-slate-900 text-white focus:outline-none cursor-pointer"
            >
              <optgroup label={lang === 'ar' ? 'الشهور المتاحة' : 'Mois Disponibles'}>
                {availableMonths.map(opt => (
                  <option key={opt.key} value={opt.key}>
                    {lang === 'ar' ? opt.labelAr : opt.labelFr}
                  </option>
                ))}
              </optgroup>
              <option value="ALL">{lang === 'ar' ? '📊 جميع الشهور' : '📊 Tous les mois'}</option>
            </select>
          </div>

          {/* Right Metrics Summary Strip & Toggle Reduce/Expand Button */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap justify-between md:justify-end">
            <div className="flex items-center gap-2 font-mono text-xs">
              {/* Recettes */}
              <div className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-200">
                <span className="text-[10px] text-emerald-300 me-1 font-sans font-bold">{lang === 'ar' ? 'مداخيل:' : 'Recettes:'}</span>
                <span className="font-bold">{monthIncomeTotal.toLocaleString()} DH</span>
              </div>

              {/* Dépenses */}
              <div className="px-2.5 py-1 rounded-lg bg-rose-500/20 border border-rose-500/30 text-rose-200">
                <span className="text-[10px] text-rose-300 me-1 font-sans font-bold">{lang === 'ar' ? 'مصاريف:' : 'Dépenses:'}</span>
                <span className="font-bold">{monthExpenseTotal.toLocaleString()} DH</span>
              </div>

              {/* Solde Net */}
              <div className={`px-2.5 py-1 rounded-lg border font-bold ${
                monthNetBalance >= 0 
                  ? 'bg-emerald-600/30 border-emerald-400/40 text-emerald-100' 
                  : 'bg-rose-600/30 border-rose-400/40 text-rose-100'
              }`}>
                <span className="text-[10px] me-1 font-sans font-bold">{lang === 'ar' ? 'الرصيد:' : 'Solde:'}</span>
                <span>{monthNetBalance >= 0 ? '+' : ''}{monthNetBalance.toLocaleString()} DH</span>
              </div>
            </div>

            {/* Reduce / Expand Button (تصغير وتوسيع هذه الخانة) */}
            <button
              type="button"
              id="btn-toggle-reduce-monthly-banner"
              onClick={() => setIsMonthlyBannerReduced(prev => !prev)}
              className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold border border-white/20 transition-all cursor-pointer flex items-center gap-1 shrink-0"
              title={isMonthlyBannerReduced ? (lang === 'ar' ? 'توسيع لعرض التفاصيل' : 'Agrandir') : (lang === 'ar' ? 'تصغير وتقليص هذه الخانة' : 'Réduire cette partie')}
            >
              {isMonthlyBannerReduced ? (
                <span>{lang === 'ar' ? 'توسيع ➕' : 'Agrandir ➕'}</span>
              ) : (
                <span>{lang === 'ar' ? 'تصغير ➖' : 'Réduire ➖'}</span>
              )}
            </button>
          </div>
        </div>

        {/* When Expanded: Show Month Presets and Detailed Cards */}
        {!isMonthlyBannerReduced && (
          <div className="pt-3 border-t border-white/10 space-y-3 animate-in fade-in duration-200">
            {/* Quick Month Preset Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {[
                { key: '2026-05', labelAr: 'ماي 2026', labelFr: 'Mai 2026' },
                { key: '2026-06', labelAr: 'يونيو 2026', labelFr: 'Juin 2026' },
                { key: '2026-07', labelAr: 'يوليوز 2026', labelFr: 'Juillet 2026' },
                { key: '2026-08', labelAr: 'غشت 2026', labelFr: 'Août 2026' },
                { key: '2026-09', labelAr: 'شتنبر 2026', labelFr: 'Septembre 2026' },
              ].map(m => (
                <button
                  key={m.key}
                  type="button"
                  id={`btn-pay-month-${m.key}`}
                  onClick={() => setFilterPeriod(m.key)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    filterPeriod === m.key
                      ? 'bg-white text-blue-900 shadow-xs'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  {lang === 'ar' ? m.labelAr : m.labelFr}
                </button>
              ))}
            </div>

            {/* 3 Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                <span className="text-[11px] text-emerald-300 font-bold block mb-0.5">
                  {lang === 'ar' ? `💰 مداخيل ${monthLabel}` : `Recettes ${monthLabel}`}
                </span>
                <div className="text-xl font-black text-emerald-300 font-mono">
                  {monthIncomeTotal.toLocaleString()} <span className="text-xs text-emerald-200">DH</span>
                </div>
                <span className="text-[10px] text-emerald-200 mt-0.5 block">
                  {monthPayments.length} {lang === 'ar' ? 'عمليات استخلاص' : 'paiements'}
                </span>
              </div>

              <div className="bg-white/10 p-3 rounded-xl border border-white/10">
                <span className="text-[11px] text-rose-300 font-bold block mb-0.5">
                  {lang === 'ar' ? `💸 مصاريف ${monthLabel}` : `Dépenses ${monthLabel}`}
                </span>
                <div className="text-xl font-black text-rose-300 font-mono">
                  {monthExpenseTotal.toLocaleString()} <span className="text-xs text-rose-200">DH</span>
                </div>
                <span className="text-[10px] text-rose-200 mt-0.5 block">
                  {monthExpenses.length} {lang === 'ar' ? 'فواتير ومصاريف' : 'dépenses'}
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                monthNetBalance >= 0 
                  ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-100' 
                  : 'bg-rose-500/20 border-rose-400/40 text-rose-100'
              }`}>
                <span className="text-[11px] font-bold block mb-0.5">
                  {lang === 'ar' ? `⚖️ الرصيد الصافي لشهر ${monthLabel}` : `Solde Net ${monthLabel}`}
                </span>
                <div className="text-xl font-black font-mono">
                  {monthNetBalance >= 0 ? '+' : ''}{monthNetBalance.toLocaleString()} <span className="text-xs">DH</span>
                </div>
                <span className="text-[10px] font-bold block mt-0.5 text-emerald-200">
                  {monthNetBalance >= 0 
                    ? (lang === 'ar' ? 'فائض مالي إيجابي' : 'Excédent budgétaire') 
                    : (lang === 'ar' ? 'عجز مالي' : 'Déficit mensuel')}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Filters & Total Summary */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder={isOwner ? "بحث في وصولاتي (رقم الوصل، الشهر...)" : t.payments.searchPlaceholder}
              className="w-full ps-9 pe-3 py-2 text-xs bg-white text-slate-900 font-bold placeholder:text-slate-400 placeholder:font-normal rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 shadow-2xs"
            />
          </div>

          {!isOwner ? (
            <div>
              <select
                value={filterBuilding}
                onChange={e => {
                  const val = e.target.value;
                  setFilterBuilding(val);
                  if (val === 'GROUP_A') setFilterBuildingTab('GROUP_A');
                  else if (val === 'GROUP_B') setFilterBuildingTab('GROUP_B');
                  else if (val === 'ALL') setFilterBuildingTab('ALL');
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-bold text-slate-900"
              >
                <option value="ALL">جميع العمارات</option>
                
                <optgroup label="المجموعة الأولى: عمارات GH A (من GH 34 A إلى GH 43 A)">
                  {buildingsGroupA.map(b => (
                    <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                  ))}
                </optgroup>
                <optgroup label="المجموعة الثانية: عمارات GH B (من GH 34 B إلى GH 43 B)">
                  {buildingsGroupB.map(b => (
                    <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                  ))}
                </optgroup>
              </select>
            </div>
          ) : (
            <div className="flex items-center px-3 py-2 text-xs font-bold text-emerald-900 bg-emerald-50 rounded-xl border border-emerald-200">
              <span>{currentUser?.building} - شقة {currentUser?.apartment}</span>
            </div>
          )}

          <div>
            <select
              value={filterPeriod}
              onChange={e => setFilterPeriod(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-medium"
            >
              <option value="ALL">{lang === 'ar' ? '📅 جميع شهور الأداء' : 'Tous les mois'}</option>
              {availableMonths.map(opt => (
                <option key={opt.key} value={opt.key}>
                  {lang === 'ar' ? opt.labelAr : opt.labelFr}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={filterMethod}
              onChange={e => setFilterMethod(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            >
              <option value="ALL">{t.payments.filterMethod}</option>
              <option value="cash">{t.payments.methodCash}</option>
              <option value="bank_transfer">{t.payments.methodTransfer}</option>
              <option value="check">{t.payments.methodCheck}</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-xs">
            <span className="text-emerald-900 font-medium">
              {isOwner ? 'مجموع ما أديته:' : 'مجموع الأداءات:'}
            </span>
            <span className="font-extrabold text-emerald-800 font-mono text-sm">
              {totalFilteredIncome.toLocaleString()} DH
            </span>
          </div>
        </div>
      </div>

      {/* Payments Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Table Sorting Bar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-slate-700">
            <ArrowUpDown className="w-3.5 h-3.5 text-emerald-700" />
            <span>{lang === 'ar' ? 'ترتيب عرض الواجبات والوصولات:' : 'Ordre d\'affichage:'}</span>
          </div>

          <div className="flex items-center gap-1 bg-white p-0.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setSortMode('date')}
              className={`px-2.5 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                sortMode === 'date'
                  ? 'bg-[#0a8591] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'ar' ? '🗓️ الأحدث تاريخاً' : 'Plus récents'}
            </button>
            <button
              type="button"
              onClick={() => setSortMode('interleaved')}
              className={`px-2.5 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                sortMode === 'interleaved'
                  ? 'bg-[#0a8591] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="ترتيب متتالي: GH 34 A تليها GH 34 B، GH 35 A تليها GH 35 B..."
            >
              {lang === 'ar' ? '🔄 GH 34 A تليها GH 34 B' : 'GH 34 A puis 34 B'}
            </button>
            <button
              type="button"
              onClick={() => setSortMode('groupA_then_B')}
              className={`px-2.5 py-1 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                sortMode === 'groupA_then_B'
                  ? 'bg-[#0a8591] text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="عمارات حرف A وحدها ثم عمارات حرف B وحدها"
            >
              {lang === 'ar' ? '🅰️ عمارات A ثم 🅱️ عمارات B' : 'Groupe A puis B'}
            </button>
          </div>

          <div className="text-[11px] font-semibold text-slate-500">
            {lang === 'ar' ? `عدد الوصولات المعروضة: ${sortedPayments.length}` : `${sortedPayments.length} reçus affichés`}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap text-xs text-start border-collapse">
            <thead>
              <tr className="bg-[#0a8591] text-white font-bold">
                <th className="p-3.5 text-start">{t.payments.receiptNo}</th>
                <th className="p-3.5 text-start">{t.payments.resident}</th>
                <th className="p-3.5 text-start">{t.payments.building} / {t.payments.apartment}</th>
                <th className="p-3.5 text-start">{t.payments.period}</th>
                <th className="p-3.5 text-start">{t.payments.amount}</th>
                <th className="p-3.5 text-start">{t.payments.date}</th>
                <th className="p-3.5 text-start">{t.payments.method}</th>
                <th className="p-3.5 text-center">{t.payments.actions}</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {sortedPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-slate-400">
                    لا توجد أداءات مطابقة للبحث
                  </td>
                </tr>
              ) : (
                sortedPayments.map((p) => {
                  const formattedPeriod = formatPeriodDisplay(p.periodMonth, lang);
                  const resolvedRealOwner = resolveOwnerName(p.buildingCode, p.apartmentNumber);
                  const displayName = resolvedRealOwner || p.residentName;
                  const paymentWithRealOwner: Payment = { ...p, residentName: displayName };

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-900">
                        <span className="px-2 py-1 rounded bg-slate-100 border border-slate-200">
                          {p.receiptNumber}
                        </span>
                      </td>
                      <td className="p-3 font-medium text-slate-900">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-900">{displayName}</span>
                          {!isOwner && (
                            <button
                              type="button"
                              onClick={() => handleOpenEditOwnerNameModal(p.buildingCode, p.apartmentNumber)}
                              className="p-1 rounded-md text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors cursor-pointer"
                              title={lang === 'ar' ? 'تعديل اسم المالك في قائمة الملاك الرسمية' : 'Modifier le nom du copropriétaire dans la liste'}
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                        <div className="text-[10px] text-emerald-700 flex items-center gap-1 font-semibold mt-0.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
                          <span>{lang === 'ar' ? 'المالك الأصلي من صفحة السكان' : 'Propriétaire (page Résidents)'}</span>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-emerald-800 font-bold">
                        {p.buildingCode} - شقة {p.apartmentNumber}
                      </td>
                      <td className="p-3 text-slate-900 font-bold">
                        <span className="inline-block px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-950 border border-emerald-200 font-semibold text-xs shadow-2xs">
                          {formattedPeriod}
                        </span>
                      </td>
                      <td className="p-3 font-extrabold text-emerald-700 font-mono text-sm">
                        {p.amount} DH
                      </td>
                      <td className="p-3 text-slate-500 font-mono">
                        <div>{p.paymentDate}</div>
                        {(p.executedAtTime || p.createdAt) && (
                          <div className="text-[10px] text-emerald-700 font-sans font-medium flex items-center gap-1 mt-0.5">
                            <Clock className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                            <span>{p.executedAtTime || (p.createdAt ? new Date(p.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '')}</span>
                          </div>
                        )}
                      </td>
                      <td className="p-3 text-slate-600">
                        <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 text-[11px] font-semibold">
                          {getMethodLabel(p.paymentMethod)}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Print / View PDF Modal */}
                          <button
                            onClick={() => setSelectedReceipt(paymentWithRealOwner)}
                            className="px-2.5 py-1 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white font-bold flex items-center gap-1 transition-colors shadow-xs cursor-pointer"
                            title={lang === 'ar' ? 'معاينة واستخراج وصل PDF' : t.payments.printReceipt}
                          >
                            <FileDown className="w-3.5 h-3.5 text-emerald-200" />
                            <span>{lang === 'ar' ? 'وصل PDF' : t.payments.printReceipt}</span>
                          </button>

                          {/* Quick WhatsApp Send */}
                          {(() => {
                            const apt = apartments.find(a => a.buildingCode === p.buildingCode && a.number === p.apartmentNumber);
                            const res = residents.find(r => r.buildingCode === p.buildingCode && r.apartmentNumber === p.apartmentNumber);
                            const phone = res?.phone || apt?.ownerPhone || apt?.residentPhone || '';
                            const waUrl = buildReceiptWhatsAppUrl(paymentWithRealOwner, formattedPeriod, phone);

                            return (
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition-colors cursor-pointer"
                                title={lang === 'ar' ? 'إرسال بيانات الوصل للمالك عبر واتساب' : 'Envoyer par WhatsApp'}
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </a>
                            );
                          })()}

                          {!isOwner && (
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                id={`btn-edit-payment-${p.id}`}
                                onClick={() => handleOpenEditPayment(p)}
                                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-emerald-700 transition-colors cursor-pointer"
                                title={lang === 'ar' ? 'تعديل وتصحيح الوصل المسجل بالخطأ' : 'Modifier'}
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                id={`btn-delete-payment-${p.id}`}
                                onClick={() => setPaymentToDelete(p)}
                                className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                                title={lang === 'ar' ? 'إلغاء / حذف الوصل المسجل بالخطأ' : 'Supprimer'}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete / Cancellation Confirmation Modal */}
      {paymentToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'تأكيد إلغاء وحذف وصل الأداء' : 'Confirmation de suppression'}
            </h3>
            
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar' 
                ? `هل أنت متأكد من إلغاء وحذف الوصل رقم (${paymentToDelete.receiptNumber}) الخاص بـ ${paymentToDelete.residentName} (شقة ${paymentToDelete.apartmentNumber} - ${paymentToDelete.buildingCode}) بمبلغ ${paymentToDelete.amount} درهم؟`
                : `Êtes-vous sûr de vouloir annuler et supprimer le reçu N° ${paymentToDelete.receiptNumber} ?`}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setPaymentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={confirmDeletePayment}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white text-xs font-black transition-all shadow-md cursor-pointer"
              >
                {lang === 'ar' ? 'تأكيد المسح / الإلغاء' : 'Confirmer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Test Payments Confirmation Modal */}
      {!isOwner && isClearConfirmOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'مسح وإفراغ جميع وصولات الأداء التجريبية' : 'Purger les reçus de test'}
            </h3>
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar'
                ? `هل أنت متأكد من مسح جميع وصولات الأداء المسجلة حالياً (${payments.length} وصل)؟ سيتم حذف هذه الوصولات التجريبية لتنظيف السجل، والبدء بتسجيل الأداءات بالأسماء الحقيقية للملاك المستخرجة تلقائياً من صفحة السكان.`
                : `Voulez-vous vraiment effacer tous les reçus de paiement enregistrés (${payments.length}) pour repartir à zéro avec les vrais copropriétaires de la page Résidents ?`}
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsClearConfirmOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={handleConfirmClearAllPayments}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white text-xs font-black transition-all shadow-md cursor-pointer"
              >
                {lang === 'ar' ? 'نعم، مسح جميع الوصولات' : 'Oui, purger tous les reçus'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Payment Modal (تعديل وتصحيح وصل الأداء المسجل بالخطأ) */}
      {!isOwner && editingPayment && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                  <Edit2 className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {lang === 'ar' ? 'تعديل وتصحيح وصل الأداء' : 'Modifier le reçu'}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono">
                    {editingPayment.receiptNumber} • {editingPayment.residentName} ({editingPayment.buildingCode} - شقة {editingPayment.apartmentNumber})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingPayment(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditPayment} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'المبلغ المؤدى (DH) *' : 'Montant réglé (DH) *'}
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={editPayAmount}
                  onChange={e => setEditPayAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'تاريخ الأداء الفعلي (يوم المحاسبة والاحتساب كمداخيل) *' : 'Date de versement *'}
                </label>
                <input
                  type="date"
                  required
                  value={editPayDate}
                  onChange={e => setEditPayDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
                <p className="text-[11px] text-emerald-800 mt-1.5 bg-emerald-50 p-2 rounded-lg border border-emerald-100">
                  {lang === 'ar'
                    ? '💡 تاريخ الأداء هو الذي يأخذ به كمداخيل ذلك الشهر: إذا أدى المالك اليوم متأخراً بأكثر من شهر، يُحتسب المبلغ كله على يوم الأداء (مداخيل شهر الأداء).'
                    : '💡 La date de versement détermine le mois de comptabilisation des recettes : la totalité du montant est imputée au mois effectif du règlement.'}
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'الفترة المغطاة بالأداء (الأشهر)' : 'Période couverte'}
                </label>
                <input
                  type="text"
                  value={editPayPeriodMonth}
                  onChange={e => setEditPayPeriodMonth(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'طريقة الأداء' : 'Mode de paiement'}
                </label>
                <select
                  value={editPayMethod}
                  onChange={e => setEditPayMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white"
                >
                  <option value="cash">{t.payments.methodCash}</option>
                  <option value="bank_transfer">{t.payments.methodTransfer}</option>
                  <option value="check">{t.payments.methodCheck}</option>
                  <option value="online">{t.payments.methodOnline}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'ملاحظات / تفاصيل' : 'Notes'}
                </label>
                <input
                  type="text"
                  value={editPayNotes}
                  onChange={e => setEditPayNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingPayment(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 transition-all cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ التعديل والتصحيح' : t.common.save}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Paid Receipts PDF Modal */}
      <PaidReceiptsPdfModal
        isOpen={isPaidReceiptsModalOpen}
        onClose={() => setIsPaidReceiptsModalOpen(false)}
      />

      {/* Payment Due Date Alerts Modal */}
      <PaymentDueAlertModal
        isOpen={isDueAlertModalOpen}
        onClose={() => setIsDueAlertModalOpen(false)}
      />

      {/* Quick Add Floating Action Button */}
      {!isOwner && (
        <button
          onClick={() => setIsQuickAddOpen(true)}
          className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 w-14 h-14 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-2xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 cursor-pointer z-40"
          title={lang === 'ar' ? 'أداء سريع' : 'Paiement rapide'}
        >
          <Zap className="w-7 h-7" />
        </button>
      )}

      {/* Quick Add Modal */}
      {isQuickAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-sm w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
                <Zap className="w-5 h-5 text-emerald-500" />
                {lang === 'ar' ? 'تسجيل أداء سريع' : 'Paiement Rapide'}
              </h3>
              <button
                onClick={() => setIsQuickAddOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleQuickSubmit} className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'العمارة *' : 'Immeuble *'}
                  </label>
                  <select
                    required
                    value={quickBuildingCode}
                    onChange={(e) => setQuickBuildingCode(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[11px] font-bold text-slate-700">
                      {lang === 'ar' ? 'الشقة *' : 'Appartement *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setManageOwnersBuilding(quickBuildingCode);
                        setManageOwnersApartment(quickApartmentNumber || '01');
                        setManageOwnersDefaultTab('add');
                        setIsManageOwnersModalOpen(true);
                      }}
                      className="text-[10px] text-blue-600 hover:text-blue-800 font-bold underline cursor-pointer"
                    >
                      {lang === 'ar' ? 'تعديل/زيادة مالك' : 'Copropriétaire'}
                    </button>
                  </div>
                  <select
                    required
                    value={quickApartmentNumber}
                    onChange={(e) => setQuickApartmentNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">{lang === 'ar' ? 'اختر الشقة' : 'Choisir'}</option>
                    {apartments
                      .filter(a => normBld(a.buildingCode) === normBld(quickBuildingCode))
                      .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }))
                      .map(a => {
                        const ownerName = resolveOwnerName(quickBuildingCode, a.number);
                        return (
                          <option key={a.id} value={a.number}>
                            {lang === 'ar' ? 'شقة' : 'Appt'} {a.number} {ownerName ? `• 👤 ${ownerName}` : ''}
                          </option>
                        );
                      })}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'الشهر المؤدى *' : 'Mois *'}
                  </label>
                  <input
                    type="month"
                    required
                    value={quickPeriodMonth}
                    onChange={e => setQuickPeriodMonth(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'المبلغ (درهم) *' : 'Montant *'}
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={quickAmount}
                    onChange={e => setQuickAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              {/* Quick Add Live Duplicate Warning */}
              {quickDuplicateCheck.isDuplicate && (
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-[11px] flex items-start gap-2 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <span className="font-bold block text-amber-900">
                      ⚠️ {lang === 'ar' ? 'أداء مسجل مسبقاً لهذا الشهر!' : 'Paiement déjà enregistré !'}
                    </span>
                    <p className="text-amber-800 leading-tight">
                      {lang === 'ar' ? quickDuplicateCheck.messageAr : quickDuplicateCheck.messageFr}
                    </p>
                  </div>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-sm font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {lang === 'ar' ? 'حفظ الأداء' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Owners Dues Excel Modal (Export & Import) */}
      <OwnersDuesExcelModal
        isOpen={isOwnersDuesModalOpen}
        onClose={() => setIsOwnersDuesModalOpen(false)}
        defaultTab={ownersDuesTab}
      />

      {/* Manage Owners Modal (خاصية تغيير الملاك: زيادة أو نقصان الملاك) */}
      <ManageOwnersModal
        isOpen={isManageOwnersModalOpen}
        onClose={() => setIsManageOwnersModalOpen(false)}
        initialBuildingCode={manageOwnersBuilding}
        initialApartmentNumber={manageOwnersApartment}
        defaultTab={manageOwnersDefaultTab}
      />

      {/* Dedicated Edit Owner Name Modal (تعديل وحفظ اسم المالك في قائمة الملاك) */}
      {isEditOwnerNameModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="px-5 py-4 bg-gradient-to-r from-blue-700 via-indigo-800 to-blue-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-white/10 text-white">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black">
                    {lang === 'ar' ? 'تعديل اسم المالك في قائمة الملاك الرسمية' : 'Modifier le nom du copropriétaire'}
                  </h3>
                  <p className="text-[11px] text-blue-200">
                    {lang === 'ar' ? 'يتم حفظ الاسم فورياً وبشكل دائم في السجل العام للملاك والوصولات والشقق' : 'Mise à jour directe et définitive dans la liste des copropriétaires'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEditOwnerNameModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveOwnerNameModalSubmit} className="p-5 space-y-4">
              {/* Select Building & Apartment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'العمارة *' : 'Immeuble *'}
                  </label>
                  <select
                    value={editOwnerBuilding}
                    onChange={(e) => {
                      const newB = e.target.value;
                      setEditOwnerBuilding(newB);
                      const currentApts = apartments.filter(a => a.buildingCode === newB);
                      const defaultApt = currentApts[0]?.number || '01';
                      setEditOwnerApartment(defaultApt);
                      setEditOwnerFullName(resolveOwnerName(newB, defaultApt));
                    }}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-bold bg-white text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  >
                    <optgroup label="المجموعة الأولى: عمارات حرف A (من GH 34 A إلى GH 43 A)">
                      {buildingsGroupA.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                    <optgroup label="المجموعة الثانية: عمارات حرف B (من GH 34 B إلى GH 43 B)">
                      {buildingsGroupB.map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'رقم الشقة *' : 'Appartement *'}
                  </label>
                  <select
                    value={editOwnerApartment}
                    onChange={(e) => {
                      const newA = e.target.value;
                      setEditOwnerApartment(newA);
                      setEditOwnerFullName(resolveOwnerName(editOwnerBuilding, newA));
                    }}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 font-bold bg-white text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  >
                    {apartments
                      .filter(a => normBld(a.buildingCode) === normBld(editOwnerBuilding))
                      .sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }))
                      .map(a => {
                        const ownerName = resolveOwnerName(editOwnerBuilding, a.number);
                        return (
                          <option key={a.id} value={a.number}>
                            {lang === 'ar' ? 'شقة' : 'Appt'} {a.number} {ownerName ? `• 👤 ${ownerName}` : ''}
                          </option>
                        );
                      })}
                  </select>
                </div>
              </div>

              {/* Current registered owner badge */}
              <div className="p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-xs flex items-center justify-between">
                <span className="text-blue-800 font-medium">
                  {lang === 'ar' ? 'الاسم الحالي المسجل في السجل:' : 'Nom actuel dans la liste officielle :'}
                </span>
                <span className="font-extrabold text-blue-950 font-mono">
                  {resolveOwnerName(editOwnerBuilding, editOwnerApartment) || (lang === 'ar' ? '(لم يُسجل بعد باللائحة)' : '(Non renseigné)')}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {lang === 'ar' ? 'الاسم الكامل الجديد لمالك الشقة *' : 'Nouveau nom complet du copropriétaire *'}
                </label>
                <input
                  type="text"
                  required
                  value={editOwnerFullName}
                  onChange={e => setEditOwnerFullName(e.target.value)}
                  placeholder={lang === 'ar' ? 'أدخل الاسم الجديد لمالك الشقة...' : 'Nom complet du copropriétaire...'}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 focus:outline-hidden font-bold text-slate-900 bg-white"
                  dir="auto"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  {lang === 'ar' 
                    ? '📌 سيتم تسجيل هذا الاسم فوراً وبشكل دائم في السجل العام للملاك والوصولات والشقق.' 
                    : '📌 Ce nom sera enregistré définitivement dans la liste des copropriétaires.'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {lang === 'ar' ? 'رقم الهاتف (اختياري)' : 'Téléphone (optionnel)'}
                  </label>
                  <input
                    type="text"
                    value={editOwnerPhone}
                    onChange={e => setEditOwnerPhone(e.target.value)}
                    placeholder="06XXXXXXXX"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-hidden font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {lang === 'ar' ? 'رقم البطاقة CIN (اختياري)' : 'CIN (optionnel)'}
                  </label>
                  <input
                    type="text"
                    value={editOwnerCin}
                    onChange={e => setEditOwnerCin(e.target.value)}
                    placeholder="AB123456"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 focus:outline-hidden font-mono uppercase"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditOwnerNameModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 text-white text-xs font-black shadow-md cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ وتحديث في قائمة الملاك 💾' : 'Enregistrer dans la liste'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Add/Remove Apartment Modal (زيادة شقة أو نقص شقة مباشرة من خانة الشقق) */}
      {isAptManagePopupOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="px-5 py-4 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-white/10 text-indigo-300">
                  <Home className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black">
                    {lang === 'ar' ? `إدارة قائمة الشقق بالعمارة ${buildingCode}` : `Gérer les appartements (${buildingCode})`}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {lang === 'ar' ? 'زيادة شقة جديدة (مثل 3 مكرر) أو مسح وحذف شقة (مثل 16)' : 'Ajouter ou supprimer une unité'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAptManagePopupOpen(false);
                  setAptActionFeedback(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Action feedback */}
              {aptActionFeedback && (
                <div className={`p-3 rounded-xl text-xs font-bold border flex items-center gap-2 ${
                  aptActionFeedback.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-rose-50 text-rose-800 border-rose-200'
                }`}>
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{aptActionFeedback.text}</span>
                </div>
              )}

              {/* SECTION 1: زيادة شقة (Add Apartment) */}
              <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-3">
                <div className="flex items-center gap-2 text-emerald-900 font-extrabold text-xs sm:text-sm">
                  <Plus className="w-4 h-4 text-emerald-700" />
                  <span>{lang === 'ar' ? '1. زيادة شقة جديدة في هذه العمارة (مثل: 03 مكرر)' : '1. Ajouter un appartement'}</span>
                </div>
                <p className="text-[11px] text-emerald-800 leading-relaxed">
                  {lang === 'ar' 
                    ? 'أدخل رقم أو تسمية الشقة المراد إضافتها (مثلاً: 03 مكرر أو 3 bis) لتظهر فوراً في خانة الشقق وسجل الوصولات:'
                    : 'Saisissez le numéro ou l\'étiquette du nouvel appartement:'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {lang === 'ar' ? 'رقم / تسمية الشقة *' : 'N° Appartement *'}
                    </label>
                    <input
                      type="text"
                      value={newAptInputNumber}
                      onChange={e => setNewAptInputNumber(e.target.value)}
                      placeholder="03 مكرر (3 bis)"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {lang === 'ar' ? 'اسم المالك (اختياري)' : 'Nom Propriétaire'}
                    </label>
                    <input
                      type="text"
                      value={newAptOwnerName}
                      onChange={e => setNewAptOwnerName(e.target.value)}
                      placeholder={lang === 'ar' ? 'مثال: ذ. عبد الرحيم' : 'Nom'}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {lang === 'ar' ? 'الطابق' : 'Étage'}
                    </label>
                    <select
                      value={newAptFloor}
                      onChange={e => setNewAptFloor(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white"
                    >
                      <option value={0}>{lang === 'ar' ? 'الطابق الأرضي (RDC)' : 'RDC'}</option>
                      <option value={1}>{lang === 'ar' ? 'الطابق 1' : 'Étage 1'}</option>
                      <option value={2}>{lang === 'ar' ? 'الطابق 2' : 'Étage 2'}</option>
                      <option value={3}>{lang === 'ar' ? 'الطابق 3' : 'Étage 3'}</option>
                      <option value={4}>{lang === 'ar' ? 'الطابق 4' : 'Étage 4'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {lang === 'ar' ? 'الواجب الشهري (د.م)' : 'Cotisation (DH)'}
                    </label>
                    <input
                      type="number"
                      value={newAptFee}
                      onChange={e => setNewAptFee(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const trimmed = newAptInputNumber.trim();
                      if (!trimmed) {
                        setAptActionFeedback({ type: 'error', text: lang === 'ar' ? 'يرجى إدخال رقم أو اسم الشقة.' : 'Veuillez saisir un numéro d\'appartement.' });
                        return;
                      }
                      addApartment({
                        buildingCode,
                        number: trimmed,
                        floor: newAptFloor,
                        monthlyFee: newAptFee || 150,
                        ownerName: newAptOwnerName.trim(),
                        residentName: newAptOwnerName.trim(),
                        ownerPhone: '',
                        residentPhone: '',
                        isRented: false,
                        balanceDue: 0,
                        status: 'occupied',
                        notes: 'تمت إضافتها يدوياً من خانة الشقق'
                      });
                      setApartmentNumber(trimmed);
                      if (newAptOwnerName.trim()) {
                        setResidentName(newAptOwnerName.trim());
                      }
                      setAptActionFeedback({
                        type: 'success',
                        text: lang === 'ar' 
                          ? `✅ تمت إضافة الشقة "${trimmed}" بالعمارة ${buildingCode} بنجاح واختيارها في النموذج!`
                          : `✅ Appartement ${trimmed} ajouté avec succès!`
                      });
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'تأكيد زيادة الشقة ➕' : 'Ajouter l\'appartement'}</span>
                  </button>
                </div>
              </div>

              {/* SECTION 2: مسح شقة (Delete Apartment) */}
              <div className="p-4 rounded-xl bg-rose-50/60 border border-rose-200 space-y-3">
                <div className="flex items-center gap-2 text-rose-900 font-extrabold text-xs sm:text-sm">
                  <Trash2 className="w-4 h-4 text-rose-700" />
                  <span>{lang === 'ar' ? '2. مسح شقة من لائحة هذه العمارة (مثل: الشقة 16)' : '2. Supprimer un appartement'}</span>
                </div>
                <p className="text-[11px] text-rose-800 leading-relaxed">
                  {lang === 'ar' 
                    ? 'اختر الشقة المراد مسحها نهائياً من لائحة الشقق بالعمارة (مثلاً الشقة رقم 16):'
                    : 'Sélectionnez l\'appartement à retirer de la liste:'}
                </p>

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <select
                    value={aptToDeleteNumber}
                    onChange={e => setAptToDeleteNumber(e.target.value)}
                    className="w-full sm:w-2/3 px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-rose-600 focus:outline-none bg-white font-bold text-slate-900"
                  >
                    {currentBuildingApts.map(a => (
                      <option key={a.id} value={a.number}>
                        {lang === 'ar' ? 'شقة' : 'Appt'} {a.number} {a.ownerName ? `• ${a.ownerName}` : ''}
                      </option>
                    ))}
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      const target = currentBuildingApts.find(a => a.number === aptToDeleteNumber);
                      if (!target) {
                        setAptActionFeedback({ type: 'error', text: lang === 'ar' ? 'الشقة المختارة غير موجودة.' : 'Appartement introuvable.' });
                        return;
                      }
                      deleteApartment(target.id);
                      // تحديث التحديد الافتراضي إن كانت هي المحددة
                      const remaining = currentBuildingApts.filter(a => a.id !== target.id);
                      if (remaining.length > 0) {
                        setApartmentNumber(remaining[0].number);
                        setAptToDeleteNumber(remaining[0].number);
                      }
                      setAptActionFeedback({
                        type: 'success',
                        text: lang === 'ar'
                          ? `🗑️ تم مسح وحذف الشقة ${target.number} من العمارة ${buildingCode} بنجاح!`
                          : `🗑️ Appartement ${target.number} supprimé avec succès!`
                      });
                    }}
                    className="w-full sm:w-1/3 px-4 py-2 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'مسح الشقة 🗑️' : 'Supprimer'}</span>
                  </button>
                </div>
              </div>

              {/* Quick shortcut presets */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-200">
                <span className="text-[11px] font-bold text-slate-600">
                  {lang === 'ar' ? 'إجراءات سريعة مطلوبة:' : 'Raccourcis rapides:'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    addApartment({
                      buildingCode,
                      number: '03 مكرر (3 bis)',
                      floor: 1,
                      monthlyFee: 150,
                      ownerName: '',
                      residentName: '',
                      ownerPhone: '',
                      residentPhone: '',
                      isRented: false,
                      balanceDue: 0,
                      status: 'occupied',
                      notes: 'شقة 3 مكرر'
                    });
                    setApartmentNumber('03 مكرر (3 bis)');
                    setAptActionFeedback({
                      type: 'success',
                      text: lang === 'ar' ? `✅ تمت إضافة الشقة "03 مكرر (3 bis)" للعمارة ${buildingCode} فوراً!` : '✅ 3 bis ajoutée!'
                    });
                  }}
                  className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 text-[11px] font-bold cursor-pointer transition-colors"
                >
                  {lang === 'ar' ? '➕ إضافة 03 مكرر فوراً' : '+ Ajouter 3 bis'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const a16 = currentBuildingApts.find(a => a.number === '16' || a.number === '16A' || a.number === '16B');
                    if (a16) {
                      deleteApartment(a16.id);
                      setAptActionFeedback({
                        type: 'success',
                        text: lang === 'ar' ? `🗑️ تم مسح الشقة رقم 16 من لائحة ${buildingCode} فوراً!` : '🗑️ Appt 16 supprimé!'
                      });
                    } else {
                      setAptActionFeedback({
                        type: 'error',
                        text: lang === 'ar' ? `الشقة رقم 16 غير موجودة في العمارة ${buildingCode}.` : 'Appt 16 introuvable.'
                      });
                    }
                  }}
                  className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-[11px] font-bold cursor-pointer transition-colors"
                >
                  {lang === 'ar' ? '🗑️ مسح الشقة رقم 16 فوراً' : 'Supprimer Appt 16'}
                </button>
              </div>
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setIsAptManagePopupOpen(false);
                  setAptActionFeedback(null);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                {lang === 'ar' ? 'تم / العودة لاستلام الواجبات' : 'Fermer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Anti-Duplicate Warning Confirmation Modal */}
      {duplicatePaymentModal && (
        <DuplicateWarningModal
          isOpen={duplicatePaymentModal.isOpen}
          onClose={() => setDuplicatePaymentModal(null)}
          onConfirm={duplicatePaymentModal.onConfirm}
          lang={lang}
          type="payment"
          existingPayment={duplicatePaymentModal.existingPayment}
          candidatePayment={duplicatePaymentModal.candidatePayment}
          customMessage={duplicatePaymentModal.customMessage}
        />
      )}
    </div>
  );
};
