import { supabase, getSupabaseConfig, createDynamicSupabaseClient } from '../supabase';
import { 
  Building, 
  Apartment, 
  Resident, 
  Payment, 
  Expense, 
  Employee, 
  MaintenanceTicket, 
  Notice, 
  Visitor,
  ManualMonthlyRecord,
  ArchiveBatch,
  AssemblyResolution
} from '../types';

export interface ResidenceSyncPayload {
  buildings: Building[];
  apartments: Apartment[];
  residents: Resident[];
  payments: Payment[];
  expenses: Expense[];
  employees: Employee[];
  maintenanceTickets: MaintenanceTicket[];
  notices: Notice[];
  visitors: Visitor[];
  manualMonthlyRecords?: ManualMonthlyRecord[];
  archivedPayments?: Payment[];
  archivedExpenses?: Expense[];
  archiveBatches?: ArchiveBatch[];
  assemblyResolutions?: AssemblyResolution[];
  pointageRecords?: Record<string, any>;
  pointageAdvances?: Record<string, number>;
  pointageBonuses?: Record<string, number>;
  lastSyncedAt: string;
  clientSourceId?: string;
  deletedIds?: string[];
}

const SYNC_DOC_ID = 'main_residence_data';

export const pushResidenceToSupabase = async (payload: ResidenceSyncPayload) => {
  const { url, key } = getSupabaseConfig();

  // 1. First try server-side proxy (works inside iframe, avoids CORS and browser blocking)
  try {
    const res = await fetch('/api/supabase/push', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        ...(url ? { 'x-supabase-url': url } : {}),
        ...(key ? { 'x-supabase-key': key } : {})
      },
      body: JSON.stringify(payload)
    });
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      if (data.success) {
        return { success: true };
      }
    } else if (contentType.includes('application/json')) {
      const errText = await res.text();
      let errorMsg = errText;
      try {
        const json = JSON.parse(errText);
        errorMsg = json.error || json.message || errText;
      } catch {
        // use raw text
      }
      if (errorMsg.includes('PGRST205') || errorMsg.includes('Could not find the table') || errorMsg === 'TABLE_MISSING') {
        return { success: false, error: 'TABLE_MISSING' };
      }
      return { success: false, error: errorMsg };
    }
    // If not json (e.g. Netlify returned index.html or 404), fall through to client fallback!
  } catch (e) {
    // If backend endpoint is completely unreachable (e.g. static host), proceed to direct client fallback
  }

  // 2. Direct client fallback (standard on Netlify, Vercel, or client static hosting)
  const client = createDynamicSupabaseClient() || supabase;
  if (!client) {
    return { success: false, error: 'يرجى إدخال رابط ومفتاح مشروع Supabase في إعدادات الربط' };
  }
  try {
    const { error } = await client
      .from('residence_sync')
      .upsert({ 
        id: SYNC_DOC_ID, 
        data: payload,
        updated_at: new Date().toISOString()
      }, { onConflict: 'id' });

    if (error) {
      if (error.code === 'PGRST205' || error.message?.includes('does not exist')) {
        return { success: false, error: 'TABLE_MISSING' };
      }
      throw error;
    }
    return { success: true };
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || err.name === 'TypeError') {
      console.warn("Supabase push could not reach host:", msg);
      return { 
        success: false, 
        error: 'تعذر الاتصال بقاعدة البيانات السحابية Supabase (الخادم غير متوفر أو الرابط غير متاح)' 
      };
    }
    console.error("Supabase push error:", err);
    let errorMsg = err.message || 'Erreur de synchronisation';
    return { success: false, error: errorMsg };
  }
};

const convertSnakeToCamelObj = (obj: any): any => {
  if (Array.isArray(obj)) return obj.map(convertSnakeToCamelObj);
  if (obj !== null && typeof obj === 'object' && !(obj instanceof Date)) {
    const n: any = {};
    for (const key of Object.keys(obj)) {
      const camelKey = key.replace(/_([a-z])/g, (g) => g[1].toUpperCase());
      n[camelKey] = convertSnakeToCamelObj(obj[key]);
    }
    return n;
  }
  return obj;
};

export const pullResidenceFromSupabase = async () => {
  const { url, key } = getSupabaseConfig();

  // 1. First try server-side proxy
  try {
    const res = await fetch('/api/supabase/pull', {
      headers: {
        ...(url ? { 'x-supabase-url': url } : {}),
        ...(key ? { 'x-supabase-key': key } : {})
      }
    });
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const json = await res.json();
      if (json.success) {
        return { success: true, data: json.data ? convertSnakeToCamelObj(json.data) as ResidenceSyncPayload : null };
      }
    } else if (contentType.includes('application/json')) {
      const errText = await res.text();
      let errorMsg = errText;
      try {
        const json = JSON.parse(errText);
        errorMsg = json.error || json.message || errText;
      } catch {
        // raw text
      }
      if (errorMsg.includes('PGRST205') || errorMsg.includes('Could not find the table') || errorMsg === 'TABLE_MISSING') {
        return { success: false, error: 'TABLE_MISSING' };
      }
      return { success: false, error: errorMsg };
    }
    // If not json (Netlify static SPA fallback), fall through to client fallback!
  } catch (e) {
    // Fallback to client if server unreachable
  }

  // 2. Direct client fallback (standard on Netlify)
  const client = createDynamicSupabaseClient() || supabase;
  if (!client) {
    return { success: false, error: 'يرجى إدخال رابط ومفتاح مشروع Supabase في إعدادات الربط' };
  }
  try {
    const { data, error } = await client
      .from('residence_sync')
      .select('data')
      .eq('id', SYNC_DOC_ID)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        // No rows returned - initialize empty or return success with no data
        return { success: true, data: null };
      }
      if (error.code === 'PGRST205' || error.message?.includes('does not exist')) {
        return { success: false, error: 'TABLE_MISSING' };
      }
      throw error;
    }
    
    return { success: true, data: data?.data ? convertSnakeToCamelObj(data.data) as ResidenceSyncPayload : null };
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || err.name === 'TypeError') {
       console.warn("Supabase pull could not reach host:", msg);
       return { success: false, error: 'TABLE_MISSING' };
    }
    console.error("Supabase pull error:", err);
    let errorMsg = err.message || 'Erreur de synchronisation';
    return { success: false, error: errorMsg };
  }
};

export const subscribeToSupabaseSync = (onUpdate: (payload: ResidenceSyncPayload) => void) => {
  if (!supabase) {
    return () => {};
  }
  try {
    const subscription = supabase
      .channel('residence_sync_changes')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'residence_sync', filter: `id=eq.${SYNC_DOC_ID}` },
        (payload) => {
          if (payload.new && payload.new.data) {
            const camelData = convertSnakeToCamelObj(payload.new.data) as ResidenceSyncPayload;
            onUpdate(camelData);
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'residence_sync', filter: `id=eq.${SYNC_DOC_ID}` },
        (payload) => {
          if (payload.new && payload.new.data) {
            const camelData = convertSnakeToCamelObj(payload.new.data) as ResidenceSyncPayload;
            onUpdate(camelData);
          }
        }
      )
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR') {
          // Channel error silently handled - host or table might be unavailable
        }
      });

    return () => {
      try {
        supabase.removeChannel(subscription);
      } catch {}
    };
  } catch (e) {
    return () => {};
  }
};

export const clearSupabaseAllData = async (): Promise<{ success: boolean; error?: string }> => {
  const { url, key } = getSupabaseConfig();

  // 1. Try server-side proxy
  try {
    const res = await fetch('/api/supabase/clear', { 
      method: 'POST',
      headers: {
        ...(url ? { 'x-supabase-url': url } : {}),
        ...(key ? { 'x-supabase-key': key } : {})
      }
    });
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const json = await res.json();
      if (json.success) return { success: true };
    } else if (contentType.includes('application/json')) {
      const errText = await res.text();
      let errorMsg = errText;
      try {
        const json = JSON.parse(errText);
        errorMsg = json.error || json.message || errText;
      } catch {}
      return { success: false, error: errorMsg };
    }
  } catch (e) {
    // fallback
  }

  // 2. Direct client fallback
  const client = createDynamicSupabaseClient() || supabase;
  if (!client) {
    return { success: false, error: 'Configuration Supabase manquante' };
  }

  try {
    // Delete sync document
    const { error: syncErr } = await client
      .from('residence_sync')
      .delete()
      .eq('id', SYNC_DOC_ID);

    if (syncErr) throw syncErr;

    return { success: true };
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || err.name === 'TypeError') {
      console.warn('Supabase clear could not reach host:', msg);
      return { success: false, error: 'تعذر الاتصال بقاعدة البيانات السحابية Supabase' };
    }
    console.error('Supabase clear error:', err);
    return { success: false, error: err.message };
  }
};

export const submitOrderToSupabase = async (customerName: string, email: string, details: string) => {
  const { url, key } = getSupabaseConfig();

  // 1. Try server-side proxy
  try {
    const res = await fetch('/api/supabase/order', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        ...(url ? { 'x-supabase-url': url } : {}),
        ...(key ? { 'x-supabase-key': key } : {})
      },
      body: JSON.stringify({ customerName, email, details })
    });
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const json = await res.json();
      if (json.success) return { success: true, data: json.data };
      else throw new Error(json.error);
    } else if (contentType.includes('application/json')) {
      const errText = await res.text();
      if (errText.includes('PGRST205') || errText.includes('Could not find the table')) {
        throw new Error('TABLE_MISSING');
      }
      let errorMsg = errText;
      try {
        const json = JSON.parse(errText);
        errorMsg = json.error || json.message || errText;
      } catch {}
      throw new Error(errorMsg);
    }
  } catch (e: any) {
    if (e.message === 'TABLE_MISSING' || e.message?.includes('تعذر الاتصال')) throw e;
    // Fallback to client
  }

  // 2. Direct client fallback
  const client = createDynamicSupabaseClient() || supabase;
  if (!client) {
    throw new Error('Configuration Supabase manquante. Veuillez vérifier vos clés.');
  }
  try {
    const { data, error } = await client
      .from('orders')
      .insert([{ customer_name: customerName, email, details }]);

    if (error) {
      if (error.code === 'PGRST205' || error.message?.includes('does not exist')) {
        throw new Error('TABLE_MISSING');
      }
      throw error;
    }
    return { success: true, data };
  } catch (err: any) {
    let errorMsg = err.message || 'Erreur lors de l\'envoi de la commande';
    if (errorMsg === 'Failed to fetch' || errorMsg.includes('Failed to fetch') || err.name === 'TypeError') {
      errorMsg = 'تعذر الاتصال بقاعدة البيانات السحابية Supabase';
    }
    throw new Error(errorMsg);
  }
};
