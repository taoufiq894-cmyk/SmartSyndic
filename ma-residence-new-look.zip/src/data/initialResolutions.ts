import { AssemblyResolution } from '../types';

export const initialAssemblyResolutions: AssemblyResolution[] = [
  {
    id: 'res-2026-01',
    assemblyYear: 2026,
    assemblyType: 'ordinary',
    titleAr: 'المصادقة على التقرير المالي والأدبي وإبراء ذمة مكتب السانديك',
    titleFr: 'Approbation des rapports financier et moral et quitus au syndic',
    descriptionAr: 'عرض الحصيلة المالية الشاملة لسنة 2025/2026، التحقق من الفائض المالي المحقق، ومطابقة سجل المداخيل والمصاريف وإبراء ذمة السانديك وفق القانون 18.00.',
    descriptionFr: 'Présentation du bilan financier annuel 2025/2026, vérification de l\'excédent et quitus de gestion au bureau syndic.',
    category: 'financial',
    status: 'active',
    majorityRequired: 'absolute',
    createdAt: '2026-09-01T10:00:00.000Z',
    votes: [
      { id: 'v1', userId: 'res-gh34a-01', userName: 'أحمد الإدريسي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:14:00.000Z' },
      { id: 'v2', userId: 'res-gh34a-02', userName: 'رشيد الفاسي', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:25:00.000Z' },
      { id: 'v3', userId: 'res-gh34a-03', userName: 'فاطمة بنسعيد', userRole: 'resident', apartmentNumber: '03', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T11:05:00.000Z' },
      { id: 'v4', userId: 'res-gh34a-05', userName: 'سعيد التازي', userRole: 'resident', apartmentNumber: '05', buildingCode: 'GH 34 A', choice: 'against', timestamp: '2026-09-20T11:40:00.000Z', comment: 'طلب تفاصيل إضافية حول فواتير الصيانة' },
      { id: 'v5', userId: 'res-gh34b-01', userName: 'يوسف العلمي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 B', choice: 'for', timestamp: '2026-09-20T14:10:00.000Z' },
      { id: 'v6', userId: 'res-gh34b-02', userName: 'خديجة العمراني', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 B', choice: 'abstain', timestamp: '2026-09-20T14:35:00.000Z' }
    ]
  },
  {
    id: 'res-2026-02',
    assemblyYear: 2026,
    assemblyType: 'ordinary',
    titleAr: 'اعتماد الميزانية التقديرية 2026 وتثبيت واجب الاشتراك الشهري في 150 درهم',
    titleFr: 'Approbation du budget prévisionnel 2026 et maintien de la cotisation à 150 DH',
    descriptionAr: 'المصادقة على جدول النفقات التقديرية التسييرية للسنة القادمة والاحتفاظ بمبلغ الاشتراك الشهري الإجباري في 150 درهم للشقة دون أي زيادة تثميناً لحسن التدبير.',
    descriptionFr: 'Approbation du prévisionnel de gestion et maintien des cotisations mensuelles à 150 MAD par appartement.',
    category: 'financial',
    status: 'active',
    majorityRequired: 'absolute',
    createdAt: '2026-09-01T10:15:00.000Z',
    votes: [
      { id: 'v11', userId: 'res-gh34a-01', userName: 'أحمد الإدريسي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:15:00.000Z' },
      { id: 'v12', userId: 'res-gh34a-02', userName: 'رشيد الفاسي', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:26:00.000Z' },
      { id: 'v13', userId: 'res-gh34a-03', userName: 'فاطمة بنسعيد', userRole: 'resident', apartmentNumber: '03', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T11:06:00.000Z' },
      { id: 'v14', userId: 'res-gh34b-01', userName: 'يوسف العلمي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 B', choice: 'for', timestamp: '2026-09-20T14:12:00.000Z' },
      { id: 'v15', userId: 'res-gh34b-04', userName: 'كريم الناصري', userRole: 'resident', apartmentNumber: '04', buildingCode: 'GH 34 B', choice: 'against', timestamp: '2026-09-20T15:20:00.000Z', comment: 'اقتراح تخفيض الواجب إلى 130 درهم' }
    ]
  },
  {
    id: 'res-2026-03',
    assemblyYear: 2026,
    assemblyType: 'ordinary',
    titleAr: 'تجديد عقد الحراسة والأمن وإضافة كاميرات مراقبة رقمية 4K للمرآب والمداخل',
    titleFr: 'Renouvellement du gardiennage et installation de caméras 4K',
    descriptionAr: 'تجديد التعاقد السنوي مع شركة الحراسة الحالية وتوسيع شبكة المراقبة بالفيديو بإضافة 16 كاميرا ذكية تغطي المداخل المشتركة وممرات السيارات ومرآب الإقامة.',
    descriptionFr: 'Reconduction du contrat de surveillance et pose de 16 caméras de sécurité haute définition.',
    category: 'security',
    status: 'active',
    majorityRequired: 'simple',
    createdAt: '2026-09-01T10:30:00.000Z',
    votes: [
      { id: 'v21', userId: 'res-gh34a-01', userName: 'أحمد الإدريسي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:16:00.000Z' },
      { id: 'v22', userId: 'res-gh34a-02', userName: 'رشيد الفاسي', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:28:00.000Z' },
      { id: 'v23', userId: 'res-gh34a-05', userName: 'سعيد التازي', userRole: 'resident', apartmentNumber: '05', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T11:42:00.000Z' },
      { id: 'v24', userId: 'res-gh34b-01', userName: 'يوسف العلمي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 B', choice: 'for', timestamp: '2026-09-20T14:14:00.000Z' },
      { id: 'v25', userId: 'res-gh34c-02', userName: 'حميد الزهري', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 C', choice: 'abstain', timestamp: '2026-09-20T16:05:00.000Z' }
    ]
  },
  {
    id: 'res-2026-04',
    assemblyYear: 2026,
    assemblyType: 'ordinary',
    titleAr: 'المصادقة على أشغال صباغة الواجهات وعزل الأسطح من صندوق الاحتياط',
    titleFr: 'Ravalement des façades GH34 & GH35 et étanchéité des terrasses',
    descriptionAr: 'المصادقة على العرض الأفضل تقنياً ومالياً لإعادة طلاء الواجهات الخارجية باللون المعتمد وإصلاح العوازل المائية للأسطح المشتركة بتمويل من الاحتياطي المتراكم دون مساهمة استثنائية.',
    descriptionFr: 'Travaux de réfection des peintures extérieures et étanchéité financés par le fonds de réserve.',
    category: 'works',
    status: 'active',
    majorityRequired: 'absolute',
    createdAt: '2026-09-01T10:45:00.000Z',
    votes: [
      { id: 'v31', userId: 'res-gh34a-01', userName: 'أحمد الإدريسي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:17:00.000Z' },
      { id: 'v32', userId: 'res-gh34a-03', userName: 'فاطمة بنسعيد', userRole: 'resident', apartmentNumber: '03', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T11:08:00.000Z' },
      { id: 'v33', userId: 'res-gh34b-01', userName: 'يوسف العلمي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 B', choice: 'against', timestamp: '2026-09-20T14:15:00.000Z', comment: 'الأولوية لإصلاح الإنارة الداخلية للسلالم أولاً' }
    ]
  },
  {
    id: 'res-2026-05',
    assemblyYear: 2026,
    assemblyType: 'ordinary',
    titleAr: 'تجديد الثقة في مكتب السانديك الحالي لولاية تسيير جديدة لسنتين',
    titleFr: 'Renouvellement du mandat du bureau du Syndic pour 2 ans',
    descriptionAr: 'المصادقة على تجديد الثقة في أعضاء المكتب المسير الحالي برئاسة السانديك العام لمواصلة تنفيذ برنامج التأهيل وعصرنة إدارة الإقامة وفق أحكام المادة 18 من القانون 18.00.',
    descriptionFr: 'Renouvellement de la confiance accordée au bureau exécutif pour un nouveau mandat de deux années.',
    category: 'management',
    status: 'active',
    majorityRequired: 'absolute',
    createdAt: '2026-09-01T11:00:00.000Z',
    votes: [
      { id: 'v41', userId: 'res-gh34a-01', userName: 'أحمد الإدريسي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:18:00.000Z' },
      { id: 'v42', userId: 'res-gh34a-02', userName: 'رشيد الفاسي', userRole: 'resident', apartmentNumber: '02', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T10:30:00.000Z' },
      { id: 'v43', userId: 'res-gh34a-03', userName: 'فاطمة بنسعيد', userRole: 'resident', apartmentNumber: '03', buildingCode: 'GH 34 A', choice: 'for', timestamp: '2026-09-20T11:10:00.000Z' },
      { id: 'v44', userId: 'res-gh34b-01', userName: 'يوسف العلمي', userRole: 'resident', apartmentNumber: '01', buildingCode: 'GH 34 B', choice: 'for', timestamp: '2026-09-20T14:16:00.000Z' }
    ]
  }
];
