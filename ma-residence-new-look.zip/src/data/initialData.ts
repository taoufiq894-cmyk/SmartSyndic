import { Building, Apartment, Resident, Employee, MaintenanceTicket, Payment, Expense, Visitor, Notice, User, PeriodicMaintenance, ManualMonthlyRecord, ArchiveBatch } from '../types';

// List of all 20 buildings: 10 buildings in Group A (GH 34 A to GH 43 A) and 10 buildings in Group B (GH 34 B to GH 43 B)
// Total units = 320 (319 residential apartments + 1 designated Syndic Office in GH 34 A Apt 01)
export const initialBuildings: Building[] = [
  // --- المجموعة الأولى: عمارات GH A (10 عمارات) ---
  { id: 'b-34a', code: 'GH 34 A', name: 'عمارة GH 34 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A (تحتوي على مكتب السانديك بالشقة 01 - RDC)' },
  { id: 'b-35a', code: 'GH 35 A', name: 'عمارة GH 35 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-36a', code: 'GH 36 A', name: 'عمارة GH 36 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-37a', code: 'GH 37 A', name: 'عمارة GH 37 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-38a', code: 'GH 38 A', name: 'عمارة GH 38 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-39a', code: 'GH 39 A', name: 'عمارة GH 39 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-40a', code: 'GH 40 A', name: 'عمارة GH 40 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-41a', code: 'GH 41 A', name: 'عمارة GH 41 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-42a', code: 'GH 42 A', name: 'عمارة GH 42 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },
  { id: 'b-43a', code: 'GH 43 A', name: 'عمارة GH 43 A', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة A' },

  // --- المجموعة الثانية: عمارات GH B (10 عمارات) ---
  { id: 'b-34b', code: 'GH 34 B', name: 'عمارة GH 34 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-35b', code: 'GH 35 B', name: 'عمارة GH 35 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-36b', code: 'GH 36 B', name: 'عمارة GH 36 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-37b', code: 'GH 37 B', name: 'عمارة GH 37 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-38b', code: 'GH 38 B', name: 'عمارة GH 38 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-39b', code: 'GH 39 B', name: 'عمارة GH 39 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-40b', code: 'GH 40 B', name: 'عمارة GH 40 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-41b', code: 'GH 41 B', name: 'عمارة GH 41 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-42b', code: 'GH 42 B', name: 'عمارة GH 42 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
  { id: 'b-43b', code: 'GH 43 B', name: 'عمارة GH 43 B', floors: 3, apartmentsCount: 16, managerName: '', managerPhone: '', notes: 'المجموعة B' },
];

import { generateMoroccanApartments, generateMoroccanResidents, getMoroccanApartmentData } from './moroccanResidentsData';

// Helper to generate apartments structure:
// Total lots: 320 (319 residential apartments + 1 Syndic Office apartment in GH 34 A Apt 01)
// Floor 0 (RDC / السفلي): Apt 01 to 04 (4 units)
// Floor 1 (1er / الأول): Apt 05 to 08 (4 units)
// Floor 2 (2ème / الثاني): Apt 09 to 12 (4 units)
// Floor 3 (3ème / الثالث): Apt 13 to 16 (4 units)
export const initialApartments: Apartment[] = generateMoroccanApartments(initialBuildings);

// Initial registered residents for all 320 apartments
export const initialResidents: Resident[] = generateMoroccanResidents(initialBuildings);

export const initialEmployees: Employee[] = [
  {
    id: 'emp-syn-1',
    name: 'ذ. عبد الرحيم بلقاضي',
    role: 'syndic',
    phone: '+212 661 223344',
    shift: 'دوام الإشراف والمكتب والتسيير',
    salary: 4000,
    assignedBuilding: 'مكتب السانديك - كامل الإقامة',
    status: 'active',
    cin: 'EE450123',
    startDate: '2026-01-01'
  },
  {
    id: 'emp-dep-2',
    name: 'السيد محمد المنصوري',
    role: 'deputy_syndic',
    phone: '+212 662 556677',
    shift: 'دوام المتابعة الميدانية والشكايات',
    salary: 1000,
    assignedBuilding: 'كامل الإقامة',
    status: 'active',
    cin: 'EE581902',
    startDate: '2026-01-01'
  },
  {
    id: 'emp-sec-1',
    name: 'أحمد التازي (حارس نهاري)',
    role: 'security',
    phone: '+212 650 112233',
    shift: '08:00 - 18:00',
    salary: 2500,
    assignedBuilding: 'البوابة الرئيسية',
    status: 'active',
    cin: 'AB123456',
    startDate: '2026-01-01'
  },
  {
    id: 'emp-sec-2',
    name: 'رشيد المرابط (حارس ليلي)',
    role: 'security',
    phone: '+212 654 334455',
    shift: '18:00 - 08:00',
    salary: 2500,
    assignedBuilding: 'البوابة ومحيط العمارات',
    status: 'active',
    cin: 'AB789012',
    startDate: '2026-01-01'
  },
  {
    id: 'emp-cln-1',
    name: 'فاطمة الزهراء العلوي',
    role: 'cleaning',
    phone: '+212 670 778899',
    shift: '08:30 - 14:30',
    salary: 2000,
    assignedBuilding: 'السلالم والمصاعد والمداخل',
    status: 'active',
    cin: 'CD334455',
    startDate: '2026-01-01'
  },
  {
    id: 'emp-jrd-1',
    name: 'عمر الإدريسي (بستاني وصيانة)',
    role: 'gardener',
    phone: '+212 672 990011',
    shift: '09:00 - 16:00',
    salary: 1800,
    assignedBuilding: 'المساحات الخضراء والري',
    status: 'active',
    cin: 'EF556677',
    startDate: '2026-01-01'
  }
];
export const initialMaintenanceTickets: MaintenanceTicket[] = [];
export const initialPayments: Payment[] = [];
export const initialExpenses: Expense[] = [
  {
    id: 'exp-1a',
    category: 'worker_salaries',
    title: 'أجور عمال الحراسة والأمن (حارس نهاري + حارس ليلي)',
    amount: 5000,
    buildingCode: 'ALL',
    date: '2026-05-31',
    supplier: 'أحمد التازي ورشيد المرابط (أعوان الحراسة)',
    invoiceRef: 'SAL-SEC-2026-05',
    paidBy: 'أمين المال والسانديك',
    paymentMethod: 'cash',
    notes: 'أجر شهري عن شهر 05-2026 موقع في سجل الأداء'
  },
  {
    id: 'exp-1b',
    category: 'worker_salaries',
    title: 'أجر عاملة النظافة (تنظيف السلالم والمصاعد والمداخل)',
    amount: 2000,
    buildingCode: 'ALL',
    date: '2026-05-31',
    supplier: 'فاطمة الزهراء العلوي (عاملة النظافة)',
    invoiceRef: 'SAL-CL-2026-05',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'مستحقات النظافة الشهرية لشهر 05-2026'
  },
  {
    id: 'exp-1c',
    category: 'worker_salaries',
    title: 'أجر البستاني وسقي وصيانة المساحات الخضراء',
    amount: 1800,
    buildingCode: 'ALL',
    date: '2026-05-31',
    supplier: 'عمر الإدريسي (بستاني الإقامة)',
    invoiceRef: 'SAL-JARD-2026-05',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'مستحقات العناية بالحدائق والري لشهر 05-2026'
  },
  {
    id: 'exp-2a',
    category: 'syndic_fees',
    title: 'أجرة وتعويض وكيل الاتحاد (السانديك) عن شهر 05-2026',
    amount: 4000,
    buildingCode: 'ALL',
    date: '2026-05-31',
    supplier: 'ذ. عبد الرحيم بلقاضي (وكيل الاتحاد)',
    invoiceRef: 'SYN-IND-2026-05',
    paidBy: 'مكتب إدارة الإقامة',
    paymentMethod: 'bank_transfer',
    notes: 'التعويض الشهري لوكيل الاتحاد المصادق عليه بالجمع العام (شهر 05-2026)'
  },
  {
    id: 'exp-2b',
    category: 'syndic_fees',
    title: 'أجرة وتعويض نائب وكيل الاتحاد عن شهر 05-2026',
    amount: 1000,
    buildingCode: 'ALL',
    date: '2026-05-31',
    supplier: 'السيد محمد المنصوري (نائب الوكيل)',
    invoiceRef: 'DEP-SYN-2026-05',
    paidBy: 'مكتب إدارة الإقامة',
    paymentMethod: 'bank_transfer',
    notes: 'التعويض الشهري لنائب وكيل الاتحاد المعتمد بالجمع العام (شهر 05-2026)'
  },
  {
    id: 'exp-3',
    category: 'cleaning_supplies',
    title: 'فاتورة مواد ومساحيق النظافة ومطهرات السلالم والبالوعات',
    amount: 1450,
    buildingCode: 'ALL',
    date: '2026-05-15',
    supplier: 'شركة المنظفات والتطهير الحديثة',
    invoiceRef: 'FAC-NET-502',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'جافيل، سانيكروا، صابون، أكياس قمامة كبيرة، مماسح'
  },
  {
    id: 'exp-4',
    category: 'electrical_supplies',
    title: 'فاتورة شراء مصابيح LED موفرة، كابلات ومؤقتات إنارة السلالم',
    amount: 1200,
    buildingCode: 'ALL',
    date: '2026-05-18',
    supplier: 'محلات التجهيز الكهربائي العام',
    invoiceRef: 'FAC-ELEC-410',
    paidBy: 'المكلف بالصيانة',
    paymentMethod: 'cash',
    notes: 'تغيير 25 مصباح LED ومؤقت دقيقة للسلالم'
  },
  {
    id: 'exp-5',
    category: 'hardware_droguerie',
    title: 'فاتورة مقتنيات العقاقير: أقفال المداخل، صباغة، مفصلات ومسامير',
    amount: 850,
    buildingCode: 'ALL',
    date: '2026-05-20',
    supplier: 'دروكري النجاح الكبير',
    invoiceRef: 'DROG-7741',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'إصلاح قفل الباب الرئيسي لعمارة GH34 وصيانة المفاصل'
  },
  {
    id: 'exp-6',
    category: 'building_materials',
    title: 'فاتورة مواد البناء: إسمنت، رمل وترميم أرضية المداخل ومجاري المطر',
    amount: 1600,
    buildingCode: 'ALL',
    date: '2026-05-22',
    supplier: 'مستودع مواد البناء الأطلس',
    invoiceRef: 'BAT-3091',
    paidBy: 'السانديك',
    paymentMethod: 'check',
    notes: 'أشغال سد الثقوب وصيانة قنوات تصريف مياه الأمطار'
  },
  {
    id: 'exp-7',
    category: 'irrigation_tools',
    title: 'فاتورة أدوات السقي: خراطيم المياه، فوهات الرش ومستلزمات ري الحدائق',
    amount: 950,
    buildingCode: 'ALL',
    date: '2026-05-24',
    supplier: 'مؤسسة التجهيز الفلاحي والسقي',
    invoiceRef: 'IRR-5520',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'شراء خرطوم ماء 50 متر ومرشات دوارة'
  },
  {
    id: 'exp-8',
    category: 'office_stationery',
    title: 'فاتورة مكتبيات: طباعة وصولات الأداء، سجلات الإدارة، أوراق وحبر طابعة',
    amount: 650,
    buildingCode: 'ALL',
    date: '2026-05-25',
    supplier: 'مكتبة ومطبعة مراكش',
    invoiceRef: 'BUR-1049',
    paidBy: 'كاتب السانديك',
    paymentMethod: 'cash',
    notes: 'دفاتر وصولات مرقمة، حبر طابعة، أظرفة بريدية'
  },
  {
    id: 'exp-9',
    category: 'lawyer_fees',
    title: 'أتعاب المحامي لمتابعة ملفات تحصيل مستحقات السانديك المتأخرة',
    amount: 2500,
    buildingCode: 'ALL',
    date: '2026-05-26',
    supplier: 'مكتب الأستاذ المحامي بهيئة مراكش',
    invoiceRef: 'AVO-2026-05',
    paidBy: 'السانديك',
    paymentMethod: 'bank_transfer',
    notes: 'ملفات الاستدعاء والأمر بالأداء لـ 4 ملاك متخلفين'
  },
  {
    id: 'exp-10',
    category: 'bailiff_fees',
    title: 'أتعاب مفوض قضائي لتبليغ الإنذارات الرسمية للممتنعين عن الأداء',
    amount: 1800,
    buildingCode: 'ALL',
    date: '2026-05-28',
    supplier: 'مكتب المفوض القضائي لدى المحكمة الابتدائية',
    invoiceRef: 'HUIS-993',
    paidBy: 'السانديك',
    paymentMethod: 'cash',
    notes: 'تبليغ 6 إنذارات رسمية مع الإشعار بالتوصل'
  },
  {
    id: 'exp-11',
    category: 'electricity',
    title: 'فاتورة كهرباء المرافق المشتركة والسلالم والمصاعد (ONEE)',
    amount: 2450,
    buildingCode: 'ALL',
    date: '2026-05-10',
    supplier: 'المكتب الوطني للكهرباء والماء الصالح للشرب (ONEE)',
    invoiceRef: 'FAC-ONEE-884321',
    paidBy: 'أمين المال',
    paymentMethod: 'bank_transfer',
    notes: 'استهلاك شهر ماي لعداد المرافق المشتركة'
  },
  {
    id: 'exp-12',
    category: 'water',
    title: 'فاتورة استهلاك ماء المرافق المشتركة ومضخات السقي والآبار',
    amount: 980,
    buildingCode: 'ALL',
    date: '2026-05-12',
    supplier: 'الوكالة المستقلة لتوزيع الماء والكهرباء',
    invoiceRef: 'FAC-RADE-55102',
    paidBy: 'أمين المال',
    paymentMethod: 'bank_transfer',
    notes: 'استهلاك عداد سقي الحدائق وغسيل السلالم والممرات عن شهر ماي'
  }
];
export const initialVisitors: Visitor[] = [];
export const initialNotices: Notice[] = [];

export const initialUsers: User[] = [
  { 
    id: 'u-1', 
    username: 'syndic', 
    name: 'مكتب السانديك', 
    role: 'syndic', 
    password: 'admin@2026', 
    phone: '',
    email: 'syndic@almarjane.ma'
  }
];

// Initial pre-configured periodic maintenance contracts & schedules for Résidence Al Morjane
export const initialPeriodicMaintenances: PeriodicMaintenance[] = [
  {
    id: 'pm-1',
    title: 'فحص وصيانة اللوحات الكهربائية المشتركة وأنظمة الإنارة التلقائية',
    category: 'lighting',
    buildingCode: 'ALL',
    apartmentOrArea: 'اللوحات الكهربائية الرئيسية للمداخل',
    frequency: 'monthly',
    nextDueDate: '2026-08-27',
    lastCompletedDate: '2026-07-27',
    remindDaysBefore: 5,
    providerOrTechnician: 'شركة الكهرباء والتقنيات العامة',
    providerPhone: '+212 522-334455',
    estimatedCost: 1200,
    notes: 'الفحص التقني الشهري للوحات التوزيع وقواطع الحماية الكهربائية ومؤقتات الإنارة',
    isActive: true,
    createdAt: '2026-01-15 10:00',
    history: []
  },
  {
    id: 'pm-2',
    title: 'مراجعة وضبط مضخات ضغط المياه (Surpresseurs) وغسيل الخزان',
    category: 'plumbing',
    buildingCode: 'ALL',
    apartmentOrArea: 'محطة الضخ المركزية والخزان الأرضي',
    frequency: 'quarterly',
    nextDueDate: '2026-08-29',
    lastCompletedDate: '2026-05-29',
    remindDaysBefore: 7,
    providerOrTechnician: 'مؤسسة الهيدروليك العامة',
    providerPhone: '+212 661-889900',
    estimatedCost: 2200,
    notes: 'فحص بالونات الضغط (Vases d\'expansion) وتنظيف فلاتر المدخل الرئيسي',
    isActive: true,
    createdAt: '2026-02-01 09:30',
    history: []
  },
  {
    id: 'pm-3',
    title: 'الفحص السنوي وتعبئة طفايات الحريق وخراطيم السلامة RIA',
    category: 'security',
    buildingCode: 'ALL',
    apartmentOrArea: 'ممرات الطوابق ومرائب السيارات',
    frequency: 'annual',
    nextDueDate: '2026-09-10',
    lastCompletedDate: '2025-09-10',
    remindDaysBefore: 15,
    providerOrTechnician: 'شركة الحماية والوقاية من الحرائق',
    providerPhone: '+212 522-998877',
    estimatedCost: 3500,
    notes: 'إعادة تعبئة البودرة وغاز CO2 لجميع طفايات العمارات العشرين مع تجديد الملصقات',
    isActive: true,
    createdAt: '2025-09-10 11:00',
    history: []
  },
  {
    id: 'pm-4',
    title: 'تطهير شامل ومكافحة الحشرات والقوارض في المداخل والبالوعات',
    category: 'cleaning',
    buildingCode: 'ALL',
    apartmentOrArea: 'غرف النفايات والمجاري ومحيط العمارات',
    frequency: 'biannual',
    nextDueDate: '2026-08-23',
    lastCompletedDate: '2026-02-23',
    remindDaysBefore: 7,
    providerOrTechnician: 'شركة النظافة والبيئة',
    providerPhone: '+212 662-112233',
    estimatedCost: 1800,
    notes: 'رش المبيدات المرخصة بيئياً في مجاري التصريف ومحيط حاويات القمامة',
    isActive: true,
    createdAt: '2026-02-23 08:00',
    history: []
  }
];

export const initialDailyChecklistItems: any[] = [
  {
    id: 'chk-1',
    title: 'مراقبة أبواب المداخل الرئيسية والأقفال والإنتركم وسلامة الممرات',
    category: 'security',
    area: 'بهو المداخل والممرات المشتركة',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-2',
    title: 'فحص ضغط مضخات الماء ومستوى امتلاء الخزانات الرئيسية',
    category: 'plumbing',
    area: 'غرفة المضخات والخزانات السفلية',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-3',
    title: 'معاينة إنارة المداخل والسلالم وحساسات الحركة (Minuterie)',
    category: 'lighting',
    area: 'الممرات والمداخل المشتركة',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-4',
    title: 'تفقد نظافة بهو المداخل، السلالم، وممرات العمارات',
    category: 'cleaning',
    area: 'المداخل والدرج',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-5',
    title: 'مراقبة إفراغ وتنظيف غرف وحاويات القمامة المنزلية',
    category: 'cleaning',
    area: 'غرف وحاويات النفايات',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-6',
    title: 'فحص البوابات الإلكترونية للمرآب وكاميرات المراقبة الأمنية',
    category: 'security',
    area: 'مرآب السيارات والبوابة الرئيسية',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-7',
    title: 'التأكد من إغلاق أبواب الأسطح وخلو مجاري تصريف المطر',
    category: 'plumbing',
    area: 'الأسطح ومجاري مياه الأمطار',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  },
  {
    id: 'chk-8',
    title: 'فحص إنارة محيط الإقامة والحدائق والمسالك الخارجية',
    category: 'lighting',
    area: 'المساحات الخضراء والحديقة',
    buildingCode: 'ALL',
    isCompleted: false,
    notes: '',
    hasIssue: false
  }
];

export const initialDailyMaintenanceLogs: any[] = [];

// السجل المالي التوثيقي التأسيسي للأشهر السابقة (ابتداء من 04/2025)
// يتضمن الترحيل التراكمي للرصيد المنقول، مجموع المداخيل والمصاريف والفائض الإيجابي
export const initialManualMonthlyRecords: ManualMonthlyRecord[] = [
  {
    id: 'rec-2025-04',
    monthKey: '2025-04',
    totalIncome: 42000,
    totalExpenses: 28450,
    openingBalance: 0,
    closingBalance: 13550,
    breakdownIncome: {
      regularFees: 38000,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4200,
      maintenance: 8500,
      supplies: 3950,
      otherExpenses: 3000
    },
    notes: 'انطلاق مهام وكيل الاتحاد الجديد - إقامة المرجان وسداد أجور الحراسة والنظافة وصيانة المضخات المشتركة',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-04-30T18:00:00.000Z'
  },
  {
    id: 'rec-2025-05',
    monthKey: '2025-05',
    totalIncome: 44500,
    totalExpenses: 29200,
    openingBalance: 13550,
    closingBalance: 28850,
    breakdownIncome: {
      regularFees: 40000,
      priorArrears: 4500
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4600,
      maintenance: 9000,
      supplies: 3800,
      otherExpenses: 3000
    },
    notes: 'استخلاص واجبات ماي وسداد مستحقات الإنارة وصيانة المساحات الخضراء والري',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-05-31T18:00:00.000Z'
  },
  {
    id: 'rec-2025-06',
    monthKey: '2025-06',
    totalIncome: 41200,
    totalExpenses: 27900,
    openingBalance: 28850,
    closingBalance: 42150,
    breakdownIncome: {
      regularFees: 38500,
      priorArrears: 2700
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4100,
      maintenance: 7500,
      supplies: 4500,
      otherExpenses: 3000
    },
    notes: 'سداد أجور المستخدمين وفواتير مواد النظافة وتطهير قنوات الصرف الصحي',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-06-30T18:00:00.000Z'
  },
  {
    id: 'rec-2025-07',
    monthKey: '2025-07',
    totalIncome: 45000,
    totalExpenses: 31500,
    openingBalance: 42150,
    closingBalance: 55650,
    breakdownIncome: {
      regularFees: 41000,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 5400,
      maintenance: 10200,
      supplies: 4100,
      otherExpenses: 3000
    },
    notes: 'صيانة إضافية لشبكة المياه ومضخات الآبار لتفادي انقطاع الماء صيفاً',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-07-31T18:00:00.000Z'
  },
  {
    id: 'rec-2025-08',
    monthKey: '2025-08',
    totalIncome: 46200,
    totalExpenses: 30800,
    openingBalance: 55650,
    closingBalance: 71050,
    breakdownIncome: {
      regularFees: 42000,
      priorArrears: 4200
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 5200,
      maintenance: 9800,
      supplies: 4000,
      otherExpenses: 3000
    },
    notes: 'استخلاص مبالغ متأخرة وسداد تكاليف صيانة الإنارة الخارجية وكاميرات المراقبة',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-08-31T18:00:00.000Z'
  },
  {
    id: 'rec-2025-09',
    monthKey: '2025-09',
    totalIncome: 43800,
    totalExpenses: 29600,
    openingBalance: 71050,
    closingBalance: 85250,
    breakdownIncome: {
      regularFees: 39500,
      priorArrears: 4300
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4300,
      maintenance: 8900,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'صيانة أقفال البوابات وتجديد معدات النظافة مع بداية الدخول المدرسي',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-09-30T18:00:00.000Z'
  },
  {
    id: 'rec-2025-10',
    monthKey: '2025-10',
    totalIncome: 42600,
    totalExpenses: 28900,
    openingBalance: 85250,
    closingBalance: 98950,
    breakdownIncome: {
      regularFees: 39000,
      priorArrears: 3600
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4400,
      maintenance: 8100,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'تنظيف بالوعات مياه الأمطار والأسطح تحسباً لفصل الشتاء',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-10-31T18:00:00.000Z'
  },
  {
    id: 'rec-2025-11',
    monthKey: '2025-11',
    totalIncome: 44000,
    totalExpenses: 30100,
    openingBalance: 98950,
    closingBalance: 112850,
    breakdownIncome: {
      regularFees: 40500,
      priorArrears: 3500
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4500,
      maintenance: 9200,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'إصلاح تسربات قنوات الصرف الخارجي وسداد مصاريف الحراسة والنظافة',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-11-30T18:00:00.000Z'
  },
  {
    id: 'rec-2025-12',
    monthKey: '2025-12',
    totalIncome: 47500,
    totalExpenses: 32400,
    openingBalance: 112850,
    closingBalance: 127950,
    breakdownIncome: {
      regularFees: 42500,
      priorArrears: 5000
    },
    breakdownExpenses: {
      salaries: 9800,
      utilities: 4800,
      maintenance: 10200,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'إقفال السنة المالية 2025 بفائض تراكمي إيجابي ممتاز قدره 127,950 درهم',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2025-12-31T18:00:00.000Z'
  },
  {
    id: 'rec-2026-01',
    monthKey: '2026-01',
    totalIncome: 45200,
    totalExpenses: 29800,
    openingBalance: 127950,
    closingBalance: 143350,
    breakdownIncome: {
      regularFees: 41000,
      priorArrears: 4200
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4600,
      maintenance: 8800,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'افتتاح السنة المالية 2026 وترحيل الرصيد الإيجابي السابق',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-01-31T18:00:00.000Z'
  },
  {
    id: 'rec-2026-02',
    monthKey: '2026-02',
    totalIncome: 44100,
    totalExpenses: 28700,
    openingBalance: 143350,
    closingBalance: 158750,
    breakdownIncome: {
      regularFees: 40000,
      priorArrears: 4100
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4200,
      maintenance: 8100,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'سداد الأجور وصيانة أعطال الإنارة وتثبيت أجهزة التوقيت بالسلالم',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-02-28T18:00:00.000Z'
  },
  {
    id: 'rec-2026-03',
    monthKey: '2026-03',
    totalIncome: 46000,
    totalExpenses: 30500,
    openingBalance: 158750,
    closingBalance: 174250,
    breakdownIncome: {
      regularFees: 42000,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4500,
      maintenance: 9600,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'أشغال صيانة الحدائق وتقليم الأشجار وسداد واجبات التسيير',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-03-31T18:00:00.000Z'
  },
  {
    id: 'rec-2026-04',
    monthKey: '2026-04',
    totalIncome: 43500,
    totalExpenses: 29100,
    openingBalance: 174250,
    closingBalance: 188650,
    breakdownIncome: {
      regularFees: 39500,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 8800,
      utilities: 4300,
      maintenance: 8400,
      supplies: 4600,
      otherExpenses: 3000
    },
    notes: 'مرور سنة كاملة على الإدارة الجديدة مع استقرار الحساب المالي في فائض متواصل',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-04-30T18:00:00.000Z'
  },
  {
    id: 'rec-2026-05',
    monthKey: '2026-05',
    totalIncome: 49674,
    totalExpenses: 37087,
    openingBalance: 188650,
    closingBalance: 201237,
    breakdownIncome: {
      regularFees: 45674,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 12800,
      utilities: 4330,
      maintenance: 10450,
      supplies: 6507,
      otherExpenses: 3000
    },
    notes: 'شهر مايو 2026: سداد أجور الحراسة والنظافة والبستاني وأتعاب السانديك (4000 DH) ومستلزمات الصيانة والكهرباء والماء',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-05-31T18:00:00.000Z'
  },
  {
    id: 'rec-2026-06',
    monthKey: '2026-06',
    totalIncome: 48000,
    totalExpenses: 21880,
    openingBalance: 201237,
    closingBalance: 227357,
    breakdownIncome: {
      regularFees: 44000,
      priorArrears: 4000
    },
    breakdownExpenses: {
      salaries: 12800,
      utilities: 4330,
      maintenance: 1800,
      supplies: 1950,
      otherExpenses: 1000
    },
    notes: 'شهر يونيو 2026: استمرار الفائض الإيجابي وترحيل رصيد التحفة (201.237 DH)',
    recordedBy: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
    updatedAt: '2026-06-30T18:00:00.000Z'
  }
];


