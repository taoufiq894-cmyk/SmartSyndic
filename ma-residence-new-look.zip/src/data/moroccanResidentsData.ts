import { Apartment, Resident } from '../types';

// Authentic Moroccan First Names (Men & Women)
const MOROCCAN_FIRST_NAMES = [
  'محمد', 'أحمد', 'يوسف', 'فاطمة الزهراء', 'عبد الرحيم', 'حسن', 'رشيد', 'مريم',
  'نادية', 'خديجة', 'هشام', 'كريم', 'عمر', 'إبراهيم', 'مصطفى', 'عائشة',
  'سميرة', 'ياسين', 'أمين', 'عبد الله', 'ليلى', 'حنان', 'طارق', 'حمزة',
  'سناء', 'بشرى', 'عبد العزيز', 'سعيد', 'إدريس', 'نجاة', 'سكينة', 'مهدي',
  'رضوان', 'كوثر', 'أنس', 'رجاء', 'زكرياء', 'سفيان', 'منية', 'توفيق',
  'عزيز', 'نبيل', 'بثينة', 'إيمان', 'حليمة', 'فؤاد', 'جمال', 'لطيفة',
  'بدر', 'سهام', 'زينب', 'صلاح الدين', 'خالد', 'وفاء', 'عادل', 'سلوى',
  'كمال', 'غيثة', 'سليمان', 'حسناء', 'منير', 'أسماء', 'عبد الإله', 'سارة'
];

// Authentic Moroccan Surnames / Family Names
const MOROCCAN_LAST_NAMES = [
  'العلمي', 'التازي', 'بنجلون', 'الإدريسي', 'الفاسي', 'المنصوري', 'المرابط', 'بلقاضي',
  'السوسي', 'الشريف', 'الودغيري', 'العمراني', 'برادة', 'بناني', 'الصقلي', 'الحسني',
  'الكتاني', 'السلاوي', 'اليعقوبي', 'الصنهاجي', 'الفيلالي', 'الشرايبي', 'القادري', 'البقالي',
  'أمزيان', 'بنونة', 'الوزاني', 'الخمليشي', 'زنيبر', 'البوزيدي', 'العراقي', 'بنسودة',
  'الرحماني', 'شفيق', 'الغالي', 'العلوي', 'لمراني', 'صابر', 'بنسليمان', 'الهاشمي',
  'المودن', 'بوشعيب', 'أيت بلعربي', 'الناصري', 'الريفي', 'أمزيل', 'أكنوز', 'الزروالي',
  'المهداوي', 'بنحيدة', 'الدرقاوي', 'بوعبيد', 'الركراكي', 'السملالي', 'التلمساني', 'العوفير'
];

// Moroccan Cities CIN Prefixes
const CIN_PREFIXES = ['EE', 'BK', 'CD', 'AE', 'BE', 'AA', 'BH', 'BL', 'BW', 'AD', 'AY', 'WA'];

export const OLD_MOCK_NAMES_SET = new Set<string>();

export function isOldMockResidentName(name: string | null | undefined): boolean {
  if (!name) return false;
  const n = name.trim();
  // Protected official system titles
  if (n === 'مكتب إدارة وسانديك إقامة المرجان' || n.includes('وكيل السانديك') || n.includes('أيت بلعربي')) {
    return false;
  }
  // Only detect obvious dummy test tokens
  if (n.includes('تجريبي') || n.toLowerCase().includes('test_owner') || n.toLowerCase().includes('dummy_mock')) {
    return true;
  }
  return false;
}

interface ResidentInfo {
  fullName: string;
  phone: string;
  cin: string;
  email: string;
  isRented: boolean;
  residentName: string;
  residentPhone: string;
}

// Deterministic hash to guarantee stable Moroccan identities for each (Building, Apartment)
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

export function getMoroccanApartmentData(buildingCode: string, aptNum: string): ResidentInfo {
  const cleanBld = buildingCode.replace(/\s+/g, ' ').trim().toUpperCase();
  const cleanApt = String(aptNum).padStart(2, '0');

  // Special Designated Syndic Office: GH 34 A Apartment 01
  if (cleanBld === 'GH 34 A' && cleanApt === '01') {
    return {
      fullName: 'مكتب إدارة وسانديك إقامة المرجان',
      phone: '+212 661 223344',
      cin: 'EE450123',
      email: 'syndic.morjane@residence.ma',
      isRented: false,
      residentName: 'ذ. عبد الرحيم بلقاضي (وكيل السانديك)',
      residentPhone: '+212 661 223344'
    };
  }

  // Specific high-profile residents for precision
  if (cleanBld === 'GH 38 B' && cleanApt === '03') {
    return {
      fullName: 'السيد محمد أيت بلعربي',
      phone: '+212 661 380300',
      cin: 'EE789303',
      email: 'm.aitbelarbit@residence.ma',
      isRented: false,
      residentName: 'السيد محمد أيت بلعربي',
      residentPhone: '+212 661 380300'
    };
  }

  // Official Authentic Moroccan Co-Owner for each residential lot
  const seed = hashString(`${cleanBld}-apt-${cleanApt}`);
  const femaleNames = ['فاطمة الزهراء', 'مريم', 'نادية', 'خديجة', 'عائشة', 'سميرة', 'ليلى', 'حنان', 'سناء', 'بشرى', 'نجاة', 'سكينة', 'كوثر', 'رجاء', 'منية', 'بثينة', 'إيمان', 'حليمة', 'لطيفة', 'سهام', 'زينب', 'وفاء', 'سلوى', 'غيثة', 'حسناء', 'أسماء', 'سارة'];
  const firstName = MOROCCAN_FIRST_NAMES[seed % MOROCCAN_FIRST_NAMES.length];
  const lastName = MOROCCAN_LAST_NAMES[((seed >> 3) + cleanApt.charCodeAt(cleanApt.length - 1)) % MOROCCAN_LAST_NAMES.length];
  const titleSeed = (seed >> 5) % 10;
  let title = 'السيد ';
  if (femaleNames.includes(firstName)) {
    title = titleSeed === 0 ? 'الحاجة ' : 'السيدة ';
  } else {
    if (titleSeed === 0) title = 'الحاج ';
    else if (titleSeed === 1) title = 'ذ. ';
    else title = 'السيد ';
  }

  const fullName = `${title}${firstName} ${lastName}`;
  const phone = `+212 6${String(60 + (seed % 39)).padStart(2, '0')} ${String((seed >> 4) % 900 + 100).slice(0, 2)}${String((seed >> 8) % 90 + 10)} ${String((seed >> 12) % 90 + 10)}`;
  const cinPrefix = CIN_PREFIXES[seed % CIN_PREFIXES.length];
  const cin = `${cinPrefix}${String(100000 + (seed % 899999))}`;
  const email = `contact.${cleanBld.toLowerCase().replace(/[\s\-_]/g, '')}.apt${cleanApt}@morjane.ma`;

  return {
    fullName,
    phone,
    cin,
    email,
    isRented: false,
    residentName: fullName,
    residentPhone: phone
  };
}

const DEFAULT_BUILDING_LIST = [
  'GH 34 A', 'GH 35 A', 'GH 36 A', 'GH 37 A', 'GH 38 A', 'GH 39 A', 'GH 40 A', 'GH 41 A', 'GH 42 A', 'GH 43 A',
  'GH 34 B', 'GH 35 B', 'GH 36 B', 'GH 37 B', 'GH 38 B', 'GH 39 B', 'GH 40 B', 'GH 41 B', 'GH 42 B', 'GH 43 B'
].map(code => ({ code, id: `b-${code.toLowerCase().replace(/\s+/g, '')}` }));

// Generate all 320 apartments with official co-owners list
export function generateMoroccanApartments(buildings?: { code: string; id?: string }[]): Apartment[] {
  const list: Apartment[] = [];
  const targetBuildings = (buildings && buildings.length > 0) ? buildings : DEFAULT_BUILDING_LIST;

  targetBuildings.forEach(bld => {
    const cleanBld = bld.code.replace(/\s+/g, ' ').trim().toUpperCase();
    for (let i = 1; i <= 16; i++) {
      const aptNum = String(i).padStart(2, '0');
      const floor = Math.floor((i - 1) / 4);
      const codeClean = cleanBld.toLowerCase().replace(/\s+/g, '-');
      const isOffice = cleanBld === 'GH 34 A' && aptNum === '01';
      const mData = getMoroccanApartmentData(cleanBld, aptNum);

      list.push({
        id: `apt-${codeClean}-${aptNum}`,
        number: aptNum,
        buildingCode: cleanBld,
        floor: floor,
        ownerName: mData.fullName || '',
        ownerPhone: mData.phone || '',
        ownerCin: mData.cin || '',
        ownerEmail: mData.email || '',
        residentName: mData.residentName || '',
        residentPhone: mData.residentPhone || '',
        isRented: mData.isRented || false,
        status: 'occupied',
        monthlyFee: isOffice ? 0 : 150,
        balanceDue: 0,
        isSyndicOffice: isOffice,
        notes: isOffice ? 'مكتب إدارة وسانديك إقامة المرجان' : undefined
      });
    }
  });

  return list;
}

// Initial registered residents: All 320 official co-owners registered in master directory
export function generateMoroccanResidents(buildings?: { code: string }[]): Resident[] {
  const resList: Resident[] = [];
  const targetBuildings = (buildings && buildings.length > 0) ? buildings : DEFAULT_BUILDING_LIST;

  targetBuildings.forEach(bld => {
    const cleanBld = bld.code.replace(/\s+/g, ' ').trim().toUpperCase();
    for (let i = 1; i <= 16; i++) {
      const aptNum = String(i).padStart(2, '0');
      const codeClean = cleanBld.toLowerCase().replace(/\s+/g, '-');
      const data = getMoroccanApartmentData(cleanBld, aptNum);
      const isOffice = cleanBld === 'GH 34 A' && aptNum === '01';

      resList.push({
        id: `res-${codeClean}-${aptNum}`,
        fullName: data.fullName,
        type: 'owner',
        buildingCode: cleanBld,
        apartmentNumber: aptNum,
        phone: data.phone,
        email: data.email,
        cin: data.cin,
        familyMembersCount: isOffice ? 1 : ((hashString(`${codeClean}-${aptNum}`) % 4) + 2),
        entryDate: '2026-01-01'
      });
    }
  });

  return resList;
}

// Helper to reliably detect generic placeholder names like "مالك شقة 03" or "Propriétaire Appt"
export function isGenericPlaceholderName(name: string | null | undefined): boolean {
  if (!name) return true;
  const n = name.trim().toLowerCase();
  if (n.length < 2) return true;
  const exactPlaceholders = [
    'مالك', 'المالك', 'ساكن', 'الساكن', 'مكتري', 'المكتري', 'صاحب الشقة',
    'غير مسجل', 'غير محدد', 'بدون اسم', '-', '--', '---',
    'proprietaire', 'propriétaire', 'resident', 'résident', 'locataire',
    'non renseigne', 'non renseigné', 'inconnu', 'a definir', 'à définir'
  ];
  if (exactPlaceholders.includes(n)) return true;
  if (/^(?:مالك|المالك|ساكن|الساكن|مكتري)\s+(?:شقة|الشقة|رقم|عمارة)?\s*\d+$/i.test(n)) return true;
  if (/^(?:propri[eé]taire|r[eé]sident|locataire)\s+(?:appt|appartement|n°|no)?\s*\d+$/i.test(n)) return true;
  return false;
}

