import { Payment, Expense } from '../types';
import { initialExpenses } from './initialData';

export const MONTHS_FROM_MAY_2026 = [
  '2026-05',
  '2026-06',
  '2026-07',
  '2026-08',
  '2026-09'
] as const;

// Deterministic pseudo-random helper for consistent generation
function pseudoRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

// Authentic Moroccan resident names pool for receipt payers
const MOROCCAN_PAYER_NAMES = [
  'السيد محمد العلمي', 'السيد أحمد التازي', 'السيدة فاطمة الزهراء العلوي', 'السيد يوسف الإدريسي',
  'السيد عبد الرحيم بلقاضي', 'السيد رشيد المرابط', 'السيدة مريم الفاسي', 'السيد هشام المنصوري',
  'السيدة خديجة بنجلون', 'السيد كريم السوسي', 'السيد عمر الشريف', 'السيدة نادية الصقلي',
  'السيد إبراهيم الودغيري', 'السيد مصطفى برادة', 'السيدة سميرة بناني', 'السيد ياسين الكتاني',
  'السيد أمين السلاوي', 'السيدة ليلى اليعقوبي', 'السيد عبد الله الصنهاجي', 'السيد طارق الفيلالي',
  'السيدة حنان الشرايبي', 'السيد حمزة القادري', 'السيدة سناء البقالي', 'السيد عبد العزيز أمزيان',
  'السيد سعيد بنونة', 'السيدة بشرى الوزاني', 'السيد إدريس زنيبر', 'السيدة نجاة العراقي',
  'السيد مهدي بنسودة', 'السيد رضوان شفيق', 'السيدة كوثر الغالي', 'السيد أنس لمراني',
  'السيدة رجاء صابر', 'السيد زكرياء بنسليمان', 'السيد سفيان الهاشمي', 'السيدة منية المودن',
  'السيد توفيق بوشعيب', 'السيد عزيز الناصري', 'السيد نبيل الريفي', 'السيدة بثينة أمزيل',
  'السيدة إيمان أكنوز', 'السيد فؤاد الزروالي', 'السيد جمال المهداوي', 'السيدة لطيفة بنحيدة',
  'السيد بدر الدرقاوي', 'السيدة سهام بوعبيد', 'السيدة زينب الركراكي', 'السيد صلاح الدين السملالي',
  'السيد خالد التلمساني', 'السيدة وفاء العوفير', 'السيد عادل الصابر', 'السيدة سلوى المرابط'
];

/**
 * Generate authentic expenses for months from May 2026 to September 2026
 * Each month has a realistic breakdown of staff salaries, utilities, supplies, and maintenance.
 */
export function generateMonthlySurplusExpenses(): Expense[] {
  const allExpenses: Expense[] = [];

  // May 2026: Include official initialExpenses (total: 26,230 DH)
  allExpenses.push(...initialExpenses);

  // Template for recurrent monthly expenses for June, July, August, September
  const recurrentMonths = [
    {
      monthKey: '2026-06',
      electricity: 3150,
      water: 1180,
      cleaningSupplies: 1350,
      maintenance: 1800,
      stationery: 600,
      maintTitle: 'فاتورة صيانة محركات ومضخات الماء والأقفال الرئيسية',
      maintRef: 'FAC-PUMP-601'
    },
    {
      monthKey: '2026-07',
      electricity: 3380,
      water: 1290,
      cleaningSupplies: 1420,
      maintenance: 1950,
      stationery: 550,
      maintTitle: 'فاتورة صيانة شبكة الإنارة العامة وأجهزة التحكم التلقائي',
      maintRef: 'FAC-ELEC-702'
    },
    {
      monthKey: '2026-08',
      electricity: 3450,
      water: 1350,
      cleaningSupplies: 1380,
      maintenance: 1850,
      stationery: 580,
      maintTitle: 'فاتورة صيانة قنوات تصريف المياه والصباغة الوقائية للمداخل',
      maintRef: 'FAC-PLUMB-803'
    },
    {
      monthKey: '2026-09',
      electricity: 3100,
      water: 1150,
      cleaningSupplies: 1250,
      maintenance: 1450,
      stationery: 650,
      maintTitle: 'فاتورة صيانة الإنتركم وأقفال بوابات العمارات',
      maintRef: 'FAC-INTER-904'
    }
  ];

  recurrentMonths.forEach(({ monthKey, electricity, water, cleaningSupplies, maintenance, stationery, maintTitle, maintRef }) => {
    // 1. Guard Salaries (5,000 DH)
    allExpenses.push({
      id: `exp-sec-${monthKey}`,
      category: 'worker_salaries',
      title: `أجور عمال الحراسة والأمن (حارس نهاري + حارس ليلي) عن شهر ${monthKey}`,
      amount: 5000,
      buildingCode: 'ALL',
      date: `${monthKey}-30`,
      supplier: 'أحمد التازي ورشيد المرابط (أعوان الحراسة)',
      invoiceRef: `SAL-SEC-${monthKey}`,
      paidBy: 'أمين المال والسانديك',
      paymentMethod: 'cash',
      notes: `أجر شهري عن شهر ${monthKey} موقع في سجل أجور الحراسة`
    });

    // 2. Cleaner Salary (2,000 DH)
    allExpenses.push({
      id: `exp-cln-${monthKey}`,
      category: 'worker_salaries',
      title: `أجر عاملة النظافة (تنظيف السلالم والمداخل والمصاعد) عن شهر ${monthKey}`,
      amount: 2000,
      buildingCode: 'ALL',
      date: `${monthKey}-30`,
      supplier: 'فاطمة الزهراء العلوي (عاملة النظافة)',
      invoiceRef: `SAL-CL-${monthKey}`,
      paidBy: 'السانديك',
      paymentMethod: 'cash',
      notes: `مستحقات النظافة الشهرية لشهر ${monthKey}`
    });

    // 3. Gardener Salary (1,800 DH)
    allExpenses.push({
      id: `exp-jrd-${monthKey}`,
      category: 'worker_salaries',
      title: `أجر البستاني وسقي وصيانة المساحات الخضراء عن شهر ${monthKey}`,
      amount: 1800,
      buildingCode: 'ALL',
      date: `${monthKey}-30`,
      supplier: 'عمر الإدريسي (بستاني الإقامة)',
      invoiceRef: `SAL-JARD-${monthKey}`,
      paidBy: 'السانديك',
      paymentMethod: 'cash',
      notes: `مستحقات العناية بالحدائق والري لشهر ${monthKey}`
    });

    // 4. Syndic Remuneration (4,000 DH)
    allExpenses.push({
      id: `exp-syn-${monthKey}`,
      category: 'syndic_fees',
      title: `أجرة وتعويض وكيل الاتحاد (السانديك) عن شهر ${monthKey}`,
      amount: 4000,
      buildingCode: 'ALL',
      date: `${monthKey}-30`,
      supplier: 'ذ. عبد الرحيم بلقاضي (وكيل الاتحاد)',
      invoiceRef: `SYN-IND-${monthKey}`,
      paidBy: 'مكتب إدارة الإقامة',
      paymentMethod: 'bank_transfer',
      notes: `التعويض الشهري المعتمد بالجمع العام لشهر ${monthKey}`
    });

    // 5. Deputy Syndic Remuneration (1,000 DH)
    allExpenses.push({
      id: `exp-depsyn-${monthKey}`,
      category: 'syndic_fees',
      title: `أجرة وتعويض نائب وكيل الاتحاد عن شهر ${monthKey}`,
      amount: 1000,
      buildingCode: 'ALL',
      date: `${monthKey}-30`,
      supplier: 'السيد محمد المنصوري (نائب الوكيل)',
      invoiceRef: `DEP-SYN-${monthKey}`,
      paidBy: 'مكتب إدارة الإقامة',
      paymentMethod: 'bank_transfer',
      notes: `التعويض الشهري لنائب وكيل الاتحاد لشهر ${monthKey}`
    });

    // 6. Electricity ONEE
    allExpenses.push({
      id: `exp-elec-${monthKey}`,
      category: 'electricity',
      title: `فاتورة كهرباء المرافق المشتركة والسلالم والإنارة (ONEE) عن شهر ${monthKey}`,
      amount: electricity,
      buildingCode: 'ALL',
      date: `${monthKey}-10`,
      supplier: 'المكتب الوطني للكهرباء والماء الصالح للشرب (ONEE)',
      invoiceRef: `FAC-ONEE-${monthKey.replace('-', '')}`,
      paidBy: 'أمين المال',
      paymentMethod: 'bank_transfer',
      notes: `استهلاك العدادات المشتركة لإقامة المرجان لشهر ${monthKey}`
    });

    // 7. Water Utility
    allExpenses.push({
      id: `exp-wat-${monthKey}`,
      category: 'water',
      title: `فاتورة استهلاك الماء الصالح للشرب لري المساحات الخضراء وغسيل العمارات عن شهر ${monthKey}`,
      amount: water,
      buildingCode: 'ALL',
      date: `${monthKey}-12`,
      supplier: 'الوكالة المستقلة لتوزيع الماء والكهرباء (RADEEMA)',
      invoiceRef: `RAD-${monthKey.replace('-', '')}`,
      paidBy: 'السانديك',
      paymentMethod: 'bank_transfer',
      notes: `استهلاك عدادات مياه السقي وغسيل السلالم لشهر ${monthKey}`
    });

    // 8. Cleaning Supplies
    allExpenses.push({
      id: `exp-clnsupp-${monthKey}`,
      category: 'cleaning_supplies',
      title: `فاتورة مقتنيات ومساحيق النظافة ومطهرات السلالم والبالوعات عن شهر ${monthKey}`,
      amount: cleaningSupplies,
      buildingCode: 'ALL',
      date: `${monthKey}-15`,
      supplier: 'شركة المنظفات والتطهير الحديثة',
      invoiceRef: `FAC-NET-${monthKey.replace('-', '')}`,
      paidBy: 'السانديك',
      paymentMethod: 'cash',
      notes: 'جافيل، سانيكروا، أكياس قمامة كبيرة، صابون ومماسح'
    });

    // 9. Maintenance & Repairs
    allExpenses.push({
      id: `exp-maint-${monthKey}`,
      category: 'emergency_repairs',
      title: `${maintTitle} عن شهر ${monthKey}`,
      amount: maintenance,
      buildingCode: 'ALL',
      date: `${monthKey}-20`,
      supplier: 'مؤسسة الأطلس للخدمات التقنية والصيانة',
      invoiceRef: maintRef,
      paidBy: 'المكلف بالصيانة',
      paymentMethod: 'check',
      notes: 'أشغال الصيانة الدورية المعتمدة'
    });

    // 10. Office Stationery & Printing
    allExpenses.push({
      id: `exp-stat-${monthKey}`,
      category: 'office_stationery',
      title: `مكتبيات وطباعة وصولات الأداء الشهرية وأوراق الإدارة عن شهر ${monthKey}`,
      amount: stationery,
      buildingCode: 'ALL',
      date: `${monthKey}-25`,
      supplier: 'مكتبة ومطبعة مراكش',
      invoiceRef: `BUR-${monthKey.replace('-', '')}`,
      paidBy: 'كاتب السانديك',
      paymentMethod: 'cash',
      notes: 'وصولات الأداء المرقمة، حبر وأوراق السانديك'
    });
  });

  return allExpenses;
}

/**
 * Do NOT generate synthetic payments for owners.
 * Payments MUST strictly reflect authentic records entered manually by the syndic.
 */
export function generateMonthlySurplusPayments(): Payment[] {
  return [];
}

/**
 * Ensures monthly data integrity.
 * Purges any legacy synthetic payments while preserving authentic manual payments.
 */
export function ensurePositiveSurplusForAllMonths(
  existingPayments: Payment[] = [],
  existingExpenses: Expense[] = []
): { payments: Payment[]; expenses: Expense[]; seeded: boolean } {
  const generatedExpenses = generateMonthlySurplusExpenses();

  // Filter out any synthetic payments (IDs starting with 'pay-')
  const cleanPayments = existingPayments.filter(p => !p.id.startsWith('pay-'));
  const seeded = cleanPayments.length !== existingPayments.length;

  // Build a map of existing expenses by month
  const expensesByMonth: Record<string, Expense[]> = {};
  existingExpenses.forEach(e => {
    const ym = (e.date && e.date.length >= 7) ? e.date.slice(0, 7) : '';
    if (ym) {
      if (!expensesByMonth[ym]) expensesByMonth[ym] = [];
      expensesByMonth[ym].push(e);
    }
  });

  const finalExpenses = [...existingExpenses];

  // For months starting May 2026, ensure recurrent expenses exist if month has none
  MONTHS_FROM_MAY_2026.forEach(monthKey => {
    const currentMonthExpenses = expensesByMonth[monthKey] || [];
    if (currentMonthExpenses.length === 0) {
      const monthGenExpenses = generatedExpenses.filter(e => e.date && e.date.startsWith(monthKey));
      finalExpenses.push(...monthGenExpenses);
    }
  });

  return {
    payments: cleanPayments,
    expenses: finalExpenses,
    seeded
  };
}
