import { Resident, Expense, Building, ExpenseCategory, PaymentMethod, Apartment, Payment } from '../types';
import * as XLSX from 'xlsx';
import { getApartmentDebtStatus, getUnpaidMonthsList } from './debtUtils';

/**
 * Helper to escape and format a CSV cell value
 */
function sanitizeCsvCell(value: any): string {
  if (value === null || value === undefined) {
    return '""';
  }
  const str = String(value).replace(/"/g, '""');
  return `"${str}"`;
}

/**
 * Downloads a text content file with UTF-8 BOM
 */
function downloadFile(content: string, fileName: string, mimeType: string = 'text/csv;charset=utf-8;') {
  // \uFEFF is UTF-8 Byte Order Mark, crucial for Excel to recognize Arabic & UTF-8 correctly
  const blob = new Blob(['\uFEFF' + content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Export Residents list to Excel/CSV with complete metadata
 */
export function exportResidentsToExcel(
  residents: Resident[],
  buildings: Building[],
  lang: string = 'ar',
  filterBuilding: string = 'ALL',
  filterType: string = 'ALL'
) {
  const isAr = lang === 'ar';
  const dateStr = new Date().toISOString().slice(0, 10);
  
  const headers = isAr ? [
    'الرقم الترتيبي',
    'الاسم الكامل',
    'الصفة (مالك/مكتري)',
    'رمز العمارة',
    'رقم الشقة',
    'رقم الهاتف',
    'رقم بطاقة التعريف (CIN)',
    'لوحة ترقيم السيارة',
    'البريد الإلكتروني',
    'عدد أفراد الأسرة',
    'تاريخ السكن'
  ] : [
    'N°',
    'Nom Complet',
    'Statut (Propriétaire/Locataire)',
    'Code Bâtiment',
    'N° Appartement',
    'Téléphone',
    'N° CIN',
    'Matricule Véhicule',
    'Email',
    'Membres Famille',
    'Date d\'Entrée'
  ];

  const rows: string[][] = [headers];

  residents.forEach((r, index) => {
    const typeLabel = isAr 
      ? (r.type === 'owner' ? 'مالك' : 'مكتري')
      : (r.type === 'owner' ? 'Propriétaire' : 'Locataire');

    rows.push([
      String(index + 1),
      r.fullName || '',
      typeLabel,
      r.buildingCode || '',
      r.apartmentNumber || '',
      r.phone || '',
      r.cin || '',
      r.vehiclePlate || '',
      r.email || '',
      String(r.familyMembersCount || 1),
      r.entryDate || ''
    ]);
  });

  // Summary footer row
  const totalOwners = residents.filter(r => r.type === 'owner').length;
  const totalTenants = residents.filter(r => r.type === 'tenant').length;
  const totalVehicles = residents.filter(r => !!r.vehiclePlate).length;

  rows.push([]);
  rows.push([
    isAr ? 'الإحصائيات الإجمالية:' : 'Résumé Statistiques:',
    isAr ? `إجمالي السكان: ${residents.length}` : `Total Résidents: ${residents.length}`,
    isAr ? `الملاك: ${totalOwners} | المكترون: ${totalTenants}` : `Propriétaires: ${totalOwners} | Locataires: ${totalTenants}`,
    isAr ? `المركبات المسجلة: ${totalVehicles}` : `Véhicules: ${totalVehicles}`,
    '', '', '', '', '', '',
    isAr ? `تاريخ التصدير: ${dateStr}` : `Exporté le: ${dateStr}`
  ]);

  const csvContent = rows
    .map(row => row.map(sanitizeCsvCell).join(','))
    .join('\r\n');

  const buildingSuffix = filterBuilding !== 'ALL' ? `_${filterBuilding.replace(/\s+/g, '_')}` : '_All_Buildings';
  const filename = `AL_MARJANE_Residents_Registry${buildingSuffix}_${dateStr}.csv`;

  downloadFile(csvContent, filename);
}

/**
 * Export Expenses list to Excel/CSV with complete metadata and category totals
 */
export function exportExpensesToExcel(
  expenses: Expense[],
  buildings: Building[],
  lang: string = 'ar',
  getCategoryLabel: (cat: ExpenseCategory) => string,
  getMethodLabel: (m: PaymentMethod) => string,
  filterCategory: string = 'ALL'
) {
  const isAr = lang === 'ar';
  const dateStr = new Date().toISOString().slice(0, 10);

  const headers = isAr ? [
    'الرقم الترتيبي',
    'التاريخ',
    'بيان ونوع المصروف',
    'الفئة',
    'المبلغ (درهم)',
    'العمارة / النطاق',
    'المورد / الشركة المنفذة',
    'رقم الفاتورة / الوصل',
    'طريقة الأداء',
    'الآمر بالصرف'
  ] : [
    'N°',
    'Date',
    'Désignation de la dépense',
    'Catégorie',
    'Montant (MAD / DH)',
    'Bâtiment Concerné',
    'Fournisseur / Société',
    'Réf. Facture',
    'Mode de Paiement',
    'Ordonné par'
  ];

  const rows: string[][] = [headers];
  let grandTotal = 0;

  expenses.forEach((e, index) => {
    const amt = Number(e.amount) || 0;
    grandTotal += amt;
    const catLabel = getCategoryLabel(e.category);
    const methodLabel = getMethodLabel(e.paymentMethod);
    const buildingLabel = e.buildingCode === 'ALL' 
      ? (isAr ? 'كامل الإقامة' : 'Toute la résidence') 
      : e.buildingCode;

    rows.push([
      String(index + 1),
      e.date || '',
      e.title || '',
      catLabel,
      amt.toFixed(2),
      buildingLabel,
      e.supplier || '',
      e.invoiceRef || '',
      methodLabel,
      e.paidBy || (isAr ? 'مكتب السانديك' : 'Bureau du Syndic')
    ]);
  });

  // Total summary row
  rows.push([]);
  rows.push([
    isAr ? 'المجموع الإجمالي' : 'TOTAL GÉNÉRAL',
    '',
    isAr ? `عدد العمليات: ${expenses.length}` : `Nombre d'opérations: ${expenses.length}`,
    '',
    grandTotal.toFixed(2) + ' DH',
    '',
    '',
    '',
    '',
    isAr ? `تاريخ استخراج التقرير: ${dateStr}` : `Généré le: ${dateStr}`
  ]);

  const csvContent = rows
    .map(row => row.map(sanitizeCsvCell).join(','))
    .join('\r\n');

  const catSuffix = filterCategory !== 'ALL' ? `_${filterCategory}` : '_All_Categories';
  const filename = `AL_MARJANE_Expenses_Report${catSuffix}_${dateStr}.csv`;

  downloadFile(csvContent, filename);
}

export interface ExportOwnersDuesOptions {
  apartments: Apartment[];
  payments: Payment[];
  buildings: Building[];
  lang?: 'ar' | 'fr';
  filterBuilding?: string; // 'ALL' | 'GROUP_A' | 'GROUP_B' | specific building
  onlyDebtors?: boolean;
  fileFormat?: 'xlsx' | 'csv';
}

/**
 * Export complete Owners' Dues & Receivables (مستحقات وديون الملاك) to Excel (.xlsx / .csv)
 * Detailed breakdown per building and apartment across all 20 buildings.
 */
export function exportOwnersDuesToExcel({
  apartments,
  payments,
  buildings,
  lang = 'ar',
  filterBuilding = 'ALL',
  onlyDebtors = false,
  fileFormat = 'xlsx'
}: ExportOwnersDuesOptions) {
  const isAr = lang === 'ar';
  const dateStr = new Date().toISOString().slice(0, 10);

  // Filter apartments
  let filteredApts = apartments.filter(apt => {
    if (filterBuilding === 'ALL') return true;
    if (filterBuilding === 'GROUP_A') {
      return apt.buildingCode.endsWith('A') || apt.buildingCode.endsWith(' A');
    }
    if (filterBuilding === 'GROUP_B') {
      return apt.buildingCode.endsWith('B') || apt.buildingCode.endsWith(' B');
    }
    return apt.buildingCode === filterBuilding;
  });

  // Sort apartments canonically: GH 34 A -> GH 43 B, apt 01 -> 16
  filteredApts.sort((a, b) => {
    const parseCode = (c: string) => {
      const match = (c || '').match(/GH\s*(\d+)\s*([AB])/i);
      return match ? { num: parseInt(match[1], 10), letter: match[2].toUpperCase() } : { num: 999, letter: '' };
    };
    const pA = parseCode(a.buildingCode);
    const pB = parseCode(b.buildingCode);
    if (pA.letter !== pB.letter) return pA.letter.localeCompare(pB.letter);
    if (pA.num !== pB.num) return pA.num - pB.num;
    const numA = parseInt(a.number.replace(/\D/g, '') || '0', 10);
    const numB = parseInt(b.number.replace(/\D/g, '') || '0', 10);
    return numA - numB;
  });

  // Prepare data with calculated debts
  const aptsWithDebt = filteredApts.map(apt => {
    const debt = getApartmentDebtStatus(apt, payments);
    const unpaidList = getUnpaidMonthsList(debt.unpaidMonths);
    const unpaidPeriodsStr = unpaidList.map(m => isAr ? m.labelAr : m.labelFr).join(' ، ');

    // Find last payment
    const aptPayments = payments.filter(p => 
      p.buildingCode.replace(/\s+/g, '').toUpperCase() === apt.buildingCode.replace(/\s+/g, '').toUpperCase() &&
      p.apartmentNumber.replace(/\D/g, '') === apt.number.replace(/\D/g, '')
    ).sort((x, y) => (y.paymentDate || '').localeCompare(x.paymentDate || ''));

    const lastPay = aptPayments[0];
    const lastPayStr = lastPay ? `${lastPay.paymentDate} (${lastPay.amount} DH - ${lastPay.periodMonth})` : (isAr ? 'لا يوجد أداء مسجل' : 'Aucun');

    return {
      apt,
      debt,
      unpaidPeriodsStr,
      lastPayStr
    };
  });

  // Apply debtors only filter if selected
  const displayList = onlyDebtors 
    ? aptsWithDebt.filter(item => !item.debt.isOffice && item.debt.totalBalanceDue > 0)
    : aptsWithDebt;

  // Header definition
  const headers = isAr ? [
    'الرقم',
    'رمز العمارة',
    'رقم الشقة',
    'اسم المالك الكامل',
    'رقم الهاتف',
    'بطاقة التعريف (CIN)',
    'الواجب الشهري (درهم)',
    'عدد الأشهر غير المؤداة',
    'إجمالي المستحقات (درهم)',
    'الوضعية المالية للسانديك',
    'تفصيل الشهور المستحقة',
    'آخر أداء مسجل',
    'الملاحظات'
  ] : [
    'N°',
    'Bâtiment',
    'Appt',
    'Nom du Propriétaire',
    'Téléphone',
    'CIN',
    'Cotisation Mensuelle (DH)',
    'Mois d\'Arriérés',
    'Total Dû (DH)',
    'Statut Financier',
    'Détail des Mois Dus',
    'Dernier Règlement',
    'Notes'
  ];

  // Rows data
  const rows: any[][] = [headers];
  let grandTotalDebt = 0;
  let totalDebtorsCount = 0;
  let totalSettledCount = 0;

  displayList.forEach((item, index) => {
    const { apt, debt, unpaidPeriodsStr, lastPayStr } = item;
    const isOffice = debt.isOffice;
    const balance = isOffice ? 0 : debt.totalBalanceDue;
    const unpaidCount = isOffice ? 0 : debt.unpaidMonths;

    if (!isOffice) {
      grandTotalDebt += balance;
      if (balance > 0) totalDebtorsCount++;
      else totalSettledCount++;
    }

    let statusText = '';
    if (isOffice) {
      statusText = isAr ? 'مكتب السانديك (معفى) 🏢' : 'Bureau Syndic (Exonéré)';
    } else if (debt.isPaid || balance === 0) {
      statusText = isAr ? 'خالص ومسوى 🟢' : 'À jour 🟢';
    } else {
      statusText = isAr ? `مديون (${balance} DH) 🔴` : `En retard (${balance} DH) 🔴`;
    }

    rows.push([
      index + 1,
      apt.buildingCode,
      apt.number,
      apt.ownerName || (isAr ? 'غير مسجل' : 'Non renseigné'),
      apt.ownerPhone || '',
      apt.ownerCin || '',
      apt.monthlyFee || 150,
      unpaidCount,
      balance,
      statusText,
      unpaidPeriodsStr || (debt.isPaid ? (isAr ? 'لا توجد متأخرات' : 'Aucun') : ''),
      lastPayStr,
      apt.notes || ''
    ]);
  });

  // Summary Row
  const summaryRow = [
    isAr ? 'المجموع' : 'TOTAL',
    isAr ? `إجمالي الشقق: ${displayList.length}` : `Lots: ${displayList.length}`,
    '',
    isAr ? `الملاك المديونون: ${totalDebtorsCount} | الخالصون: ${totalSettledCount}` : `Débiteurs: ${totalDebtorsCount} | À jour: ${totalSettledCount}`,
    '',
    '',
    '',
    '',
    grandTotalDebt,
    isAr ? `مجموع المستحقات: ${grandTotalDebt.toLocaleString()} درهم` : `Total Dû: ${grandTotalDebt.toLocaleString()} DH`,
    '',
    isAr ? `تاريخ الاستخراج: ${dateStr}` : `Exporté le: ${dateStr}`,
    'إقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10'
  ];
  rows.push([]);
  rows.push(summaryRow);

  const filterSuffix = filterBuilding !== 'ALL' ? `_${filterBuilding.replace(/\s+/g, '_')}` : '_All_20_Buildings';
  const debtorSuffix = onlyDebtors ? '_Debiteurs_Seulement' : '_Tous_Proprietaires';
  const baseFilename = `AL_MARJANE_Moustahaqat_Al_Moulak${filterSuffix}${debtorSuffix}_${dateStr}`;

  if (fileFormat === 'xlsx') {
    // Generate styled XLSX workbook
    const ws = XLSX.utils.aoa_to_sheet(rows);

    // Set auto column widths
    ws['!cols'] = [
      { wch: 6 },   // N°
      { wch: 14 },  // Building
      { wch: 10 },  // Apt
      { wch: 28 },  // Owner
      { wch: 18 },  // Phone
      { wch: 14 },  // CIN
      { wch: 18 },  // Monthly Fee
      { wch: 18 },  // Unpaid Months
      { wch: 18 },  // Total Due
      { wch: 22 },  // Status
      { wch: 45 },  // Detail periods
      { wch: 32 },  // Last payment
      { wch: 28 }   // Notes
    ];

    const wb = XLSX.utils.book_new();
    const sheetName = isAr ? 'مستحقات الملاك' : 'Arrieres Coproprietaires';
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    // Write file
    XLSX.writeFile(wb, `${baseFilename}.xlsx`);
  } else {
    // Download as UTF-8 CSV with BOM
    const csvContent = rows
      .map(row => row.map(sanitizeCsvCell).join(','))
      .join('\r\n');
    downloadFile(csvContent, `${baseFilename}.csv`);
  }
}

