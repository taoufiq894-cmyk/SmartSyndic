import { ResidenceLocationInfo } from '../types';

export const STORAGE_KEY_RESIDENCE_LOCATION = 'ma_residence_location_config_v1';

export const DEFAULT_RESIDENCE_LOCATION: ResidenceLocationInfo = {
  name: "إقامة المرجان",
  nameFr: "Résidence Al Morjane",
  city: "مراكش",
  country: "المملكة المغربية",
  fullAddressAr: "أبواب مراكش، المنطقة 10، السكن المتوسط، إقامة المرجان، مراكش",
  fullAddressFr: "Abouab Marrakech, Zone 10, Logement Moyen Standing, Résidence Al Morjane, Marrakech",
  latitude: 31.6437,
  longitude: -8.0754,
  googleMapsUrl: "https://maps.google.com/?q=31.6437,-8.0754",
  googleMapsShortUrl: "https://maps.google.com/?q=31.6437,-8.0754",
  wazeUrl: "https://waze.com/ul?ll=31.6437,-8.0754&navigate=yes",
  appleMapsUrl: "https://maps.apple.com/?q=31.6437,-8.0754",
  syndicOfficeLocationAr: "المنطقة 10، عمارة GH 34 A، الشقة رقم 01 (الطابق الأرضي السفلي - RDC)",
  syndicOfficeLocationFr: "Zone 10, Immeuble GH 34 A, Appartement N°01 (Rez-de-chaussée - RDC)",
  mainEntranceAr: "البوابة الرئيسية للمنطقة 10 أمام العمارات مع حراسة أمنية مستمرة 24/7",
  mainEntranceFr: "Entrée principale Zone 10 avec poste de sécurité 24/7",
  landmarksAr: "أبواب مراكش المنطقة 10، بمحاذاة الشارع الرئيسي والمرافق الخدمية والتجارية",
  landmarksFr: "Abouab Marrakech Zone 10, à proximité de l'artère principale et des commerces",
  contactPhone: "0661000000",
  securityPhone: "0662000000",
  email: "syndic@residence-elmarjane.ma",
  notesAr: "يرجى من الزوار وعمال التوصيل الإدلاء برقم العمارة ورقم الشقة عند بوابة أمن المنطقة 10 لتسهيل الدخول.",
  notesFr: "Prière d'indiquer le numéro du bloc (GH) et de l'appartement au poste de sécurité pour faciliter l'accès."
};

/**
 * Load location configuration from localStorage with fallback to defaults
 */
export const getResidenceLocation = (): ResidenceLocationInfo => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_RESIDENCE_LOCATION);
    if (saved) {
      const parsed = JSON.parse(saved);
      // Automatically migrate old Temara/Skhirat references to new Marrakech Zone 10 address
      if (parsed.city?.includes('تمارة') || parsed.city?.includes('الصخيرات') || parsed.fullAddressAr?.includes('تمارة')) {
        const migrated: ResidenceLocationInfo = {
          ...parsed,
          city: "مراكش",
          fullAddressAr: "أبواب مراكش، المنطقة 10، السكن المتوسط، إقامة المرجان، مراكش",
          fullAddressFr: "Abouab Marrakech, Zone 10, Logement Moyen Standing, Résidence Al Morjane, Marrakech",
          syndicOfficeLocationAr: "المنطقة 10، عمارة GH 34 A، الشقة رقم 01 (الطابق الأرضي السفلي - RDC)",
          syndicOfficeLocationFr: "Zone 10, Immeuble GH 34 A, Appartement N°01 (Rez-de-chaussée - RDC)",
          landmarksAr: "أبواب مراكش المنطقة 10، بمحاذاة الشارع الرئيسي والمرافق الخدمية والتجارية",
          landmarksFr: "Abouab Marrakech Zone 10, à proximité de l'artère principale et des commerces",
          mainEntranceAr: "البوابة الرئيسية للمنطقة 10 أمام العمارات مع حراسة أمنية مستمرة 24/7",
          mainEntranceFr: "Entrée principale Zone 10 avec poste de sécurité 24/7",
        };
        // If the coordinates were the old Temara ones, update them to Marrakech defaults
        if (parsed.latitude === 33.92147 && parsed.longitude === -6.91742) {
          migrated.latitude = DEFAULT_RESIDENCE_LOCATION.latitude;
          migrated.longitude = DEFAULT_RESIDENCE_LOCATION.longitude;
          migrated.googleMapsUrl = DEFAULT_RESIDENCE_LOCATION.googleMapsUrl;
          migrated.googleMapsShortUrl = DEFAULT_RESIDENCE_LOCATION.googleMapsShortUrl;
          migrated.wazeUrl = DEFAULT_RESIDENCE_LOCATION.wazeUrl;
          migrated.appleMapsUrl = DEFAULT_RESIDENCE_LOCATION.appleMapsUrl;
        }
        localStorage.setItem(STORAGE_KEY_RESIDENCE_LOCATION, JSON.stringify(migrated));
        return migrated;
      }
      return { ...DEFAULT_RESIDENCE_LOCATION, ...parsed };
    }
  } catch (err) {
    console.warn('Error reading residence location from storage:', err);
  }
  return DEFAULT_RESIDENCE_LOCATION;
};

/**
 * Smartly parse Latitude and Longitude from any text, URL, Google Maps link, or coordinates string
 */
export const parseCoordinatesFromInput = (input: string): { latitude: number; longitude: number } | null => {
  if (!input || !input.trim()) return null;
  const str = input.trim();

  // Pattern 1: URL with q=lat,lng or ll=lat,lng or daddr=lat,lng
  const urlParamMatch = str.match(/[?&](?:q|ll|daddr|saddr)=([+-]?\d+(?:\.\d+)?),([+-]?\d+(?:\.\d+)?)/i);
  if (urlParamMatch) {
    const lat = parseFloat(urlParamMatch[1]);
    const lng = parseFloat(urlParamMatch[2]);
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      return { latitude: Number(lat.toFixed(6)), longitude: Number(lng.toFixed(6)) };
    }
  }

  // Pattern 2: URL with /@lat,lng or !3dlat!4dlng
  const urlAtMatch = str.match(/@([+-]?\d+(?:\.\d+)?),([+-]?\d+(?:\.\d+)?)/);
  if (urlAtMatch) {
    const lat = parseFloat(urlAtMatch[1]);
    const lng = parseFloat(urlAtMatch[2]);
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      return { latitude: Number(lat.toFixed(6)), longitude: Number(lng.toFixed(6)) };
    }
  }

  // Pattern 3: Standard decimal coordinates: "33.92147, -6.91742" or "31.6340 -8.0123"
  const standardMatch = str.match(/([+-]?\d{1,2}(?:\.\d+)?)\s*[,;\s]\s*([+-]?\d{1,3}(?:\.\d+)?)/);
  if (standardMatch) {
    const lat = parseFloat(standardMatch[1]);
    const lng = parseFloat(standardMatch[2]);
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
      return { latitude: Number(lat.toFixed(6)), longitude: Number(lng.toFixed(6)) };
    }
  }

  // Pattern 4: Degrees Minutes Seconds (DMS) e.g., 31°37'46.2"N 8°02'09.6"W
  const dmsMatch = str.match(/(\d+)°(?:(\d+)'(?:(\d+(?:\.\d+)?)"?)?)?\s*([NSEW])\s*[,;\s]?\s*(\d+)°(?:(\d+)'(?:(\d+(?:\.\d+)?)"?)?)?\s*([NSEW])/i);
  if (dmsMatch) {
    try {
      const latDeg = parseFloat(dmsMatch[1]) + (parseFloat(dmsMatch[2] || '0') / 60) + (parseFloat(dmsMatch[3] || '0') / 3600);
      const latDir = dmsMatch[4].toUpperCase();
      const lat = latDir === 'S' ? -latDeg : latDeg;

      const lngDeg = parseFloat(dmsMatch[5]) + (parseFloat(dmsMatch[6] || '0') / 60) + (parseFloat(dmsMatch[7] || '0') / 3600);
      const lngDir = dmsMatch[8].toUpperCase();
      const lng = lngDir === 'W' ? -lngDeg : lngDeg;

      if (!isNaN(lat) && !isNaN(lng)) {
        return { latitude: Number(lat.toFixed(6)), longitude: Number(lng.toFixed(6)) };
      }
    } catch {
      // ignore
    }
  }

  return null;
};

/**
 * Save updated location configuration to localStorage
 */
export const saveResidenceLocation = (info: ResidenceLocationInfo): void => {
  try {
    localStorage.setItem(STORAGE_KEY_RESIDENCE_LOCATION, JSON.stringify(info));
  } catch (err) {
    console.error('Error saving residence location to storage:', err);
  }
};

/**
 * Clear/delete stored residence coordinates
 */
export const clearStoredResidenceLocation = (): ResidenceLocationInfo => {
  const cleared: ResidenceLocationInfo = {
    ...DEFAULT_RESIDENCE_LOCATION,
    latitude: 0,
    longitude: 0,
    googleMapsUrl: '',
    googleMapsShortUrl: '',
    wazeUrl: '',
    appleMapsUrl: ''
  };
  saveResidenceLocation(cleared);
  return cleared;
};

/**
 * Check if coordinates are configured and valid
 */
export const hasValidCoordinates = (info: ResidenceLocationInfo): boolean => {
  return typeof info?.latitude === 'number' && 
         typeof info?.longitude === 'number' && 
         (info.latitude !== 0 || info.longitude !== 0) &&
         info.latitude >= -90 && info.latitude <= 90 &&
         info.longitude >= -180 && info.longitude <= 180;
};

/**
 * Generate formatted WhatsApp share text for the exact residence location
 */
export const generateLocationShareMessage = (
  info: ResidenceLocationInfo, 
  lang: 'ar' | 'fr' = 'ar',
  destinationDetails?: { building?: string; apartment?: string; recipientName?: string }
): string => {
  const valid = hasValidCoordinates(info);
  const mapsUrl = valid ? `https://maps.google.com/?q=${info.latitude},${info.longitude}` : '';
  const wazeUrl = valid ? `https://waze.com/ul?ll=${info.latitude},${info.longitude}&navigate=yes` : '';

  if (lang === 'ar') {
    let msg = `📍 *موقع ${info.name || 'إقامة المرجان'} (Localisation)*\n\n`;
    if (destinationDetails?.recipientName) {
      msg += `مرحباً بك ${destinationDetails.recipientName}،\n`;
    }
    if (destinationDetails?.building || destinationDetails?.apartment) {
      msg += `🏢 *الوجهة المحددة:* ${destinationDetails.building || ''} ${destinationDetails.apartment ? `- الشقة ${destinationDetails.apartment}` : ''}\n\n`;
    }
    msg += `🗺️ *العنوان الدقيق:* ${info.fullAddressAr}\n`;
    if (valid) {
      msg += `📍 *إحداثيات GPS:* \`${info.latitude}, ${info.longitude}\`\n\n`;
      msg += `📌 *رابط خرائط جوجل (Google Maps):*\n${mapsUrl}\n\n`;
      msg += `🚗 *رابط الملاحة عبر Waze:*\n${wazeUrl}\n\n`;
    }
    msg += `🚪 *مدخل الإقامة ومكتب السانديك:*\n`;
    msg += `• مكتب السانديك: ${info.syndicOfficeLocationAr}\n`;
    msg += `• البوابة الرئيسية: ${info.mainEntranceAr}\n`;
    if (info.contactPhone) {
      msg += `📞 *هاتف السانديك / الحراسة:* ${info.contactPhone}\n`;
    }
    if (info.notesAr) {
      msg += `\n💡 *ملاحظة:* ${info.notesAr}\n`;
    }
    return msg;
  } else {
    let msg = `📍 *Localisation - ${info.nameFr || 'Résidence Al Morjane'}*\n\n`;
    if (destinationDetails?.recipientName) {
      msg += `Bonjour ${destinationDetails.recipientName},\n`;
    }
    if (destinationDetails?.building || destinationDetails?.apartment) {
      msg += `🏢 *Destination:* ${destinationDetails.building || ''} ${destinationDetails.apartment ? `- Apt ${destinationDetails.apartment}` : ''}\n\n`;
    }
    msg += `🗺️ *Adresse exacte:* ${info.fullAddressFr}\n`;
    if (valid) {
      msg += `📍 *Coordonnées GPS:* \`${info.latitude}, ${info.longitude}\`\n\n`;
      msg += `📌 *Lien Google Maps:*\n${mapsUrl}\n\n`;
      msg += `🚗 *Lien Navigation Waze:*\n${wazeUrl}\n\n`;
    }
    msg += `🚪 *Accès & Bureau Syndic:*\n`;
    msg += `• Bureau Syndic: ${info.syndicOfficeLocationFr}\n`;
    msg += `• Entrée Principale: ${info.mainEntranceFr}\n`;
    if (info.contactPhone) {
      msg += `📞 *Contact Syndic / Sécurité:* ${info.contactPhone}\n`;
    }
    if (info.notesFr) {
      msg += `\n💡 *Note:* ${info.notesFr}\n`;
    }
    return msg;
  }
};

/**
 * Open WhatsApp with the generated location message
 */
export const shareLocationViaWhatsApp = (
  info: ResidenceLocationInfo,
  phoneNumber?: string,
  lang: 'ar' | 'fr' = 'ar',
  destinationDetails?: { building?: string; apartment?: string; recipientName?: string }
): void => {
  const message = generateLocationShareMessage(info, lang, destinationDetails);
  const encodedMsg = encodeURIComponent(message);
  
  let targetUrl = '';
  if (phoneNumber && phoneNumber.trim().length > 0) {
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    const fullNumber = cleanNumber.startsWith('0') ? `212${cleanNumber.slice(1)}` : cleanNumber;
    targetUrl = `https://wa.me/${fullNumber}?text=${encodedMsg}`;
  } else {
    targetUrl = `https://api.whatsapp.com/send?text=${encodedMsg}`;
  }

  window.open(targetUrl, '_blank', 'noopener,noreferrer');
};
