import * as XLSX from 'xlsx';
import { Employee, PointageStatus, EmployeeSalaryCalculation } from '../types';

export const STANDARD_WORK_DAYS = 26;
export const STANDARD_REST_DAYS = 4;

export const AR_DAYS_SHORT = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س']; // الأحد, الإثنين, الثلاثاء, الأربعاء, الخميس, الجمعة, السبت
export const FR_DAYS_SHORT = ['Di', 'Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa'];

export const AR_DAYS_FULL = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
export const FR_DAYS_FULL = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];

/**
 * Returns list of day dates for a given month 'YYYY-MM'
 */
export function getMonthDays(monthKey: string): Array<{
  date: string;
  dayNum: number;
  dayOfWeek: number;
  dayNameAr: string;
  dayNameFr: string;
  dayNameFullAr: string;
  isSunday: boolean;
  isFriday: boolean;
}> {
  const [yearStr, monthStr] = monthKey.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10); // 1-12

  // Number of days in month
  const totalDays = new Date(year, month, 0).getDate();
  const days = [];

  for (let d = 1; d <= totalDays; d++) {
    const padDay = d < 10 ? `0${d}` : `${d}`;
    const dateStr = `${yearStr}-${monthStr}-${padDay}`;
    const dateObj = new Date(year, month - 1, d);
    const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 5 = Friday, 6 = Saturday

    days.push({
      date: dateStr,
      dayNum: d,
      dayOfWeek,
      dayNameAr: AR_DAYS_SHORT[dayOfWeek],
      dayNameFr: FR_DAYS_SHORT[dayOfWeek],
      dayNameFullAr: AR_DAYS_FULL[dayOfWeek],
      isSunday: dayOfWeek === 0,
      isFriday: dayOfWeek === 5,
    });
  }

  return days;
}

/**
 * Returns the effective start date for an employee.
 * If emp.startDate is explicitly set, uses that.
 * Otherwise, uses the worker registration date (emp.createdAt or timestamp from emp.id),
 * as worker registration date is strictly considered their start date of work.
 */
export function getEmployeeEffectiveStartDate(emp: Employee): string {
  if (emp.startDate && emp.startDate.trim()) {
    return emp.startDate.trim();
  }
  // Check if this is an initial default worker
  if (emp.id && (emp.id.startsWith('emp-sec-') || emp.id.startsWith('emp-cln-') || emp.id.startsWith('emp-jrd-') || emp.id.startsWith('emp-syn-') || emp.id.startsWith('emp-dep-'))) {
    return '2026-01-01';
  }
  if (emp.createdAt && emp.createdAt.trim()) {
    return emp.createdAt.trim().slice(0, 10);
  }
  if (emp.id && emp.id.startsWith('emp-')) {
    const rawNum = emp.id.replace('emp-', '');
    const timestamp = Number(rawNum);
    if (!isNaN(timestamp) && timestamp > 1600000000000) {
      const d = new Date(timestamp);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    }
  }
  // Default fallback for newly registered worker without a start date: default to current registration date (September 2026), NEVER 2026-01-01!
  return '2026-09-11';
}

/**
 * Checks if an employee was already registered/active in or before the given month.
 * A worker registered in 2026-09 will return false for month 2026-08.
 */
export function isEmployeeActiveInMonth(emp: Employee, monthKey: string): boolean {
  const effectiveStart = getEmployeeEffectiveStartDate(emp);
  const startMonth = effectiveStart.slice(0, 7); // e.g. "2026-09"
  return startMonth <= monthKey;
}

/**
 * Key generator for pointage record: `${employeeId}_${date}`
 */
export function getPointageKey(employeeId: string, date: string): string {
  return `${employeeId}_${date}`;
}

/**
 * Calculate salary for an employee according to the 26 work days + 4 rest days rule:
 * - 26 jours de travail + 4 jours de repos = Mois plein (ex. 2200 DH)
 * - Taux journalier = salaire / 26
 * - Déduction absence = nombre de jours d'absence * (salaire / 26)
 * - Salaire net = salaire - déductions + primes - avances
 */
export function calculateEmployeeSalary(
  emp: Employee,
  monthKey: string,
  pointages: Record<string, PointageStatus>,
  advance: number = 0,
  bonus: number = 0
): EmployeeSalaryCalculation {
  const days = getMonthDays(monthKey);
  const baseSalary = Number(emp.salary) || 0;
  const effectiveStartDate = getEmployeeEffectiveStartDate(emp);
  
  // Daily rate is strictly based on the 26 working days duration
  const dailyRate = Math.round((baseSalary / STANDARD_WORK_DAYS) * 100) / 100;

  let presentDays = 0;
  let restDays = 0;
  let absentDays = 0;
  let paidLeaveDays = 0;
  let halfDays = 0;

  // Working days and attendance are calculated strictly starting from effectiveStartDate
  days.forEach(d => {
    // If day is prior to effectiveStartDate, it is not eligible / not counted
    if (d.date < effectiveStartDate) {
      return;
    }

    const key = getPointageKey(emp.id, d.date);
    const status = pointages[key];

    if (status === 'present') {
      presentDays++;
    } else if (status === 'rest') {
      restDays++;
    } else if (status === 'absent') {
      absentDays++;
    } else if (status === 'leave_paid') {
      paidLeaveDays++;
    } else if (status === 'half_day') {
      halfDays++;
      presentDays += 0.5;
    }
  });

  const firstDayOfMonth = days[0]?.date || `${monthKey}-01`;
  const lastDayOfMonth = days[days.length - 1]?.date || `${monthKey}-31`;
  const isStartedAfterMonthStart = Boolean(effectiveStartDate > firstDayOfMonth);
  const isNotYetStarted = Boolean(effectiveStartDate > lastDayOfMonth);

  let netSalary = 0;
  let totalAbsenceDeduction = 0;

  if (isNotYetStarted) {
    // Worker has not started working yet in this month
    netSalary = 0;
    totalAbsenceDeduction = 0;
  } else if (isStartedAfterMonthStart) {
    // Worker joined mid-month: salary is calculated based on days worked starting from effectiveStartDate
    const earnedSalary = Math.min(baseSalary, Math.round(((presentDays + paidLeaveDays) * dailyRate) * 100) / 100);
    totalAbsenceDeduction = Math.round((absentDays * dailyRate) * 100) / 100;
    netSalary = Math.max(0, Math.round((earnedSalary + bonus - advance) * 100) / 100);
  } else {
    // Standard full month employment:
    // Full day absence = 1 * dailyRate, Half day absence = 0.5 * dailyRate
    totalAbsenceDeduction = Math.round((absentDays * dailyRate + (halfDays * 0.5 * dailyRate)) * 100) / 100;
    netSalary = Math.max(0, Math.round((baseSalary - totalAbsenceDeduction + bonus - advance) * 100) / 100);
  }

  return {
    employeeId: emp.id,
    monthKey,
    baseSalary,
    standardWorkDays: STANDARD_WORK_DAYS,
    standardRestDays: STANDARD_REST_DAYS,
    dailyRate,
    presentDays,
    restDays,
    absentDays,
    paidLeaveDays,
    halfDays,
    totalAbsenceDeduction,
    advanceDeduction: advance,
    bonusAmount: bonus,
    netSalary,
    isPaid: false,
    startDate: effectiveStartDate,
  };
}

/**
 * Generate standard default pointage for an employee or all employees in a month:
 * 4 days rest (Sundays or chosen days) + 26 days present
 * Respects worker's startDate: attendance starts only on or after startDate.
 */
export function generateDefaultMonthPointage(
  monthKey: string,
  employees: Employee[],
  currentRecords: Record<string, PointageStatus> = {}
): Record<string, PointageStatus> {
  const days = getMonthDays(monthKey);
  const updated: Record<string, PointageStatus> = { ...currentRecords };

  employees.forEach(emp => {
    const empStart = getEmployeeEffectiveStartDate(emp);

    if (!isEmployeeActiveInMonth(emp, monthKey)) {
      // Worker hasn't been registered yet in this month; purge any accidental records
      days.forEach(d => {
        delete updated[getPointageKey(emp.id, d.date)];
      });
      return;
    }

    // Filter eligible days for this employee (days >= empStart)
    const eligibleDays = days.filter(d => d.date >= empStart);
    if (eligibleDays.length === 0) {
      return;
    }

    // Determine rest days among eligible days (preference: Sundays)
    const sundayDates = eligibleDays.filter(d => d.isSunday).map(d => d.date);
    const restDatesSet = new Set<string>();

    const targetRestDays = empStart && empStart > days[0].date
      ? Math.min(sundayDates.length, Math.max(1, Math.round((eligibleDays.length / days.length) * STANDARD_REST_DAYS)))
      : 4;

    if (sundayDates.length >= targetRestDays) {
      sundayDates.slice(0, targetRestDays).forEach(d => restDatesSet.add(d));
    } else {
      sundayDates.forEach(d => restDatesSet.add(d));
      for (const d of eligibleDays) {
        if (restDatesSet.size >= targetRestDays) break;
        if (!restDatesSet.has(d.date)) {
          restDatesSet.add(d.date);
        }
      }
    }

    // Now assign statuses:
    // Days prior to emp.startDate: remove/skip
    days.forEach(d => {
      const key = getPointageKey(emp.id, d.date);
      if (empStart && d.date < empStart) {
        delete updated[key];
        return;
      }

      if (restDatesSet.has(d.date)) {
        updated[key] = 'rest';
      } else {
        updated[key] = 'present';
      }
    });
  });

  return updated;
}

/**
 * Export pointage to Excel
 */
export function exportPointageToExcel(
  monthKey: string,
  employees: Employee[],
  pointages: Record<string, PointageStatus>,
  lang: string = 'ar',
  advances: Record<string, number> = {},
  bonuses: Record<string, number> = {}
) {
  const days = getMonthDays(monthKey);
  const [year, month] = monthKey.split('-');

  // Build rows
  const rows: any[] = [];

  employees.forEach((emp, index) => {
    const adv = advances[`${emp.id}_${monthKey}`] || 0;
    const bon = bonuses[`${emp.id}_${monthKey}`] || 0;
    const calc = calculateEmployeeSalary(emp, monthKey, pointages, adv, bon);

    const row: Record<string, any> = {
      '#': index + 1,
      [lang === 'ar' ? 'اسم العامل' : 'Nom Employé']: emp.name,
      [lang === 'ar' ? 'المهمة / الوظيفة' : 'Rôle']: emp.role,
      [lang === 'ar' ? 'تاريخ بدء العمل' : 'Date Début']: emp.startDate || '-',
      [lang === 'ar' ? 'رقم ب.ت.و (CIN)' : 'CIN']: emp.cin || '-',
      [lang === 'ar' ? 'الراتب الأساسي (DH)' : 'Salaire Base (DH)']: calc.baseSalary,
      [lang === 'ar' ? 'الأجر اليومي (DH/يوم)' : 'Tarif Journalier (DH/j)']: calc.dailyRate,
    };

    // Add days columns
    days.forEach(d => {
      const isBeforeStart = Boolean(emp.startDate && d.date < emp.startDate);
      const colName = `${d.dayNum} (${lang === 'ar' ? d.dayNameAr : d.dayNameFr})`;

      if (isBeforeStart) {
        row[colName] = lang === 'ar' ? '— (لم يبدأ)' : '— (Non embauché)';
        return;
      }

      const key = getPointageKey(emp.id, d.date);
      const st = pointages[key];
      let displaySt = '-';
      if (st === 'present') displaySt = 'P (حاضر)';
      else if (st === 'rest') displaySt = 'R (راحة)';
      else if (st === 'absent') displaySt = 'A (غياب)';
      else if (st === 'leave_paid') displaySt = 'J (مرخص)';
      else if (st === 'half_day') displaySt = '0.5 (نصف)';

      row[colName] = displaySt;
    });

    // Summary columns
    row[lang === 'ar' ? 'أيام الحضور' : 'Jours Présence'] = calc.presentDays;
    row[lang === 'ar' ? 'أيام الراحة (4j)' : 'Jours Repos (4j)'] = calc.restDays;
    row[lang === 'ar' ? 'أيام الغياب' : 'Jours Absence'] = calc.absentDays;
    row[lang === 'ar' ? 'اقتطاع الغياب (DH)' : 'Déduction Absence (DH)'] = calc.totalAbsenceDeduction;
    if (bon > 0) row[lang === 'ar' ? 'المكافأة (DH)' : 'Prime (DH)'] = bon;
    if (adv > 0) row[lang === 'ar' ? 'التسبيق (DH)' : 'Avance (DH)'] = adv;
    row[lang === 'ar' ? 'صافي الأجر المستحق (DH)' : 'Net à Payer (DH)'] = calc.netSalary;

    rows.push(row);
  });

  const worksheet = XLSX.utils.json_to_sheet(rows);

  // Set column widths
  const colWidths = [
    { wch: 4 }, // #
    { wch: 24 }, // Name
    { wch: 14 }, // Role
    { wch: 14 }, // Start Date
    { wch: 10 }, // CIN
    { wch: 14 }, // Base
    { wch: 14 }, // Daily
  ];
  days.forEach(() => colWidths.push({ wch: 8 }));
  colWidths.push({ wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 16 }, { wch: 16 });
  worksheet['!cols'] = colWidths;

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, `Pointage ${monthKey}`);

  const fileName = `Pointage_Salaires_${monthKey}_${year}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}
