import { toPng } from 'html-to-image';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { Payment } from '../types';

/**
 * Builds standard file name for a receipt PDF
 */
export function getReceiptPdfFileName(receipt: Payment): string {
  const safeReceiptNo = (receipt.receiptNumber || 'REC').replace(/[^a-zA-Z0-9_-]/g, '_');
  const safeBld = (receipt.buildingCode || '').replace(/\s+/g, '_');
  const safeApt = (receipt.apartmentNumber || '').trim();
  const safeDate = (receipt.paymentDate || new Date().toISOString().slice(0, 10)).replace(/[^a-zA-Z0-9_-]/g, '-');
  return `Recu_Syndic_${safeReceiptNo}_${safeBld}_Apt${safeApt}_${safeDate}.pdf`;
}

/**
 * Captures an HTML element as high-resolution PNG Data URL,
 * safely handling modern CSS color spaces like OKLCH.
 */
async function captureElementToDataUrl(element: HTMLElement, scale = 2.5): Promise<string> {
  try {
    const dataUrl = await toPng(element, {
      pixelRatio: scale,
      backgroundColor: '#ffffff',
      cacheBust: false,
      skipAutoScale: true,
      skipFonts: true,
      fontEmbedCSS: '',
      style: {
        transform: 'none',
        boxShadow: 'none',
        margin: '0 auto',
      },
    });
    return dataUrl;
  } catch (primaryErr) {
    console.warn('html-to-image capture fallback triggered:', primaryErr);
    // Fallback: html2canvas with oklch sanitization in onclone
    const canvas = await html2canvas(element, {
      scale,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      onclone: (clonedDoc) => {
        const tempCanvas = clonedDoc.createElement('canvas');
        tempCanvas.width = 1;
        tempCanvas.height = 1;
        const ctx = tempCanvas.getContext('2d');

        const convertColor = (val: string): string => {
          if (!val || !val.includes('oklch')) return val;
          return val.replace(/oklch\([^)]+\)/g, (match) => {
            if (!ctx) return '#10b981';
            try {
              ctx.fillStyle = match;
              return ctx.fillStyle || '#10b981';
            } catch {
              return '#10b981';
            }
          });
        };

        clonedDoc.querySelectorAll('style').forEach(style => {
          if (style.textContent && style.textContent.includes('oklch')) {
            style.textContent = convertColor(style.textContent);
          }
        });

        clonedDoc.querySelectorAll('*').forEach(el => {
          const htmlEl = el as HTMLElement;
          const styleAttr = htmlEl.getAttribute('style');
          if (styleAttr && styleAttr.includes('oklch')) {
            htmlEl.setAttribute('style', convertColor(styleAttr));
          }
        });
      }
    });
    return canvas.toDataURL('image/png');
  }
}

/**
 * Generates a jsPDF instance from a DOM element
 */
export async function generateReceiptPdfDoc(
  receiptElementId: string,
  receipt: Payment
): Promise<jsPDF | null> {
  const element = document.getElementById(receiptElementId);
  if (!element) {
    console.error(`Element with id ${receiptElementId} not found.`);
    return null;
  }

  try {
    const imgData = await captureElementToDataUrl(element, 2.5);

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = (e) => reject(e);
      img.src = imgData;
    });

    const imgWidth = img.naturalWidth || img.width || 750;
    const imgHeight = img.naturalHeight || img.height || 1000;

    const pdfPageWidth = pdf.internal.pageSize.getWidth();
    const pdfPageHeight = pdf.internal.pageSize.getHeight();
    
    const margin = 10;
    const printableWidth = pdfPageWidth - margin * 2;
    const printableHeight = (imgHeight * printableWidth) / imgWidth;

    const startY = printableHeight < pdfPageHeight - margin * 2
      ? Math.max(margin, (pdfPageHeight - printableHeight) / 2)
      : margin;

    pdf.addImage(
      imgData,
      'PNG',
      margin,
      startY,
      printableWidth,
      printableHeight,
      undefined,
      'FAST'
    );

    return pdf;
  } catch (error) {
    console.error('Error generating PDF doc:', error);
    return null;
  }
}

/**
 * Exports the HTML receipt element to a high-resolution PDF file download.
 */
export async function downloadReceiptAsPdf(
  receiptElementId: string,
  receipt: Payment
): Promise<boolean> {
  try {
    const pdf = await generateReceiptPdfDoc(receiptElementId, receipt);
    if (!pdf) return false;
    const fileName = getReceiptPdfFileName(receipt);
    pdf.save(fileName);
    return true;
  } catch (error) {
    console.error('Error downloading PDF receipt:', error);
    return false;
  }
}

/**
 * Generates a File object representing the PDF receipt
 */
export async function generateReceiptPdfFile(
  receiptElementId: string,
  receipt: Payment
): Promise<File | null> {
  try {
    const pdf = await generateReceiptPdfDoc(receiptElementId, receipt);
    if (!pdf) return null;
    const blob = pdf.output('blob');
    const fileName = getReceiptPdfFileName(receipt);
    return new File([blob], fileName, { type: 'application/pdf' });
  } catch (err) {
    console.error('Error creating PDF File object:', err);
    return null;
  }
}

/**
 * Shares the PDF receipt file directly using native Web Share API (supports WhatsApp, Mail, AirDrop on Mobile)
 */
export async function shareReceiptPdf(
  receiptElementId: string,
  receipt: Payment,
  formattedPeriod: string
): Promise<{ success: boolean; sharedAsFile: boolean }> {
  try {
    const file = await generateReceiptPdfFile(receiptElementId, receipt);
    if (!file) return { success: false, sharedAsFile: false };

    const shareTitle = `وصل أداء السانديك N° ${receipt.receiptNumber}`;
    const shareText = `وصل أداء واجبات السانديك إقامة المرجان المنطقة 10 أبواب مراكش السكن المتوسط - ${receipt.buildingCode} شقة ${receipt.apartmentNumber} لشهر ${formattedPeriod} بمبلغ ${receipt.amount} درهم.`;

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        files: [file],
        title: shareTitle,
        text: shareText
      });
      return { success: true, sharedAsFile: true };
    } else if (navigator.share) {
      await downloadReceiptAsPdf(receiptElementId, receipt);
      await navigator.share({
        title: shareTitle,
        text: `${shareText}\n(تم تنزيل ملف الوصل PDF على جهازك لإرفاقه)`
      });
      return { success: true, sharedAsFile: false };
    } else {
      // Fallback: download the PDF
      await downloadReceiptAsPdf(receiptElementId, receipt);
      return { success: true, sharedAsFile: false };
    }
  } catch (err: any) {
    if (err.name === 'AbortError') {
      return { success: false, sharedAsFile: false };
    }
    console.error('Error in shareReceiptPdf:', err);
    return { success: false, sharedAsFile: false };
  }
}

/**
 * Builds WhatsApp sharing URL with text and recipient phone
 */
export function buildReceiptWhatsAppUrl(
  receipt: Payment,
  formattedPeriod: string,
  recipientPhone?: string
): string {
  const message = `*وصل أداء واجبات السانديك القانوني (Loi 18.00)*\n` +
    `🏢 *إقامة المرجان المنطقة 10 أبواب مراكش السكن المتوسط (GH 34 - GH 43)*\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `📄 *رقم الوصل:* ${receipt.receiptNumber}\n` +
    `👤 *الساكن / المالك:* ${receipt.residentName}\n` +
    `🏠 *الشقة:* ${receipt.buildingCode} - شقة ${receipt.apartmentNumber}\n` +
    `📅 *الفترة المؤداة:* ${formattedPeriod} (${receipt.periodMonth})\n` +
    `💰 *المبلغ المؤدى:* ${receipt.amount} درهم مغربي (MAD)\n` +
    `💳 *طريقة الأداء:* ${
      receipt.paymentMethod === 'cash' ? 'نقداً (Espèces)' :
      receipt.paymentMethod === 'bank_transfer' ? 'تحويل بنكي (Virement)' :
      receipt.paymentMethod === 'check' ? 'شيك بنكي (Chèque)' : 'أداء إلكتروني'
    }\n` +
    `🗓️ *تاريخ الأداء:* ${receipt.paymentDate}\n` +
    `✍️ *المستلم:* ${receipt.receivedBy || 'مكتب السانديك'}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `✅ *نشكركم على التزامكم ومساهمتكم في حسن تسيير وصيانة الإقامة.*`;

  const encodedText = encodeURIComponent(message);
  
  if (recipientPhone) {
    let clean = recipientPhone.replace(/\D/g, '');
    if (clean.startsWith('0')) {
      clean = '212' + clean.substring(1);
    } else if (!clean.startsWith('212') && clean.length === 9) {
      clean = '212' + clean;
    }
    return `https://wa.me/${clean}?text=${encodedText}`;
  }

  return `https://wa.me/?text=${encodedText}`;
}

/**
 * Builds Mailto URL with subject and pre-composed body
 */
export function buildReceiptEmailUrl(
  receipt: Payment,
  formattedPeriod: string,
  recipientEmail?: string
): string {
  const subject = `وصل أداء واجبات السانديك N° ${receipt.receiptNumber} - ${receipt.buildingCode} شقة ${receipt.apartmentNumber}`;
  const body = `السلام عليكم ورحمة الله وبركاته،

نرسل إليكم وصل أداء واجبات التسيير المشترك (السانديك) الخاص بشقتكم بإقامة المرجان المنطقة 10 أبواب مراكش السكن المتوسط:

- رقم الوصل: ${receipt.receiptNumber}
- المالك / الساكن: ${receipt.residentName}
- العمارة والشقة: ${receipt.buildingCode} - شقة ${receipt.apartmentNumber}
- الفترة المؤداة: ${formattedPeriod} (${receipt.periodMonth})
- المبلغ المؤدى: ${receipt.amount} درهم مغربي
- تاريخ الأداء: ${receipt.paymentDate}
- طريقة الأداء: ${receipt.paymentMethod}
- المستلم: ${receipt.receivedBy || 'مكتب السانديك'}

تجدون هذا الوصل مستخرجاً ومعتمداً بصيغة PDF.
نشكركم على حسن تعاونكم وتفهمكم.

مكتب السانديك — إقامة المرجان المنطقة 10 أبواب مراكش السكن المتوسط
(طبقا لمقتضيات القانون رقم 18.00 المتعلق بنظام الملكية المشتركة)`;

  const targetEmail = recipientEmail || '';
  return `mailto:${encodeURIComponent(targetEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

