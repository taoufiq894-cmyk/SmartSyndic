import { toPng } from 'html-to-image';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * Captures an HTML element as high-resolution PNG Data URL,
 * safely handling modern CSS color spaces like OKLCH.
 */
async function captureElementToDataUrl(element: HTMLElement, scale = 2): Promise<string> {
  try {
    const dataUrl = await toPng(element, {
      pixelRatio: scale,
      backgroundColor: '#ffffff',
      cacheBust: false,
      skipAutoScale: true,
      skipFonts: true,
      fontEmbedCSS: '',
      style: {
        transform: 'none',
        boxShadow: 'none',
        margin: '0 auto',
      },
    });
    return dataUrl;
  } catch (primaryErr) {
    console.warn('html-to-image capture fallback triggered:', primaryErr);
    // Fallback: html2canvas with oklch sanitization in onclone
    const canvas = await html2canvas(element, {
      scale,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      onclone: (clonedDoc) => {
        const tempCanvas = clonedDoc.createElement('canvas');
        tempCanvas.width = 1;
        tempCanvas.height = 1;
        const ctx = tempCanvas.getContext('2d');

        const convertColor = (val: string): string => {
          if (!val || !val.includes('oklch')) return val;
          return val.replace(/oklch\([^)]+\)/g, (match) => {
            if (!ctx) return '#10b981';
            try {
              ctx.fillStyle = match;
              return ctx.fillStyle || '#10b981';
            } catch {
              return '#10b981';
            }
          });
        };

        clonedDoc.querySelectorAll('style').forEach(style => {
          if (style.textContent && style.textContent.includes('oklch')) {
            style.textContent = convertColor(style.textContent);
          }
        });

        clonedDoc.querySelectorAll('*').forEach(el => {
          const htmlEl = el as HTMLElement;
          const styleAttr = htmlEl.getAttribute('style');
          if (styleAttr && styleAttr.includes('oklch')) {
            htmlEl.setAttribute('style', convertColor(styleAttr));
          }
        });
      }
    });
    return canvas.toDataURL('image/png');
  }
}

/**
 * Exports any element to a high-resolution, multi-page ready PDF file.
 */
export async function exportElementToPdf(
  elementId: string,
  fileNamePrefix: string
): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id ${elementId} not found.`);
    return false;
  }

  try {
    const imgData = await captureElementToDataUrl(element, 2);

    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = (e) => reject(e);
      img.src = imgData;
    });

    const imgWidth = img.naturalWidth || img.width || 1000;
    const imgHeight = img.naturalHeight || img.height || 1400;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pdfPageWidth = pdf.internal.pageSize.getWidth(); 
    const pdfPageHeight = pdf.internal.pageSize.getHeight(); 
    const margin = 8; 
    const contentWidth = pdfPageWidth - margin * 2; 
    
    const imgHeightInPdf = (imgHeight * contentWidth) / imgWidth;

    let heightLeft = imgHeightInPdf;
    let position = margin;
    let pageNumber = 1;

    pdf.addImage(imgData, 'PNG', margin, position, contentWidth, imgHeightInPdf, undefined, 'FAST');
    heightLeft -= (pdfPageHeight - margin * 2);

    while (heightLeft > 0) {
      position = margin - (pageNumber * (pdfPageHeight - margin * 2));
      pdf.addPage();
      pageNumber++;
      pdf.addImage(imgData, 'PNG', margin, position, contentWidth, imgHeightInPdf, undefined, 'FAST');
      heightLeft -= (pdfPageHeight - margin * 2);
    }

    const dateStr = new Date().toISOString().split('T')[0];
    const fileName = `${fileNamePrefix}_AlMarjane_Abwab_Marrakech_Zone10_${dateStr}.pdf`;

    pdf.save(fileName);
    return true;
  } catch (error) {
    console.error('Error generating PDF:', error);
    return false;
  }
}

/**
 * Exports the financial report element to a high-resolution, multi-page ready PDF file.
 */
export async function exportMonthlyFinancialReportToPdf(
  reportElementId: string,
  periodTitle: string,
  reportType: 'monthly' | 'annual' | 'custom_period' = 'monthly'
): Promise<boolean> {
  const element = document.getElementById(reportElementId);
  if (!element) {
    console.error(`Element with id ${reportElementId} not found.`);
    return false;
  }

  try {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pdfPageWidth = pdf.internal.pageSize.getWidth(); // 210 mm
    const pdfPageHeight = pdf.internal.pageSize.getHeight(); // 297 mm
    const margin = 8; // 8mm margin
    const contentWidth = pdfPageWidth - margin * 2; // 194 mm
    const maxPageContentHeight = pdfPageHeight - margin * 2; // 281 mm

    const pageBlocks = element.querySelectorAll<HTMLElement>('.pdf-page-block');

    if (pageBlocks.length > 0) {
      // Capture each logical page block as a dedicated, uncut page
      for (let i = 0; i < pageBlocks.length; i++) {
        const block = pageBlocks[i];
        if (i > 0) {
          pdf.addPage();
        }

        const imgData = await captureElementToDataUrl(block, 2);
        const img = new Image();
        await new Promise<void>((resolve, reject) => {
          img.onload = () => resolve();
          img.onerror = (e) => reject(e);
          img.src = imgData;
        });

        const imgWidth = img.naturalWidth || img.width || 1000;
        const imgHeight = img.naturalHeight || img.height || 1400;
        const imgHeightInPdf = (imgHeight * contentWidth) / imgWidth;

        // Scale down if slightly taller than printable height to ensure no overflow
        const finalWidth = imgHeightInPdf > maxPageContentHeight 
          ? (contentWidth * maxPageContentHeight) / imgHeightInPdf 
          : contentWidth;
        const finalHeight = Math.min(imgHeightInPdf, maxPageContentHeight);
        const xOffset = margin + (contentWidth - finalWidth) / 2;

        pdf.addImage(
          imgData,
          'PNG',
          xOffset,
          margin,
          finalWidth,
          finalHeight,
          undefined,
          'FAST'
        );
      }
    } else {
      // Fallback single image slicing
      const imgData = await captureElementToDataUrl(element, 2);

      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = (e) => reject(e);
        img.src = imgData;
      });

      const imgWidth = img.naturalWidth || img.width || 1000;
      const imgHeight = img.naturalHeight || img.height || 1400;
      const imgHeightInPdf = (imgHeight * contentWidth) / imgWidth;

      let heightLeft = imgHeightInPdf;
      let position = margin;
      let pageNumber = 1;

      pdf.addImage(
        imgData,
        'PNG',
        margin,
        position,
        contentWidth,
        imgHeightInPdf,
        undefined,
        'FAST'
      );

      heightLeft -= (pdfPageHeight - margin * 2);

      while (heightLeft > 0) {
        position = margin - (pageNumber * (pdfPageHeight - margin * 2));
        pdf.addPage();
        pageNumber++;
        pdf.addImage(
          imgData,
          'PNG',
          margin,
          position,
          contentWidth,
          imgHeightInPdf,
          undefined,
          'FAST'
        );
        heightLeft -= (pdfPageHeight - margin * 2);
      }
    }

    // Clean safe filename with exact residence branding
    const safePeriod = periodTitle.replace(/[^a-zA-Z0-9_-]/g, '_');
    const prefix = reportType === 'annual' 
      ? 'Rapport_Financier_Annuel' 
      : reportType === 'custom_period'
        ? 'Rapport_Financier_Periode'
        : 'Rapport_Financier_Mensuel';
    const fileName = `${prefix}_AlMarjane_Abwab_Marrakech_Zone10_${safePeriod}.pdf`;

    pdf.save(fileName);
    return true;
  } catch (error) {
    console.error('Error generating Financial PDF Report:', error);
    return false;
  }
}

/**
 * Exports financial report data as a cleanly formatted CSV spreadsheet (compatible with Excel/Sheets).
 */
export function exportFinancialReportToCSV(data: {
  residenceName: string;
  reportType: string;
  period: string;
  totalIncome: number;
  totalExpenses: number;
  netBalance: number;
  collectionRate: number;
  previousCarriedBalance?: number;
  finalClosingBalance?: number;
  previousMonthName?: string;
  nextMonthName?: string;
  monthlyCarryoverChain?: Array<{
    month: string;
    openingBalance: number;
    income: number;
    expenses: number;
    monthNet: number;
    closingBalance: number;
    status: string;
  }>;
  syndicDues?: number;
  officialCategories?: Array<{
    number: number;
    title: string;
    description: string;
    amount: number;
    percentage: number;
    invoicesCount: number;
  }>;
  expensesByCategory: Array<{
    name: string;
    amount: number;
    percentage: number;
  }>;
  expenses: Array<{
    date: string;
    title: string;
    category: string;
    supplier: string;
    buildingCode: string;
    amount: number;
  }>;
}) {
  const rows: string[] = [];

  // UTF-8 BOM for Excel Arabic character compatibility
  const BOM = '\uFEFF';

  // Header Title
  rows.push(`"المملكة المغربية - إقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10"`);
  rows.push(`"${data.reportType} - الفترة: ${data.period}"`);
  rows.push(`"تاريخ الاستخراج: ${new Date().toISOString().slice(0, 10)}"`);
  rows.push('');

  // Global KPIs & Carryover Summary
  rows.push('"المؤشرات المالية العامة وترحيل الأرصدة (Report à Nouveau)"');
  if (data.previousCarriedBalance !== undefined) {
    const prevLabel = data.previousMonthName ? `الرصيد المنقول من الشهر السابق (${data.previousMonthName})` : 'الرصيد المنقول من الفترة السابقة';
    rows.push(`"${prevLabel}","${data.previousCarriedBalance}"`);
  }
  rows.push(`"إجمالي المداخيل والمقبوضات المحصلة (درهم)","${data.totalIncome}"`);
  rows.push(`"إجمالي المصاريف والنفقات المؤداة (درهم)","${data.totalExpenses}"`);
  rows.push(`"رصيد الفترة الصافي (فائض أو عجز الفترة) (درهم)","${data.netBalance}"`);
  if (data.finalClosingBalance !== undefined) {
    const nextLabel = data.nextMonthName ? `الرصيد الإجمالي النهائي في نهاية الفترة (يُرحّل إلى ${data.nextMonthName})` : 'الرصيد الإجمالي النهائي المرحّل للفترة الموالية';
    rows.push(`"${nextLabel}","${data.finalClosingBalance}"`);
  }
  rows.push(`"نسبة التحصيل العامة (%)","${data.collectionRate}%"`);
  if (data.syndicDues !== undefined) {
    rows.push(`"أجرة تسيير وكيل السانديك ونائبه (درهم)","${data.syndicDues}"`);
  }
  rows.push('');

  // Carryover Chain Table if available
  if (data.monthlyCarryoverChain && data.monthlyCarryoverChain.length > 0) {
    rows.push('"جدول تتبع ترحيل الفائض والناقص من شهر لآخر (سجل الترحيل الشهري - Report à Nouveau)"');
    rows.push('"الشهر","الرصيد المنقول في بداية الشهر","المقبوضات (+)","المصاريف (-)","رصيد الشهر الخالص (=)","الرصيد الختامي المرحّل للشهر الموالي","الوضعية"');
    data.monthlyCarryoverChain.forEach(item => {
      rows.push(`"${item.month}","${item.openingBalance}","${item.income}","${item.expenses}","${item.monthNet}","${item.closingBalance}","${item.status}"`);
    });
    rows.push('');
  }

  // 10 Official Expense Categories Breakdown
  if (data.officialCategories && data.officialCategories.length > 0) {
    rows.push('"جدول تبويب المصاريف الرسمية (الأبواب العشرة المعتمدة)"');
    rows.push('"الرقم","باب المصروف","البيان والتفصيل المحاسبي","عدد العمليات / الفواتير","المبلغ (درهم)","النسبة المئوية (%)"');
    data.officialCategories.forEach(cat => {
      rows.push(`"${cat.number}","${cat.title}","${cat.description}","${cat.invoicesCount}","${cat.amount}","${cat.percentage}%"`);
    });
    rows.push(`"المجموع الإجمالي لكافة المصاريف","","","","${data.totalExpenses}","100%"`);
    rows.push('');
  }

  // Expenses by Category
  rows.push('"توزيع المصاريف حسب الخدمة المسجلة"');
  rows.push('"نوع النفقة / الخدمة","المبلغ (درهم)","النسبة المئوية"');
  data.expensesByCategory.forEach(c => {
    rows.push(`"${c.name}","${c.amount}","${c.percentage}%"`);
  });
  rows.push('');

  // Invoices log
  rows.push('"سجل فواتير المصاريف والنفقات"');
  rows.push('"التاريخ","بيان المصروف","النوع","المورد","العمارة","المبلغ (درهم)"');
  data.expenses.forEach(e => {
    rows.push(`"${e.date}","${e.title}","${e.category}","${e.supplier}","${e.buildingCode}","${e.amount}"`);
  });

  const csvContent = BOM + rows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const safePeriod = data.period.replace(/[^a-zA-Z0-9_-]/g, '_');
  link.setAttribute('download', `Rapport_Financier_AlMarjane_Abwab_Marrakech_Zone10_${safePeriod}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Exports the monthly residents report element to a high-resolution, multi-page ready PDF file.
 */
export async function exportMonthlyResidentsReportToPdf(
  reportElementId: string,
  periodTitle: string,
  buildingCode = 'ALL'
): Promise<boolean> {
  const element = document.getElementById(reportElementId);
  if (!element) {
    console.error(`Element with id ${reportElementId} not found.`);
    return false;
  }

  try {
    const imgData = await captureElementToDataUrl(element, 2.2);

    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = (e) => reject(e);
      img.src = imgData;
    });

    const imgWidth = img.naturalWidth || img.width || 1000;
    const imgHeight = img.naturalHeight || img.height || 1400;

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pdfPageWidth = pdf.internal.pageSize.getWidth(); // 210 mm
    const pdfPageHeight = pdf.internal.pageSize.getHeight(); // 297 mm
    const margin = 8; // 8mm margin
    const contentWidth = pdfPageWidth - margin * 2; // 194 mm
    
    // Calculate total height of the rendered image in PDF units
    const imgHeightInPdf = (imgHeight * contentWidth) / imgWidth;

    let heightLeft = imgHeightInPdf;
    let position = margin;
    let pageNumber = 1;

    // First page
    pdf.addImage(
      imgData,
      'PNG',
      margin,
      position,
      contentWidth,
      imgHeightInPdf,
      undefined,
      'FAST'
    );

    heightLeft -= (pdfPageHeight - margin * 2);

    // Multi-page slicing if table/content exceeds single A4 page
    while (heightLeft > 0) {
      position = margin - (pageNumber * (pdfPageHeight - margin * 2));
      pdf.addPage();
      pageNumber++;
      pdf.addImage(
        imgData,
        'PNG',
        margin,
        position,
        contentWidth,
        imgHeightInPdf,
        undefined,
        'FAST'
      );
      heightLeft -= (pdfPageHeight - margin * 2);
    }

    const safePeriod = periodTitle.replace(/[^a-zA-Z0-9_-]/g, '_');
    const safeBld = buildingCode === 'ALL' ? 'Toutes_Immeubles' : `Immeuble_${buildingCode.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    const fileName = `Rapport_Mensuel_Coproprietaires_AlMarjane_${safeBld}_${safePeriod}.pdf`;

    pdf.save(fileName);
    return true;
  } catch (error) {
    console.error('Error generating Residents PDF Report:', error);
    return false;
  }
}

/**
 * Exports monthly resident report data as CSV spreadsheet
 */
export function exportResidentsReportToCSV(data: {
  residenceName: string;
  period: string;
  buildingFilter: string;
  totalApartments: number;
  paidCount: number;
  unpaidCount: number;
  collectionRate: number;
  totalCollected: number;
  totalExpenses: number;
  netReserve: number;
  apartmentsData: Array<{
    apartmentNumber: string;
    buildingCode: string;
    ownerName: string;
    status: string;
    amountPaid: number;
    monthlyFee: number;
    accumulatedDebt: number;
    notes?: string;
  }>;
}) {
  const rows: string[] = [];
  const BOM = '\uFEFF';

  // Header Title
  rows.push(`"المملكة المغربية - إقامة المرجان السكن المتوسط ابواب مراكش المنطقة 10"`);
  rows.push(`"التقرير الشهري للسكان والملاك المشتركين - كشف استخلاص واجبات السانديك"`);
  rows.push(`"الفترة: ${data.period} | نطاق العمارات: ${data.buildingFilter === 'ALL' ? 'كافة العمارات (20 عمارة)' : data.buildingFilter}"`);
  rows.push(`"تاريخ الاستخراج: ${new Date().toISOString().slice(0, 10)}"`);
  rows.push('');

  // Summary Metrics
  rows.push('"الملخص المالي والإداري للشهر"');
  rows.push(`"إجمالي عدد الشقق المسجلة","${data.totalApartments}"`);
  rows.push(`"عدد الشقق المستوفية للواجب (مدفوع)","${data.paidCount}"`);
  rows.push(`"عدد الشقق المتأخرة عن الدفع","${data.unpaidCount}"`);
  rows.push(`"نسبة الاستخلاص للشهر","${data.collectionRate}%"`);
  rows.push(`"مجموع واجبات السانديك المحصلة (درهم)","${data.totalCollected}"`);
  rows.push(`"مجموع مصاريف الخدمات والصيانة المنجزة (درهم)","${data.totalExpenses}"`);
  rows.push(`"الرصيد الصافي المتبقي في الصندوق (درهم)","${data.netReserve}"`);
  rows.push('');

  // Table rows
  rows.push('"جدول استخلاص الشقق والملاك"');
  rows.push('"رقم الشقة","العمارة","اسم المالك / الساكن","الواجب الشهري (درهم)","حالة الأداء للشهر","المبلغ المدفوع (درهم)","المتأخرات التراكمية (درهم)","ملاحظات"');
  data.apartmentsData.forEach(item => {
    rows.push(`"${item.apartmentNumber}","${item.buildingCode}","${item.ownerName}","${item.monthlyFee}","${item.status}","${item.amountPaid}","${item.accumulatedDebt}","${item.notes || '-'}"`);
  });

  const csvContent = BOM + rows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  const safePeriod = data.period.replace(/[^a-zA-Z0-9_-]/g, '_');
  link.setAttribute('download', `Rapport_Coproprietaires_AlMarjane_${safePeriod}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

