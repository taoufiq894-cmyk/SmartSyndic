import { Apartment } from '../types';

/**
 * Syndic Access & Financial Status:
 * - يسمح فقط للملاك المتأخرين بأربعة أشهر أو أقل (0 إلى 4 أشهر) عن أداء واجبات السانديك بالدخول إلى التطبيق.
 * - أكثر من 4 أشهر (5 أشهر فما فوق) يمنعون من الدخول.
 * - تنبيه المنع: "يجب أداء ما بذمتكم مستحقات السنديك لتتمكنو ا من الدخول الى التطبيق".
 * - وحدة مكتب السانديك (GH 34 A شقة 01) هي وحدة الإدارة ومعفاة من الواجبات.
 */
export const MAX_ALLOWED_UNPAID_MONTHS = 4; // الحد الأقصى المسموح به للتأخير للدخول للتطبيق (4 أشهر)
export const SUSPENSION_MONTHS_THRESHOLD = 5; // أكثر من 4 أشهر (5 أشهر فما فوق) يمنعون من الدخول

export const DEBT_RESTRICTION_ALERT_AR = 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق';
export const DEBT_RESTRICTION_ALERT_FR = 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';

export interface DebtStatus {
  isBlocked: boolean; // true if unpaidMonths > MAX_ALLOWED_UNPAID_MONTHS (أكثر من 4 أشهر)
  unpaidMonths: number;
  totalBalanceDue: number;
  monthlyFee: number;
  maxAllowedMonths: number;
  maxAllowedDebt: number;
  excessMonths: number;
  minAmountToUnblock: number;
  isPaid: boolean; // true if settled / fully paid for current reference period
  isOffice: boolean; // true if Syndic Office
  statusLabelAr: string;
  statusLabelFr: string;
  restrictionMessageAr?: string;
  restrictionMessageFr?: string;
}

/**
 * Calculates debt status for an apartment.
 * Takes into account recorded payments in the application.
 */
export function getApartmentDebtStatus(apt?: Apartment | null, allPayments?: { buildingCode: string; apartmentNumber: string; periodMonth: string; amount?: number }[]): DebtStatus {
  if (!apt) {
    return {
      isBlocked: false,
      unpaidMonths: 0,
      totalBalanceDue: 0,
      monthlyFee: 150,
      maxAllowedMonths: MAX_ALLOWED_UNPAID_MONTHS,
      maxAllowedDebt: 150 * MAX_ALLOWED_UNPAID_MONTHS,
      excessMonths: 0,
      minAmountToUnblock: 0,
      isPaid: true,
      isOffice: false,
      statusLabelAr: 'عادي (لا توجد مديونية) 🟢',
      statusLabelFr: 'À jour (Aucun retard) 🟢',
    };
  }

  // If this unit is the Syndic Office, it is never blocked and has no fees
  if (apt.isSyndicOffice || (apt.buildingCode === 'GH 34 A' && apt.number === '01')) {
    return {
      isBlocked: false,
      unpaidMonths: 0,
      totalBalanceDue: 0,
      monthlyFee: 0,
      maxAllowedMonths: MAX_ALLOWED_UNPAID_MONTHS,
      maxAllowedDebt: 0,
      excessMonths: 0,
      minAmountToUnblock: 0,
      isPaid: true,
      isOffice: true,
      statusLabelAr: 'مكتب السانديك (معفى)',
      statusLabelFr: 'Bureau Syndic (Exonéré)',
    };
  }

  const monthlyFee = Number(apt.monthlyFee) > 0 ? Number(apt.monthlyFee) : 150;
  const maxAllowedDebt = monthlyFee * MAX_ALLOWED_UNPAID_MONTHS;

  const rawBalance = Number(apt.balanceDue) || 0;
  const rawUnpaidMonths = Number(apt.unpaidMonthsCount) || 0;

  // 1. Inspect payments array if provided
  const aptPayments = (allPayments && allPayments.length > 0)
    ? allPayments.filter(p => 
        p.buildingCode?.replace(/\s+/g, ' ').trim().toLowerCase() === apt.buildingCode?.replace(/\s+/g, ' ').trim().toLowerCase() && 
        String(p.apartmentNumber).trim() === String(apt.number).trim()
      )
    : [];

  let paymentDerivedUnpaidMonths: number | null = null;
  if (aptPayments.length > 0) {
    let latestPaidTotalMonths = -1;
    for (const p of aptPayments) {
      const parsed = parsePeriodYearMonth(p.periodMonth);
      if (parsed) {
        const tm = parsed.year * 12 + (parsed.month - 1);
        if (tm > latestPaidTotalMonths) {
          latestPaidTotalMonths = tm;
        }
      }
    }

    if (latestPaidTotalMonths >= 0) {
      const currentTotalMonths = CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1);
      paymentDerivedUnpaidMonths = Math.max(0, currentTotalMonths - latestPaidTotalMonths);
    }
  }

  let unpaidMonths = 1;
  let totalBalanceDue = monthlyFee;
  let isPaid = false;

  // The Syndic explicitly defines debt, or payments indicate debt status
  if (paymentDerivedUnpaidMonths !== null && (rawBalance === 0 && rawUnpaidMonths === 0)) {
    // Rely directly on payments history if no manual override is entered
    unpaidMonths = paymentDerivedUnpaidMonths;
    totalBalanceDue = unpaidMonths * monthlyFee;
    isPaid = unpaidMonths === 0;
  } else if (rawBalance > 0 || rawUnpaidMonths > 0) {
    if (rawUnpaidMonths > 0) {
      unpaidMonths = rawUnpaidMonths;
      totalBalanceDue = rawBalance > 0 ? rawBalance : (unpaidMonths * monthlyFee);
    } else {
      totalBalanceDue = rawBalance;
      unpaidMonths = Math.max(1, Math.round(totalBalanceDue / monthlyFee));
    }
    // If recent payments occurred that cover this debt, reflect it
    if (paymentDerivedUnpaidMonths !== null && paymentDerivedUnpaidMonths < unpaidMonths) {
      unpaidMonths = paymentDerivedUnpaidMonths;
      totalBalanceDue = unpaidMonths * monthlyFee;
    }
    isPaid = unpaidMonths === 0 && totalBalanceDue === 0;
  } else {
    // Clean / Normal: No debt entered by syndic
    unpaidMonths = 1;
    totalBalanceDue = monthlyFee;
    isPaid = false;
  }

  // Access blocking: strictly only up to 4 months delay allowed. More than 4 months (> 4) are blocked.
  const isBlocked = unpaidMonths > MAX_ALLOWED_UNPAID_MONTHS;
  const excessMonths = Math.max(0, unpaidMonths - MAX_ALLOWED_UNPAID_MONTHS);
  const minAmountToUnblock = excessMonths * monthlyFee;

  let statusLabelAr = '';
  let statusLabelFr = '';
  if (isPaid) {
    statusLabelAr = 'عادي (خالص ومسوى) 🟢';
    statusLabelFr = 'À jour (Aucun retard) 🟢';
  } else if (isBlocked) {
    statusLabelAr = `ممنوع من الدخول ⛔ (متأخر ${unpaidMonths} أشهر - أكثر من 4 أشهر)`;
    statusLabelFr = `Accès Bloqué ⛔ (${unpaidMonths} mois - > 4 mois)`;
  } else if (unpaidMonths === 1) {
    statusLabelAr = 'مديون بشهر واحد (مسموح بالدخول ✅)';
    statusLabelFr = 'Non réglé (1 mois - Accès autorisé ✅)';
  } else {
    statusLabelAr = `متأخر ${unpaidMonths} أشهر (مسموح بالدخول ✅)`;
    statusLabelFr = `En retard de ${unpaidMonths} mois (Accès autorisé ✅)`;
  }

  return {
    isBlocked,
    unpaidMonths,
    totalBalanceDue,
    monthlyFee,
    maxAllowedMonths: MAX_ALLOWED_UNPAID_MONTHS,
    maxAllowedDebt,
    excessMonths,
    minAmountToUnblock,
    isPaid,
    isOffice: false,
    statusLabelAr,
    statusLabelFr,
    restrictionMessageAr: isBlocked ? DEBT_RESTRICTION_ALERT_AR : undefined,
    restrictionMessageFr: isBlocked ? DEBT_RESTRICTION_ALERT_FR : undefined,
  };
}

/**
 * Reference Current Date for Syndic Management: August 2026 (أغسطس / غشت 2026)
 */
export const CURRENT_REFERENCE_YEAR = 2026;
export const CURRENT_REFERENCE_MONTH = 8; // August / غشت / أغسطس

export const MONTH_NAMES_AR = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export const MONTH_NAMES_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
];

/**
 * Parses any period string into year and month numbers.
 * Supports:
 * - "2026-06" (YYYY-MM)
 * - "06-2026" (MM-YYYY)
 * - "2026/06" or "06/2026"
 * - "يونيو 2026" or "Juin 2026"
 * - Ranges like "2026-06 إلى 2026-08" or "06-2026 إلى 08-2026" (extracts the latest covered month)
 */
export function parsePeriodYearMonth(periodStr?: string | null): { year: number; month: number } | null {
  if (!periodStr || typeof periodStr !== 'string') return null;
  const clean = periodStr.trim();
  if (!clean) return null;

  // Handle range (e.g. "2026-06 إلى 2026-08" or "06-2026 إلى 08-2026" or "à")
  if (clean.includes('إلى') || clean.includes(' à ') || clean.includes(' to ') || clean.includes(' - ')) {
    const parts = clean.split(/إلى| à | to | - /);
    const lastPart = parts[parts.length - 1].trim();
    const parsedLast = parsePeriodYearMonth(lastPart);
    if (parsedLast) return parsedLast;
  }

  // Check for Month Name in Arabic or French
  for (let m = 0; m < 12; m++) {
    const arName = MONTH_NAMES_AR[m];
    const frName = MONTH_NAMES_FR[m];
    if (clean.includes(arName) || clean.toLowerCase().includes(frName.toLowerCase())) {
      const yearMatch = clean.match(/\b(20\d\d)\b/);
      const year = yearMatch ? parseInt(yearMatch[1], 10) : CURRENT_REFERENCE_YEAR;
      return { year, month: m + 1 };
    }
  }

  // Check for "غشت" (Moroccan Arabic for August) or "شتنبر" (September) or "دجنبر" (December)
  if (clean.includes('غشت') || clean.includes('اوت')) {
    const yearMatch = clean.match(/\b(20\d\d)\b/);
    return { year: yearMatch ? parseInt(yearMatch[1], 10) : CURRENT_REFERENCE_YEAR, month: 8 };
  }
  if (clean.includes('شتنبر')) {
    const yearMatch = clean.match(/\b(20\d\d)\b/);
    return { year: yearMatch ? parseInt(yearMatch[1], 10) : CURRENT_REFERENCE_YEAR, month: 9 };
  }
  if (clean.includes('دجنبر')) {
    const yearMatch = clean.match(/\b(20\d\d)\b/);
    return { year: yearMatch ? parseInt(yearMatch[1], 10) : CURRENT_REFERENCE_YEAR, month: 12 };
  }

  // Match YYYY-MM or MM-YYYY with separator (- or /)
  const sepMatch = clean.match(/^(\d{1,4})[-/](\d{1,4})$/);
  if (sepMatch) {
    const p1 = parseInt(sepMatch[1], 10);
    const p2 = parseInt(sepMatch[2], 10);

    // Case 1: YYYY-MM (e.g. 2026-06)
    if (p1 >= 2000 && p1 <= 2099 && p2 >= 1 && p2 <= 12) {
      return { year: p1, month: p2 };
    }
    // Case 2: MM-YYYY (e.g. 06-2026) -> User screenshot!
    if (p2 >= 2000 && p2 <= 2099 && p1 >= 1 && p1 <= 12) {
      return { year: p2, month: p1 };
    }
  }

  return null;
}

/**
 * Computes months late for any given payment period relative to August 2026.
 * Example:
 * - "06-2026" / "2026-06" (June 2026) -> 2 months late (unpaid: July & August 2026)
 * - "07-2026" / "2026-07" (July 2026) -> 1 month late (unpaid: August 2026)
 * - "08-2026" / "2026-08" (August 2026) -> 0 months late (up to date)
 * - "01-2026" / "2026-01" (January 2026) -> 7 months late (blocked)
 */
export function calculateMonthsLateFromPeriod(periodStr?: string | null): {
  monthsLate: number;
  year: number;
  month: number;
  isBlocked: boolean;
  periodLabelAr: string;
  periodLabelFr: string;
} {
  const parsed = parsePeriodYearMonth(periodStr);
  if (!parsed) {
    return {
      monthsLate: 0,
      year: CURRENT_REFERENCE_YEAR,
      month: CURRENT_REFERENCE_MONTH,
      isBlocked: false,
      periodLabelAr: periodStr || `أغسطس ${CURRENT_REFERENCE_YEAR}`,
      periodLabelFr: periodStr || `Août ${CURRENT_REFERENCE_YEAR}`
    };
  }

  const totalCurrentMonths = CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1);
  const totalPeriodMonths = parsed.year * 12 + (parsed.month - 1);
  const monthsLate = Math.max(0, totalCurrentMonths - totalPeriodMonths);
  const isBlocked = monthsLate >= SUSPENSION_MONTHS_THRESHOLD;

  const monthIdx = parsed.month - 1;
  const periodLabelAr = `${MONTH_NAMES_AR[monthIdx]} ${parsed.year}`;
  const periodLabelFr = `${MONTH_NAMES_FR[monthIdx]} ${parsed.year}`;

  return {
    monthsLate,
    year: parsed.year,
    month: parsed.month,
    isBlocked,
    periodLabelAr,
    periodLabelFr
  };
}

/**
 * Calculates months late by subtracting last paid month from current date (August 2026).
 * Example:
 * - Last paid: June 2026 (Month 6) -> August 2026 (Month 8) - June 2026 (Month 6) = 2 months late.
 * - Last paid: December 2025 -> (2026-2025)*12 + (8 - 12) = 8 months late.
 */
export function calculateMonthsLateFromDate(lastPaidYear: number, lastPaidMonth: number): number {
  return Math.max(0, (CURRENT_REFERENCE_YEAR - lastPaidYear) * 12 + (CURRENT_REFERENCE_MONTH - lastPaidMonth));
}

/**
 * Returns the YYYY-MM key for the last paid month based on unpaid months.
 * Example: unpaidMonths = 2 -> 2026-06 (June 2026)
 *          unpaidMonths = 1 -> 2026-07 (July 2026)
 *          unpaidMonths = 0 -> 2026-08 (August 2026)
 */
export function getLastPaidMonthKey(unpaidMonths: number): string {
  if (unpaidMonths <= 0) {
    return `${CURRENT_REFERENCE_YEAR}-${String(CURRENT_REFERENCE_MONTH).padStart(2, '0')}`;
  }
  const totalMonths = (CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1)) - unpaidMonths;
  const year = Math.floor(totalMonths / 12);
  const monthNum = (totalMonths % 12) + 1;
  return `${year}-${String(monthNum).padStart(2, '0')}`;
}

/**
 * Returns the YYYY-MM key for the earliest unpaid/due month.
 * Example:
 * - unpaidMonths = 2 -> 2026-07 (July 2026 needs to be paid first)
 * - unpaidMonths = 1 -> 2026-08 (August 2026 needs to be paid)
 * - unpaidMonths = 0 -> 2026-08 (or current month)
 */
export function getEarliestUnpaidMonthKey(unpaidMonths: number): string {
  if (unpaidMonths <= 0) {
    return `${CURRENT_REFERENCE_YEAR}-${String(CURRENT_REFERENCE_MONTH).padStart(2, '0')}`;
  }
  // Earliest unpaid is (last paid month + 1)
  const totalMonths = (CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1)) - unpaidMonths + 1;
  const year = Math.floor(totalMonths / 12);
  const monthNum = (totalMonths % 12) + 1;
  return `${year}-${String(monthNum).padStart(2, '0')}`;
}

export interface UnpaidMonthItem {
  key: string; // "2026-07"
  year: number;
  monthNum: number;
  labelAr: string; // "يوليو 2026"
  labelFr: string; // "Juillet 2026"
  monthNameAr: string;
  monthNameFr: string;
}

/**
 * Returns a detailed list of all unpaid months for an apartment from earliest to current.
 */
export function getUnpaidMonthsList(unpaidMonths: number): UnpaidMonthItem[] {
  if (unpaidMonths <= 0) {
    return [];
  }

  const items: UnpaidMonthItem[] = [];
  for (let i = unpaidMonths; i >= 1; i--) {
    const totalMonths = (CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1)) - i + 1;
    const year = Math.floor(totalMonths / 12);
    const monthIndex = totalMonths % 12;
    const monthNum = monthIndex + 1;
    const key = `${year}-${String(monthNum).padStart(2, '0')}`;
    items.push({
      key,
      year,
      monthNum,
      labelAr: `${MONTH_NAMES_AR[monthIndex]} ${year}`,
      labelFr: `${MONTH_NAMES_FR[monthIndex]} ${year}`,
      monthNameAr: MONTH_NAMES_AR[monthIndex],
      monthNameFr: MONTH_NAMES_FR[monthIndex]
    });
  }

  return items;
}

/**
 * Formats any YYYY-MM, MM-YYYY or range string into beautiful localized representation.
 * E.g. "06-2026" -> "يونيو 2026" (ar) / "Juin 2026" (fr)
 * E.g. "2026-06 إلى 2026-08" -> "من يونيو 2026 إلى أغسطس 2026"
 */
export function formatPeriodDisplay(periodKey: string, lang: string = 'ar'): string {
  if (!periodKey) return '';
  const clean = periodKey.trim();

  // Handle Range
  if (clean.includes('إلى') || clean.includes(' à ')) {
    const parts = clean.split(/إلى| à /);
    if (parts.length === 2) {
      const p1 = parsePeriodYearMonth(parts[0].trim());
      const p2 = parsePeriodYearMonth(parts[1].trim());
      if (p1 && p2) {
        if (lang === 'ar') {
          return `من ${MONTH_NAMES_AR[p1.month - 1]} ${p1.year} إلى ${MONTH_NAMES_AR[p2.month - 1]} ${p2.year}`;
        } else {
          return `Du ${MONTH_NAMES_FR[p1.month - 1]} ${p1.year} au ${MONTH_NAMES_FR[p2.month - 1]} ${p2.year}`;
        }
      }
    }
    return clean;
  }

  const parsed = parsePeriodYearMonth(clean);
  if (parsed) {
    if (lang === 'ar') {
      return `${MONTH_NAMES_AR[parsed.month - 1]} ${parsed.year}`;
    }
    return `${MONTH_NAMES_FR[parsed.month - 1]} ${parsed.year}`;
  }

  return clean;
}

/**
 * Derives the last paid month string from unpaid months count relative to August 2026.
 */
export function getLastPaidMonthDisplay(unpaidMonths: number, lang: string = 'ar'): string {
  if (unpaidMonths <= 0) {
    return lang === 'ar' ? `أغسطس ${CURRENT_REFERENCE_YEAR}` : `Août ${CURRENT_REFERENCE_YEAR}`;
  }
  
  // Subtract unpaid months from August 2026:
  const totalMonths = (CURRENT_REFERENCE_YEAR * 12 + (CURRENT_REFERENCE_MONTH - 1)) - unpaidMonths;
  const year = Math.floor(totalMonths / 12);
  const monthIndex = totalMonths % 12;
  
  if (lang === 'ar') {
    return `${MONTH_NAMES_AR[monthIndex]} ${year}`;
  }
  return `${MONTH_NAMES_FR[monthIndex]} ${year}`;
}

export interface ApartmentAuditResult {
  apartmentNumber: string;
  buildingCode: string;
  lastPaidMonth: string;
  monthsLate: number;
  isAllowed: boolean;
  formattedOutput: string;
}

/**
 * Formats inspection result according to mandatory standard:
 * رقم الشقة: [رقم]
 * آخر شهر مدفوع: [الشهر/السنة]
 * أشهر التأخير المحسوبة: [العدد]
 * حالة الدخول: [مسموح بالدخول ✅ / ممنوع من الدخول ❌]
 */
export function auditApartmentAccess(apt: Apartment): ApartmentAuditResult {
  const debt = getApartmentDebtStatus(apt);
  const lastPaid = getLastPaidMonthDisplay(debt.unpaidMonths);
  const isAllowed = !debt.isBlocked;
  
  const formattedOutput = [
    `رقم الشقة: ${apt.number}`,
    `آخر شهر مدفوع: ${lastPaid}`,
    `أشهر التأخير المحسوبة: ${debt.unpaidMonths}`,
    `حالة الدخول: ${isAllowed ? 'مسموح بالدخول ✅ (تأخير 4 أشهر أو أقل)' : 'ممنوع من الدخول ❌ (متأخر بأكثر من 4 أشهر - يجب أداء مستحقات السانديك)'}`
  ].join('\n');

  return {
    apartmentNumber: apt.number,
    buildingCode: apt.buildingCode,
    lastPaidMonth: lastPaid,
    monthsLate: debt.unpaidMonths,
    isAllowed,
    formattedOutput
  };
}

