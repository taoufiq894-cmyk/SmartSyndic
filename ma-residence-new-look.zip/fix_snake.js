const snakeToCamel = (str) => str.replace(/_([a-z])/g, (g) => g[1].toUpperCase());
const convertObj = (obj) => {
  if (Array.isArray(obj)) return obj.map(convertObj);
  if (obj !== null && typeof obj === 'object') {
    const n = {};
    for (const key of Object.keys(obj)) {
      n[snakeToCamel(key)] = convertObj(obj[key]);
    }
    return n;
  }
  return obj;
};
console.log(convertObj({ building_code: "GH 34 A", tests_array: [{ test_val: 1 }] }));
