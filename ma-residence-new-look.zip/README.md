# MA RESIDENCE - Système de Gestion de Copropriété

Application moderne de gestion de syndic et de copropriété (Résidence MA RESIDENCE).

---

## 🚀 Déploiement sur Netlify (Guide Complet)

Le projet dispose déjà du fichier de configuration `netlify.toml` pour une prise en charge immédiate avec SPA Routing et Vite.

### Étapes pour déployer sur Netlify :

1. **Exporter vers GitHub** :
   - Depuis le menu Google AI Studio, exportez le projet vers votre compte GitHub.

2. **Créer le site sur Netlify** :
   - Connectez-vous sur [https://app.netlify.com](https://app.netlify.com).
   - Cliquez sur **"Add new site"** -> **"Import an existing project"**.
   - Choisissez votre dépôt GitHub.

3. **Paramètres de Build (Automatiques)** :
   - **Build Command** : `npm run build`
   - **Publish directory** : `dist`
   - Le fichier `netlify.toml` inclus gère automatiquement la redirection vers `index.html` pour React Router.

4. **Variables d'environnement (Supabase)** :
   - Dans **Site configuration** -> **Environment variables**, ajoutez :
     - `VITE_SUPABASE_URL` : Votre URL Supabase
     - `VITE_SUPABASE_ANON_KEY` : Votre clé Anon Supabase

5. **Déploiement** :
   - Cliquez sur **Deploy site**. L'application sera en ligne et automatiquement synchronisée !

---

## 🚀 Déploiement sur Vercel (End-to-End Guide)

Le projet est entièrement configuré pour **Vercel** (`vercel.json`, `Vite`, `React 19`, `Tailwind CSS`).

### Méthode 1 : Déploiement direct via GitHub & Vercel (Recommandé)

1. **Exporter le projet vers GitHub** :
   - Depuis le menu de Google AI Studio en haut à droite, cliquez sur **Settings / Export** -> **Export to GitHub** (ou téléchargez le fichier ZIP et poussez-le sur votre dépôt GitHub).

2. **Connecter Vercel** :
   - Rendez-vous sur [https://vercel.com](https://vercel.com) et connectez-vous.
   - Cliquez sur le bouton **"Add New..."** -> **"Project"**.
   - Sélectionnez votre dépôt GitHub `MA-RESIDENCE` (ou le nom de votre repo).

3. **Paramètres de Build (Automatiques)** :
   - **Framework Preset** : `Vite` (détecté automatiquement).
   - **Build Command** : `npm run build`
   - **Output Directory** : `dist`
   - **Install Command** : `npm install`

4. **Variables d'environnement (Optionnel / Supabase Cloud)** :
   Dans la section **Environment Variables** sur Vercel, vous pouvez ajouter :
   - `VITE_SUPABASE_URL` = *(Votre URL Supabase si utilisée)*
   - `VITE_SUPABASE_ANON_KEY` = *(Votre clé publique Supabase si utilisée)*

5. **Déployer** :
   - Cliquez sur **Deploy**.
   - En moins de 60 secondes, votre application sera en ligne avec une adresse officielle Vercel du type :  
     `https://ma-residence-app.vercel.app`

---

### Méthode 2 : Déploiement via Vercel CLI (Ligne de commande)

Si vous avez le projet sur votre machine locale :

```bash
# 1. Installer la CLI Vercel si ce n'est pas déjà fait
npm i -g vercel

# 2. Se connecter et déployer
vercel

# 3. Pour déployer en Production :
vercel --prod
```

---

## 🌐 Configurer un Nom de Domaine Personnalisé sur Vercel

Pour lier votre propre nom de domaine (ex: `syndic-maroc.ma` ou `gestion-residence.com`) :

1. Dans votre tableau de bord Vercel, ouvrez le projet.
2. Allez dans **Settings** -> **Domains**.
3. Saisissez votre domaine (ex: `app.votredomaine.com`).
4. Ajoutez les enregistrements DNS indiqués par Vercel (CNAME ou A Record) chez votre registraire de domaine (OVH, GoDaddy, Namecheap, etc.).
5. Vercel génèrera automatiquement un certificat SSL (HTTPS) gratuit.
