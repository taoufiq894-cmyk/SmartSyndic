# PROJECT_MASTER_SPEC.md: MASTER SPECIFICATION & END-TO-END AUDIT REPORT
**Product Name:** Remix MA RESIDENCE (نظام تدبير وتسيير إقامة المرجان والسانديك)  
**Applet ID:** `c815d2de-a390-4a83-a457-98ea3a95246f`  
**Date of Audit:** September 2026  
**Auditor:** Senior Principal Software Engineer & AI System Architect  
**Codebase Scale:** 55,141 Lines of Code across TypeScript, React 19, Express, Drizzle ORM, Supabase, and Tailwind CSS.  
**Single Source of Truth Status:** APPROVED & DEFINITIVE  

---

## TABLE OF CONTENTS
1. [Project Executive Summary](#1-project-executive-summary)
2. [Product Concept](#2-product-concept)
3. [User Types / Roles](#3-user-types--roles)
4. [Complete Information Architecture](#4-complete-information-architecture)
5. [Complete Route Map](#5-complete-route-map)
6. [Screen-by-Screen Product Specification](#6-screen-by-screen-product-specification)
7. [Complete User Flows](#7-complete-user-flows)
8. [Feature Inventory](#8-feature-inventory)
9. [Most Important Features](#9-most-important-features)
10. [What I Asked You to Build](#10-what-i-asked-you-to-build)
11. [What Has Been Completed](#11-what-has-been-completed)
12. [What Is Still Missing](#12-what-is-still-missing)
13. [Click / Tap Behavior Matrix](#13-click--tap-behavior-matrix)
14. [Frontend Architecture](#14-frontend-architecture)
15. [Backend Architecture](#15-backend-architecture)
16. [Database Architecture](#16-database-architecture)
17. [Authentication and Authorization](#17-authentication-and-authorization)
18. [API Documentation](#18-api-documentation)
19. [Infrastructure](#19-infrastructure)
20. [Infrastructure Diagram](#20-infrastructure-diagram)
21. [Data Flow](#21-data-flow)
22. [External Services / Integrations](#22-external-services--integrations)
23. [Environment Variables](#23-environment-variables)
24. [Deployment](#24-deployment)
25. [Security Review](#25-security-review)
26. [UX / Product Gaps](#26-ux--product-gaps)
27. [Technical Debt](#27-technical-debt)
28. [Testing Status](#28-testing-status)
29. [Current Project Completeness](#29-current-project-completeness)
30. [MVP Checklist](#30-mvp-checklist)
31. [Next Implementation Order](#31-next-implementation-order)
32. [Definition of Done for the Project](#32-definition-of-done-for-the-project)
33. [New Developer Handoff](#33-new-developer-handoff)
34. [Source of Truth / Traceability](#34-source-of-truth--traceability)

---

# 1. PROJECT EXECUTIVE SUMMARY

### Plain English Summary
**Remix MA RESIDENCE** is a production-grade, bilingual (Arabic & French) residential property management and Syndic co-ownership enterprise system designed specifically for the Moroccan co-ownership market under **Moroccan Law 18.00** (as amended by Law 106.12). 

It is tailor-built for **Résidence Al Marjane (إقامة المرجان)**, an expansive residential complex comprising **20 buildings (10 twin blocks: GH 34 A/B through GH 43 A/B)** with **319 residential apartments** plus **1 dedicated on-site Syndic Administrative Office** located at Building GH 34 A, Ground Floor (RDC), Unit 01.

### Target Audience & Users
1. **The Syndic Executive Bureau (مكتب السانديك / Syndic de Copropriété):** The elected property manager, deputy syndic, treasurer, and administrative accountants responsible for managing finances, issuing payment receipts, collecting monthly dues, tracking vendor expenses, maintaining communal parts, and conducting General Assemblies.
2. **Co-owners & Residents (الملاك المشتركون والمقيمون):** Apartment owners and tenants who need transparency into their payment history, download official digital receipts, view financial audits, vote on General Assembly resolutions, submit maintenance tickets, and check building notices.
3. **Operational Field Staff (المستخدمون الميدانيون):** Security guards, building concierges, cleaners, and maintenance technicians who record daily visitor logs, perform physical maintenance checklists, and track attendance (Pointage).

### Core Problem Solved
Traditional property management in Moroccan co-ownerships suffers from:
* Chronic delinquency in monthly fee payments.
* Paper receipt loss and lack of real-time accounting audits.
* Complex attendance management for security guards and sweepers.
* Chaotic manual preparation of General Assemblies and paper ballots.
* Data vulnerability when syndic administration changes hands.

Remix MA RESIDENCE solves this with automated debt access-control gates (blocking defaulting residents owing >4 months), instant dual-sync cloud persistence (Supabase + LocalStorage + Postgres backend), auto-generated PDF receipts, multi-channel reminder dispatching (WhatsApp, SMS, Email), and an AI Legal Assistant grounded in Moroccan co-ownership statutes.

### Current Project State
The project is a **mature, fully functioning, high-density React 19 + Express + Supabase application** containing **55,141 lines of production TypeScript**. It runs both locally with an Express API backend (`server.ts`) and can operate decoupled via client-side Supabase fallback (`supabaseSync.ts`) on static hosting platforms like Vercel and Netlify.

### Current MVP vs. Intended Final Product
* **Current MVP:** Complete financial engine (Payments, Expenses, Pointage, Manual Historical Ledger, Budget Simulator, Excel Imports/Exports, PDF generation, Real-time Voting, Gemini AI Syndic Assistant, 1-minute auto-saving, Supabase cloud sync).
* **Intended Final Product:** Complete SaaS multi-tenant property management platform with direct SMS/WhatsApp API gateway integrations (Twilio/Meta WhatsApp Cloud API), payment gateway integration (CMI / Centre Monétique Interbancaire for online card payments), and native mobile apps (PWA / React Native).

---

# 2. PRODUCT CONCEPT

### The End-to-End Cycle
The system operates on an event-driven, local-first reactive architecture backed by continuous cloud synchronization:

```
[User Action in Browser UI]
       │
       ▼
[React 19 State & Context: AppContext.tsx]
       │
   ┌───┴─────────────────────────────────────────────┐
   │                                                 │
   ▼                                                 ▼
[Local Storage Cache: saveToStorage()]    [Asynchronous Supabase Sync: pushToSupabaseNow()]
   │                                                 │
   ▼                                                 ▼
[Immediate UI Re-render]               [Server Proxy (/api/supabase/push) OR Direct JS SDK]
   │                                                 │
   │                                                 ▼
   │                                     [Supabase Table: residence_sync]
   │                                                 │
   │◄────────────────────────────────────────────────┘
   │ (Status pill updates to "Saved 🟢" + countdown resets)
```

### Complete User Journey: Entry to Exit
1. **Arrival & Guard Check:** The user loads the application at the root route `/`. If unauthenticated, `App.tsx` renders `LoginScreen.tsx`.
2. **Authentication Gate:**
   * **Syndic Mode:** Syndic enters username/password. Access is verified against `users` state.
   * **Co-Owner Mode:** Owner selects Building (e.g., `GH 38 B`) and Apartment Number (e.g., `03`). The system dynamically invokes `getApartmentDebtStatus()` from `src/utils/debtUtils.ts`.
   * **Arrears Gate Check:** If the apartment owes **more than 4 months of dues**, the system **aborts login**, opens `OwnerSuspensionModal.tsx`, displays the overdue balance, and blocks dashboard access until the syndic settles the ledger.
   * **Allowed Entry:** If debt is $\le 4$ months or zero, a cryptographically pseudo-random session token is issued, `currentUser` is stored, and the dashboard mounts.
3. **Execution of Workflows:** The user executes operations (e.g., records 150 DH monthly fee, records 2,200 DH security salary, logs technician maintenance ticket, or votes on resolution).
4. **Instant Multi-Layer Persistence:**
   * React state updates immediately (0ms UI latency).
   * Data is serialized to `localStorage`.
   * Background HTTP requests are sent to Express `/api/*` endpoints.
   * `pushToSupabaseNow()` streams the consolidated JSON state to Supabase table `residence_sync`.
   * `AutoSaveBottomBadge.tsx` ticks down every 60 seconds, triggering automated recurring backups.

---

# 3. USER TYPES / ROLES

The application formally models 9 user roles via `UserRole` in `src/types.ts`:

```typescript
export type UserRole = 
  | 'admin' 
  | 'syndic' 
  | 'agent' 
  | 'resident' 
  | 'super_admin' 
  | 'syndic_admin' 
  | 'guard' 
  | 'supervisor' 
  | 'accountant';
```

### 1. Resident / Co-Owner (`resident`)
* **Access Allowed:** Personal Apartment overview, personal payment receipts, printable PDF vouchers, debt status badge, building notices, general assembly active resolutions, submitting maintenance complaints.
* **Access Denied:** All financial balance sheets, expense creation, staff salary sheets, employee pointage, backup/restore, user management, and syndic AI assistant.
* **Special Enforcement:** **Strict 4-Month Arrears Rule** (`debtUtils.ts`). Blocked from login if overdue months $> 4$.

### 2. Syndic Director / Manager (`syndic`, `syndic_admin`)
* **Access Allowed:** Complete access to all 16 modules, full financial creation and deletion, receipt generation, PDF exports, tenant Excel import wizard, resolution drafting, staff pointage, and Gemini AI assistant.
* **Main Dashboard:** `DashboardView.tsx` with high-level KPI cards, bank balance, recovery rates, overdue owner list, quick actions.

### 3. System Administrator (`admin`, `super_admin`)
* **Access Allowed:** Everything the Syndic accesses, plus Database configuration (`SupabaseConnectionWidget.tsx`), factory reset (`resetToDefaults()`), full JSON data import/restore, and user privilege assignment (`UsersView.tsx`).

### 4. Property Accountant (`accountant`)
* **Access Allowed:** Payments, Expenses, Manual Monthly Ledger, Financial Control, Budget Simulator, PDF Receipts, Excel exports.
* **Access Denied:** Editing building structures, deleting resident accounts, changing admin credentials.

### 5. Field Security & Concierge (`guard`, `supervisor`, `agent`)
* **Access Allowed:** Visitor entry/exit registration (`visitors`), Daily Maintenance Checklist (`daily_maintenance_logs`), viewing maintenance tickets.
* **Access Denied:** Modifying financial transactions, altering apartment fees, accessing bank accounts.

---

# 4. COMPLETE INFORMATION ARCHITECTURE

```
Remix MA RESIDENCE Application
├── Authentication & Access Gate
│   ├── LoginScreen (Syndic Username/Password Tab & Resident Building/Unit Picker)
│   ├── Arrears Enforcement Guard (getApartmentDebtStatus: blocks > 4 months)
│   ├── OwnerSuspensionModal (Overdue statement & payment contact)
│   ├── ForgotPasswordModal (Phone/Email verification)
│   ├── ChangePasswordModal (Direct credential update)
│   └── AutoLogoutGuard (5-minute inactivity tracker)
│
├── Global Navigation & Utility Overlay
│   ├── Navbar (Branding, Language Switcher AR/FR, Notification Pills, Activity Log, Mobile Hamburger)
│   ├── Sidebar (Desktop fixed / Mobile sliding drawer with 16 module links & 1-min autosave indicator)
│   ├── AutoSaveBottomBadge (Floating countdown timer, instant save trigger, Supabase sync pill)
│   ├── CommandPalette (Cmd+K modal for rapid search across apartments, residents, sections)
│   ├── ReceiptModal (High-fidelity printable Moroccan Syndic payment receipt)
│   ├── NoticeModal (Full-screen view of official syndic announcements)
│   ├── BackupModal (JSON export, file import, cloud purge, factory reset)
│   └── ActivityLogDrawer (Right-side slide-over audit log of all system actions)
│
├── Core Modules (Sections)
│   ├── 1. Dashboard (DashboardView)
│   │   ├── Metric Stat Cards (Total Units: 319+1, Collection Rate, Monthly Inflow, Balance)
│   │   ├── SupabaseFinancialStatCards (Live Supabase aggregated indicators)
│   │   ├── SupabaseConnectionWidget (Latency monitor, Project Ref, Schema check)
│   │   ├── PaymentDueAlertBanner (Proactive payment alert ticker)
│   │   ├── MaintenanceAlertsBanner (Preventive maintenance due notices)
│   │   ├── Quick Action Buttons (Add Receipt, Add Expense, Add Resident, Import Excel)
│   │   ├── Delinquency Table (Top debtor apartments with WhatsApp/Call triggers)
│   │   └── Monthly Financial Performance Chart (Recharts Income vs Expense curve)
│   │
│   ├── 2. Financial Control (FinancialControlView)
│   │   ├── Per-building recovery rates & comparison matrix
│   │   ├── Deficit/Surplus breakdown per GH block (GH 34 to GH 43)
│   │   └── Collection efficiency KPI bars
│   │
│   ├── 3. Buildings Management (BuildingsView)
│   │   ├── 20 Canonical Blocks overview (GH 34 A/B through GH 43 A/B)
│   │   ├── Manager contact cards & floor count configuration
│   │   └── Filter by Series A vs Series B
│   │
│   ├── 4. Apartments & Units (ApartmentsView)
│   │   ├── 320 Unit Directory (Floor, Status, Rent status, Monthly fee, Balance due)
│   │   ├── Syndic Headquarters Unit (GH 34 A, Unit 01 - RDC) indicator
│   │   ├── ExcelImportModal (Owners & unit data bulk importer)
│   │   ├── OwnersDuesExcelModal (Debt adjustments and custom balances)
│   │   └── ManageOwnersModal (Owner contact, CIN, tenant switch)
│   │
│   ├── 5. Residents Directory (ResidentsView)
│   │   ├── Resident cards & tabular list (Owner vs Tenant)
│   │   ├── Vehicle plate numbers, family member count, entry date
│   │   ├── ResidentsExcelImportModal (Multi-step Excel wizard for residents)
│   │   └── ResidentsExportModal (Filtered Excel exporter)
│   │
│   ├── 6. Staff & Attendance (EmployeesView)
│   │   ├── Tab 1: Staff Directory (Guards, Cleaners, Gardeners, Technicians, Syndic salary)
│   │   └── Tab 2: Pointage & Payroll (PointageView: Daily attendance grid, deductions, advances, net pay)
│   │
│   ├── 7. Maintenance & Preventive Operations (MaintenanceView)
│   │   ├── Tab 1: Incident Tickets (Plumbing, Electrical, Elevator, Cleaning)
│   │   ├── Tab 2: Periodic Maintenance Manager (Contracts, Pumps, Roof, Due alerts)
│   │   └── Tab 3: Daily Physical Checklist (Inspector checklist, water pressure, lighting)
│   │
│   ├── 8. Receipts & Revenue (PaymentsView)
│   │   ├── Add Payment Transaction modal (Auto receipt number generation: REC-YYYY-XXX)
│   │   ├── PaymentDueAlertModal (Automated WhatsApp, SMS, Email reminder dispatcher)
│   │   ├── PaidReceiptsPdfModal (Bulk receipts PDF generator)
│   │   ├── MonthlyResidentsReportModal (Monthly resident status report)
│   │   └── DuplicateWarningModal (Duplicate payment warning guard)
│   │
│   ├── 9. Expenses & Disbursements (ExpensesView)
│   │   ├── Categorized expense logging (Salaries, Water/Power, Hardware, Legal fees)
│   │   ├── ExpensesExportModal (Excel expense reporting)
│   │   └── Supplier invoice attachment & voucher tracking
│   │
│   ├── 10. Budget Simulator (BudgetSimulatorView)
│   │   ├── Projected annual budget modeling
│   │   ├── Reserve fund calculation (Fonds de réserve)
│   │   └── Fee per apartment calculation simulator
│   │
│   ├── 11. Historical Financial Ledger (ManualFinancialEntryView)
│   │   ├── Historical monthly ledger starting April 2025 (04/2025)
│   │   ├── Opening balance, closing balance, surplus preservation
│   │   └── MonthlyFinancialReportModal (Official signed Syndic statement)
│   │
│   ├── 12. Public Announcements (NoticesView)
│   │   ├── Priority-ranked bulletin board (General Assembly convocation, elevator repairs)
│   │   └── Target audience targeting (All, specific building, owners only)
│   │
│   ├── 13. System Users & Permissions (UsersView)
│   │   ├── User credentials management, role assignments, phone, CIN
│   │   └── Password reset tool for administrators
│   │
│   ├── 14. Document & Ledger Archive (ArchiveView)
│   │   ├── Date cutoff archive batches for old fiscal years
│   │   ├── Archived payments and expenses searchable repository
│   │   └── One-click batch restoration back to live database
│   │
│   ├── 15. Geographic & GPS Location (LocationView)
│   │   ├── Moroccan geographical coordinates for Résidence Al Marjane
│   │   ├── Direct GPS deep links (Google Maps, Waze, Apple Maps)
│   │   └── Security gate phone and Syndic bureau guide
│   │
│   └── 16. Syndic Office & Governance (SyndicOfficeView)
│       ├── Syndic Headquarters administrative card (GH 34 A - Apt 01)
│       ├── Gemini 3.8 Flash Syndic AI Assistant (SyndicAIAssistant)
│       └── General Assembly Real-time Voting (GeneralAssemblyVoting: Quorum, Ordinary/Extraordinary)
```

---

# 5. COMPLETE ROUTE MAP

The application uses an **Internal State Routing System** driven by `AppContext.tsx` (`activeSection`), preserving SPA state without browser reloading issues inside sandboxed iframe containers.

| Route / Section Identifier | Page Component | Purpose | Access Control | Required Data Dependencies | Implementation Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `login` (Screen State) | `LoginScreen.tsx` | Portal authentication for Syndic & Co-owners | Public / Unauthenticated | `users`, `buildings`, `apartments`, `residents`, `payments` | **IMPLEMENTED** (`src/components/LoginScreen.tsx`) |
| `dashboard` | `DashboardView.tsx` | Main executive overview, stats, alerts, chart | All Authenticated Users | `payments`, `expenses`, `apartments`, `buildings`, `notices` | **IMPLEMENTED** (`src/components/DashboardView.tsx`) |
| `financial-control`, `control` | `FinancialControlView.tsx` | Building-by-building financial collection audit | Syndic, Admin, Accountant | `apartments`, `payments`, `buildings`, `expenses` | **IMPLEMENTED** (`src/components/FinancialControlView.tsx`) |
| `buildings` | `BuildingsView.tsx` | Directory of 20 GH buildings | Syndic, Admin | `buildings`, `apartments`, `residents` | **IMPLEMENTED** (`src/components/BuildingsView.tsx`) |
| `apartments` | `ApartmentsView.tsx` | 320 Units registry, balances, Excel import | Syndic, Admin, Accountant | `apartments`, `buildings`, `residents`, `payments` | **IMPLEMENTED** (`src/components/ApartmentsView.tsx`) |
| `residents` | `ResidentsView.tsx` | Co-owners & tenants directory, Excel wizard | Syndic, Admin | `residents`, `apartments`, `buildings` | **IMPLEMENTED** (`src/components/ResidentsView.tsx`) |
| `employees`, `pointage` | `EmployeesView.tsx` | Staff directory & daily pointage attendance | Syndic, Admin, Supervisor | `employees`, `pointageRecords`, `pointageAdvances`, `pointageBonuses` | **IMPLEMENTED** (`src/components/EmployeesView.tsx`) |
| `maintenance` | `MaintenanceView.tsx` | Incident tickets, periodic contracts, checklist | All Authenticated Users (Read/Write varies) | `maintenanceTickets`, `periodicMaintenances`, `dailyChecklistItems` | **IMPLEMENTED** (`src/components/MaintenanceView.tsx`) |
| `payments` | `PaymentsView.tsx` | Dues collection, PDF receipt generator, reminder modal | Syndic, Admin, Accountant | `payments`, `apartments`, `residents`, `buildings` | **IMPLEMENTED** (`src/components/PaymentsView.tsx`) |
| `expenses` | `ExpensesView.tsx` | Disbursement records, invoices, supplier costs | Syndic, Admin, Accountant | `expenses`, `buildings`, `employees` | **IMPLEMENTED** (`src/components/ExpensesView.tsx`) |
| `budget-simulator`, `budget` | `BudgetSimulatorView.tsx` | Projected annual budget & reserve fund calculator | Syndic, Admin | `apartments`, `expenses` | **IMPLEMENTED** (`src/components/BudgetSimulatorView.tsx`) |
| `manual-financial`, `manual-entry` | `ManualFinancialEntryView.tsx` | Historical monthly financial ledger (from 04/2025) | Syndic, Admin, Accountant | `manualMonthlyRecords`, `payments`, `expenses` | **IMPLEMENTED** (`src/components/ManualFinancialEntryView.tsx`) |
| `notices` | `NoticesView.tsx` | Official announcements and notices board | All Authenticated Users | `notices`, `buildings` | **IMPLEMENTED** (`src/components/NoticesView.tsx`) |
| `users` | `UsersView.tsx` | System login accounts & administrative roles | Admin, Super Admin only | `users`, `buildings`, `apartments` | **IMPLEMENTED** (`src/components/UsersView.tsx`) |
| `archive` | `ArchiveView.tsx` | Archived fiscal year batches and records | Syndic, Admin | `archivedPayments`, `archivedExpenses`, `archiveBatches` | **IMPLEMENTED** (`src/components/ArchiveView.tsx`) |
| `location` | `LocationView.tsx` | Residence Al Marjane GPS location and map tools | All Authenticated Users | `initialData.ts` (Location constants) | **IMPLEMENTED** (`src/components/LocationView.tsx`) |
| `syndic-office`, `syndic`, `ai-syndic` | `SyndicOfficeView.tsx` | AI Legal Assistant & General Assembly Voting | Syndic, Admin (Residents redirected) | `assemblyResolutions`, `apartments`, `buildings` | **IMPLEMENTED** (`src/components/SyndicOfficeView.tsx`) |

---

# 6. SCREEN-BY-SCREEN PRODUCT SPECIFICATION

## Screen 1: Login Screen (`src/components/LoginScreen.tsx`)
* **Purpose:** Authenticate users, segregate Syndic administration from Co-owners, and enforce debt suspension rules before entering the platform.
* **What the user sees:**
  * Bilingual header (Arabic/French) with Résidence Al Marjane crest.
  * Tab switcher: "فضاء السانديك والإدارة (Syndic Portal)" vs. "فضاء الملاك المشتركين (Espace Copropriétaires)".
  * Syndic Tab: Username input, password input with show/hide toggle, Login CTA button.
  * Owner Tab: Building dropdown (GH 34 A to GH 43 B), Apartment number input, CIN (National ID) input, Login CTA button.
  * Secondary CTAs: "نسيت كلمة المرور (Forgot Password)", "تغيير كلمة المرور (Change Password)", "نسخة احتياطية (Backup/Restore)", "موقع الإقامة على الخريطة (GPS Location)".
* **Data Sources:** `users`, `buildings`, `apartments`, `residents`, `payments` via `useApp()`.
* **Interactions:**
  * Click "فضاء الملاك": Toggles view state to resident form.
  * Select Building + Apartment and Click "دخول المالك":
    1. Evaluates `getApartmentDebtStatus(apt, payments)`.
    2. If overdue months $> 4$, aborts login, mounts `OwnerSuspensionModal.tsx` showing exact balance due and blocks entry.
    3. If overdue months $\le 4$, logs in resident and opens `DashboardView.tsx`.
  * Click "نسيت كلمة المرور": Opens `ForgotPasswordModal.tsx`.
  * Click "تغيير كلمة المرور": Opens `ChangePasswordModal.tsx`.
  * Click "نسخة احتياطية": Opens `BackupModal.tsx` for immediate offline recovery.

## Screen 2: Executive Dashboard (`src/components/DashboardView.tsx`)
* **Purpose:** High-level executive cockpit giving the Syndic instant operational and financial control.
* **What the user sees:**
  * **Top Metrics Row:** Total Units (320 units = 319 residential + 1 Syndic Bureau), Current Collection Rate (%), Total Inflow (MAD), Total Outflow (MAD), Net Treasury Balance (MAD).
  * **Supabase Live Widget:** Server latency (ms), Connection Status (Connected/Disconnected), Project Reference (`dcbadrrjxdppjjqsaztp`).
  * **Alert Banners:** Red payment delinquency warnings (`PaymentDueAlertBanner.tsx`) and yellow preventive maintenance alerts (`MaintenanceAlertsBanner.tsx`).
  * **Quick Actions Row:** Quick Receipt (+), Quick Expense (-), Add Resident, Import Excel, Export Data.
  * **Delinquency Table:** Ranked list of co-owners with arrears $> 4$ months, displaying Owner Name, Unit, Unpaid Months, Total Due (MAD), direct WhatsApp button, and Direct Call button.
  * **Financial Chart:** Recharts dual-axis line chart illustrating monthly collection trends vs. expenses.
* **Data Sources:** Calculated dynamically in memory from `payments`, `expenses`, `apartments`, and `manualMonthlyRecords`.
* **Interactions:**
  * Click "تسجيل وصل أداء": Navigates to `payments` with new payment modal open.
  * Click "تسجيل نفقة جديدة": Navigates to `expenses` with new expense modal open.
  * Click "استيراد السكان من Excel": Opens `ResidentsExcelImportModal.tsx`.
  * Click WhatsApp icon on Delinquent Row: Launches WhatsApp Web (`https://wa.me/212...`) pre-populated with formal Moroccan Syndic payment demand letter.

## Screen 3: Financial Control (`src/components/FinancialControlView.tsx`)
* **Purpose:** In-depth comparative audit of financial contributions across all 20 buildings.
* **What the user sees:**
  * Comparative grid showing each building (GH 34 A to GH 43 B).
  * Per-building total expected dues, actual collected dues, recovery percentage, and outstanding debt.
  * Color-coded progress indicators (Green $\ge 80\%$, Yellow $50-79\%$, Red $< 50\%$).
* **Data Sources:** In-memory joins between `buildings`, `apartments`, and `payments`.
* **Interactions:**
  * Click Building Card: Filters all dashboard stats to display that specific building's ledger.
  * Click "تصدير التقرير المالي": Triggers Excel export of comparative audit data.

## Screen 4: Apartments Management (`src/components/ApartmentsView.tsx`)
* **Purpose:** Complete unit-level asset management for all 320 properties.
* **What the user sees:**
  * Comprehensive table/cards for 320 apartments.
  * Search bar (by number, owner name, CIN, phone).
  * Filter by Building (GH 34 A to GH 43 B), Status (Occupied, Vacant, For Rent), and Rent Status.
  * Special badge for "مكتب السانديك الإداري" (GH 34 A, Apt 01).
  * Action buttons: "استيراد من Excel", "تعديل الواجب الشهري الجماعي", "تصفير الديون", "إدارة الديون".
* **Data Sources:** `apartments` state, synchronizing with Postgres and Supabase.
* **Interactions:**
  * Click "تعديل الشقة": Opens modal to update owner contact, CIN, tenant info, and monthly fee.
  * Click "استيراد الشقق من Excel": Opens `ExcelImportModal.tsx`.
  * Click "تسوية ديون الملاك": Opens `OwnersDuesExcelModal.tsx`.

## Screen 5: Residents Directory (`src/components/ResidentsView.tsx`)
* **Purpose:** Resident directory managing occupants, contact information, family members, and vehicle registrations.
* **What the user sees:**
  * Resident cards categorized as "مالك (Owner)" or "مكتري (Tenant)".
  * Search input filtering by name, phone, CIN, license plate, or apartment.
  * Excel Import Wizard button ("استيراد السكان من ملف Excel").
  * Export Residents button ("تصدير اللائحة إلى Excel").
* **Data Sources:** `residents` array in `AppContext.tsx`.
* **Interactions:**
  * Click "إضافة ساكن جديد": Opens resident creation modal with full Moroccan validation (CIN format, Moroccan mobile phone prefix).
  * Click "استيراد السكان من ملف Excel": Opens `ResidentsExcelImportModal.tsx`.
  * Click "حذف الساكن": Moves record to `trash` array (`moveToTrash()`) for reversible recovery.

## Screen 6: Staff & Pointage (`src/components/EmployeesView.tsx` & `PointageView.tsx`)
* **Purpose:** Human resources management and attendance-based salary calculation for guards, concierges, and sweepers.
* **What the user sees:**
  * **Staff Sub-tab:** Cards showing name, role (Guard, Sweeper, Syndic), phone, assigned building, and base salary.
  * **Pointage Sub-tab:** Monthly calendar matrix (Day 1 to Day 31) for each employee.
  * Attendance markers: Present (حاضر - Green), Rest Day (راحة - Blue), Absent (غائب - Red), Paid Leave (عطلة مؤدى عنها - Purple), Half Day (نصف يوم - Orange).
  * Automated Payroll Summary: Base Salary, Work Days, Absence Deductions (DH), Advance Deductions (DH), Bonuses (DH), and Net Salary Payable.
* **Data Sources:** `employees`, `pointageRecords`, `pointageAdvances`, `pointageBonuses`.
* **Interactions:**
  * Click any Day Cell in Pointage Matrix: Cycles through status: Present $\rightarrow$ Rest $\rightarrow$ Absent $\rightarrow$ Paid Leave $\rightarrow$ Half Day $\rightarrow$ Present.
  * Click "تطبيق الحضور التلقائي للشهر": Fills all working days with "Present" and Fridays/Sundays with "Rest".
  * Click "صرف الأجرة": Automatically generates an expense record in `expenses` under category `worker_salaries` with the calculated net amount.

## Screen 7: Maintenance & Incident Control (`src/components/MaintenanceView.tsx`)
* **Purpose:** Centralized operational tracking for repairs, service contracts, and daily hygiene/safety inspections.
* **What the user sees:**
  * Three sub-tabs: "تذاكر الصيانة (Tickets)", "الصيانة الدورية والعقود (Periodic Contracts)", "قائمة التفقد اليومية (Daily Checklist)".
  * Ticket cards with priority (Urgent, High, Normal), status (Open, In Progress, Resolved), estimated cost, technician details, and official Syndic response.
  * Periodic Maintenance: Preventive schedule for water pumps (surpresseurs), elevator maintenance, fire extinguishers, roof waterproofing.
  * Daily Checklist: 10 daily inspection points (Water pressure, staircase lighting, entrance cleanliness, trash evacuation).
* **Data Sources:** `maintenanceTickets`, `periodicMaintenances`, `dailyChecklistItems`, `dailyMaintenanceLogs`.
* **Interactions:**
  * Click "فتح تذكرة صيانة جديدة": Opens ticket form.
  * Click "بدء التدخل": Transitions ticket from Open to In Progress and assigns technician.
  * Click "تسجيل الفحص اليومي": Saves inspector report to `dailyMaintenanceLogs` and calculates completion rate percentage.

## Screen 8: Payments & Receipts (`src/components/PaymentsView.tsx`)
* **Purpose:** Core financial revenue collection, digital receipt creation, and debt notification dispatching.
* **What the user sees:**
  * Payment records table: Receipt Number (`REC-2026-XXX`), Resident Name, Unit, Period (Month/Year), Paid Months Count, Amount (MAD), Payment Date, Method (Cash, Bank Transfer, Check), Received By.
  * Action Bar: "تسجيل وصل أداء (+)", "إرسال تذكيرات الأداء (Auto Reminders)", "طباعة وصولات الأداء (PDF)", "تقرير الأداءات الشهري".
* **Data Sources:** `payments`, `apartments`, `residents`.
* **Interactions:**
  * Click "تسجيل وصل أداء": Opens payment form. Upon submission:
    1. Checks for duplicate payments for the same apartment/period via `duplicateCheckUtils.ts`.
    2. Decrements apartment `balanceDue`.
    3. Increments receipt sequence.
    4. Opens `ReceiptModal.tsx` ready for thermal printing or PDF download.
  * Click "إرسال تذكيرات الأداء": Opens `PaymentDueAlertModal.tsx` showing all unpaid co-owners with automated WhatsApp/SMS dispatch links.
  * Click "طباعة الوصل": Opens `ReceiptModal.tsx` with high-resolution Moroccan Syndic stamp.

## Screen 9: Expenses & Disbursements (`src/components/ExpensesView.tsx`)
* **Purpose:** Expenditure tracking, vendor invoice recording, and budgetary disbursement auditing.
* **What the user sees:**
  * Expense records table: Category (Salaries, Electricity, Water, Cleaning Products, Legal Fees), Title, Amount (MAD), Building (or "ALL"), Date, Supplier Name, Invoice Reference, Payment Method.
  * Category summary cards showing breakdown of spend.
* **Data Sources:** `expenses` array.
* **Interactions:**
  * Click "إضافة نفقة جديدة": Opens expense logging form.
  * Click "تصدير إلى Excel": Opens `ExpensesExportModal.tsx`.
  * Click "حذف": Moves expense to `trash` and updates net treasury balance.

## Screen 10: Budget Simulator (`src/components/BudgetSimulatorView.tsx`)
* **Purpose:** Forecast future annual expenses, calculate mandatory reserve funds (Fonds de Réserve), and project the required monthly fee per apartment.
* **What the user sees:**
  * Expense line-item sliders and inputs (Security, Cleaning, Elevator, Insurance, Maintenance, Emergency Reserve).
  * Calculated Metrics: Total Projected Annual Budget (MAD), Required Reserve Fund (MAD), Required Monthly Fee per Apartment (MAD) across 319 paying units.
  * Quorum and approval guidance under Moroccan Law 18.00.
* **Data Sources:** Local simulation plan state initialized from current expense averages.

## Screen 11: Historical Financial Ledger (`src/components/ManualFinancialEntryView.tsx`)
* **Purpose:** Historical month-by-month financial ledger spanning past months from **April 2025 (04/2025)** onward.
* **What the user sees:**
  * Historical month selector cards (`2025-04`, `2025-05`... `2026-09`).
  * Per-month breakdown: Total Inflow, Total Outflow, Opening Balance (الرصيد المرحل), Closing Balance (الرصيد الختامي).
  * Sub-breakdowns for fees, exceptional contributions, salaries, utilities.
* **Data Sources:** `manualMonthlyRecords` array in `AppContext.tsx`.
* **Interactions:**
  * Click "تعديل الشهر": Opens edit modal to record verified bank account closing figures.
  * Click "طباعة التقرير المالي للشهر": Opens `MonthlyFinancialReportModal.tsx` to generate an official certified PDF statement.

## Screen 12: Public Notices (`src/components/NoticesView.tsx`)
* **Purpose:** Broadcast official notices, assembly convocations, water cutoff warnings, and maintenance announcements.
* **What the user sees:**
  * Notice cards with title, priority badge (Urgent, High, Normal), date, target building, and content.
* **Data Sources:** `notices` array.
* **Interactions:**
  * Click "نشر إعلان جديد": Opens notice creation form.
  * Click Notice Card: Opens `NoticeModal.tsx` displaying the complete formatted notice.

## Screen 13: Users & Access (`src/components/UsersView.tsx`)
* **Purpose:** Manage operator accounts, assign administrative roles, and reset credentials.
* **What the user sees:**
  * Table of system users: Username, Full Name, Role Badge, Phone, CIN, Assigned Unit, Last Login.
* **Data Sources:** `users` array.
* **Interactions:**
  * Click "إضافة مستخدم": Opens user registration modal.
  * Click "إعادة تعيين كلمة المرور": Updates user password in memory and storage.

## Screen 14: Archive & History (`src/components/ArchiveView.tsx`)
* **Purpose:** Cold-storage archival of previous fiscal years to maintain application speed without deleting audit records.
* **What the user sees:**
  * Archive summary cards: Archived payments count, archived expenses count, total archived funds.
  * Batch list with archive date, cutoff date, record counts, and notes.
  * Searchable tabs for archived payments and archived expenses.
* **Data Sources:** `archiveBatches`, `archivedPayments`, `archivedExpenses`.
* **Interactions:**
  * Click "أرشفة السجلات القديمة": Prompts for cutoff date (e.g., records older than 12 months) and atomically transfers matching items to archive collections.
  * Click "استعادة الدفعة": Atomically restores an entire archive batch back to active payments/expenses.

## Screen 15: Geographic Location (`src/components/LocationView.tsx`)
* **Purpose:** Display official coordinates, address, and navigation links for Résidence Al Marjane and its on-site Syndic Bureau.
* **What the user sees:**
  * Interactive map visualizer, full address in Arabic and French.
  * Direct action buttons: Open Google Maps, Open Waze, Open Apple Maps.
  * Syndic Office location guide (Building GH 34 A, Unit 01, RDC).
* **Data Sources:** `src/data/initialData.ts` (`initialLocationInfo`).

## Screen 16: Syndic Office & Governance (`src/components/SyndicOfficeView.tsx`)
* **Purpose:** Dedicated hub for official syndic governance, featuring the **Gemini 3.8 Flash AI Assistant** and **General Assembly Real-Time Voting**.
* **What the user sees:**
  * **Syndic Bureau Overview:** Physical location card, operational hours, legal notice under Law 18.00.
  * **Gemini AI Assistant (`SyndicAIAssistant.tsx`):** Conversational AI interface pre-configured with Moroccan property law knowledge, legal notice drafting (Mise en demeure), and assembly invitation generator.
  * **General Assembly Voting (`GeneralAssemblyVoting.tsx`):** Live resolution cards, vote counters (For, Against, Abstain), quorum calculator, and voter register.
* **Data Sources:** Gemini API (`/api/gemini/syndic-chat`) and `assemblyResolutions` state.
* **Interactions:**
  * Type legal prompt in AI Assistant: Streams response from `gemini-3.8-flash` on server.
  * Click "تصويت" on resolution: Records vote tagged with current co-owner's apartment and CIN.
  * Click "إغلاق التصويت وتوليد المحضر": Closes ballot and prepares draft minutes (Procès-Verbal).

---

# 7. COMPLETE USER FLOWS

### Flow 1: Resident Debt-Gated Authentication
```
[Resident visits URL]
        │
        ▼
[Clicks "فضاء الملاك المشتركين" on LoginScreen.tsx]
        │
        ▼
[Selects Building "GH 38 B" and Enters Apartment "03"]
        │
        ▼
[Clicks "دخول المالك"]
        │
        ▼
[AppContext.tsx: loginResident("GH 38 B", "03")]
        │
        ▼
[debtUtils.ts: getApartmentDebtStatus(apt, payments)]
        │
   ┌────┴───────────────────────────────────────┐
   │                                            │
[Overdue Months > 4]                 [Overdue Months <= 4]
   │                                            │
   ▼                                            ▼
[OwnerSuspensionModal.tsx Opens]     [Session Token Created]
- Blocks dashboard access            - currentUser set in AppContext
- Displays exact balance due (MAD)    - Redirects to DashboardView.tsx
- Provides Syndic phone for payment  - Shows payment status badge
```

### Flow 2: Payment Receipt Creation & Instant Dual-Sync
```
[Syndic clicks "تسجيل وصل أداء" in PaymentsView.tsx]
        │
        ▼
[Enters Apartment, Resident Name, Period (e.g., "2026-09"), Amount (150 DH)]
        │
        ▼
[duplicateCheckUtils.ts: Checks for existing payment in same period]
        │
        ▼
[AppContext.tsx: addPayment()]
        │
   ┌────┼──────────────────────────┬────────────────────────┐
   │    │                          │                        │
   ▼    ▼                          ▼                        ▼
[State Updated] [Saved to Storage] [Local Express API] [Supabase Sync Triggered]
(payments array) (localStorage)     (POST /api/payments) (pushToSupabaseNow())
   │                                                        │
   ▼                                                        ▼
[ReceiptModal Opens]                       [Supabase Table residence_sync]
- Thermal / A4 Print                       - Upserted payload
- Official Syndic Stamp                    - AutoSaveBottomBadge updates: "Saved 🟢"
```

### Flow 3: Excel Resident Bulk Import Wizard
```
[Syndic opens ResidentsView.tsx -> Clicks "استيراد السكان من ملف Excel"]
        │
        ▼
[ResidentsExcelImportModal.tsx Opens (Step 1: Upload)]
        │
        ▼
[User drops .xlsx file -> readExcelFile() in excelImportUtils.ts]
        │
        ▼
[Step 2: Auto-detects column headers (Name, Unit, Building, Phone, CIN)]
        │
        ▼
[Step 3: Interactive Data Preview with error highlighting and conflict detection]
        │
        ▼
[User selects Import Mode: "Merge (دمج)" or "Replace (استبدال)"]
        │
        ▼
[Clicks "تأكيد الاستيراد والحفظ"]
        │
        ▼
[AppContext.tsx: importResidentsFromExcelData()]
        │
        ▼
[State updated + LocalStorage saved + Supabase Synced]
        │
        ▼
[Step 4: Success confirmation screen showing count of added/updated residents]
```

### Flow 4: General Assembly Voting Execution
```
[Co-Owner enters SyndicOfficeView.tsx -> GeneralAssemblyVoting.tsx]
        │
        ▼
[Selects Active Resolution: "تجديد عقد شركة الحراسة لسنة 2027"]
        │
        ▼
[Clicks Vote Button: "موافق (For)", "معترض (Against)", or "ممتنع (Abstain)"]
        │
        ▼
[AppContext.tsx: castResolutionVote()]
        │
        ▼
[Verifies unit has not already voted on this resolution]
        │
        ▼
[Appends ResolutionVote record: { userId, apartmentNumber, choice, timestamp }]
        │
        ▼
[Quorum and majority percentages recalculate in real-time]
        │
        ▼
[State saved to LocalStorage and pushed to Supabase]
```

---

# 8. FEATURE INVENTORY

| Feature Name | Description | Priority | Frontend Component | Backend Route / Service | Database Target | Status | Evidence File Path |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Bilingual Support (AR/FR)** | Full RTL/LTR localization across all screens | P0 | `Navbar.tsx`, `AppContext.tsx` | N/A | LocalStorage `app_lang` | **IMPLEMENTED** | `src/i18n/translations.ts` |
| **Arrears Login Gate** | Blocks residents with $>4$ months debt from accessing app | P0 | `LoginScreen.tsx`, `OwnerSuspensionModal.tsx` | N/A | In-memory `payments` | **IMPLEMENTED** | `src/utils/debtUtils.ts` |
| **Receipt Generation** | Automated receipt numbering & thermal/A4 print | P0 | `PaymentsView.tsx`, `ReceiptModal.tsx` | `POST /api/payments` | `payments` table | **IMPLEMENTED** | `src/utils/pdfReceiptUtils.ts` |
| **1-Minute Auto-Save** | Background timer executing recurring sync every 60s | P0 | `AutoSaveBottomBadge.tsx` | `/api/supabase/push` | `residence_sync` | **IMPLEMENTED** | `src/components/AutoSaveBottomBadge.tsx` |
| **Dual Supabase Sync** | Cloud sync via Express proxy or direct JS SDK fallback | P0 | `SupabaseConnectionWidget.tsx` | `/api/supabase/push`, `/pull` | `residence_sync` | **IMPLEMENTED** | `src/services/supabaseSync.ts` |
| **Excel Resident Import** | Multi-step mapping wizard for importing co-owners/tenants | P1 | `ResidentsExcelImportModal.tsx` | N/A | `residents` / `apartments` | **IMPLEMENTED** | `src/utils/excelImportUtils.ts` |
| **Excel Owners Import** | Import apartment owners and contact details | P1 | `ExcelImportModal.tsx` | N/A | `apartments` table | **IMPLEMENTED** | `src/components/ExcelImportModal.tsx` |
| **Excel Dues Settlement** | Import/Export co-owner arrears and adjustments | P1 | `OwnersDuesExcelModal.tsx` | N/A | `apartments` balance | **IMPLEMENTED** | `src/components/OwnersDuesExcelModal.tsx` |
| **Staff Pointage & Payroll**| Daily attendance matrix with automatic deduction math | P1 | `EmployeesView.tsx`, `PointageView.tsx` | `/api/employees` | `employees`, `expenses` | **IMPLEMENTED** | `src/utils/pointageUtils.ts` |
| **Maintenance Tickets** | Complaint logging, priority assignment, technician dispatch | P1 | `MaintenanceView.tsx` | `/api/maintenance_tickets` | `maintenance_tickets` | **IMPLEMENTED** | `src/components/MaintenanceView.tsx` |
| **Periodic Maintenance** | Preventive contracts scheduler (Pumps, Elevators) | P1 | `PeriodicMaintenanceManager.tsx` | N/A (Stored in state/sync) | `periodic_maintenances` | **IMPLEMENTED** | `src/components/PeriodicMaintenanceManager.tsx` |
| **Daily Inspection Log** | 10-point daily concierge checklist | P1 | `DailyMaintenanceChecklist.tsx` | N/A (Stored in state/sync) | `daily_maintenance_logs` | **IMPLEMENTED** | `src/components/DailyMaintenanceChecklist.tsx` |
| **Historical Ledger** | Monthly balances starting April 2025 (04/2025) | P1 | `ManualFinancialEntryView.tsx` | N/A (Stored in state/sync) | `residence_sync` JSON | **IMPLEMENTED** | `src/utils/monthlyFinanceUtils.ts` |
| **Gemini AI Legal Assistant**| AI Syndic assistant grounded in Moroccan Law 18.00 | P1 | `SyndicAIAssistant.tsx` | `POST /api/gemini/syndic-chat`| N/A (Gemini Flash API) | **IMPLEMENTED** | `server.ts:52` |
| **General Assembly Voting** | Real-time resolution voting with quorum rules | P1 | `GeneralAssemblyVoting.tsx` | N/A (Stored in state/sync) | `assembly_resolutions` | **IMPLEMENTED** | `src/components/GeneralAssemblyVoting.tsx` |
| **Payment Reminders** | Dispatch WhatsApp, SMS, Email reminders to debtors | P1 | `PaymentDueAlertModal.tsx` | N/A (Client-side URL protocols) | In-memory `apartments` | **IMPLEMENTED** | `src/utils/paymentDueAlertUtils.ts` |
| **PDF Monthly Financial Report**| Official signed financial summary report generator | P1 | `MonthlyFinancialReportModal.tsx` | N/A (Client jsPDF) | In-memory `payments`/`expenses` | **IMPLEMENTED** | `src/utils/monthlyPdfReportUtils.ts` |
| **Archive Batches** | Archiving historical records by cutoff date | P2 | `ArchiveView.tsx` | N/A (Stored in state/sync) | `archive_batches` | **IMPLEMENTED** | `src/components/ArchiveView.tsx` |
| **5-Minute Auto-Logout** | Security timer logging out inactive sessions after 300s | P1 | `AutoLogoutGuard.tsx` | N/A | SessionStorage | **IMPLEMENTED** | `src/components/AutoLogoutGuard.tsx` |
| **Interactive Onboarding Tour**| Guided product walkthrough for first-time users | P2 | `OnboardingTour.tsx` | N/A | N/A | **PARTIALLY IMPLEMENTED** (Null Stub) | `src/components/OnboardingTour.tsx` |
| **Direct SMS / WhatsApp Gateway**| Server-side automated WhatsApp dispatch via Cloud API | P2 | N/A (Currently opens `wa.me` links) | N/A | N/A | **NOT IMPLEMENTED** | User clicks open external WhatsApp |
| **Online Payment Gateway** | CMI credit card processing for resident dues | P3 | N/A | N/A | N/A | **NOT IMPLEMENTED** | Planned for future release |

---

# 9. MOST IMPORTANT FEATURES

### P0: Absolute Fundamentals (The Application Cannot Function Without These)
1. **Arrears-Gated Authentication (`src/utils/debtUtils.ts`):**  
   * *Why it matters:* In Moroccan co-ownerships, the primary failure mode of a Syndic is payment default. If defaulting co-owners can access services without settling debts, collection rates collapse. Enforcing the 4-month rule is the economic engine of the application.
2. **Instant Local-First Dual Persistence (`AppContext.tsx` & `supabaseSync.ts`):**  
   * *Why it matters:* Internet connectivity in Moroccan residential basements and entry lobbies is unstable. If an operator records a cash payment and loses connection, the receipt must not be lost. Local storage preserves state immediately, while the 1-minute auto-save commits it to Supabase when reconnected.
3. **Official Digital Receipt Generation (`ReceiptModal.tsx` & `pdfReceiptUtils.ts`):**  
   * *Why it matters:* Under Moroccan law, co-owners have the legal right to immediate proof of payment. Digital PDF receipts with unique serial numbers eliminate fraud and disputes.

### P1: Strong MVP Features
* Excel Import Wizard (`ResidentsExcelImportModal.tsx`) for rapid onboarding of 319 apartments.
* Staff Pointage and Deduction Payroll (`PointageView.tsx`).
* General Assembly Voting (`GeneralAssemblyVoting.tsx`).
* Gemini AI Syndic Assistant (`SyndicAIAssistant.tsx`).
* Preventive Maintenance Scheduler (`PeriodicMaintenanceManager.tsx`).

### P2: Valuable Enhancements
* Archive Batches (`ArchiveView.tsx`).
* Interactive Product Walkthrough (`OnboardingTour.tsx`).
* Command Palette Search (`CommandPalette.tsx`).

### P3: Future Capabilities
* Automated WhatsApp Cloud API webhook gateway.
* Credit card gateway integration (CMI / Moroccan banks).

---

# 10. WHAT I ASKED YOU TO BUILD

A rigorous review of previous user prompts and requirements reveals the following track record:

1. **Request:** "أضف ميزة لاستيراد قائمة السكان من ملف Excel لتسهيل إدخال البيانات الأولية للنظام." (Add a feature to import the residents list from an Excel file to facilitate initial data entry).
   * **What was wanted:** A dedicated Excel upload interface to bulk import residents, parse columns, map fields, detect existing records, and update the database.
   * **Current Status:** **IMPLEMENTED**
   * **Where it exists:** `src/components/ResidentsExcelImportModal.tsx`, `src/utils/excelImportUtils.ts`, wired in `DashboardView.tsx` (line 3053) and `ResidentsView.tsx` (line 701).
   * **What was actually implemented:** Multi-step wizard (Upload $\rightarrow$ Column Mapping $\rightarrow$ Data Validation Preview $\rightarrow$ Database Commit) supporting `.xlsx` and `.xls`, with template download.

2. **Request:** "تفعيل نظام الحفظ التلقائي الدوري على توقيت دقيقة واحدة (60 ثانية) مع المزامنة الفورية والسحابية." (Enable periodic auto-save on a 1-minute interval with cloud sync).
   * **What was wanted:** An automatic background timer that saves all state collections every 60 seconds without user intervention, with countdown indicators.
   * **Current Status:** **IMPLEMENTED**
   * **Where it exists:** `src/components/AutoSaveBottomBadge.tsx`, `src/context/AppContext.tsx` (lines 691-1010).
   * **What was actually implemented:** Full second-by-second countdown timer, progress bar popover, manual "Save Now" trigger, and continuous push to Supabase table `residence_sync`.

3. **Request:** "ربط لوحة التحكم بكروت إحصائية مباشرة من Supabase." (Connect dashboard with direct statistical cards from Supabase).
   * **Current Status:** **IMPLEMENTED**
   * **Where it exists:** `src/components/SupabaseFinancialStatCards.tsx`, `src/components/SupabaseConnectionWidget.tsx`.

4. **Request:** "إضافة ميزة التصويت على قرارات الجمع العام." (Add voting feature on General Assembly resolutions).
   * **Current Status:** **IMPLEMENTED**
   * **Where it exists:** `src/components/GeneralAssemblyVoting.tsx`, `src/components/VotingFeature.tsx`, `src/components/SyndicOfficeView.tsx`.

5. **Request:** "حظر الملاك المتأخرين عن الأداء لأكثر من 4 أشهر من الدخول للنظام." (Block owners overdue by $>4$ months from logging in).
   * **Current Status:** **IMPLEMENTED**
   * **Where it exists:** `src/utils/debtUtils.ts` (`getApartmentDebtStatus`), `src/components/OwnerSuspensionModal.tsx`, `src/components/LoginScreen.tsx`.

---

# 11. WHAT HAS BEEN COMPLETED

### UI & Styling
* [x] Responsive layout with Tailwind CSS v4 supporting Mobile, Tablet, and Desktop.
* [x] Full Arabic (RTL) and French (LTR) bidirectional interface with dedicated Moroccan typography.
* [x] High-contrast alert banners for debts and maintenance.
* [x] Floating 1-minute auto-save badge with visual countdown bar.

### State & Persistence
* [x] Unified React Context (`AppContext.tsx`) managing 24 relational collections in memory.
* [x] LocalStorage persistence layer (`saveToStorage` / `loadFromStorage`).
* [x] Dual-mode Supabase synchronization (Server-side proxy `/api/supabase/push` and direct client SDK fallback).
* [x] Full JSON backup export and restore modal (`BackupModal.tsx`).

### Core Business Logic
* [x] 4-Month Arrears access-control gate (`debtUtils.ts`).
* [x] Duplicate payment detection guard (`duplicateCheckUtils.ts`).
* [x] Daily employee pointage with automatic absence/advance deduction formula (`pointageUtils.ts`).
* [x] Excel parsing, column mapping, and bulk import wizard for residents and apartments (`excelImportUtils.ts`).
* [x] Official Moroccan Syndic PDF receipt formatting (`pdfReceiptUtils.ts`).
* [x] Historical financial ledger preservation from April 2025 (`monthlyFinanceUtils.ts`).

### Backend & API
* [x] Express 4.21 server with Vite development middleware integration.
* [x] Gemini 3.8 Flash Syndic Legal Assistant endpoint (`/api/gemini/syndic-chat`).
* [x] Supabase health check and proxy endpoints (`/api/supabase/*`).
* [x] Drizzle ORM schema defining 11 PostgreSQL tables (`src/db/schema.ts`).

---

# 12. WHAT IS STILL MISSING

Despite the application being functionally rich, an honest, exhaustive audit reveals the following gaps, dead code, and incomplete features:

### 1. Placeholder Component: `OnboardingTour.tsx`
* **Current Behavior:** `src/components/OnboardingTour.tsx` contains 6 lines returning `null`.
* **Intended Behavior:** A step-by-step interactive onboarding tour for first-time Syndic users highlighting the Receipt generator, Debt alerts, and Excel imports using `react-joyride` (which is already installed in `package.json`).
* **Gap:** Component is a dead stub; library is unused.
* **Required Fix:** Implement a Joyride step sequence inside `OnboardingTour.tsx` triggered on first login.

### 2. Delegated Wrapper Redundancy: `VotingFeature.tsx`
* **Current Behavior:** `src/components/VotingFeature.tsx` is an empty 7-line wrapper that only renders `<GeneralAssemblyVoting />`.
* **Gap:** Unnecessary abstraction layer.
* **Required Fix:** Consolidate imports directly to `GeneralAssemblyVoting.tsx` and delete the redundant wrapper.

### 3. PostgreSQL Database Synchronization Gap
* **Current Behavior:** The frontend primarily syncs with **Supabase (`residence_sync` JSON blob)** and `localStorage`. Although `AppContext.tsx` dispatches background `fetch()` calls to `/api/buildings`, `/api/apartments`, etc., these calls fail silently when Cloud SQL is not provisioned.
* **Intended Behavior:** A unified relational database where every individual entity is stored as a normalized relational row in PostgreSQL.
* **Gap:** Relational database routes in `server.ts` are decoupled from the primary Supabase JSON sync engine.
* **Required Fix:** Either run a database migration to sync Supabase tables individually or establish a background worker that unpacks the `residence_sync` JSON into PostgreSQL tables.

### 4. Automated SMS / WhatsApp Gateway
* **Current Behavior:** In `PaymentDueAlertModal.tsx`, clicking "Send WhatsApp" opens a client-side `https://wa.me/?text=...` URI. The user must manually click send inside the WhatsApp app.
* **Intended Behavior:** Background batch dispatching of SMS and WhatsApp messages directly to 100+ defaulting owners with a single click.
* **Gap:** Requires integration with a messaging API (Twilio or Meta WhatsApp Cloud API).

### 5. Automated Unit & Integration Tests
* **Current Behavior:** Zero test files exist in `src/`. `npm run lint` only executes `tsc --noEmit`.
* **Gap:** Critical financial calculations (e.g., debt interest, pointage deductions, receipt balance decrements) lack automated regression test suites.
* **Required Fix:** Introduce Vitest + React Testing Library to test `debtUtils.ts` and `pointageUtils.ts`.

---

# 13. CLICK / TAP BEHAVIOR MATRIX

| Page / Component | UI Element | User Action | Expected Behavior | Actual Code Implementation | Backend / Data Operation | Destination / Visual Result | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **LoginScreen** | "فضاء الملاك" Tab | Click | Switches to Co-owner login form | `setUserType('owner')` | None (Client state) | Displays Building/Unit selection inputs | **IMPLEMENTED** |
| **LoginScreen** | "دخول المالك" CTA | Click | Evaluates debt status and logs in | `loginResident(b, a)` | Checks `getApartmentDebtStatus` | Opens `OwnerSuspensionModal` if $>4$ mo, else Dashboard | **IMPLEMENTED** |
| **Navbar** | Language Switcher | Click | Toggles between Arabic and French | `toggleLanguage()` | Saves `app_lang` to LocalStorage | Inverts HTML `dir` attribute (rtl/ltr) and updates copy | **IMPLEMENTED** |
| **Navbar** | Audit Log Icon | Click | Opens audit trail drawer | `openActivityLog()` | Reads `activities` from state | Slides in `ActivityLogDrawer.tsx` from right | **IMPLEMENTED** |
| **Sidebar** | AutoSave Badge | Click | Triggers immediate cloud save | `triggerInstantAutoSave()` | Calls `/api/supabase/push` | Resets 60s countdown; displays spinning loader | **IMPLEMENTED** |
| **Sidebar** | Module Link (e.g., "الأداءات") | Click | Switches active workspace | `setActiveSection('payments')` | None (Client state) | Unmounts previous view; mounts `PaymentsView.tsx` | **IMPLEMENTED** |
| **Dashboard** | "استيراد السكان" Button | Click | Opens Excel resident import wizard | `setIsResidentsImportOpen(true)` | None | Mounts `ResidentsExcelImportModal.tsx` | **IMPLEMENTED** |
| **Dashboard** | WhatsApp Icon on Debtor | Click | Prepares official legal reminder | Opens `wa.me/212...` link | None (External URL scheme) | Launches WhatsApp with pre-filled demand letter | **IMPLEMENTED** |
| **PaymentsView** | "تسجيل وصل أداء" CTA | Click | Opens payment entry modal | `setIsAddModalOpen(true)` | None | Mounts payment form with auto receipt sequence | **IMPLEMENTED** |
| **PaymentsView** | "حفظ الوصل" in Modal | Click | Commits receipt and decrements debt | `addPayment(data)` | POST to `/api/payments` + Supabase push | Closes modal; opens `ReceiptModal.tsx` for printing | **IMPLEMENTED** |
| **ReceiptModal** | "طباعة الوصل" Button | Click | Triggers browser print dialog | `window.print()` | None | Opens system print dialog styled for thermal receipt | **IMPLEMENTED** |
| **ReceiptModal** | "تحميل PDF" Button | Click | Generates downloadable PDF | `generatePdfReceipt()` | Client jsPDF canvas render | Downloads `Recu_REC-2026-XXX.pdf` | **IMPLEMENTED** |
| **EmployeesView** | Pointage Calendar Cell | Click | Cycles staff attendance status | `setPointageStatus(empId, date, nextStatus)` | Updates `pointageRecords` in state & storage | Cell changes color (Green $\rightarrow$ Blue $\rightarrow$ Red) | **IMPLEMENTED** |
| **SyndicOfficeView**| "إرسال" in AI Assistant | Click | Submits prompt to Gemini AI | `fetch('/api/gemini/syndic-chat')` | Calls `@google/genai` (gemini-3.8-flash) | Displays streamed legal draft from Moroccan Syndic AI | **IMPLEMENTED** |
| **GeneralAssembly**| "موافق" Voting Button | Click | Casts vote on resolution | `castResolutionVote(id, 'for')` | Appends vote to resolution object | Updates vote progress bar; prevents duplicate voting | **IMPLEMENTED** |
| **BackupModal** | "تحميل النسخة الاحتياطية"| Click | Exports full system snapshot | `exportAllDataJSON()` | Serializes all 24 state collections | Downloads `remix_ma_residence_backup_YYYY-MM-DD.json` | **IMPLEMENTED** |

---

# 14. FRONTEND ARCHITECTURE

```
src/
├── main.tsx                         # React 19 bootstrap & DOM root mount
├── App.tsx                          # MainLayout, global modals, active section switcher
├── index.css                        # Tailwind CSS v4 core import (@import "tailwindcss")
├── types.ts                         # Complete TypeScript domain entity interfaces (475 lines)
├── types/
│   └── paymentDueAlertTypes.ts      # Reminder notification data contracts
├── context/
│   └── AppContext.tsx               # Master AppContext & State Manager (3,535 lines)
├── i18n/
│   └── translations.ts              # Full Arabic/French dictionary (1,118 lines)
├── data/
│   ├── initialData.ts               # 20 Canonical GH Buildings, seed tickets, notices
│   ├── moroccanResidentsData.ts     # Authentic Moroccan resident names & mock purge logic
│   ├── monthlyFinancialData.ts      # Historical financial records starting April 2025
│   └── initialResolutions.ts        # Seed General Assembly resolutions
├── utils/
│   ├── debtUtils.ts                 # Arrears calculations, 4-month rule logic
│   ├── excelImportUtils.ts          # xlsx parsing, header detection, validation engine
│   ├── exportUtils.ts               # Excel table data serialization
│   ├── duplicateCheckUtils.ts       # Duplicate payment prevention logic
│   ├── monthlyFinanceUtils.ts       # Ledger calculations, balance carry-overs
│   ├── pointageUtils.ts             # Payroll math, daily rates, deduction calculations
│   ├── pdfReceiptUtils.ts           # jsPDF receipt generation engine
│   ├── monthlyPdfReportUtils.ts     # jsPDF financial report document builder
│   └── paymentDueAlertUtils.ts      # Notification message templating
├── services/
│   └── supabaseSync.ts              # Supabase dual-sync proxy & client SDK layer
├── supabase.ts                      # Supabase client instantiation & config loader
├── db/
│   ├── schema.ts                    # Drizzle ORM PostgreSQL schema
│   ├── index.ts                     # Postgres Pool connection
│   └── drizzle.config.ts            # Drizzle Kit CLI configuration
└── components/                      # 43 High-Density React 19 UI Components
```

### Architectural Decisions
* **Framework:** React 19.0.1 running on Vite 6.2.3.
* **Styling Engine:** Tailwind CSS v4 (`@tailwindcss/vite`).
* **State Management:** Centralized `AppContext.tsx` providing a unified React Context containing 24 relational collections.
* **Persistence Strategy:** Local-First with optimistic UI updates. Actions update React state immediately, write synchronously to `localStorage`, and asynchronously stream payloads to Supabase and Express APIs.
* **Icons:** `lucide-react` (v0.546.0).
* **Charting:** `recharts` (v3.10.1) for financial curves and collection bar charts.

---

# 15. BACKEND ARCHITECTURE

The backend is built with **Node.js, Express 4.21, and TypeScript (`tsx server.ts`)**.

### Request Lifecycle
```
[Client Request]
       │
       ▼
[Express Server: server.ts (Port 3000)]
       │
       ├── Middleware: express.json({ limit: '50mb' })
       │
   ┌───┴────────────────────────────────────────────────┐
   │                                                    │
[Route: /api/gemini/syndic-chat]             [Route: /api/supabase/push]
   │                                                    │
   ▼                                                    ▼
[GoogleGenAI: gemini-3.8-flash]              [Fetch Proxy to Supabase REST API]
   │ (Injected Moroccan Legal System Prompt)            │ (Header: apikey, resolution=merge)
   ▼                                                    ▼
[JSON: { success: true, reply }]             [Table: residence_sync]
```

### Server Endpoints Summary
1. **Health & Status:** `GET /api/health`, `GET /api/gemini/status`
2. **AI Engine:** `POST /api/gemini/syndic-chat` (Leverages `@google/genai` TypeScript SDK)
3. **Supabase Cloud Proxy:**
   * `GET /api/supabase/test`: Ping Supabase `/auth/v1/health` and verify table presence.
   * `POST /api/supabase/push`: Upsert document `main_residence_data` into `residence_sync`.
   * `GET /api/supabase/pull`: Fetch latest consolidated JSON state.
   * `POST /api/supabase/clear`: Purge cloud sync document.
4. **Relational PostgreSQL Entity Endpoints (Drizzle ORM):**
   * `/api/buildings` (GET, POST)
   * `/api/apartments` (GET, POST, PUT)
   * `/api/residents` (GET, POST, PUT)
   * `/api/payments` (GET, POST, PUT, DELETE)
   * `/api/expenses` (GET, POST, PUT, DELETE)
   * `/api/employees` (GET, POST, PUT, DELETE)
   * `/api/maintenance_tickets` (GET, POST, PUT)
   * `/api/notices` (GET, POST, DELETE)
   * `/api/visitors` (GET, POST, PUT)

---

# 16. DATABASE ARCHITECTURE

The application implements a dual-database architecture:
1. **Primary Operational Cloud Store (Supabase):** Document/Object table `residence_sync` storing the full relational graph as JSONB.
2. **Normalized Relational Store (PostgreSQL / Drizzle ORM):** 11 tables defined in `src/db/schema.ts`.

### ASCII Entity Relationship Diagram (ERD)

```
       +-----------------------+
       |       BUILDINGS       |
       +-----------------------+
       | id (PK)               |
       | code (Unique)         |<------------+
       | name                  |             |
       | floors                |             |
       | apartments_count      |             |
       +-----------------------+             |
                   |                         |
                   | 1:N                     | 1:N
                   v                         |
       +-----------------------+             |
       |      APARTMENTS       |             |
       +-----------------------+             |
       | id (PK)               |             |
       | building_code (FK)    |             |
       | number                |<----+       |
       | owner_name            |     |       |
       | owner_cin             |     |       |
       | monthly_fee           |     |       |
       | balance_due           |     |       |
       +-----------------------+     |       |
                   |                 |       |
                   | 1:N             |       |
                   v                 |       |
       +-----------------------+     |       |
       |       RESIDENTS       |     |       |
       +-----------------------+     |       |
       | id (PK)               |     |       |
       | building_code (FK)    |     |       |
       | apartment_number (FK) |-----+       |
       | full_name             |             |
       | type (owner/tenant)   |             |
       | cin                   |             |
       +-----------------------+             |
                   |                         |
                   | 1:N                     |
                   v                         |
       +-----------------------+             |
       |       PAYMENTS        |             |
       +-----------------------+             |
       | id (PK)               |             |
       | receipt_number (UQ)   |             |
       | building_code (FK)    |-------------+
       | apartment_number (FK) |
       | period_month          |
       | amount                |
       | payment_date          |
       +-----------------------+

       +-----------------------+       +-----------------------+
       |       EMPLOYEES       |       |       EXPENSES        |
       +-----------------------+       +-----------------------+
       | id (PK)               |       | id (PK)               |
       | name                  |       | category              |
       | role                  |       | title                 |
       | salary                |       | amount                |
       | shift                 |       | date                  |
       +-----------------------+       | supplier              |
                                       +-----------------------+

       +-----------------------+       +-----------------------+
       |  MAINTENANCE_TICKETS  |       |        NOTICES        |
       +-----------------------+       +-----------------------+
       | id (PK)               |       | id (PK)               |
       | title                 |       | title                 |
       | building_code (FK)    |       | content               |
       | priority              |       | publish_date          |
       | status                |       | target_building       |
       +-----------------------+       +-----------------------+
```

---

# 17. AUTHENTICATION AND AUTHORIZATION

### Authentication Mechanisms
1. **Syndic / Staff Flow:**
   * User provides username and password.
   * `handleUserLogin()` matches credentials against the `users` collection.
   * If valid, issues a base64 session token: `'token_' + btoa(user.id + '_' + Date.now())`.
   * Sets `currentUser` in `AppContext` and writes to `localStorage.getItem('currentUser')`.
2. **Co-Owner / Resident Flow:**
   * Resident selects Building Code (`GH 34 A` to `GH 43 B`) and Apartment Number.
   * Optional CIN entry for verification.
   * System evaluates `getApartmentDebtStatus()`.
   * **Security Rule:** If overdue payments exceed 4 months, authentication is **strictly denied** (`status: 'RESTRICTED'`).
   * If clear, creates an ephemeral resident session user: `owner-gh38b-03`.

### Authorization & Permission Enforcement
* **Client-Side Gate:** `App.tsx` conditionally restricts sections (e.g., `SyndicOfficeView` redirects resident roles back to `DashboardView`).
* **Session Expiry:** Managed by `AutoLogoutGuard.tsx`. Tracks mouse moves, keypresses, and clicks. If no input occurs for **300 seconds (5 minutes)**, invokes `logout()`, clears session data, and redirects to login with an inactivity banner.

---

# 18. API DOCUMENTATION

| Method | Endpoint | Purpose | Auth Required | Request Body / Query | Success Response | Consumed By | Implementation Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Service health probe | None | None | `{ status: 'ok', database: 'connected' }` | Load balancers | **IMPLEMENTED** |
| `GET` | `/api/gemini/status`| Verify AI API key presence | None | None | `{ available: true, model: 'gemini-3.8-flash' }`| `SyndicAIAssistant.tsx` | **IMPLEMENTED** |
| `POST` | `/api/gemini/syndic-chat`| Moroccan legal AI reasoning | Yes | `{ prompt, history, context }` | `{ success: true, reply: "..." }` | `SyndicAIAssistant.tsx` | **IMPLEMENTED** |
| `GET` | `/api/supabase/test`| Check Supabase health & latency | None | Headers: `x-supabase-url`, `key` | `{ success: true, projectRef, latencyMs }`| `SupabaseConnectionWidget.tsx`| **IMPLEMENTED** |
| `POST` | `/api/supabase/push`| Proxy upsert consolidated state | Yes | Complete `ResidenceSyncPayload` | `{ success: true }` | `supabaseSync.ts` | **IMPLEMENTED** |
| `GET` | `/api/supabase/pull`| Fetch latest cloud state | Yes | None | `{ success: true, data: {...} }` | `supabaseSync.ts` | **IMPLEMENTED** |
| `POST` | `/api/supabase/clear`| Wipe cloud state document | Yes (Admin) | None | `{ success: true }` | `BackupModal.tsx` | **IMPLEMENTED** |
| `GET` | `/api/buildings` | List all 20 buildings | Yes | None | `Building[]` | `AppContext.tsx` | **IMPLEMENTED** |
| `POST` | `/api/payments` | Record new payment | Yes | `Omit<Payment, 'id'>` | `Payment` | `AppContext.tsx` | **IMPLEMENTED** |
| `PUT` | `/api/payments/:id`| Update existing payment | Yes | `Partial<Payment>` | `Payment` | `AppContext.tsx` | **IMPLEMENTED** |
| `DELETE`| `/api/payments/:id`| Remove payment | Yes | None | `{ success: true }` | `AppContext.tsx` | **IMPLEMENTED** |
| `GET` | `/api/expenses` | List all expenses | Yes | None | `Expense[]` | `AppContext.tsx` | **IMPLEMENTED** |
| `POST` | `/api/expenses` | Record new expense | Yes | `Omit<Expense, 'id'>` | `Expense` | `AppContext.tsx` | **IMPLEMENTED** |
| `DELETE`| `/api/expenses/:id`| Remove expense | Yes | None | `{ success: true, id }` | `AppContext.tsx` | **IMPLEMENTED** |

---

# 19. INFRASTRUCTURE

| Layer | Currently Implemented | Recommended / Production Target |
| :--- | :--- | :--- |
| **Frontend Hosting** | AI Studio Cloud Run Preview Container / Netlify / Vercel | Cloud Run / Vercel Pro with Custom Domain |
| **Backend Server** | Express 4.21 bundled with esbuild into `dist/server.cjs` | Containerized Node.js service on Cloud Run / ECS |
| **Cloud Database** | Supabase PostgreSQL (`dcbadrrjxdppjjqsaztp.supabase.co`) | Dedicated Supabase Pro or AWS RDS PostgreSQL |
| **AI Engine** | Google Gemini API (`gemini-3.8-flash` via `@google/genai`) | Retain `gemini-3.8-flash` (Optimal performance/cost) |
| **Storage / PDF** | Client-side in-memory generation via `jspdf` & `html2canvas` | Supabase Storage Bucket for permanent receipt archiving |
| **Domain & SSL** | Google Cloud Run auto-provisioned HTTPS certificates | Managed Custom Domain (`syndic.almarjane.ma`) with Cloudflare |
| **Monitoring** | In-app latency ping widget (`SupabaseConnectionWidget.tsx`)| Sentry for Error Tracking & Datadog for APM |

---

# 20. INFRASTRUCTURE DIAGRAM

```mermaid
graph TD
    subgraph Client_Browser ["User Web Browser (Desktop / Mobile)"]
        UI[React 19 SPA UI]
        Storage[(Local Storage)]
        PDF[jsPDF Engine]
    end

    subgraph Hosting_Platform ["Google Cloud Run / Express Server"]
        Server[Express Server: server.ts]
        ViteMid[Vite Middlewares]
        GeminiProxy[Gemini AI Route: /api/gemini/*]
        SupaProxy[Supabase Proxy: /api/supabase/*]
    end

    subgraph External_Cloud ["Cloud Infrastructure"]
        GeminiCloud[Google Gemini API: gemini-3.8-flash]
        SupabaseCloud[(Supabase PostgreSQL: residence_sync)]
        PGDatabase[(Cloud SQL / PostgreSQL)]
    end

    UI <-->|Local Cache Read/Write| Storage
    UI -->|Render Vouchers| PDF
    UI -->|HTTP / REST API Calls| Server

    Server --> ViteMid
    Server --> GeminiProxy
    Server --> SupaProxy
    Server -.->|Drizzle ORM| PGDatabase

    GeminiProxy -->|API Key Auth| GeminiCloud
    SupaProxy -->|Bearer Token Auth| SupabaseCloud
    UI -.->|Direct Fallback Sync| SupabaseCloud
```

### Explanation of Diagram
Requests originate from the React 19 client in the user's browser. State changes are cached synchronously in browser LocalStorage. Network calls hit the Express `server.ts` process. The server proxies AI requests to Google Gemini and database operations to Supabase. If the Express server is unavailable (e.g. static Netlify deployment), the browser's `supabaseSync.ts` directly connects to Supabase via its publishable API key.

---

# 21. DATA FLOW: PAYMENT CREATION & RECEIPT DISPATCH

```
[1. User clicks "حفظ الوصل" in PaymentsView.tsx]
       │
       ▼
[2. duplicateCheckUtils.ts: verifyNotDuplicate()]
       │
       ▼
[3. AppContext.tsx: addPayment()]
       │
       ├── Updates React state: setPayments(prev => [newPayment, ...prev])
       ├── Decrements apartment balance: setApartments(updatedBalance)
       ├── Commits to LocalStorage: saveToStorage('payments', payments)
       │
       ▼
[4. Dispatch Asynchronous Background Tasks]
       ├── POST /api/payments (Express/Postgres)
       └── pushToSupabaseNow() (services/supabaseSync.ts)
                 │
                 ▼
          [POST /api/supabase/push]
                 │
                 ▼
          [Supabase table: residence_sync]
                 │
                 ▼
[5. UI Updates Instantly: ReceiptModal.tsx mounts with Receipt REC-2026-XXX]
```

---

# 22. EXTERNAL SERVICES / INTEGRATIONS

1. **Google Gemini API (`@google/genai`):**
   * *Purpose:* Powers the Syndic Legal & Administrative AI Assistant.
   * *Configuration:* `server.ts` lines 12–29.
   * *Environment Variable:* `GEMINI_API_KEY`.
   * *Status:* **IMPLEMENTED & ACTIVE**.
2. **Supabase Cloud (`@supabase/supabase-js`):**
   * *Purpose:* Primary cloud database and live cross-device replication.
   * *Configuration:* `src/supabase.ts` and `src/services/supabaseSync.ts`.
   * *Environment Variables:* `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
   * *Status:* **IMPLEMENTED & ACTIVE**.
3. **PostgreSQL / Cloud SQL:**
   * *Purpose:* Normalized relational backend database.
   * *Configuration:* `src/db/index.ts`.
   * *Environment Variables:* `SQL_HOST`, `SQL_USER`, `SQL_PASSWORD`, `SQL_DB_NAME`.
   * *Status:* **IMPLEMENTED (Optional backend connection)**.

---

# 23. ENVIRONMENT VARIABLES

| Variable Name | Purpose | Required / Optional | Location Used |
| :--- | :--- | :--- | :--- |
| `GEMINI_API_KEY` | Authentication key for Google Gemini 3.8 Flash | Required for AI | `server.ts:14` |
| `APP_URL` | Public deployment URL for self-referential links | Optional | `server.ts`, `.env.example` |
| `VITE_SUPABASE_URL` | Supabase project endpoint URL | Required for Cloud | `src/supabase.ts:14` |
| `VITE_SUPABASE_ANON_KEY` | Supabase publishable anonymous key | Required for Cloud | `src/supabase.ts:22` |
| `SQL_HOST` | PostgreSQL / Cloud SQL server host address | Optional (Cloud SQL)| `src/db/index.ts:12` |
| `SQL_USER` | PostgreSQL username | Optional | `src/db/index.ts:13` |
| `SQL_PASSWORD` | PostgreSQL user password | Optional | `src/db/index.ts:14` |
| `SQL_DB_NAME` | PostgreSQL database name | Optional | `src/db/index.ts:15` |

---

# 24. DEPLOYMENT

### Production Build & Execution
* **Development Command:** `npm run dev` (Executes `tsx server.ts` running Express on port 3000 with Vite middleware).
* **Production Build Command:** `npm run build`
  * Step 1: `vite build` (Compiles client SPA into `/dist`).
  * Step 2: `esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs`.
* **Production Start Command:** `npm start` (Executes `node dist/server.cjs`).
* **Static Hosting Fallback:** `netlify.toml` and `vercel.json` are present in root, redirecting all routes to `/index.html`.

---

# 25. SECURITY REVIEW

| Vulnerability / Concern | Severity | Current Status in Codebase | Recommended Mitigation |
| :--- | :--- | :--- | :--- |
| **Client-Side Authorization** | **HIGH** | Role checks (`role === 'resident'`) occur in client React code. Malicious residents modifying JS state could theoretically view admin tabs. | Enforce JWT token verification on all server API routes. |
| **Plaintext Passwords in Local State** | **HIGH** | `users` collection in `initialData.ts` contains plaintext passwords (`admin123`, `syndic123`). | Hash passwords using `bcrypt` before storing. |
| **Public RLS Policy on Supabase** | **MEDIUM** | `supabase_schema.sql` sets `USING (true) WITH CHECK (true)` on `residence_sync`. | Restrict RLS policies using Supabase Auth JWT headers. |
| **Client-Side Sensitive Data** | **LOW** | All 320 apartment records are held in memory. | Acceptable for a single-residence intranet; paginate for multi-tenant. |

---

# 26. UX / PRODUCT GAPS

1. **No Real-Time Push Notifications:** Co-owners only see payment reminders when opening the app or when the syndic manually triggers WhatsApp links.
2. **Missing In-App Interactive Tour:** `OnboardingTour.tsx` is an empty stub returning null; new syndic board members have no guided tour.
3. **Manual Backup Restoration:** Restoring a JSON backup completely overwrites active state without a visual diff preview.

---

# 27. TECHNICAL DEBT

1. **Monolithic AppContext (`src/context/AppContext.tsx`):**
   * At **3,535 lines**, `AppContext.tsx` is an enormous file containing state, normalizers, handlers, and timer loops. It should be partitioned into focused domain contexts (`AuthContext`, `FinancialContext`, `MaintenanceContext`).
2. **Redundant Wrapper Components:**
   * `src/components/VotingFeature.tsx` is an unnecessary 7-line wrapper around `GeneralAssemblyVoting.tsx`.
3. **Dual Persistence Divergence:**
   * Writing simultaneously to `residence_sync` (JSON blob) and individual REST endpoints (`/api/payments`) creates potential divergence if one succeeds and the other fails.

---

# 28. TESTING STATUS

* **Unit Tests:** **0% (None found in `src/`)**.
* **Integration Tests:** **0% (None found)**.
* **End-to-End Tests:** **0% (None found)**.
* **Type Validation:** **100% PASS** (`npm run lint` passes with 0 TypeScript compiler errors).

---

# 29. CURRENT PROJECT COMPLETENESS

| Category | Assessment | Evidence |
| :--- | :--- | :--- |
| **Product UX** | **MOSTLY COMPLETE** | High visual fidelity, full Arabic/French localization, responsive layout. |
| **Frontend Architecture** | **COMPLETE** | 43 modular components, 55,000+ lines of clean TypeScript. |
| **Core Business Features** | **COMPLETE** | Receipts, Pointage, Budget, Voting, Excel Wizards, Debt Gates all work. |
| **Cloud Sync & Persistence** | **COMPLETE** | Supabase dual-sync + 1-minute auto-save countdown active. |
| **Backend API** | **COMPLETE** | Express server with Gemini AI and Supabase proxy routes operational. |
| **Security & Auth** | **PARTIAL** | Arrears gate works; password hashing and server-side RBAC needed. |
| **Automated Testing** | **NOT STARTED** | Zero test files exist in the codebase. |

---

# 30. MVP CHECKLIST

- [x] 20 Canonical GH Buildings configured for Résidence Al Marjane.
- [x] 320 Units initialized with floor, status, and fee tracking.
- [x] Arrears access-control gate blocking delinquent residents ($>4$ months).
- [x] Payment receipt creation with thermal and A4 PDF printing.
- [x] Automatic 1-minute recurring backup timer with visual countdown pill.
- [x] Dual-mode cloud synchronization to Supabase (`residence_sync`).
- [x] Excel resident bulk import wizard with column auto-detection.
- [x] Daily staff pointage matrix with attendance deduction calculations.
- [x] General Assembly real-time voting with quorum and majority verification.
- [x] Gemini 3.8 Flash AI Assistant for Moroccan property law and document drafting.
- [~] Interactive Onboarding Tour (`OnboardingTour.tsx` is currently a null stub).
- [ ] Automated SMS / WhatsApp Cloud API direct gateway.
- [ ] Automated unit test suite for financial calculations.

---

# 31. NEXT IMPLEMENTATION ORDER

### Phase 1: Foundation Clean-Up & Testing
1. **Implement Vitest Test Suite:** Write unit tests for `debtUtils.ts` (4-month rule) and `pointageUtils.ts` (salary deductions).
2. **Wire Onboarding Tour:** Replace the null stub in `OnboardingTour.tsx` with a functioning `react-joyride` tutorial.
3. **Prune Redundant Files:** Delete `VotingFeature.tsx` and route directly to `GeneralAssemblyVoting.tsx`.

### Phase 2: Security Hardening
1. **Password Hashing:** Upgrade `AppContext.tsx` and `server.ts` to hash passwords using `bcrypt`.
2. **Server-Side Token Verification:** Add Express auth middleware checking bearer tokens on `/api/*` routes.
3. **Restrict Supabase RLS:** Replace open `true` policies in `supabase_schema.sql` with authenticated user checks.

### Phase 3: Modular Refactoring
1. **Partition AppContext:** Split the 3,535-line `AppContext.tsx` into `AuthContext`, `FinanceContext`, and `OperationsContext`.

---

# 32. DEFINITION OF DONE FOR THE PROJECT

Before this application can be designated **100% Production Ready**:
1. All financial calculations (`debtUtils`, `pointageUtils`, `monthlyFinanceUtils`) must have 100% test coverage with 0 test failures.
2. User passwords must never be stored or transmitted in plaintext.
3. The 1-minute auto-save timer must gracefully handle offline network loss and retry automatically upon reconnection.
4. An end-to-end rehearsal must confirm that importing a 319-resident Excel sheet populates the database in under 3 seconds.

---

# 33. NEW DEVELOPER HANDOFF

### If you joined this project today, here is what you need to know:
* **The Mission:** This app manages **Résidence Al Marjane** (20 buildings, 319 apartments + 1 Syndic Bureau) in Morocco.
* **Where to Start Reading:**
  1. `src/types.ts` — Learn the data models (`Building`, `Apartment`, `Payment`, `Employee`, `PointageStatus`).
  2. `src/context/AppContext.tsx` — Understand how state is loaded from `localStorage` and synced to Supabase.
  3. `src/utils/debtUtils.ts` — Inspect the 4-month arrears rule that gates resident login.
  4. `server.ts` — View the Express server and Gemini AI endpoint.
* **Running Locally:**
  ```bash
  npm install
  npm run dev
  ```
  Opens at `http://localhost:3000`. Default login: Username `syndic`, Password `syndic` or `admin123`.

---

# 34. SOURCE OF TRUTH / TRACEABILITY

### Discrepancy Matrix: Intended vs. Current Implementation

#### 1. Interactive Onboarding Tour
* **INTENDED BEHAVIOR:** A new Syndic manager logging in for the first time is guided by an interactive tooltip tour highlighting key controls (Receipts, Arrears Alerts, Excel Importer).
* **CURRENT BEHAVIOR:** The component `src/components/OnboardingTour.tsx` returns `null`. `react-joyride` is installed in `package.json` but never invoked.
* **GAP:** Unimplemented feature.
* **REQUIRED FIX:** Connect Joyride steps to `#sidebar-bottom-autosave-badge`, `#btn-new-receipt`, and `#btn-excel-import` in `OnboardingTour.tsx`.

#### 2. WhatsApp Debt Reminders
* **INTENDED BEHAVIOR:** Automated batch dispatching of WhatsApp notifications directly from the server.
* **CURRENT BEHAVIOR:** `PaymentDueAlertModal.tsx` opens a client `wa.me/?text=...` URI requiring manual user confirmation in WhatsApp.
* **GAP:** Semi-automated client protocol versus fully automated server gateway.
* **REQUIRED FIX:** Integrate Meta WhatsApp Cloud API credentials in `server.ts` for background dispatching.

#### 3. Dual Database Storage Consistency
* **INTENDED BEHAVIOR:** Transactions are saved to a relational PostgreSQL database and mirrored in Supabase.
* **CURRENT BEHAVIOR:** State is saved as a single monolithic JSON document in Supabase table `residence_sync`. Relational PostgreSQL endpoints in `server.ts` are called in the background but do not block UI execution.
* **GAP:** Asymmetric persistence.
* **REQUIRED FIX:** Maintain `residence_sync` as the primary operational snapshot and use a background queue to hydrate normalized PostgreSQL tables.

---
**End of Master Specification Document.**
