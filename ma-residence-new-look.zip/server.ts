import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { db } from './src/db/index.js';
import * as schema from './src/db/schema.js';
import { eq } from 'drizzle-orm';
import { GoogleGenAI } from '@google/genai';

let SUPABASE_URL = 'https://dcbadrrjxdppjjqsaztp.supabase.co';
let SUPABASE_KEY = 'sb_publishable_5MlLgJzQFCJtzQMAZNDAKw_13yLLave';

let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return geminiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  function toSnakeCaseKeys(obj: any): any {
    if (Array.isArray(obj)) return obj.map(toSnakeCaseKeys);
    if (obj !== null && typeof obj === 'object' && !(obj instanceof Date)) {
      const res: any = {};
      for (const [key, value] of Object.entries(obj)) {
        const snakeKey = key.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
        res[snakeKey] = toSnakeCaseKeys(value);
      }
      return res;
    }
    return obj;
  }

  function toCamelCaseKeys(obj: any): any {
    if (Array.isArray(obj)) return obj.map(toCamelCaseKeys);
    if (obj !== null && typeof obj === 'object' && !(obj instanceof Date)) {
      const res: any = {};
      for (const [key, value] of Object.entries(obj)) {
        const camelKey = key.replace(/_([a-z])/g, (_, g) => g.toUpperCase());
        res[camelKey] = toCamelCaseKeys(value);
      }
      return res;
    }
    return obj;
  }

  // Simple Health Check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', database: 'connected' });
  });

  // --- Gemini AI for Syndic Office ---
  app.get('/api/gemini/status', (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    const hasKey = Boolean(process.env.GEMINI_API_KEY);
    res.json({
      available: true,
      hasGeminiApiKey: hasKey,
      model: hasKey ? 'gemini-3.8-flash' : 'syndic-expert-engine',
      officeName: 'مكتب السانديك - إقامة المرجان'
    });
  });

  // Local Moroccan Law 18.00 & Syndic administrative knowledge generator
  function generateSyndicLocalReply(prompt: string, context?: any): string {
    const p = prompt.toLowerCase();
    const isFr = /^[a-zA-Z\s,.'’éèàêëîïôöùûüç0-9-;:!?/]+$/.test(prompt.slice(0, 30)) || 
      p.includes('mise en demeure') || p.includes('convocation') || p.includes('syndic') || p.includes('loi 18.00');

    const residenceName = context?.residenceName || 'إقامة المرجان';
    const totalApartments = context?.totalApartments || 319;
    const buildingsCount = context?.totalBuildings || 20;
    const balance = context?.currentNetBalance || '0 DH';
    const income = context?.currentIncomeTotal || '0 DH';
    const expenses = context?.currentExpensesTotal || '0 DH';
    const openTickets = context?.openMaintenanceTickets || 0;

    if (p.includes('إنذار') || p.includes('mise en demeure') || p.includes('تذكير') || p.includes('impayé') || p.includes('متأخر')) {
      if (isFr) {
        return `### 📜 Modèle officiel : Mise en demeure de payer (Loi 18.00)

**ROYAUME DU MAROC**  
**UNION DES COPROPRIÉTAIRES DE LA RÉSIDENCE AL MORJANE**  
*Majeure copropriété de 20 immeubles (GH 34 à GH 43) - 319 lots*  
**Siège du Bureau du Syndic :** Immeuble GH 34 A - Rez-de-chaussée, N° 01  
**Date :** ${new Date().toLocaleDateString('fr-FR')}  

---

**À L'ATTENTION DE :**  
M. / Mme : _____________________________________________  
Copropriétaire du Lot N° : _______ - Immeuble : _________  
Adresse : Résidence Al Morjane  

**Objet : MISE EN DEMEURE FORMELLE AVANT PROCÉDURE JUDICIAIRE ET HYPOTHÈQUE FORCÉE**  
**Réf Légale :** Articles 25, 26 et 40 de la Loi n° 18.00 relative au statut de la copropriété des immeubles bâtis, telle que modifiée et complétée par la Loi n° 106.12.

Madame, Monsieur,

En notre qualité de Syndic légalement élu de l'Union des Copropriétaires de la Résidence Al Morjane, nous constatons avec regret le défaut d'apurement de vos charges de copropriété échues.

À ce jour, votre compte présente un arriéré exigible et impayé arrêté comme suit :
- **Période d'arriéré :** Du ____________ au ____________
- **Nombre de mensualités en retard :** _____ mois
- **Montant principal des charges :** ____________ MAD
- **Frais de rappel et de gestion :** ____________ MAD
- **TOTAL DÛ : ____________ MAD** *(en toutes lettres : ___________________________)*

Nous vous rappelons que l'obligation de participation aux charges communes est d'ordre public selon l'article 25 de la Loi 18.00.

Par la présente, nous vous mettons **FORMELLEMENT EN DEMEURE** de bien vouloir procéder au règlement intégral de la somme susmentionnée dans un délai de **quinze (15) jours francs** à compter de la réception de la présente.

Le paiement peut être effectué :
1. Directement au bureau du syndic (Immeuble GH 34 A - N° 01) contre reçu officiel.
2. Par virement bancaire sur le compte de l'Union des Copropriétaires :  
   **RIB :** [Numéro de compte bancaire de la résidence]

**Conséquences à défaut de règlement sous quinzaine :**  
À l'expiration de ce délai impératif, nous nous verrons dans l'obligation stricte, sans autre préavis :
1. De solliciter auprès du Président du Tribunal de Première Instance une **Ordonnance d'injonction de payer (مسطرة الأمر بالأداء)** avec exécution provisoire.
2. De procéder à l'inscription d'une **HYPOTHÈQUE FORCÉE (الرهن الإجباري)** sur votre titre foncier auprès de la Conservation de la Propriété Foncière (Article 40 de la Loi 18.00), dont les frais et honoraires de justice resteront à votre charge exclusive.

Comptant sur votre sens civique et votre responsabilité pour préserver l'harmonie et la viabilité financière de notre résidence.

*Veuillez agréer, Madame, Monsieur, l'assurance de notre considération distinguée.*

**Pour le Bureau du Syndic**  
*Signature et Cachet de l'Union des Copropriétaires*`;
      } else {
        return `### 📜 نموذج رسمي: إنذار بأداء واجبات السانديك (قانون 18.00)

**المملكة المغربية**  
**اتحاد ملاك إقامة المرجان**  
*مجمع سكني يضم 20 عمارة (319 شقة سكنية)*  
**مقر مكتب السانديك:** عمارة GH 34 A - الطابق الأرضي، شقة رقم 01  
**التاريخ:** ${new Date().toLocaleDateString('ar-MA')}  

---

**إلـى السيـد(ة):** ................................................................  
**مالك(ة) الشقة رقم:** ........... - **العمارة:** ...........  
**إقامة المرجان**  

**الموضوع: إنـذار بـالأداء قـبـل سـلـوك المساطـر القضائيـة والرهـن الإجبـاري**  
**المرجع القانوني:** مقتضيات المواد 25، 26 و40 من القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية، المعدل والمتمم بالقانون رقم 106.12.

سلام تام بوجود مولانا الإمام،

وبعد، بصفتنا وكيلاً قانونياً لاتحاد الملاك المشتركين لإقامة المرجان، يؤسفنا إشعاركم بأن ذمتكم المالية تجاه صندوق الإقامة لا زالت تسجل متأخرات غير مؤداة خاصة بالواجبات الشهرية للتدبير والصيانة والنظافة والحراسة، والمفصلة كالتالي:

- **الفترة المستحقة:** من شهر ....................... إلى غاية شهر .......................
- **عدد أشهر التأخير:** ........... شهراً.
- **مبلغ الواجبات الشهرية العالقة:** ....................... درهم.
- **مصاريف التذكير والإنذار:** ....................... درهم.
- **المجموع الإجمالي الواجب أداؤه فوراً:** ....................... درهم *(بالحروف: ......................................................)*.

ونحيطكم علماً بأن أداء هذه الواجبات يقع على عاتقكم بقوة القانون وبشكل إلزامي وفقاً لأحكام المادة 25 من القانون 18.00 لضمان السير العادي للمرافق المشتركة المشتركة بين الجميع.

وعليه، فإننا نوجه إليكم هذا **الإنذار الرسمي** لتسوية وضعيتكم وأداء المبلغ المذكور داخل أجل أقصاه **خمسة عشر (15) يوماً** تبتدئ من تاريخ توصلكم بهذه المراسلة.

يمكن الأداء لدى:
1. مكتب السانديك الرسمي (عمارة GH 34 A - الشقة 01) وتسلم وصل أداء رسمي ومختوم.
2. أو بالتحويل البنكي لحساب اتحاد الملاك البنكي:  
   **رقم الحساب البنكي (RIB):** ..............................................................

**الآثار القانونية المترتبة في حال عدم الأداء داخل الأجل:**  
في حال انقضاء أجل 15 يوماً دون تسوية الوضعية، فإن مكتب السانديك سيضطر مجبراً إلى:
1. استصدار **أمر بالأداء استعجالي وقضائي** من طرف السيد رئيس المحكمة الابتدائية المختصة مع النفاذ المعجل وتحميلكم الصوائر القانونية.
2. تقييد **رهن إجباري (Hypothèque forcée)** على رسمكم العقاري بالمحافظة العقارية وفقاً لمقتضيات المادة 40 من القانون رقم 18.00، ولن يرفع إلا بعد أداء أصل الدين وجميع المصاريف القضائية.

وإننا لنعول على حسكم بالمسؤولية والمواطنة وتفادي المساطر القانونية لما فيه مصلحة إقامتنا المشتركة.

وتقبلوا فائق التقدير والاحترام.

**عن مكتب السانديك**  
*وكيل اتحاد الملاك المشتركين - إقامة المرجان*  
*(الخاتم والتوقيع)*`;
      }
    }

    if (p.includes('جمع عام') || p.includes('convocation') || p.includes('assemblée') || p.includes('ordre du jour') || p.includes('دعوة')) {
      if (isFr) {
        return `### 📢 Modèle officiel : Convocation à l'Assemblée Générale Ordinaire

**UNION DES COPROPRIÉTAIRES DE LA RÉSIDENCE AL MORJANE**  
*Ensemble immobilier de 20 immeubles (GH 34 à GH 43)*  
**Bureau du Syndic :** Immeuble GH 34 A - RDC, Apt 01  

**Date d'émission :** ${new Date().toLocaleDateString('fr-FR')}  

---

**AVIS DE CONVOCATION À L'ASSEMBLÉE GÉNÉRALE ANNUELLE ORDINAIRE**  
*(Conformément aux articles 16, 17 et 18 de la loi marocaine n° 18.00)*

Mesdames, Messieurs les Copropriétaires de la Résidence Al Morjane,

Le Syndic de copropriété a l'honneur de vous convier à la réunion de l'**Assemblée Générale Annuelle Ordinaire** de l'Union des Copropriétaires, qui se tiendra le :

🗓️ **Date :** Samedi ___ / ___ / 202___  
⏰ **Heure :** 15h00 (Accueil et émargement dès 14h30)  
📍 **Lieu :** Salle polyvalente / Esplanade de la Résidence Al Morjane  

#### ORDRE DU JOUR DÉTAILLÉ :
1. **Émargement de la feuille de présence**, vérification des procurations et constatation du quorum légal.
2. **Présentation et discussion du Rapport Moral d'activité** du Syndic pour l'exercice écoulé.
3. **Présentation du Rapport Financier** (Bilan détaillé des recettes et des dépenses : gardiennage, nettoyage, entretien des pompes et éclairage).
4. **Approbation des comptes** et vote du quitus au Bureau du Syndic sortant.
5. **Vote du Budget Prévisionnel** pour le nouvel exercice et fixation du montant de la cotisation mensuelle par lot.
6. **Plan de maintenance et travaux préventifs prioritaires** (étanchéité, sécurité des portes, espaces verts).
7. **Élection / Renouvellement du Syndic** et de son adjoint conformément à la loi 18.00.
8. **Questions diverses et points d'amélioration collective.**

*Note statutaire :* Si le quorum réglementaire de la moitié des voix des copropriétaires n'est pas atteint lors de cette première convocation, une seconde séance se tiendra valablement après un délai de 30 jours quel que soit le nombre des présents.

En cas d'empêchement, vous pouvez vous faire représenter par un autre copropriétaire muni d'un pouvoir écrit et légalisé.

**Le Syndic de Copropriété**`;
      } else {
        return `### 📢 إعلان رسمي: دعوة لحضور الجمع العام السنوي العادي

**المملكة المغربية**  
**اتحاد ملاك إقامة المرجان (20 عمارة - 319 شقة)**  
**مقر المكتب:** عمارة GH 34 A - الطابق الأرضي - الشقة 01  
**التاريخ:** ${new Date().toLocaleDateString('ar-MA')}  

---

**بـــــلاغ ودعــــوة لـلـجـمـع الـعـــام الـعــــادي الـسـنــــوي**  
*(طبقاً لأحكام المواد 16، 17، 18، 19 من القانون 18.00 المتعلق بنظام الملكية المشتركة)*

إلى كافة السيدات والسادة الملاك المشتركين بإقامة المرجان،

يتشرف وكيل اتحاد الملاك المشتركين (السانديك) بدعوتكم الكريمة لحضور فعاليات **الجمع العام السنوي العادي** للملاك، المزمع عقده بمشيئة الله:

🗓️ **التاريخ:** يوم السبت ..... / ..... / 202....  
⏰ **التوقيت:** على الساعة الخامسة مساءً (17:00) - استقبال الحضور وتوقيع ورقة الحضور ابتداءً من 16:30.  
📍 **المكان:** فضاء الاجتماعات بإقامة المرجان / مقر مكتب السانديك.  

#### جــدول الأعـمــــال الـمـفـصـــل:
1. **التحقق من النصاب القانوني** وتوقيع ورقة الحضور وتدقيق التوكيلات الممنوحة.
2. **تلاوة التقرير الأدبي** لحصيلة عمل مكتب السانديك برسم السنة المنصرمة ومناقشته.
3. **عرض التقرير المالي المفصل** (حصيلة المداخيل، المصاريف: أجور العمال، الحراسة، النظافة، الكهرباء، المحامي، المفوض القضائي، الرصيد الباقي).
4. **المصادقة على الحسابات المالية** والتصويت على إبراء ذمة المكتب المسير.
5. **عرض ومناقشة الميزانية التقديرية** للسنة القادمة وتحديد واجب الاشتراك الشهري للشقق.
6. **برنامج الصيانة الوقائية والمشاريع المستقبلية** (المضخات، الإنارة، كاميرات المراقبة، البوابات، المساحات الخضراء).
7. **انتخاب أو تجديد الثقة في وكيل الاتحاد (السانديك) ونائبه** طبقاً للقانون.
8. **دراسة النقط المختلفة واقتراحات الساكنة.**

*تنبيه قانوني:* في حال عدم اكتمال النصاب القانوني المنصوص عليه في القانون، سيتم الدعوة لجمع عام ثانٍ ينعقد صحيحاً بمن حضر بعد انصرام الأجل القانوني (30 يوماً).

نظراً لأهمية القرارات المرتقبة في تدبير وتثمين ممتلكات إقامتنا المشتركة، فإن حضوركم الشخصي واجب وضروري. وفي حال تعذر ذلك، يرجى ملء وتوقيع التوكيل القانوني المرفق.

**عن مكتب السانديك - وكيل اتحاد الملاك المشتركين**`;
      }
    }

    if (p.includes('رهن') || p.includes('hypothèque') || p.includes('محافظة') || p.includes('conservation')) {
      if (isFr) {
        return `### ⚖️ Guide Juridique : Procédure de l'Hypothèque Forcée (Loi 18.00)

L'article 40 de la Loi 18.00 confère au Syndic un privilège puissant pour garantir le recouvrement des créances de l'Union des Copropriétaires.

#### 1. Fondement légal (Article 40)
Les créances de l'Union des Copropriétaires à l'encontre de tout copropriétaire bénéficient d'une **hypothèque forcée** sur son lot privatifié (titre foncier individuel). Cette hypothèque prend rang dès son inscription à la Conservation Foncière.

#### 2. Conditions préalables requises :
1. Une dette certaine, liquide et exigible (charges votées en AG ou dépenses indispensables d'entretien).
2. L'envoi préalable d'une mise en demeure par lettre recommandée avec AR ou par huissier de justice (مفوض قضائي), restée sans effet après le délai légal de 15 jours.
3. Une attestation de créance certifiée et signée par le Syndic spécifiant le détail des arriérés.

#### 3. Dossier à déposer à la Conservation Foncière :
- Demande d'inscription de l'hypothèque forcée signée par le Syndic.
- Procès-verbal de l'Assemblée Générale élisant le Syndic (certifié conforme).
- Copie de la mise en demeure notifiée avec accusé de réception ou procès-verbal de notification de l'huissier.
- État certifié des impayés arrêté à la date de la demande.
- Extrait du règlement de copropriété mentionnant la quote-part du lot.

#### 4. Effets juridiques majeurs :
- Le copropriétaire ne peut vendre, ni céder son lot sans mainlevée préalable délivrée par le Syndic.
- En cas de vente forcée ou volontaire, l'Union des Copropriétaires est payée par priorité sur le prix de vente.
- La mainlevée n'est accordée qu'après règlement intégral du principal, des intérêts et des frais d'inscription et de radiation.`;
      } else {
        return `### ⚖️ الدليل الإجرائي القانوني: مسطرة الرهن الإجباري (المادة 40 من القانون 18.00)

تعتبر مسطرة **الرهن الإجباري** من أقوى الضمانات القانونية المخولة قانوناً لوكيل الاتحاد (السانديك) لحماية حقوق الملاك واستخلاص ديون السانديك المتأخرة.

#### 1. السند القانوني (المادة 40 من القانون 18.00)
تنص المادة 40 على ما يلي:  
*"تضمن ديون اتحاد الملاك المترتبة في ذمة أحد الملاك المشتركين، برهن إجباري يقع على جزئه المفرز... يمارس هذا الرهن بطلب من وكيل الاتحاد بمجرد أن تصبح الديون مستحقة وغير مؤداة وبعد توجيه إنذار بالأداء للمدين ظل دون جدوى لمدة ثلاثين يوماً..."*

#### 2. الشروط والمراحل العملية لإجراء الرهن:
1. **ثبوت الدين واستحقاقه:** أن تكون الواجبات مقررة قانوناً من طرف الجمع العام أو ناتجة عن نفقات حفظ وصيانة الأجزاء المشتركة.
2. **توجيه الإنذار الرسمي:** عبر رسالة مضمونة مع الإشعار بالتوصل أو بواسطة مفوض قضائي ومنحه مهلة قانونية للأداء.
3. **إعداد شهادة بمبلغ الدين:** صادرة وموقعة ومختومة من طرف السانديك توضح المبلغ بالتفصيل وتاريخ الاستحقاق.

#### 3. الوثائق المطلوبة لدى المحافظة العقارية:
- طلب رسمي موجه للسيد المحافظ على الأملاك العقارية لتقييد رهن إجباري.
- نسخة مشهود بمطابقتها للأصل من محضر الجمع العام الذي انتخب فيه السانديك.
- نسخة من الإنذار الموجه للمالك مع محضر التبليغ أو بطاقة التوصل البريدية.
- شهادة إبراء أو بيان تفصيلي بالمتأخرات موقع من السانديك.
- رقم الرسم العقاري الخاص بالشقة المفرزة موضوع الرهن.

#### 4. الأثر القانوني للرهن الإجباري:
- يغل يد المالك عن بيع الشقة أو التصرف فيها أو رهنها لبنك آخر حتى يسدد كامل ديون السانديك ويسحب شهادة رفع اليد (Mainlevée).
- يمنح اتحاد الملاك مرتبة ممتازة لاستيفاء ديونه بالأولوية على ثمن العقار.
- مصاريف التقييد ورفعه يتحملها المالك المدين بالكامل.`;
      }
    }

    if (p.includes('محضر') || p.includes('pv') || p.includes('procès-verbal') || p.includes('اجتماع')) {
      if (isFr) {
        return `### 📋 Modèle officiel : Procès-Verbal de Réunion du Bureau du Syndic

**RÉSIDENCE AL MORJANE**  
*Ensemble de 20 immeubles (GH 34 à GH 43)*  
**PROCÈS-VERBAL DE LA RÉUNION PÉRIODIQUE DU BUREAU DU SYNDIC**  

**Date :** Le ____ / ____ / 202___ à ____h____  
**Lieu :** Bureau d'administration du Syndic - Immeuble GH 34 A (RDC - Apt 01)  

**Étaient présents :**  
- M. _________________________ : Syndic Principal  
- M. _________________________ : Syndic Adjoint  
- M. _________________________ : Responsable Technique & Maintenance  
- M. _________________________ : Représentant de la Commission des Comptes  

#### 1. Suivi des Prestations Externes :
- **Société de Sécurité et Gardiennage :** Examen des rondes de nuit, respect des postes aux entrées de l'esplanade et contrôle des accès.
- **Société de Nettoyage :** Constat sur la propreté des cages d'escaliers des 20 immeubles et ramassage des déchets ménagers.

#### 2. Situation Financière et Recouvrement :
- Bilan des encaissements du mois en cours : ____________ MAD.
- Examen des dossiers des copropriétaires débiteurs (+6 mois de retard).
- Décision de transmission de _____ dossiers d'impayés à l'avocat et à l'huissier de justice pour engagement des procédures d'injonctions de payer.

#### 3. Travaux et Maintenance Technique :
- Contrôle de la surpression d'eau et des pompes de relevage des blocs GH 34 à GH 43.
- Remplacement des luminaires défaillants dans les parties communes par des LED économiques à détecteur de mouvement.

#### 4. Résolutions et Décisions Adoptées :
1. *Résolution N° 1 :* Validation du paiement des factures de fournitures et salaires des agents de permanence.
2. *Résolution N° 2 :* Lancement d'une campagne de sensibilisation des résidents sur le respect des espaces verts et des places de stationnement.

L'ordre du jour étant épuisé, la séance a été levée à ____h____.

*Fait à la Résidence Al Morjane, le même jour que dessus.*

**Le Syndic Principal** &emsp;&emsp;&emsp;&emsp; **Le Syndic Adjoint**`;
      } else {
        return `### 📋 نموذج رسمي: محضر اجتماع مكتب السانديك (PV)

**إقامة المرجان - اتحاد الملاك المشتركين**  
*مجمع سكني مكون من 20 عمارة (319 شقة سكنية)*  
**مقر المكتب:** عمارة GH 34 A - الشقة 01  

---

**محـضـر اجـتـمـاع دوري لـمـكـتـب الـسـانـديـك ومـجـلـس الإقـامـة**

**التاريخ:** انعقد بتاريخ ..... / ..... / 202.... على الساعة ............  
**المكان:** مقر مكتب السانديك بالشقة 01 عمارة GH 34 A.  

**الحاضرون:**  
1. السيد: .................................................... وكيل الاتحاد (السانديك).  
2. السيد: .................................................... نائب وكيل الاتحاد.  
3. السيد: .................................................... منسق عمارات GH 34 إلى GH 38.  
4. السيد: .................................................... منسق عمارات GH 39 إلى GH 43.  

#### جـدول الأعمال والمناقشات:
1. **تقييم خدمات الحراسة والأمن والنظافة:**
   - تسجيل انتظام أعوان الحراسة في المداخل والتأكيد على الدوريات الليلية بين العمارات الـ 20.
   - متابعة نظافة المداخل والسلالم والأسطح وممرات السيارات المشتركة.

2. **الوضعية المالية وملف المتأخرات:**
   - حصر المداخيل المحصلة برسم الشهر المنصرم ومقارنتها بالمصاريف الإلزامية (أجور العمال، الكهرباء، المحامي، المفوض القضائي).
   - فرز لوائح السكان المتأخرين الذين تجاوز تأخرهم 6 أشهر، وتكليف المفوض القضائي بتبليغ الإنذارات الرسمية القانونية.

3. **الصيانة الوقائية والأشغال العاجلة:**
   - فحص اشتغال مضخات ضغط الماء وخزانات الأمان المشتركة وتفقد الإنارة الذكية في الممرات.

#### الـقـرارات والـتـوصـيـات الـمـتـخـذة:
- **القرار الأول:** المصادقة على صرف مستحقات ونفقات الصيانة الدورية وأداء فواتير الإنارة المشتركة.
- **القرار الثاني:** تفعيل التنبيهات الإلكترونية والرسائل المباشرة للمتأخرين عبر الواتساب والإيميل مع إعطاء مهلة ودية قبل اللجوء للمحكمة.
- **القرار الثالث:** إطلاق مبادرة تحسين الفضاء الأخضر المركزي والاعتناء بمحيط العمارات.

رُفعت الجلسة على الساعة ................... بعد استنفاد جميع النقط المسجلة بجدول الأعمال.

**نائب السانديك** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **وكيل الاتحاد (السانديك)**`;
      }
    }

    // Default intelligent syndic analysis & advice
    if (isFr) {
      return `### 💡 Analyse & Recommandations du Bureau du Syndic

**Résidence Al Morjane** (20 immeubles, 319 logements)  
*État financier actuel : Total Recettes : ${income} | Dépenses : ${expenses} | Solde disponible : ${balance}*

Concernant votre demande : **"${prompt}"**

Voici l'analyse opérationnelle et juridique adaptée aux spécificités de la copropriété au Maroc (Loi 18.00 / 106.12) :

1. **Cadre réglementaire applicable :**  
   Conformément au Dahir portant statut de la copropriété, toute décision touchant la conservation ou les modifications substantielles des parties communes doit être conforme au règlement de copropriété ou votée en Assemblée Générale à la majorité requise (article 21 ou 24 selon la nature des travaux).

2. **Gestion rigoureuse du recouvrement :**  
   Pour les copropriétaires enregistrant plus de 6 mois d'arriérés, la loi marocaine accorde au Syndic le droit d'engager immédiatement la procédure d'injonction de payer sans qu'il soit nécessaire d'obtenir une nouvelle autorisation de l'Assemblée Générale.

3. **Bonnes pratiques administratives :**  
   - Toujours formaliser les accords et décisions par écrit (procès-verbal contresigné).  
   - Maintenir à jour le registre d'immatriculation des copropriétaires et des locataires au bureau du syndic (Immeuble GH 34 A).  
   - Conserver systématiquement les justificatifs de dépenses et de facturation (gardiennage, électricité des communs, fournitures de drogerie).

Le Bureau du Syndic reste à votre disposition pour générer tout document complémentaire (mise en demeure, convocation, affichage résidentiel).`;
    } else {
      return `### 💡 استشارة وتوجيه إداري لمكتب السانديك

**إقامة المرجان** (20 عمارة، 319 شقة سكنية)  
*المؤشرات المالية الحالية: مجموع المداخيل: ${income} | مجموع المصاريف: ${expenses} | الرصيد المتاح: ${balance} | تذاكر الصيانة المفتوحة: ${openTickets}*

بخصوص طلبكم: **"${prompt}"**

إليكم التوجيهات القانونية والإدارية والعملية المطابقة لمقتضيات القانون رقم 18.00 المنظم للملكية المشتركة في المغرب:

1. **الجانب التنظيمي والقانوني:**  
   إن تدبير المجمع السكني لإقامة المرجان يخضع لقرارات الجمع العام ونظام الملكية المشتركة. كل ما يرتبط بالأجزاء المشتركة (المصاعد، المضخات، الممرات، المداخل، السطوح) يقع تحت المسؤولية المباشرة لوكيل الاتحاد لضمان سلامة وسكينة الساكنة.

2. **تدبير الاستخلاص والمتأخرين (+6 أشهر):**  
   - الساكنة التي تجاوز تأخرها 6 أشهر تصنف ضمن المتأخرين الحرجين الموجبين للإنذار الرسمي عبر المفوض القضائي ومباشرة مسطرة الأمر بالأداء أمام رئيس المحكمة الابتدائية مع تقييد الرهن الإجباري.
   - الساكنة ذات التأخر بين 1 و5 أشهر تعامل وفق مساطر التذكير الودية عبر الواتساب والرسائل المكتوبة للحفاظ على العلاقات الطيبة.

3. **توصيات الحكامة والشفافية:**  
   - مسك دفاتر محاسبية دقيقة توثق المداخيل والمصاريف اليومية بفواتير وتواصيل مختومة.
   - عقد اجتماعات دورية منتظمة مع ممثلي العمارات لتشخيص الأعطاب الطارئة بسرعة.
   - إعداد التقريرين المالي والأدبي مسبقاً قبل موعد الجمع العام السنوي لتمكين الملاك من الاطلاع عليهما.

إذا كنت ترغب في صياغة نموذج رسمي (إنذار، إعلان للساكنة، محضر اجتماع، أو شكاية)، يرجى تحديد نوع الوثيقة وسأقوم بصياغتها فوراً بالصيغة القانونية المعتمدة!`;
    }
  }

  app.post('/api/gemini/syndic-chat', async (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    try {
      const { prompt, history, context } = req.body;
      if (!prompt || typeof prompt !== 'string') {
        return res.status(400).json({ error: 'نص الطلب مطلوب' });
      }

      const ai = getGemini();
      
      // If Gemini client is available, attempt real Gemini generation
      if (ai) {
        try {
          const systemInstruction = `أنت المساعد الذكي الإداري والقانوني والمالي المخصص حصرياً لـ "مكتب السانديك" (وكيل اتحاد الملاك المشتركين) في "إقامة المرجان" بالمملكة المغربية.
دورك:
1. صياغة المراسلات الرسمية والإعلانات والبلاغات الموجهة للملاك وسكان الإقامة بأسلوب إداري رفيع.
2. صياغة الإنذارات ورسائل التذكير القانونية للملاك المتأخرين عن الأداء (Mise en demeure) وفق مقتضيات القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية في المغرب والمعدل بالقانون رقم 106.12.
3. إعداد وصياغة دعوات وجداول أعمال ومحاضر الجموع العامة السنوية والاستثنائية للملاك (Procès-verbaux d'Assemblée Générale).
4. تقديم استشارات تنظيمية في تدبير الأجزاء المشتركة، حل النزاعات الودية، تنظيم مواقف السيارات، تدبير عقود شركات الحراسة والنظافة وصيانة المصاعد.
5. تقديم تحليلات مالية ومقترحات لترشيد المصاريف ورفع نسبة تحصيل اشتراكات السانديك.

سياق إقامة المرجان:
- الموقع: المغرب.
- البنية: 20 عمارة (10 كتل توأمية من GH 34 A/B إلى GH 43 A/B).
- عدد الوحدات: 319 شقة سكنية + 1 مكتب السانديك الإداري (المقر الرسمي بالشقة 01 - RDC في عمارة GH 34 A).
- نظام الواجبات: يحدد بقرار الجمع العام (بين 150 إلى 200 درهم شهرياً للشقة).

قواعد الإجابة:
- استخدم لغة عربية فصيحة، واضحة، ومهنية للغاية وقوية الصياغة (أو الفرنسية إذا كتب المستخدم بالفرنسية).
- عند طلب صياغة نموذج وثيقة أو إعلان أو إنذار، قدم النموذج كاملاً وجاهزاً للنسخ المباشر أو الطباعة مع وضع فراغات واضحة للبيانات التكميلية (التاريخ، الاسم، التوقيع).
- كن عملياً ومباشراً وموجهاً لمصلحة حسن تدبير الإقامة المشتركة.`;

          const contents: any[] = [];
          if (Array.isArray(history) && history.length > 0) {
            for (const msg of history) {
              if ((msg.role === 'user' || msg.role === 'model') && typeof msg.text === 'string' && msg.text.trim()) {
                contents.push({
                  role: msg.role,
                  parts: [{ text: msg.text }]
                });
              }
            }
          }

          let userText = prompt;
          if (context) {
            userText = `[معطيات وإحصائيات حالية من نظام السانديك: ${JSON.stringify(context)}]\n\n${prompt}`;
          }

          contents.push({
            role: 'user',
            parts: [{ text: userText }]
          });

          const response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: contents,
            config: {
              systemInstruction: systemInstruction,
              temperature: 0.7,
            }
          });

          if (response && response.text) {
            return res.json({
              success: true,
              reply: response.text,
              model: 'gemini-3.8-flash'
            });
          }
        } catch (apiErr: any) {
          console.warn('Gemini API call failed, falling back to Syndic Knowledge Engine:', apiErr.message);
        }
      }

      // High-grade Moroccan Law 18.00 Syndic Expert Engine fallback
      const localReply = generateSyndicLocalReply(prompt, context);
      return res.json({
        success: true,
        reply: localReply,
        model: 'syndic-legal-engine'
      });
    } catch (error: any) {
      console.error('Gemini Syndic Assistant Error:', error);
      const fallbackReply = generateSyndicLocalReply(req.body?.prompt || '', req.body?.context);
      return res.json({
        success: true,
        reply: fallbackReply,
        model: 'syndic-safe-fallback'
      });
    }
  });

  // Helper function to handle network/fetch errors gracefully
  function formatSupabaseError(error: any): string {
    const msg = error?.message || String(error);
    const cause = error?.cause ? String(error.cause) : '';
    if (
      msg.includes('ENOTFOUND') || 
      msg.includes('fetch failed') || 
      msg.includes('Failed to fetch') || 
      msg.includes('ECONNREFUSED') || 
      msg.includes('ETIMEDOUT') || 
      cause.includes('ENOTFOUND')
    ) {
      return 'تعذر الاتصال بقاعدة البيانات السحابية (الخادم غير متوفر أو معطل مؤقتاً).';
    }
    return msg;
  }

  const normalizeSupabaseUrl = (urlStr: string): string => {
    if (!urlStr) return '';
    let cleaned = urlStr.trim();
    cleaned = cleaned.replace(/\/rest\/v1\/?$/i, '');
    cleaned = cleaned.replace(/\/+$/, '');
    return cleaned;
  };

  const getTargetSupabase = (req: express.Request) => {
    const customUrl = (req.headers['x-supabase-url'] as string)?.trim();
    const customKey = (req.headers['x-supabase-key'] as string)?.trim();
    const rawUrl = (customUrl && customUrl.startsWith('http')) ? customUrl : SUPABASE_URL;
    return {
      url: normalizeSupabaseUrl(rawUrl),
      key: customKey || SUPABASE_KEY
    };
  };

  // Test Supabase Connection Endpoint
  app.get('/api/supabase/test', async (req, res) => {
    const startTime = Date.now();
    const { url: targetUrl, key: targetKey } = getTargetSupabase(req);
    const defaultProjectRef = targetUrl.match(/https:\/\/([^.]+)\.supabase\.co/)?.[1] || 'dcbadrrjxdppjjqsaztp';

    try {
      const response = await fetch(`${targetUrl}/auth/v1/health`, {
        method: 'GET',
        headers: {
          'apikey': targetKey,
        }
      });
      const latencyMs = Date.now() - startTime;
      const projectRef = response.headers.get('sb-project-ref') || defaultProjectRef;
      
      let tableReady = false;
      try {
        const tableCheck = await fetch(`${targetUrl}/rest/v1/residence_sync?select=id&limit=1`, {
          method: 'GET',
          headers: {
            'apikey': targetKey,
            'Authorization': `Bearer ${targetKey}`,
          }
        });
        tableReady = tableCheck.ok;
      } catch (tErr) {
        tableReady = false;
      }

      if (response.ok) {
        return res.json({
          success: true,
          projectRef,
          status: 'connected',
          latencyMs,
          tableReady,
          timestamp: new Date().toISOString(),
          message: `تم الاتصال بنجاح بمشروع Supabase (${projectRef})`,
          messageFr: `Connexion réussie au projet Supabase (${projectRef})`
        });
      }

      return res.status(response.status).json({
        success: false,
        projectRef,
        status: 'error',
        code: String(response.status),
        message: `خطأ في الاتصال بمشروع Supabase (${response.status})`
      });
    } catch (error: any) {
      return res.status(500).json({
        success: false,
        projectRef: defaultProjectRef,
        status: 'disconnected',
        message: formatSupabaseError(error)
      });
    }
  });

  // --- Supabase Cloud Sync Proxy (Bypasses iframe & mobile CORS/fetch restrictions) ---
  app.post('/api/supabase/push', async (req, res) => {
    const { url: targetUrl, key: targetKey } = getTargetSupabase(req);
    try {
      const payload = req.body;
      const response = await fetch(`${targetUrl}/rest/v1/residence_sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': targetKey,
          'Authorization': `Bearer ${targetKey}`,
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify({
          id: 'main_residence_data',
          data: payload,
          updated_at: new Date().toISOString()
        })
      });
      if (!response.ok) {
        const errText = await response.text();
        if (!errText.includes('PGRST205') && !errText.includes('Could not find the table')) {
          console.warn('Server Supabase push failed:', errText);
        }
        return res.status(response.status).json({ success: false, error: errText });
      }
      return res.json({ success: true });
    } catch (error: any) {
      const formattedErr = formatSupabaseError(error);
      return res.status(500).json({ success: false, error: formattedErr });
    }
  });

  app.get('/api/supabase/pull', async (req, res) => {
    const { url: targetUrl, key: targetKey } = getTargetSupabase(req);
    try {
      const response = await fetch(`${targetUrl}/rest/v1/residence_sync?id=eq.main_residence_data&select=data`, {
        method: 'GET',
        headers: {
          'apikey': targetKey,
          'Authorization': `Bearer ${targetKey}`,
        }
      });
      if (!response.ok) {
        const errText = await response.text();
        return res.status(response.status).json({ success: false, error: errText });
      }
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0 && data[0].data) {
        const payload = data[0].data;
        if (payload && Array.isArray(payload.buildings)) {
          const map = new Map<string, any>();
          payload.buildings.forEach((b: any) => {
            if (b && b.code) map.set(b.code.replace(/\s+/g, ' ').trim().toUpperCase(), b);
          });
          payload.buildings = canonical20Buildings.map(base => {
            const clean = base.code.replace(/\s+/g, ' ').trim().toUpperCase();
            return map.get(clean) || base;
          });
        }
        return res.json({ success: true, data: payload });
      }
      return res.json({ success: true, data: null });
    } catch (error: any) {
      const formattedErr = formatSupabaseError(error);
      return res.status(500).json({ success: false, error: formattedErr });
    }
  });

  app.post('/api/supabase/clear', async (req, res) => {
    const { url: targetUrl, key: targetKey } = getTargetSupabase(req);
    try {
      const response = await fetch(`${targetUrl}/rest/v1/residence_sync?id=eq.main_residence_data`, {
        method: 'DELETE',
        headers: {
          'apikey': targetKey,
          'Authorization': `Bearer ${targetKey}`,
        }
      });
      if (!response.ok) {
        const errText = await response.text();
        return res.status(response.status).json({ success: false, error: errText });
      }
      return res.json({ success: true });
    } catch (error: any) {
      const formattedErr = formatSupabaseError(error);
      return res.status(500).json({ success: false, error: formattedErr });
    }
  });

  app.post('/api/supabase/order', async (req, res) => {
    const { url: targetUrl, key: targetKey } = getTargetSupabase(req);
    try {
      const { customerName, email, details } = req.body;
      const response = await fetch(`${targetUrl}/rest/v1/orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': targetKey,
          'Authorization': `Bearer ${targetKey}`,
          'Prefer': 'return=representation'
        },
        body: JSON.stringify({
          customer_name: customerName,
          email: email,
          details: details
        })
      });
      if (!response.ok) {
        const errText = await response.text();
        return res.status(response.status).json({ success: false, error: errText });
      }
      const data = await response.json();
      return res.json({ success: true, data });
    } catch (error: any) {
      const formattedErr = formatSupabaseError(error);
      return res.status(500).json({ success: false, error: formattedErr });
    }
  });

  const canonical20Buildings = [
    { id: 'b-34a', code: 'GH 34 A', name: 'عمارة GH 34 A', floors: 3, apartments_count: 16, notes: 'المجموعة A (تحتوي على مكتب السانديك بالشقة 01 - RDC)' },
    { id: 'b-35a', code: 'GH 35 A', name: 'عمارة GH 35 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-36a', code: 'GH 36 A', name: 'عمارة GH 36 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-37a', code: 'GH 37 A', name: 'عمارة GH 37 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-38a', code: 'GH 38 A', name: 'عمارة GH 38 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-39a', code: 'GH 39 A', name: 'عمارة GH 39 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-40a', code: 'GH 40 A', name: 'عمارة GH 40 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-41a', code: 'GH 41 A', name: 'عمارة GH 41 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-42a', code: 'GH 42 A', name: 'عمارة GH 42 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-43a', code: 'GH 43 A', name: 'عمارة GH 43 A', floors: 3, apartments_count: 16, notes: 'المجموعة A' },
    { id: 'b-34b', code: 'GH 34 B', name: 'عمارة GH 34 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-35b', code: 'GH 35 B', name: 'عمارة GH 35 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-36b', code: 'GH 36 B', name: 'عمارة GH 36 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-37b', code: 'GH 37 B', name: 'عمارة GH 37 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-38b', code: 'GH 38 B', name: 'عمارة GH 38 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-39b', code: 'GH 39 B', name: 'عمارة GH 39 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-40b', code: 'GH 40 B', name: 'عمارة GH 40 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-41b', code: 'GH 41 B', name: 'عمارة GH 41 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-42b', code: 'GH 42 B', name: 'عمارة GH 42 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
    { id: 'b-43b', code: 'GH 43 B', name: 'عمارة GH 43 B', floors: 3, apartments_count: 16, notes: 'المجموعة B' },
  ];

  // --- Buildings ---
  app.get('/api/buildings', async (req, res) => {
    try {
      const all = await db.select().from(schema.buildings);
      const existingCodes = new Set((all || []).map(b => (b.code || '').replace(/\s+/g, ' ').trim().toUpperCase()));
      
      const missing = canonical20Buildings.filter(b => !existingCodes.has(b.code.toUpperCase()));
      if (missing.length > 0) {
        for (const m of missing) {
          try {
            await db.insert(schema.buildings).values(m).onConflictDoNothing();
          } catch (e) {}
        }
        const updated = await db.select().from(schema.buildings);
        return res.json(updated);
      }
      res.json(all);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/buildings', async (req, res) => {
    try {
      const newItem = await db.insert(schema.buildings).values(req.body).returning();
      res.json(newItem[0]);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Apartments ---
  app.get('/api/apartments', async (req, res) => {
    try {
      const all = await db.select().from(schema.apartments);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/apartments', async (req, res) => {
    try {
      const data = toSnakeCaseKeys(req.body);
      const newItem = await db.insert(schema.apartments).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/apartments/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const data = toSnakeCaseKeys(req.body);
      const updated = await db.update(schema.apartments).set(data).where(eq(schema.apartments.id, id)).returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/apartments/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.apartments).where(eq(schema.apartments.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Residents ---
  app.get('/api/residents', async (req, res) => {
    try {
      const all = await db.select().from(schema.residents);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/residents', async (req, res) => {
    try {
      const data = toSnakeCaseKeys(req.body);
      const newItem = await db.insert(schema.residents).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/residents/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const data = toSnakeCaseKeys(req.body);
      const updated = await db.update(schema.residents).set(data).where(eq(schema.residents.id, id)).returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/residents/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.residents).where(eq(schema.residents.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Payments ---
  app.get('/api/payments', async (req, res) => {
    try {
      const all = await db.select().from(schema.payments);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/payments', async (req, res) => {
    try {
      const raw = req.body || {};
      const data = toSnakeCaseKeys(raw);
      if (!data.id) {
        data.id = 'p-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
      }
      if (!data.receipt_number) {
        data.receipt_number = raw.receiptNumber || `REC-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`;
      }
      if (!data.payment_date) {
        data.payment_date = raw.paymentDate || raw.date || new Date().toISOString().slice(0, 10);
      }
      if (!data.resident_name) {
        data.resident_name = raw.residentName || raw.ownerName || 'مقيم';
      }
      if (!data.building_code) {
        data.building_code = raw.buildingCode || 'GH 34 A';
      }
      if (!data.apartment_number) {
        data.apartment_number = raw.apartmentNumber || '01';
      }
      if (!data.period_month) {
        data.period_month = raw.periodMonth || new Date().toISOString().slice(0, 7);
      }
      if (data.amount === undefined || data.amount === null) {
        data.amount = String(raw.amount || 150);
      } else {
        data.amount = String(data.amount);
      }
      delete data.date;
      delete data.executed_at_time;
      const newItem = await db.insert(schema.payments).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/payments/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const raw = req.body || {};
      const data = toSnakeCaseKeys(raw);
      delete data.date;
      delete data.executed_at_time;
      if (data.amount !== undefined && data.amount !== null) {
        data.amount = String(data.amount);
      }
      const updated = await db
        .update(schema.payments)
        .set(data)
        .where(eq(schema.payments.id, id))
        .returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/payments/:id', async (req, res) => {
    const { id } = req.params;
    try {
      await db.delete(schema.payments).where(eq(schema.payments.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Expenses ---
  app.get('/api/expenses', async (req, res) => {
    try {
      const all = await db.select().from(schema.expenses);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/expenses', async (req, res) => {
    try {
      const raw = req.body || {};
      const data = toSnakeCaseKeys(raw);
      if (!data.id) {
        data.id = 'exp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
      }
      if (!data.date) {
        data.date = raw.date || new Date().toISOString().slice(0, 10);
      }
      if (!data.title) {
        data.title = raw.title || 'مصروف عام';
      }
      if (!data.category) {
        data.category = raw.category || 'maintenance';
      }
      if (data.amount === undefined || data.amount === null) {
        data.amount = String(raw.amount || 0);
      } else {
        data.amount = String(data.amount);
      }
      delete data.executed_at_time;
      const newItem = await db.insert(schema.expenses).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/expenses/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const raw = req.body || {};
      const data = toSnakeCaseKeys(raw);
      delete data.executed_at_time;
      if (data.amount !== undefined && data.amount !== null) {
        data.amount = String(data.amount);
      }
      const updated = await db.update(schema.expenses).set(data).where(eq(schema.expenses.id, id)).returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/expenses/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.expenses).where(eq(schema.expenses.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Employees ---
  app.get('/api/employees', async (req, res) => {
    try {
      const all = await db.select().from(schema.employees);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/employees', async (req, res) => {
    try {
      const raw = req.body || {};
      const data = toSnakeCaseKeys(raw);
      if (!data.id) {
        data.id = 'emp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
      }
      if (!data.name) {
        data.name = raw.name || 'عامل جديد';
      }
      if (!data.role) {
        data.role = raw.role || 'security';
      }
      if (!data.start_date) {
        data.start_date = raw.startDate || new Date().toISOString().slice(0, 10);
      }
      if (data.salary !== undefined && data.salary !== null) {
        data.salary = String(data.salary);
      }
      const newItem = await db.insert(schema.employees).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.put('/api/employees/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const data = toSnakeCaseKeys(req.body);
      const updated = await db.update(schema.employees).set(data).where(eq(schema.employees.id, id)).returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/employees/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.employees).where(eq(schema.employees.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Maintenance Tickets ---
  app.get('/api/maintenance_tickets', async (req, res) => {
    try {
      const all = await db.select().from(schema.maintenance_tickets);
      res.json(toCamelCaseKeys(all));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/maintenance_tickets', async (req, res) => {
    try {
      const data = toSnakeCaseKeys(req.body);
      if (!data.id) {
        data.id = 'ticket-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
      }
      const newItem = await db.insert(schema.maintenance_tickets).values(data).returning();
      res.json(toCamelCaseKeys(newItem[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/maintenance_tickets/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const data = toSnakeCaseKeys(req.body);
      const updated = await db.update(schema.maintenance_tickets).set(data).where(eq(schema.maintenance_tickets.id, id)).returning();
      res.json(toCamelCaseKeys(updated[0]));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/maintenance_tickets/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.maintenance_tickets).where(eq(schema.maintenance_tickets.id, id));
      res.json({ success: true, id });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Notices ---
  app.get('/api/notices', async (req, res) => {
    try {
      const all = await db.select().from(schema.notices);
      res.json(all);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/notices', async (req, res) => {
    try {
      const newItem = await db.insert(schema.notices).values(req.body).returning();
      res.json(newItem[0]);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/notices/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      await db.delete(schema.notices).where(eq(schema.notices.id, id));
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Visitors ---
  app.get('/api/visitors', async (req, res) => {
    try {
      const all = await db.select().from(schema.visitors);
      res.json(all);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/visitors', async (req, res) => {
    try {
      const newItem = await db.insert(schema.visitors).values(req.body).returning();
      res.json(newItem[0]);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/visitors/:id', async (req, res) => {
    const { id } = req.params;
    try {
      const { eq } = await import('drizzle-orm');
      const updated = await db.update(schema.visitors).set(req.body).where(eq(schema.visitors.id, id)).returning();
      res.json(updated[0]);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- Manual Monthly Records (Financial Registry & Historical Months) ---
  let serverManualMonthlyRecords: any[] = [];

  app.get('/api/manual_monthly_records', (req, res) => {
    res.json(serverManualMonthlyRecords);
  });

  app.post('/api/manual_monthly_records', (req, res) => {
    try {
      const records = req.body;
      if (Array.isArray(records)) {
        serverManualMonthlyRecords = records;
      } else if (records && typeof records === 'object' && (records.monthKey || records.month)) {
        const key = records.monthKey || records.month;
        const idx = serverManualMonthlyRecords.findIndex(r => (r.monthKey || r.month) === key);
        if (idx >= 0) {
          serverManualMonthlyRecords[idx] = records;
        } else {
          serverManualMonthlyRecords.push(records);
        }
      }
      res.json({ success: true, count: serverManualMonthlyRecords.length });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/manual_monthly_records/:monthKey', (req, res) => {
    const { monthKey } = req.params;
    serverManualMonthlyRecords = serverManualMonthlyRecords.filter(r => (r.monthKey || r.month) !== monthKey);
    res.json({ success: true, monthKey });
  });

  // Catch unmatched /api routes and ensure they NEVER return HTML fallback
  app.all('/api/*', (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.status(404).json({
      error: `API route not found: ${req.method} ${req.path}`,
      success: false
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
